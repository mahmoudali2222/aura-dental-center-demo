import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { narrowWeekday, weekOrder } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';

/**
 * A department's working days, drawn as seven small day marks (the days it works are filled), with the full sentence for
 * screen readers. The days come straight from the API (the same days the booking calendar offers), never from a built-in list.
 * `text` also prints the sentence for people who read rather than look; it is shown only for a department that does not
 * work every day, so a patient is never left wondering why some dates offer no times.
 */
export function WorkingDays({ days, text = false, centerDays }: { days: number[]; text?: boolean; centerDays?: number[] }) {
  const t = useT();
  const i18n = useI18n();
  if (days.length === 0) return null;
  const worked = new Set(days);
  // the center's own closed weekdays are never open, whatever the department says
  const open = (d: number) => worked.has(d) && (!centerDays || centerDays.includes(d));
  const sorted = [...new Set(days)].filter(open).sort((a, b) => a - b);
  const limited = sorted.length < 7;
  const sentence = t('departments.workingDays', { days: i18n.list(sorted.map((d) => i18n.weekday(d, 'long'))) });
  return (
    <div className="weekstrip" data-limited={limited || undefined}>
      <ul className="weekstrip__days" role="img" aria-label={limited ? sentence : t('departments.worksEveryDay')}>
        {weekOrder(i18n.locale).map((d) => (
          <li key={d} className={open(d) ? 'is-on' : 'is-off'} aria-hidden="true">{narrowWeekday(d, i18n.locale)}</li>
        ))}
      </ul>
      {text && limited ? <p className="weekstrip__text">{sentence}</p> : null}
    </div>
  );
}
