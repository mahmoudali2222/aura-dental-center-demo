import { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import type { DepartmentSummary } from '../../shared/api/types.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { useT } from '../i18n/useT.js';
import { usePrefersReducedMotion } from './HeroMedia.js';
import { ChevronEnd, ChevronStart } from './icons.js';

/**
 * The before/after pictures the center supplied for its departments, one per department, shown exactly as supplied: never cropped,
 * stretched or recoloured (each picture already contains its own Before / After halves and its own caption). They are read from the
 * departments' own picture setting, so replacing a picture in the Admin Dashboard replaces it here. A department without a
 * picture, or whose file is missing, is simply left out.
 */
export function ResultsScroller({ departments }: { departments: DepartmentSummary[] }) {
  const t = useT();
  const { dir } = useI18n();
  const reduced = usePrefersReducedMotion();
  const track = useRef<HTMLUListElement>(null);
  const [missing, setMissing] = useState<Set<string>>(() => new Set());
  const items = departments.filter((d) => d.imagePath && !missing.has(d.id));
  if (items.length === 0) return null;

  // "next" always means towards the end of the line, so the buttons behave the same in both directions
  const move = (towardsEnd: boolean) => {
    const el = track.current;
    if (!el || typeof el.scrollBy !== 'function') return;
    const sign = (towardsEnd ? 1 : -1) * (dir === 'rtl' ? -1 : 1);
    el.scrollBy({ left: sign * el.clientWidth * 0.8, behavior: reduced ? 'auto' : 'smooth' });
  };

  return (
    <section className="section section--tint results" aria-labelledby="results-title">
      <div className="container">
        <div className="section__head">
          <div>
            <h2 id="results-title">{t('home.results.title')}</h2>
            <p className="section__lead">{t('home.results.lead')}</p>
          </div>
          <div className="results__nav">
            <button type="button" className="icon-btn" onClick={() => move(false)} aria-label={t('home.results.prev')}><ChevronStart /></button>
            <button type="button" className="icon-btn" onClick={() => move(true)} aria-label={t('home.results.next')}><ChevronEnd /></button>
          </div>
        </div>
      </div>
      <div className="container results__bleed">
        <ul className="results__track" ref={track} tabIndex={0} aria-label={t('home.results.title')}>
          {items.map((d) => (
            <li key={d.id} className="results__item">
              <Link to={`/departments/${d.slug}`} className="results__link" aria-label={t('departments.exampleAlt', { department: d.name })}>
                <img className="results__img" src={d.imagePath!} alt="" loading="lazy" decoding="async" onError={() => setMissing((s) => new Set(s).add(d.id))} />
                <span className="results__caption">{d.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
