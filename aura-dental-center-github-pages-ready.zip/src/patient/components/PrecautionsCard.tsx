import { AssetImage } from '../../shared/ui/index.js';
import { patientConfig } from '../config.js';
import { useT } from '../i18n/useT.js';

/**
 * The center's "Important patient precautions before the procedure" picture (Arabic and English, supplied by the center), shown
 * exactly as supplied together with its text for anyone who prefers to read it (and for French readers). It sits in the booking
 * flow, on the confirmation and in "My appointments", where a patient is about to visit. It is a reminder, not a gate: nothing
 * about booking depends on it, and the note field still asks patients not to type medical details into the website.
 */
export function PrecautionsCard({ heading = true }: { heading?: boolean }) {
  const t = useT();
  const items = [t('precautions.sugar'), t('precautions.heart'), t('precautions.thinners'), t('precautions.chronic')];
  const { src, width, height } = patientConfig.precautions;
  return (
    <section className="precautions" aria-labelledby={heading ? 'precautions-title' : undefined}>
      {heading ? <h3 id="precautions-title" className="precautions__title">{t('book.before.title')}</h3> : null}
      <p className="precautions__text">{t('book.before.text')}</p>
      <figure className="precautions__figure">
        <AssetImage src={src} width={width} height={height} className="precautions__img" alt={`${t('precautions.title')}. ${items.join(' ')}`} />
      </figure>
      <details className="precautions__details">
        <summary>{t('book.before.readText')}</summary>
        <p className="precautions__subtitle">{t('precautions.title')}</p>
        <ul>{items.map((i) => <li key={i}>{i}</li>)}</ul>
      </details>
    </section>
  );
}
