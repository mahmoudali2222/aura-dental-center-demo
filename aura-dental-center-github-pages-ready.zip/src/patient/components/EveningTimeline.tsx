import type { CenterInfo } from '../../shared/api/types.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { hourLabel } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';

/**
 * The center's evening drawn from its real profile: one block per slot the API reports (normally four two-hour visits between
 * 4 PM and 12 AM), with the opening days underneath. Nothing here is typed in: change the slots or working days in the Admin
 * Dashboard and this follows. The blocks fill in once when the page opens; that is the only animation on the page that runs by itself.
 */
export function EveningTimeline({ center }: { center: CenterInfo | null }) {
  const t = useT();
  const i18n = useI18n();
  if (!center || center.slots.length === 0) return <div className="timeline timeline--pending" aria-hidden="true" />;
  const first = center.slots[0]!;
  const last = center.slots[center.slots.length - 1]!;
  const days = center.workingDays.length === 7 ? t('footer.everyDay') : i18n.list([...center.workingDays].sort((a, b) => a - b).map((d) => i18n.weekday(d, 'long')));
  return (
    <aside className="timeline" aria-labelledby="timeline-title">
      <h2 id="timeline-title" className="timeline__title">{t('home.timeline.title')}</h2>
      <p className="timeline__range tabular">{i18n.range(first.startTime, last.endTime)}</p>
      <ol className="timeline__slots" style={{ gridTemplateColumns: `repeat(${center.slots.length}, minmax(0, 1fr))` }}>
        {center.slots.map((s, i) => (
          <li key={s.slotNumber} className="timeline__slot" style={{ ['--i' as string]: i }}>
            <span className="visually-hidden">{i18n.range(s.startTime, s.endTime)}</span>
            <span className="timeline__block" aria-hidden="true" />
            <span className="timeline__tick tabular" aria-hidden="true">{hourLabel(s.startTime, i18n.locale)}</span>
          </li>
        ))}
      </ol>
      <p className="timeline__note">{days}. {t('home.timeline.note')}</p>
    </aside>
  );
}
