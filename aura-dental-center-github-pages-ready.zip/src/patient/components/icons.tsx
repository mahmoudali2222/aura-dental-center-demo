import type { SVGProps } from 'react';

/** A handful of plain line icons, drawn here so the site needs no icon library. Decorative: always hidden from screen readers. */
type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function Svg({ size = 20, children, ...rest }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" {...rest}>
      {children}
    </svg>
  );
}

/** Points towards the end of a line of text: right in English/French, left in Arabic (the stylesheet mirrors it). */
export const ArrowEnd = (p: IconProps) => <Svg className="icon-dir" {...p}><path d="M5 12h14M13 6l6 6-6 6" /></Svg>;
export const ChevronStart = (p: IconProps) => <Svg className="icon-dir" {...p}><path d="M15 6l-6 6 6 6" /></Svg>;
export const ChevronEnd = (p: IconProps) => <Svg className="icon-dir" {...p}><path d="M9 6l6 6-6 6" /></Svg>;
export const MenuIcon = (p: IconProps) => <Svg {...p}><path d="M4 7h16M4 12h16M4 17h16" /></Svg>;
export const CloseIcon = (p: IconProps) => <Svg {...p}><path d="M6 6l12 12M18 6L6 18" /></Svg>;
export const CheckIcon = (p: IconProps) => <Svg {...p}><path d="M5 12.5l4.5 4.5L19 7.5" /></Svg>;
export const CalendarIcon = (p: IconProps) => <Svg {...p}><rect x="4" y="5.5" width="16" height="14" rx="3" /><path d="M8 3.5v4M16 3.5v4M4 10h16" /></Svg>;
export const ClockIcon = (p: IconProps) => <Svg {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></Svg>;
export const PhoneIcon = (p: IconProps) => <Svg {...p}><path d="M6.5 4h3l1.5 4-2 1.5a11 11 0 0 0 5.5 5.5L16 13l4 1.5v3a2 2 0 0 1-2 2A14 14 0 0 1 4.5 6a2 2 0 0 1 2-2z" /></Svg>;
export const PinIcon = (p: IconProps) => <Svg {...p}><path d="M12 21s6.5-5.6 6.5-11a6.5 6.5 0 0 0-13 0C5.5 15.400 12 21 12 21z" /><circle cx="12" cy="10" r="2.3" /></Svg>;
/** A generic paper plane (not the Telegram logo). */
export const SendIcon = (p: IconProps) => <Svg {...p}><path d="M20.5 4L3.500 11l6 2.500L12 20l2.500-5.500L20.500 4z" /><path d="M9.500 13.500l11-9.500" /></Svg>;
export const UserIcon = (p: IconProps) => <Svg {...p}><circle cx="12" cy="8.500" r="3.500" /><path d="M5 20c.8-3.500 3.500-5.500 7-5.500s6.200 2 7 5.500" /></Svg>;
export const HeartPulseIcon = (p: IconProps) => <Svg {...p}><path d="M12 20s-7.500-4.500-7.500-10A4.300 4.300 0 0 1 12 7.500 4.300 4.300 0 0 1 19.500 10c0 5.500-7.500 10-7.500 10z" /><path d="M7.500 12h2.500l1.200-2 1.600 4 1.200-2h2" /></Svg>;
