import { patientConfig } from '../config.js';
import { useT } from '../i18n/useT.js';
import { SendIcon } from './icons.js';

/**
 * The entry to the center's AI assistant. Telegram is the assistant's channel, so this only links there; the website has no chat
 * of its own. Kept to one quiet row so it never competes with booking.
 */
export function AssistantBand() {
  const t = useT();
  return (
    <section className="container assistant" aria-labelledby="assistant-title">
      <span className="assistant__icon" aria-hidden="true"><SendIcon size={22} /></span>
      <div className="assistant__text">
        <h2 id="assistant-title">{t('telegram.card.title')}</h2>
        <p>{t('telegram.card.text')}</p>
      </div>
      <a className="btn btn--secondary" href={patientConfig.telegram.botUrl} target="_blank" rel="noopener noreferrer">
        {t('telegram.card.open')}<span className="visually-hidden"> ({patientConfig.telegram.handle})</span>
      </a>
    </section>
  );
}
