import { createHttpClient } from '../shared/api/http.js';
import { publicApi } from '../shared/api/public.js';
import { patientApi } from '../shared/api/patient.js';

/** One HTTP client for the whole patient app: it owns the CSRF token and reports lost sessions. */
export const http = createHttpClient();
export const pub = publicApi(http);
export const patientCalls = patientApi(http);
