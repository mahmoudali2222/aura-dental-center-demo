import { Link } from 'react-router-dom';
import { Alert, Button, Loading } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { errorText } from '../../shared/lib/errors.js';
import { pub } from '../api.js';
import { useCenter } from '../app/center.js';
import { useSession } from '../app/session.js';
import { patientConfig } from '../config.js';
import { useT } from '../i18n/useT.js';
import { AssistantBand } from '../components/AssistantBand.js';
import { DepartmentRow } from '../components/DepartmentRow.js';
import { EveningTimeline } from '../components/EveningTimeline.js';
import { HeroMedia } from '../components/HeroMedia.js';
import { NextAppointment } from '../components/NextAppointment.js';
import { ResultsScroller } from '../components/ResultsScroller.js';
import { ArrowEnd } from '../components/icons.js';

export function Home() {
  const t = useT();
  const i18n = useI18n();
  const { center } = useCenter();
  const { status } = useSession();
  const depts = useAsync((signal) => pub.departments(i18n.locale, signal), [i18n.locale]);
  const steps = [
    { title: t('home.how1.title'), text: t('home.how1') },
    { title: t('home.how2.title'), text: t('home.how2') },
    { title: t('home.how3.title'), text: t('home.how3') },
  ];
  return (
    <>
      <section className="hero" aria-labelledby="hero-title">
        <HeroMedia video={patientConfig.heroVideo} />
        <div className="container hero__grid">
          <div className="hero__copy">
            <h1 id="hero-title">{t('home.hero')}</h1>
            <p className="hero__lead">{center?.introduction || t('home.introFallback')}</p>
            <div className="hero__actions">
              <Link to="/book" className="btn btn--lg">{t('home.cta')}</Link>
              <Link to="/departments" className="btn btn--lg btn--ghost">{t('home.ctaSecondary')}</Link>
            </div>
          </div>
          <EveningTimeline center={center} />
        </div>
      </section>

      {status === 'authenticated' ? <NextAppointment /> : null}

      <section className="section container" aria-labelledby="home-departments">
        <div className="section__head">
          <div>
            <h2 id="home-departments">{t('home.departments')}</h2>
            <p className="section__lead">{t('departments.intro')}</p>
          </div>
          <Link to="/departments" className="more-link">{t('home.viewAll')}<ArrowEnd size={18} /></Link>
        </div>
        {depts.status === 'loading' && !depts.data ? <Loading /> : null}
        {depts.status === 'error' && !depts.data ? <Alert tone="error">{errorText(i18n, depts.error)} <Button small variant="secondary" onClick={depts.reload}>{t('common.retry')}</Button></Alert> : null}
        {depts.data ? <ul className="dept-list">{depts.data.map((d) => <DepartmentRow key={d.id} department={d} center={center} />)}</ul> : null}
      </section>

      {depts.data ? <ResultsScroller departments={depts.data} /> : null}

      <section className="section container" aria-labelledby="home-how">
        <h2 id="home-how">{t('home.howTitle')}</h2>
        <ol className="steps">
          {steps.map((s, i) => (
            <li key={s.title} className="steps__item">
              <span className="steps__n tabular" aria-hidden="true">{i + 1}</span>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <AssistantBand />
    </>
  );
}
