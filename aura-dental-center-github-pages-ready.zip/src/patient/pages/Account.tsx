import { useEffect, useState, type FormEvent } from 'react';
import { Alert, Button, SelectField, TextField, Loading } from '../../shared/ui/index.js';
import { errorText, fieldErrors } from '../../shared/lib/errors.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { LOCALES, type Locale } from '../../shared/api/types.js';
import { LOCALE_META } from '../../shared/i18n/types.js';
import { patientCalls } from '../api.js';
import type { LinkToken as LinkTokenAlias } from '../../shared/api/patient.js';
import { useSession } from '../app/session.js';
import { patientConfig } from '../config.js';
import { useT } from '../i18n/useT.js';
import { isolateLtr } from '../../shared/i18n/format.js';

export function Account() {
  const t = useT();
  return (
    <div className="page container">
      <header className="page__head">
        <h1>{t('account.title')}</h1>
        <p>{t('account.lead')}</p>
      </header>
      <div className="account">
        <div className="account__col">
          <ProfileForm />
          <PasswordForm />
        </div>
        <div className="account__col">
          <TelegramSection />
        </div>
      </div>
    </div>
  );
}

function ProfileForm() {
  const t = useT();
  const i18n = useI18n();
  const { user, update } = useSession();
  const [name, setName] = useState(user?.fullName ?? '');
  const [pref, setPref] = useState<string>(user?.preferredLocale ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [saved, setSaved] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null); setSaved(false);
    try {
      const r = await patientCalls.updateProfile({ fullName: name.trim(), preferredLocale: (pref || null) as Locale | null });
      update(r.patient);
      if (pref) i18n.setLocale(pref as Locale);
      setSaved(true);
    } catch (err) { setError(err); } finally { setBusy(false); }
  }
  const f = fieldErrors(i18n, error);
  return (
    <form onSubmit={submit} className="card panel" aria-labelledby="profile-h" noValidate>
      <h2 id="profile-h">{t('account.profile')}</h2>
      {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
      {saved ? <Alert tone="success">{t('account.saved')}</Alert> : null}
      <TextField label={t('auth.fullName')} value={name} onChange={(e) => setName(e.target.value)} error={f.fullName} />
      <TextField label={t('auth.phone')} value={user ? isolateLtr(user.phone) : ''} readOnly dir="ltr" hint={t('account.phone.note')} />
      <SelectField label={t('account.language')} value={pref} onChange={(e) => setPref(e.target.value)}>
        <option value="">{t('account.language.browser')}</option>
        {LOCALES.map((l) => <option key={l} value={l}>{LOCALE_META[l].nativeName}</option>)}
      </SelectField>
      <Button type="submit" loading={busy}>{t('common.save')}</Button>
    </form>
  );
}

function PasswordForm() {
  const t = useT();
  const i18n = useI18n();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [done, setDone] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null); setDone(false);
    try { await patientCalls.changePassword({ currentPassword: current, newPassword: next }); setDone(true); setCurrent(''); setNext(''); }
    catch (err) { setError(err); } finally { setBusy(false); }
  }
  // the backend reports password-policy problems under the field name "password"; they belong to the NEW password field here
  const issues = fieldErrors(i18n, error);
  return (
    <form onSubmit={submit} className="card panel" aria-labelledby="pw-h" noValidate>
      <h2 id="pw-h">{t('account.password.title')}</h2>
      {error ? <Alert tone="error">{errorText(i18n, error, { INVALID_CREDENTIALS: 'account.password.currentWrong' })}</Alert> : null}
      {done ? <Alert tone="success">{t('account.password.changed')}</Alert> : null}
      <TextField label={t('account.password.current')} type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} />
      <TextField label={t('account.password.new')} type="password" autoComplete="new-password" hint={t('auth.password.hint')} value={next} onChange={(e) => setNext(e.target.value)} error={issues.newPassword ?? issues.password} />
      <Button type="submit" loading={busy} disabled={!current || !next}>{t('account.password.submit')}</Button>
    </form>
  );
}

function TelegramSection() {
  const t = useT();
  const i18n = useI18n();
  const status = useAsync((signal) => patientCalls.telegramStatus(signal), []);
  const [token, setToken] = useState<LinkTokenAlias | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [unlinked, setUnlinked] = useState(false);
  // the code is short-lived: stop showing it once it has expired
  useEffect(() => {
    if (!token) return;
    const ms = new Date(token.expiresAt).getTime() - Date.now();
    const id = setTimeout(() => setToken(null), Math.max(0, ms));
    return () => clearTimeout(id);
  }, [token]);

  async function create() {
    setBusy(true); setError(null); setUnlinked(false);
    try { setToken(await patientCalls.createTelegramLinkCode()); } catch (err) { setError(err); } finally { setBusy(false); }
  }
  async function unlink() {
    setBusy(true); setError(null);
    try { await patientCalls.unlinkTelegram(); setUnlinked(true); setToken(null); status.reload(); } catch (err) { setError(err); } finally { setBusy(false); }
  }
  return (
    <section className="card panel panel--telegram" aria-labelledby="tg-h">
      <h2 id="tg-h">{t('account.telegram.title')}</h2>
      <p>{t('account.telegram.text')}</p>
      {status.status === 'loading' && !status.data ? <Loading /> : null}
      {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
      {unlinked ? <Alert tone="success">{t('account.telegram.unlinked')}</Alert> : null}
      {status.data ? <p><strong>{status.data.linked ? t('account.telegram.linked') : t('account.telegram.notLinked')}</strong></p> : null}
      {token ? (
        <Alert tone="info" title={t('account.telegram.code')}>
          <strong className="ltr link-code">{token.code}</strong>
          <p>{t('account.telegram.instructions', { code: token.code, minutes: Math.round(token.ttlSeconds / 60) })}</p>
        </Alert>
      ) : null}
      <div className="panel__actions">
        <Button variant="secondary" onClick={() => void create()} loading={busy}>{t('account.telegram.create')}</Button>
        <a className="btn btn--ghost" href={patientConfig.telegram.botUrl} target="_blank" rel="noopener noreferrer">
          {t('telegram.card.open')}<span className="visually-hidden"> ({patientConfig.telegram.handle})</span>
        </a>
        {status.data?.linked ? <Button variant="ghost" onClick={() => void unlink()} disabled={busy}>{t('account.telegram.unlink')}</Button> : null}
      </div>
    </section>
  );
}
