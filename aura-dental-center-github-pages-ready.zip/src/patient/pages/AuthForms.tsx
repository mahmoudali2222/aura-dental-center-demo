import { useState, type FormEvent } from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom';
import { Alert, Button, TextField } from '../../shared/ui/index.js';
import { errorText, fieldErrors } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { patientCalls } from '../api.js';
import { useSession } from '../app/session.js';
import { useT } from '../i18n/useT.js';

interface FromState { from?: string; needsLogin?: boolean }

function useAfterAuth() {
  const state = (useLocation().state ?? {}) as FromState;
  // only same-site paths are honoured as a return address
  const target = state.from && state.from.startsWith('/') && !state.from.startsWith('//') ? state.from : '/appointments';
  return { target, needsLogin: !!state.needsLogin };
}

export function Login() {
  const t = useT();
  const i18n = useI18n();
  const { status, login, expired } = useSession();
  const { target, needsLogin } = useAfterAuth();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  // Signing in flips the session to 'authenticated'; this redirect is the one place that sends the visitor onward (back to where they came from).
  if (status === 'authenticated') return <Navigate to={target} replace />;

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try { await login({ phone: phone.trim(), password }); }
    catch (err) { setError(err); }
    finally { setBusy(false); }
  }
  const fields = fieldErrors(i18n, error);
  return (
    <div className="page container auth">
    <form onSubmit={submit} className="auth__card" noValidate>
      <h1>{t('auth.login.title')}</h1>
      <p className="auth__lead">{t('auth.login.lead')}</p>
      {expired ? <Alert tone="warning">{t('auth.sessionExpired')}</Alert> : null}
      {needsLogin ? <Alert tone="info">{t('auth.signInToContinue')}</Alert> : null}
      {error && Object.keys(fields).length === 0 ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
      <TextField label={t('auth.phone')} name="phone" type="tel" inputMode="tel" autoComplete="tel" dir="ltr" required value={phone} onChange={(e) => setPhone(e.target.value)} error={fields.phone} />
      <TextField label={t('auth.password')} name="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} error={fields.password} />
      <Button type="submit" loading={busy} disabled={!phone || !password} className="btn--lg btn--block">{t('auth.login.submit')}</Button>
      <p className="auth__note muted">{t('auth.recovery')}</p>
      <p className="auth__alt">{t('auth.login.noAccount')} <Link to="/register" state={useLocation().state}>{t('nav.register')}</Link></p>
    </form>
    </div>
  );
}

export function Register() {
  const t = useT();
  const i18n = useI18n();
  const { status, adopt } = useSession();
  const { target } = useAfterAuth();
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  // Signing in flips the session to 'authenticated'; this redirect is the one place that sends the visitor onward (back to where they came from).
  if (status === 'authenticated') return <Navigate to={target} replace />;

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const r = await patientCalls.register({ fullName: fullName.trim(), phone: phone.trim(), password, locale: i18n.locale });
      adopt({ user: r.patient, csrfToken: r.csrfToken });
    } catch (err) { setError(err); }
    finally { setBusy(false); }
  }
  const fields = fieldErrors(i18n, error);
  return (
    <div className="page container auth">
    <form onSubmit={submit} className="auth__card" noValidate>
      <h1>{t('auth.register.title')}</h1>
      <p className="auth__lead">{t('auth.register.lead')}</p>
      {error && Object.keys(fields).length === 0 ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
      <TextField label={t('auth.fullName')} name="fullName" autoComplete="name" required value={fullName} onChange={(e) => setFullName(e.target.value)} error={fields.fullName} />
      <TextField label={t('auth.phone')} name="phone" type="tel" inputMode="tel" autoComplete="tel" dir="ltr" required hint={t('auth.phone.hint')} value={phone} onChange={(e) => setPhone(e.target.value)} error={fields.phone} />
      <TextField label={t('auth.password')} name="password" type="password" autoComplete="new-password" required minLength={8} hint={t('auth.password.hint')} value={password} onChange={(e) => setPassword(e.target.value)} error={fields.password} />
      <Button type="submit" loading={busy} disabled={!fullName || !phone || !password} className="btn--lg btn--block">{t('auth.register.submit')}</Button>
      <p className="auth__alt">{t('auth.register.haveAccount')} <Link to="/login" state={useLocation().state}>{t('nav.login')}</Link></p>
    </form>
    </div>
  );
}
