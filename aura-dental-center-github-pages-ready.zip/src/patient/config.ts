/**
 * Settings of the patient website that are not data from the backend.
 *
 * Everything the center can change (name, address, phone, hours, departments, working days, dentists, prices) comes from the API and
 * is edited in the Admin Dashboard; none of it is written here. This file holds only the few things that belong to the website itself.
 */

export interface LogoConfig {
  /** Site-relative path of the official logo, e.g. '/assets/branding/logo.svg'. */
  src: string;
  /** True when the picture already contains the center's name: the name is then kept for screen readers only. */
  includesName: boolean;
}

export interface HeroVideoConfig {
  /** Site-relative path, e.g. '/assets/branding/hero.mp4'. */
  src: string;
  /** Still picture shown before the video plays and when the visitor prefers reduced motion, e.g. '/assets/branding/hero-poster.jpg'. */
  poster?: string;
}

export interface PatientConfig {
  telegram: { botUrl: string; handle: string };
  logo: LogoConfig | null;
  heroVideo: HeroVideoConfig | null;
  /** The patient-precautions picture supplied by the center (Arabic and English text inside the picture). */
  precautions: { src: string; width: number; height: number };
}

export const patientConfig: PatientConfig = {
  /** The center's AI assistant. Telegram is its channel: the website only links to it, there is no chat window here. */
  telegram: { botUrl: 'https://t.me/drAliclinic2_bot', handle: '@drAliclinic2_bot' },

  /**
   * OFFICIAL LOGO: not supplied yet, so nothing is shown. The header and footer already reserve its place (see BrandMark.tsx):
   * when the file is added, set e.g. { src: '/assets/branding/logo.svg', includesName: true } here and nothing else changes.
   */
  logo: null,

  /**
   * HERO BACKGROUND VIDEO: not supplied yet, so the hero shows its plain background. The hero already has a media layer
   * (see HeroMedia.tsx): when the file is added, set e.g. { src: '/assets/branding/hero.mp4', poster: '/assets/branding/hero-poster.jpg' }.
   */
  heroVideo: null,

  precautions: { src: '/assets/info/patient-precautions.jpg', width: 1048, height: 1008 },
};
