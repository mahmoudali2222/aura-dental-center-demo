import { LOCALES, type Locale } from '../../shared/api/types.js';
import type { Translations } from '../api/types.js';

/** Form state for "one set of fields per language". */
export type TrForm = Record<Locale, Record<string, string>>;

export function emptyTrForm(keys: readonly string[]): TrForm {
  const out = {} as TrForm;
  for (const l of LOCALES) out[l] = Object.fromEntries(keys.map((k) => [k, '']));
  return out;
}

export function trToForm(tr: Translations<Record<string, string>> | undefined, keys: readonly string[]): TrForm {
  const out = emptyTrForm(keys);
  for (const l of LOCALES) for (const k of keys) out[l][k] = tr?.[l]?.[k] ?? '';
  return out;
}

/**
 * What to send to the backend. A language that was never filled in and is still empty is left out. A language that exists
 * and whose first (mandatory) field is now empty is sent with an empty value, which the backend reads as "remove this
 * language". Everything else is sent in full.
 */
export function trToPayload(form: TrForm, keys: readonly string[], existing?: Translations<Record<string, string>>): Translations<Record<string, string>> {
  const out: Translations<Record<string, string>> = {};
  for (const l of LOCALES) {
    const values = Object.fromEntries(keys.map((k) => [k, (form[l][k] ?? '').trim()]));
    const anyFilled = keys.some((k) => values[k] !== '');
    if (!anyFilled && !existing?.[l]) continue;
    out[l] = values;
  }
  return out;
}

/** How many languages have the first field filled in (the backend needs at least one). */
export function filledLanguages(form: TrForm, primaryKey: string): Locale[] {
  return LOCALES.filter((l) => (form[l][primaryKey] ?? '').trim() !== '');
}
