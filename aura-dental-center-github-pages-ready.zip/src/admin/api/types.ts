import type { Appointment, Locale } from '../../shared/api/types.js';

/** Shapes returned by the admin endpoints (see docs/API_REFERENCE.md). */
export type Translations<T> = Partial<Record<Locale, T>>;

export interface AdminAppointment extends Appointment {
  patient: { id: string; fullName: string; phone: string };
  cancelReason: string | null;
}

export interface DashboardData {
  date: string;
  timezone: string;
  counts: { booked: number; completed: number; no_show: number; cancelled: number };
  appointments: AdminAppointment[];
  departments: { id: string; slug: string; name: string; activeToday: number; capacity: number }[];
  next7Days: { date: string; booked: number }[];
}

export interface AdminPatient {
  id: string;
  phone: string;
  fullName: string;
  preferredLocale: Locale | null;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  /** Only on the single-patient endpoint. */
  telegramLinked?: boolean;
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  appointmentId: string | null;
  medicalHistory: string;
  allergies: string;
  diagnosis: string;
  treatment: string;
  notes: string;
  createdBy: { id: string; username: string };
  updatedBy: { id: string; username: string };
  createdAt: string;
  updatedAt: string;
}
export type MedicalRecordInput = Partial<Pick<MedicalRecord, 'medicalHistory' | 'allergies' | 'diagnosis' | 'treatment' | 'notes'>> & { appointmentId?: string | null };

export interface AdminDentist {
  id: string;
  departmentId: string;
  photoPath: string | null;
  isActive: boolean;
  isSample: boolean;
  translations: Translations<{ name: string; bio: string }>;
}

export interface AdminDepartment {
  id: string;
  slug: string;
  displayOrder: number;
  isActive: boolean;
  imagePath: string | null;
  /** ISO weekdays (1 = Monday ... 7 = Sunday) on which patients can book this department; sorted, at least one. */
  workingDays: number[];
  translations: Translations<{ name: string; description: string }>;
  dentist: { id: string; photoPath: string | null; isSample: boolean; translations: Translations<{ name: string; bio: string }> } | null;
  serviceCount: number;
  bookable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AdminService {
  id: string;
  departmentId: string;
  price: number | null;
  displayOrder: number;
  isActive: boolean;
  isSample: boolean;
  imagePath: string | null;
  translations: Translations<{ name: string; description: string }>;
}

export interface AdminGalleryCase {
  id: string;
  departmentId: string;
  departmentSlug: string;
  serviceId: string | null;
  beforeImagePath: string;
  afterImagePath: string;
  caseKind: 'real' | 'sample';
  consentConfirmed: boolean;
  isPublished: boolean;
  displayOrder: number;
  translations: Translations<{ title: string; description: string; altBefore: string; altAfter: string }>;
}

export interface CenterSettings {
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  mapUrl: string | null;
  defaultLocale: Locale;
  currency: string;
  bookingHorizonDays: number;
  workingDays: number[];
  timezone: string;
  translations: Translations<{ name: string; address: string; introduction: string; hoursNote: string }>;
}

export interface AdminSlot { slotNumber: number; startTime: string; endTime: string; endsNextDay: boolean; isActive: boolean }

export interface Closure { id: string; dateFrom: string; dateTo: string; departmentId: string | null; reason: string }

export interface AuditEvent {
  id: string;
  occurredAt: string;
  actorType: 'admin' | 'patient' | 'integration' | 'system' | 'anonymous';
  actorId: string | null;
  action: string;
  entityType: string | null;
  entityId: string | null;
  outcome: 'success' | 'failure' | 'denied';
  metadata: Record<string, unknown>;
  ip: string | null;
}
