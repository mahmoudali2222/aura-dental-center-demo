import { createHttpClient, type PageMeta } from '../../shared/api/http.js';
import { adminAuthApi } from '../../shared/api/admin.js';
import { publicApi } from '../../shared/api/public.js';
import type { Locale } from '../../shared/api/types.js';
import type {
  AdminAppointment, AdminDentist, AdminDepartment, AdminGalleryCase, AdminPatient, AdminService, AdminSlot, AuditEvent, CenterSettings, Closure,
  DashboardData, MedicalRecord, MedicalRecordInput, Translations,
} from './types.js';

/** One HTTP client for the whole dashboard: it owns the CSRF token and reports lost sessions. */
export const http = createHttpClient();
export const auth = adminAuthApi(http);
export const pub = publicApi(http);

type Page<T> = Promise<{ data: T[]; meta: PageMeta }>;

export interface AppointmentFilters {
  from?: string; to?: string; departmentId?: string; patientId?: string; status?: string; q?: string; sort?: 'asc' | 'desc';
}

/** Every admin call in one place. Pages never build URLs themselves. Authorization is the backend's job. */
export const admin = {
  dashboard: (locale: Locale, signal?: AbortSignal) => http.get<DashboardData>('/admin/dashboard', { query: { locale }, signal }),

  appointments: {
    list: (f: AppointmentFilters, locale: Locale, page = 1, pageSize = 25, signal?: AbortSignal): Page<AdminAppointment> =>
      http.getPaged<AdminAppointment>('/admin/appointments', { query: { ...f, locale, page, pageSize }, signal }),
    get: (id: string, locale: Locale, signal?: AbortSignal) => http.get<AdminAppointment>(`/admin/appointments/${encodeURIComponent(id)}`, { query: { locale }, signal }),
    create: (input: { patientId: string; departmentId: string; serviceId?: string | null; date: string; slotNumber: number; patientNote?: string }, locale: Locale) =>
      http.post<AdminAppointment>('/admin/appointments', input, { query: { locale } }),
    cancel: (id: string, input: { reason?: string; override?: boolean }, locale: Locale) =>
      http.post<AdminAppointment>(`/admin/appointments/${encodeURIComponent(id)}/cancel`, input, { query: { locale } }),
    reschedule: (id: string, input: { date: string; slotNumber: number; reason?: string; override?: boolean }, locale: Locale) =>
      http.post<AdminAppointment>(`/admin/appointments/${encodeURIComponent(id)}/reschedule`, input, { query: { locale } }),
    setStatus: (id: string, status: 'completed' | 'no_show', locale: Locale) =>
      http.post<AdminAppointment>(`/admin/appointments/${encodeURIComponent(id)}/status`, { status }, { query: { locale } }),
  },

  patients: {
    list: (q: { q?: string; active?: 'true' | 'false' }, page = 1, pageSize = 25, signal?: AbortSignal): Page<AdminPatient> =>
      http.getPaged<AdminPatient>('/admin/patients', { query: { ...q, page, pageSize }, signal }),
    get: (id: string, signal?: AbortSignal) => http.get<AdminPatient>(`/admin/patients/${encodeURIComponent(id)}`, { signal }),
    create: (input: { fullName: string; phone: string; password: string; preferredLocale?: Locale }) => http.post<AdminPatient>('/admin/patients', input),
    update: (id: string, input: { fullName?: string; phone?: string; preferredLocale?: Locale | null; isActive?: boolean }) =>
      http.patch<AdminPatient>(`/admin/patients/${encodeURIComponent(id)}`, input),
    resetPassword: (id: string, input: { newPassword: string; identityVerified: boolean }) => http.post(`/admin/patients/${encodeURIComponent(id)}/reset-password`, input),
    revokeTelegram: (id: string) => http.post(`/admin/patients/${encodeURIComponent(id)}/telegram/revoke`),
  },

  medicalRecords: {
    list: (patientId: string, signal?: AbortSignal) => http.get<MedicalRecord[]>(`/admin/patients/${encodeURIComponent(patientId)}/medical-records`, { signal }),
    create: (patientId: string, input: MedicalRecordInput) => http.post<MedicalRecord>(`/admin/patients/${encodeURIComponent(patientId)}/medical-records`, input),
    update: (id: string, input: MedicalRecordInput) => http.patch<MedicalRecord>(`/admin/medical-records/${encodeURIComponent(id)}`, input),
  },

  departments: {
    list: (signal?: AbortSignal) => http.get<AdminDepartment[]>('/admin/departments', { signal }),
    create: (input: { slug: string; displayOrder?: number; isActive?: boolean; imagePath?: string | null; workingDays?: number[]; translations: Translations<{ name?: string; description?: string }> }) =>
      http.post<AdminDepartment>('/admin/departments', input),
    update: (id: string, input: { slug?: string; displayOrder?: number; isActive?: boolean; imagePath?: string | null; workingDays?: number[]; acknowledgeExistingAppointments?: boolean; translations?: Translations<{ name?: string; description?: string }> }) =>
      http.patch<AdminDepartment>(`/admin/departments/${encodeURIComponent(id)}`, input),
  },

  dentists: {
    list: (departmentId?: string, signal?: AbortSignal) => http.get<AdminDentist[]>('/admin/dentists', { query: { departmentId }, signal }),
    create: (input: { departmentId: string; replaceExisting?: boolean; photoPath?: string | null; translations: Translations<{ name?: string; bio?: string }> }) =>
      http.post<AdminDentist>('/admin/dentists', input),
    update: (id: string, input: { photoPath?: string | null; isActive?: boolean; translations?: Translations<{ name?: string; bio?: string }> }) =>
      http.patch<AdminDentist>(`/admin/dentists/${encodeURIComponent(id)}`, input),
  },

  services: {
    list: (departmentId?: string, signal?: AbortSignal) => http.get<AdminService[]>('/admin/services', { query: { departmentId }, signal }),
    create: (input: { departmentId: string; price?: number | null; displayOrder?: number; isActive?: boolean; imagePath?: string | null; translations: Translations<{ name?: string; description?: string }> }) =>
      http.post<AdminService>('/admin/services', input),
    update: (id: string, input: { departmentId?: string; price?: number | null; displayOrder?: number; isActive?: boolean; imagePath?: string | null; translations?: Translations<{ name?: string; description?: string }> }) =>
      http.patch<AdminService>(`/admin/services/${encodeURIComponent(id)}`, input),
  },

  gallery: {
    list: (signal?: AbortSignal) => http.get<AdminGalleryCase[]>('/admin/gallery', { signal }),
    create: (input: GalleryWrite & { departmentId: string; beforeImagePath: string; afterImagePath: string }) => http.post<AdminGalleryCase>('/admin/gallery', input),
    update: (id: string, input: GalleryWrite & { departmentId?: string; beforeImagePath?: string; afterImagePath?: string }) => http.patch<AdminGalleryCase>(`/admin/gallery/${encodeURIComponent(id)}`, input),
    remove: (id: string) => http.del(`/admin/gallery/${encodeURIComponent(id)}`),
  },

  settings: {
    center: (signal?: AbortSignal) => http.get<CenterSettings>('/admin/settings/center', { signal }),
    saveCenter: (input: Partial<Omit<CenterSettings, 'timezone' | 'translations'>> & { translations?: Translations<Partial<{ name: string; address: string; introduction: string; hoursNote: string }>> }) =>
      http.put<CenterSettings>('/admin/settings/center', input),
    slots: (signal?: AbortSignal) => http.get<AdminSlot[]>('/admin/settings/slots', { signal }),
    setSlot: (slotNumber: number, isActive: boolean) => http.patch<AdminSlot[]>(`/admin/settings/slots/${slotNumber}`, { isActive }),
    closures: (range: { from?: string; to?: string } = {}, signal?: AbortSignal) => http.get<Closure[]>('/admin/closures', { query: range, signal }),
    createClosure: (input: { dateFrom: string; dateTo: string; departmentId?: string | null; reason?: string; acknowledgeExistingAppointments?: boolean }) => http.post<Closure>('/admin/closures', input),
    removeClosure: (id: string) => http.del(`/admin/closures/${encodeURIComponent(id)}`),
  },

  audit: {
    list: (f: { action?: string; entityType?: string; entityId?: string; actorId?: string; outcome?: string; from?: string; to?: string }, page = 1, pageSize = 50, signal?: AbortSignal): Page<AuditEvent> =>
      http.getPaged<AuditEvent>('/admin/audit-events', { query: { ...f, page, pageSize }, signal }),
  },
};

interface GalleryWrite {
  serviceId?: string | null;
  caseKind?: 'real' | 'sample';
  consentConfirmed?: boolean;
  isPublished?: boolean;
  displayOrder?: number;
  translations?: Translations<Partial<{ title: string; description: string; altBefore: string; altAfter: string }>>;
}
