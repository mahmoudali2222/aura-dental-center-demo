import { Navigate, Route, Routes } from 'react-router-dom';
import { AdminLayout } from './components/AdminLayout.js';
import { RequireAdmin } from './components/RequireAdmin.js';
import { Login } from './pages/Login.js';
import { ChangePassword } from './pages/ChangePassword.js';
import { Dashboard } from './pages/Dashboard.js';
import { Appointments } from './pages/Appointments.js';
import { Patients } from './pages/Patients.js';
import { PatientDetail } from './pages/PatientDetail.js';
import { Departments } from './pages/Departments.js';
import { Services } from './pages/Services.js';
import { Gallery } from './pages/Gallery.js';
import { Settings } from './pages/Settings.js';
import { Audit } from './pages/Audit.js';

/** Routes are relative to the router's basename ("/admin" in production). */
export function AdminRoutes() {
  return (
    <Routes>
      <Route path="login" element={<Login />} />
      <Route element={<RequireAdmin><AdminLayout /></RequireAdmin>}>
        <Route index element={<Dashboard />} />
        <Route path="change-password" element={<ChangePassword />} />
        <Route path="appointments" element={<Appointments />} />
        <Route path="patients" element={<Patients />} />
        <Route path="patients/:id" element={<PatientDetail />} />
        <Route path="departments" element={<Departments />} />
        <Route path="services" element={<Services />} />
        <Route path="gallery" element={<Gallery />} />
        <Route path="settings" element={<Settings />} />
        <Route path="audit" element={<Audit />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
