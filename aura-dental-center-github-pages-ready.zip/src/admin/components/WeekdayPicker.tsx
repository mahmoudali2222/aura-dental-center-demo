import { useI18n } from '../../shared/i18n/I18nProvider.js';

/** ISO weekdays, Monday first (1 = Monday ... 7 = Sunday), exactly what the API stores. */
export const WEEK = [1, 2, 3, 4, 5, 6, 7];

/** The days as the API wants them: sorted, no duplicates. */
export const normalizeDays = (days: readonly number[]): number[] => [...new Set(days)].sort((a, b) => a - b);
export const sameDays = (a: readonly number[], b: readonly number[]): boolean => {
  const x = normalizeDays(a); const y = normalizeDays(b);
  return x.length === y.length && x.every((v, i) => v === y[i]);
};

/**
 * Seven checkboxes, one per weekday, named in the language of the page. At least one day must stay ticked; the picker only
 * reports the choice, the caller decides what an empty choice means (it shows `error`).
 */
export function WeekdayPicker({ legend, hint, value, onChange, error }: { legend: string; hint?: string; value: number[]; onChange: (days: number[]) => void; error?: string | undefined }) {
  const i18n = useI18n();
  const toggle = (day: number, on: boolean) => onChange(normalizeDays(on ? [...value, day] : value.filter((d) => d !== day)));
  return (
    <fieldset className="stack">
      <legend>{legend}</legend>
      {hint ? <p className="muted" style={{ margin: 0 }}>{hint}</p> : null}
      <div className="row">
        {WEEK.map((d) => (
          <label key={d} className="check"><input type="checkbox" checked={value.includes(d)} onChange={(e) => toggle(d, e.target.checked)} /><span>{i18n.weekday(d, 'long')}</span></label>
        ))}
      </div>
      {error ? <span className="field__error">{error}</span> : null}
    </fieldset>
  );
}
