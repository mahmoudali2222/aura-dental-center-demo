import { NavLink, Outlet, Link } from 'react-router-dom';
import { Button, LanguageSwitcher } from '../../shared/ui/index.js';
import { useSession } from '../app/session.js';
import { useT } from '../i18n/useT.js';

/** Header + side navigation around every dashboard page. While the first password change is pending only sign-out is offered. */
export function AdminLayout() {
  const t = useT();
  const { user, logout } = useSession();
  const forced = !!user?.mustChangePassword;
  return (
    <div className="admin-shell">
      <a className="skip-link" href="#main">{t('common.skipToContent')}</a>
      <header className="admin-header">
        <strong className="admin-brand">{t('admin.title')}</strong>
        <div className="row">
          {user ? <span className="muted">{t('admin.signedInAs', { name: user.fullName || user.username })}</span> : null}
          {!forced ? <Link to="/change-password">{t('admin.changePassword')}</Link> : null}
          <LanguageSwitcher />
          <Button small variant="ghost" onClick={() => void logout()}>{t('admin.logout')}</Button>
        </div>
      </header>
      {!forced ? (
        <nav className="admin-nav" aria-label={t('admin.nav.main')}>
          <NavLink to="/" end>{t('admin.nav.dashboard')}</NavLink>
          <NavLink to="/appointments">{t('admin.nav.appointments')}</NavLink>
          <NavLink to="/patients">{t('admin.nav.patients')}</NavLink>
          <NavLink to="/departments">{t('admin.nav.departments')}</NavLink>
          <NavLink to="/services">{t('admin.nav.services')}</NavLink>
          <NavLink to="/gallery">{t('admin.nav.gallery')}</NavLink>
          <NavLink to="/settings">{t('admin.nav.settings')}</NavLink>
          <NavLink to="/audit">{t('admin.nav.audit')}</NavLink>
        </nav>
      ) : null}
      <main id="main" tabIndex={-1} className="admin-main">
        <Outlet />
      </main>
    </div>
  );
}
