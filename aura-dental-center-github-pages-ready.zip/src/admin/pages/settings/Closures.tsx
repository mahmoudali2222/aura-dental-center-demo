import { useState } from 'react';
import { Alert, Button, EmptyState, Loading } from '../../../shared/ui/index.js';
import { useAsync } from '../../../shared/lib/useAsync.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { Closure } from '../../api/types.js';
import { ConfirmDialog } from '../../components/ConfirmDialog.js';
import { CENTER_ZONE, todayInZone } from '../../lib/dates.js';
import { useAction } from '../../lib/useAction.js';
import { useT } from '../../i18n/useT.js';
import { pickName } from '../catalog/shared.js';
import { ClosureDialog } from './ClosureDialog.js';

export function Closures() {
  const t = useT();
  const i18n = useI18n();
  const today = todayInZone(CENTER_ZONE);
  const [showPast, setShowPast] = useState(false);
  const list = useAsync((signal) => admin.settings.closures(showPast ? {} : { from: today }, signal), [showPast, today]);
  const depts = useAsync((signal) => admin.departments.list(signal), []);
  const [notice, setNotice] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [reopening, setReopening] = useState<Closure | null>(null);
  const remove = useAction((id: string) => admin.settings.removeClosure(id));
  const departments = depts.data ?? [];

  const dates = (c: Closure) => (c.dateFrom === c.dateTo ? i18n.date(c.dateFrom, 'long') : t('clo.dates.range', { from: i18n.date(c.dateFrom, 'long'), to: i18n.date(c.dateTo, 'long') }));
  const scope = (c: Closure) => {
    if (!c.departmentId) return t('clo.scope.all');
    const d = departments.find((x) => x.id === c.departmentId);
    return d ? pickName(d.translations, i18n.locale, d.slug) : '';
  };
  const rows = list.data ?? [];

  return (
    <section className="stack card" aria-labelledby="closures-title">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2 id="closures-title" style={{ margin: 0 }}>{t('clo.title')}</h2>
        <Button onClick={() => { setNotice(null); setAdding(true); }}>{t('clo.add')}</Button>
      </div>
      <p className="muted" style={{ margin: 0 }}>{t('clo.intro')}</p>
      <label className="check"><input type="checkbox" checked={showPast} onChange={(e) => setShowPast(e.target.checked)} /><span>{t('clo.showPast')}</span></label>
      {notice ? <Alert tone="success">{notice}</Alert> : null}
      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data && rows.length === 0 ? <EmptyState>{t('clo.empty')}</EmptyState> : null}
      {rows.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">{t('clo.col.dates')}</th><th scope="col">{t('clo.col.scope')}</th><th scope="col">{t('clo.col.reason')}</th><th scope="col">{t('admin.col.actions')}</th></tr></thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id}>
                  <td>{dates(c)}</td>
                  <td>{scope(c)}</td>
                  <td>{c.reason || <span className="muted">{t('common.none')}</span>}</td>
                  <td><Button small variant="secondary" aria-label={t('clo.reopenAria', { dates: dates(c) })} onClick={() => { setNotice(null); remove.reset(); setReopening(c); }}>{t('clo.reopen')}</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      <ClosureDialog open={adding} today={today} departments={departments} onClose={() => setAdding(false)} onSaved={(m) => { setNotice(m); list.reload(); }} />
      {reopening ? (
        <ConfirmDialog open title={t('clo.reopen.title')} confirmLabel={t('clo.reopen.confirm')} busy={remove.busy} error={remove.error}
          onClose={() => { remove.reset(); setReopening(null); }}
          onConfirm={async () => { if (await remove.attempt(reopening.id)) { setNotice(t('clo.reopened')); setReopening(null); list.reload(); } }}>
          <p>{t('clo.reopen.text', { dates: dates(reopening) })}</p>
        </ConfirmDialog>
      ) : null}
    </section>
  );
}
