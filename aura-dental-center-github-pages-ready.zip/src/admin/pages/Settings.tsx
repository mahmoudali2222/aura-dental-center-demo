import { useState } from 'react';
import { Alert, Button, Loading } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin } from '../api/index.js';
import type { CenterSettings } from '../api/types.js';
import { useT } from '../i18n/useT.js';
import { Closures } from './settings/Closures.js';
import { ProfileForm } from './settings/ProfileForm.js';
import { SlotsCard } from './settings/SlotsCard.js';

export function Settings() {
  const t = useT();
  const i18n = useI18n();
  const center = useAsync((signal) => admin.settings.center(signal), []);
  // What the backend answered to the last save becomes the form's new starting point (the form is re-created from it).
  const [saved, setSaved] = useState<{ version: number; center: CenterSettings } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const current = saved?.center ?? center.data;

  return (
    <div className="stack">
      <h1 style={{ margin: 0 }}>{t('set.title')}</h1>
      <p className="muted" style={{ margin: 0 }}>{t('set.intro')}</p>
      {center.status === 'loading' && !center.data ? <Loading /> : null}
      {center.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, center.error)} <Button small variant="secondary" onClick={center.reload}>{t('common.retry')}</Button></Alert> : null}
      {current ? (
        <section className="stack card" aria-label={t('set.title')}>
          <p className="muted" style={{ margin: 0 }}>{t('set.timezone', { zone: current.timezone })}</p>
          {notice ? <Alert tone="success">{notice}</Alert> : null}
          <ProfileForm key={saved?.version ?? 0} center={current} onSaved={(next) => { setSaved({ version: (saved?.version ?? 0) + 1, center: next }); setNotice(t('set.saved')); }} />
        </section>
      ) : null}
      <SlotsCard />
      <Closures />
    </div>
  );
}
