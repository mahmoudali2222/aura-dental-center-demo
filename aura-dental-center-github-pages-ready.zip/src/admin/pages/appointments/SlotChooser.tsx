import { useEffect, useMemo, useState } from 'react';
import { Alert, Button, Loading } from '../../../shared/ui/index.js';
import { useAsync } from '../../../shared/lib/useAsync.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { pub } from '../../api/index.js';
import { useT } from '../../i18n/useT.js';

export interface SlotChoice { date: string; slotNumber: number; startTime: string; endTime: string; endsNextDay: boolean }

/**
 * Day + time chooser fed by the public availability endpoint, which lists only genuinely bookable slots (the booking
 * transaction applies the same rules again, so a stale choice is refused, never double-booked). `refreshKey` forces a reload.
 */
export function SlotChooser({ slug, value, onChange, refreshKey = 0, notice }: {
  slug: string; value: SlotChoice | null; onChange: (c: SlotChoice | null) => void; refreshKey?: number; notice?: boolean;
}) {
  const t = useT();
  const i18n = useI18n();
  const state = useAsync((signal) => pub.availability(slug, {}, signal), [slug, refreshKey]);
  const [day, setDay] = useState<string | null>(value?.date ?? null);
  const days = useMemo(() => (state.data?.days ?? []).filter((d) => d.status === 'open'), [state.data]);

  // keep the selection valid when availability changes under the user's feet
  useEffect(() => {
    if (!state.data) return;
    if (day && !days.some((d) => d.date === day)) { setDay(null); onChange(null); }
    else if (value && !days.some((d) => d.date === value.date && d.slots.some((s) => s.slotNumber === value.slotNumber))) onChange(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.data]);

  if (state.status === 'loading' && !state.data) return <Loading />;
  if (state.status === 'error' && !state.data) {
    return <Alert tone="error">{t('appts.slot.loadFailed')} {errorText(i18n, state.error)} <Button small variant="secondary" onClick={state.reload}>{t('common.retry')}</Button></Alert>;
  }
  if (days.length === 0) return <Alert tone="info">{t('appts.slot.noDays')}</Alert>;

  const selectedDay = days.find((d) => d.date === day);
  return (
    <div className="stack">
      {notice ? <Alert tone="warning">{t('appts.slot.refreshed')}</Alert> : null}
      <fieldset>
        <legend>{t('appts.slot.chooseDay')}</legend>
        <div className="row" role="radiogroup" aria-label={t('appts.slot.dayGroup')}>
          {days.map((d) => (
            <label key={d.date} className="card" style={{ cursor: 'pointer', borderColor: day === d.date ? 'var(--color-accent)' : undefined }}>
              <input type="radio" name={`day-${slug}`} value={d.date} checked={day === d.date} className="visually-hidden" onChange={() => { setDay(d.date); onChange(null); }} />
              <strong>{i18n.date(d.date, 'weekday')}</strong>
              <br />{i18n.date(d.date, 'short')}
              <br /><span className="muted">{t('appts.slot.free', { count: d.availableCount })}</span>
            </label>
          ))}
        </div>
      </fieldset>
      {selectedDay ? (
        <fieldset>
          <legend>{t('appts.slot.chooseTime')}</legend>
          <div className="row" role="radiogroup" aria-label={t('appts.slot.timeGroup')}>
            {selectedDay.slots.map((s) => {
              const checked = value?.date === selectedDay.date && value.slotNumber === s.slotNumber;
              return (
                <label key={s.slotNumber} className="card" style={{ cursor: 'pointer', borderColor: checked ? 'var(--color-accent)' : undefined }}>
                  <input type="radio" name={`slot-${slug}`} value={s.slotNumber} checked={checked} className="visually-hidden"
                    onChange={() => onChange({ date: selectedDay.date, slotNumber: s.slotNumber, startTime: s.startTime, endTime: s.endTime, endsNextDay: s.endsNextDay })} />
                  <span>{i18n.range(s.startTime, s.endTime)}</span>
                  {s.endsNextDay ? <span className="muted"> ({t('common.nextDay')})</span> : null}
                </label>
              );
            })}
          </div>
        </fieldset>
      ) : null}
      <p className="muted">{t('appts.slot.timezone', { zone: state.data?.timezone ?? '' })}</p>
    </div>
  );
}
