import { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Button, Dialog, StatusBadge, TextAreaField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { toApiError } from '../../../shared/lib/useAsync.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminAppointment } from '../../api/types.js';
import { CENTER_ZONE } from '../../lib/dates.js';
import { useT } from '../../i18n/useT.js';
import { SlotChooser, type SlotChoice } from './SlotChooser.js';

type Mode = 'detail' | 'cancel' | 'reschedule' | 'complete' | 'no_show';
/** After these the chosen time is certainly stale: drop it and reload availability. */
const STALE = new Set(['SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'BEYOND_BOOKING_HORIZON', 'RESCHEDULE_NO_CHANGE']);

/**
 * Details of one appointment and everything staff can do with it. The 24-hour rule belongs to the backend: the first
 * attempt never carries `override`. Only when the backend answers WITHIN_24H_WINDOW does the dialog ask for an explicit,
 * reasoned exception, and only then is `override: true` sent (and audited by the backend).
 */
export function ManageDialog({ appointment: a, onClose, onChanged }: { appointment: AdminAppointment | null; onClose: () => void; onChanged: (message: string) => void }) {
  const t = useT();
  return (
    <Dialog open={!!a} title={t('appts.detail.title')} onClose={onClose}>
      {a ? <Body key={a.id} appointment={a} onClose={onClose} onChanged={onChanged} /> : null}
    </Dialog>
  );
}

function Body({ appointment: a, onClose, onChanged }: { appointment: AdminAppointment; onClose: () => void; onChanged: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const [mode, setMode] = useState<Mode>('detail');
  const [reason, setReason] = useState('');
  const [override, setOverride] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [choice, setChoice] = useState<SlotChoice | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [stale, setStale] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);
  const booked = a.status === 'booked';
  const when = `${i18n.date(a.date)} · ${i18n.range(a.startTime, a.endTime)}`;

  function go(next: Mode) { setMode(next); setError(null); setOverride(false); setConfirmed(false); setReason(''); setChoice(null); setStale(false); }

  async function perform(fn: () => Promise<unknown>, done: string) {
    if (running.current) return;
    running.current = true; setBusy(true); setError(null);
    try { await fn(); onChanged(done); onClose(); }
    catch (e) {
      const code = toApiError(e).code;
      if (code === 'WITHIN_24H_WINDOW' && !override && (mode === 'cancel' || mode === 'reschedule')) setOverride(true);
      else {
        setError(e);
        if (mode === 'reschedule' && STALE.has(code)) { setChoice(null); setRefreshKey((k) => k + 1); setStale(true); }
      }
    } finally { running.current = false; setBusy(false); }
  }

  const overrideReady = !override || (reason.trim() !== '' && confirmed);
  const overrideFields = override ? { override: true as const, reason: reason.trim() } : reason.trim() ? { reason: reason.trim() } : {};

  const overridePanel = override ? (
    <div className="stack">
      <Alert tone="warning" title={t('appts.override.title')}>{t('appts.override.text')}</Alert>
      <TextAreaField label={t('appts.override.reason')} hint={t('appts.override.reasonHint')} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} />
      <label className="check"><input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} /><span>{t('appts.override.confirm')}</span></label>
    </div>
  ) : null;
  const errorBox = error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null;

  if (mode === 'cancel') {
    return (
      <div className="stack">
        <h3>{t('appts.cancel.title')}</h3>
        <p>{t('appts.cancel.text')}</p>
        {!override ? <TextAreaField label={t('appts.cancel.reason')} optional maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} /> : overridePanel}
        {errorBox}
        <div className="row">
          <Button variant="danger" loading={busy} disabled={!overrideReady} onClick={() => void perform(() => admin.appointments.cancel(a.id, overrideFields, i18n.locale), t('appts.cancel.done'))}>
            {override ? t('appts.override.cancel') : t('appts.cancel.confirm')}
          </Button>
          <Button variant="ghost" onClick={() => go('detail')}>{t('appts.cancel.keep')}</Button>
        </div>
      </div>
    );
  }

  if (mode === 'reschedule') {
    return (
      <div className="stack">
        <h3>{t('appts.resched.title')}</h3>
        <p className="muted">{t('appts.resched.current', { when })}</p>
        <SlotChooser slug={a.department.slug} value={choice} onChange={setChoice} refreshKey={refreshKey} notice={stale} />
        {choice ? <p><strong>{t('appts.slot.selected', { when: `${i18n.date(choice.date)} · ${i18n.range(choice.startTime, choice.endTime)}` })}</strong></p> : null}
        {!override ? <TextAreaField label={t('appts.resched.reason')} optional maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} /> : overridePanel}
        {errorBox}
        <div className="row">
          <Button loading={busy} disabled={!choice || !overrideReady}
            onClick={() => choice && void perform(() => admin.appointments.reschedule(a.id, { date: choice.date, slotNumber: choice.slotNumber, ...overrideFields }, i18n.locale), t('appts.resched.done'))}>
            {override ? t('appts.override.reschedule') : t('appts.resched.confirm')}
          </Button>
          <Button variant="ghost" onClick={() => go('detail')}>{t('common.cancel')}</Button>
        </div>
      </div>
    );
  }

  if (mode === 'complete' || mode === 'no_show') {
    return (
      <div className="stack">
        <h3>{t('appts.status.title')}</h3>
        <p>{mode === 'complete' ? t('appts.status.completeText') : t('appts.status.noShowText')}</p>
        {errorBox}
        <div className="row">
          <Button loading={busy} onClick={() => void perform(() => admin.appointments.setStatus(a.id, mode === 'complete' ? 'completed' : 'no_show', i18n.locale), t('appts.status.done'))}>{t('appts.status.confirm')}</Button>
          <Button variant="ghost" onClick={() => go('detail')}>{t('common.cancel')}</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="stack">
      <p className="row"><strong>{when}</strong> <StatusBadge status={a.status} /></p>
      <dl className="stack" style={{ margin: 0 }}>
        <div><dt className="muted">{t('admin.col.patient')}</dt><dd style={{ margin: 0 }}><Link to={`/patients/${a.patient.id}`}>{a.patient.fullName}</Link> · <span className="ltr">{a.patient.phone}</span></dd></div>
        <div><dt className="muted">{t('admin.col.department')}</dt><dd style={{ margin: 0 }}>{a.department.name}</dd></div>
        {a.dentist ? <div><dt className="muted">{t('admin.col.dentist')}</dt><dd style={{ margin: 0 }}>{a.dentist.name}</dd></div> : null}
        {a.service ? <div><dt className="muted">{t('admin.col.service')}</dt><dd style={{ margin: 0 }}>{a.service.name}</dd></div> : null}
        <div><dt className="muted">{t('appts.detail.createdVia')}</dt><dd style={{ margin: 0 }}>{t(`appts.via.${a.createdVia}`)}</dd></div>
        <div><dt className="muted">{t('appts.detail.note')}</dt><dd style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{a.patientNote || t('appts.detail.noNote')}</dd></div>
        {a.rescheduledCount > 0 ? <div><dt className="muted">{t('appts.detail.rescheduled')}</dt><dd style={{ margin: 0 }}>{a.rescheduledCount}</dd></div> : null}
        {a.status === 'cancelled' ? (
          <>
            {a.cancelledAt ? <div><dt className="muted">{t('appts.detail.cancelledAt')}</dt><dd style={{ margin: 0 }}>{i18n.instant(a.cancelledAt, CENTER_ZONE)}</dd></div> : null}
            {a.cancelledBy ? <div><dt className="muted">{t('appts.detail.cancelledBy')}</dt><dd style={{ margin: 0 }}>{t(`appts.by.${a.cancelledBy}`)}</dd></div> : null}
            {a.cancelReason ? <div><dt className="muted">{t('appts.detail.cancelReason')}</dt><dd style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{a.cancelReason}</dd></div> : null}
          </>
        ) : null}
      </dl>
      {booked ? (
        <>
          {a.selfService.canCancel && a.selfService.deadline ? <p className="muted">{t('appts.detail.deadline', { when: i18n.instant(a.selfService.deadline, CENTER_ZONE) })}</p> : null}
          {!a.selfService.canCancel ? <Alert tone="info">{t('appts.detail.insideWindow')}</Alert> : null}
          <div className="row">
            <Button variant="secondary" onClick={() => go('reschedule')}>{t('appts.action.reschedule')}</Button>
            <Button variant="secondary" onClick={() => go('complete')}>{t('appts.action.complete')}</Button>
            <Button variant="secondary" onClick={() => go('no_show')}>{t('appts.action.noShow')}</Button>
            <Button variant="danger" onClick={() => go('cancel')}>{t('appts.action.cancel')}</Button>
          </div>
        </>
      ) : null}
      <div className="row"><Button variant="ghost" onClick={onClose}>{t('common.close')}</Button></div>
    </div>
  );
}
