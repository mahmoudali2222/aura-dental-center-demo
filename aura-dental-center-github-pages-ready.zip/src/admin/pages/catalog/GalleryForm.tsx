import { useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, SelectField, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useAsync } from '../../../shared/lib/useAsync.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminDepartment, AdminGalleryCase } from '../../api/types.js';
import { TranslationFields } from '../../components/TranslationFields.js';
import { formErrors } from '../../lib/formErrors.js';
import { trToForm, trToPayload } from '../../lib/translations.js';
import { useT } from '../../i18n/useT.js';
import { pickName, validOrder } from './shared.js';

const KEYS = ['title', 'description', 'altBefore', 'altAfter'] as const;

export function GalleryDialog({ open, galleryCase, departments, onClose, onSaved }: {
  open: boolean; galleryCase: AdminGalleryCase | null; departments: AdminDepartment[]; onClose: () => void; onSaved: (message: string) => void;
}) {
  const t = useT();
  return (
    <Dialog open={open} title={galleryCase ? t('gal.form.editTitle') : t('gal.form.createTitle')} onClose={onClose}>
      {open ? <Form galleryCase={galleryCase} departments={departments} onClose={onClose} onSaved={onSaved} /> : null}
    </Dialog>
  );
}

function Form({ galleryCase: g, departments, onClose, onSaved }: { galleryCase: AdminGalleryCase | null; departments: AdminDepartment[]; onClose: () => void; onSaved: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const [departmentId, setDepartmentId] = useState(g?.departmentId ?? '');
  const [serviceId, setServiceId] = useState(g?.serviceId ?? '');
  const [before, setBefore] = useState(g?.beforeImagePath ?? '');
  const [after, setAfter] = useState(g?.afterImagePath ?? '');
  const [kind, setKind] = useState<'real' | 'sample'>(g?.caseKind ?? 'real');
  const [consent, setConsent] = useState(g?.consentConfirmed ?? false);
  const [published, setPublished] = useState(g?.isPublished ?? false);
  const [order, setOrder] = useState(String(g?.displayOrder ?? 0));
  const [tr, setTr] = useState(() => trToForm(g?.translations, KEYS));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);
  const services = useAsync((signal) => (departmentId ? admin.services.list(departmentId, signal) : Promise.resolve([])), [departmentId]);
  const orderOk = validOrder(order);
  // A real case may only be published once the patient's consent is confirmed (the backend enforces it too).
  const publishBlocked = kind === 'real' && !consent;
  const willPublish = published && !publishBlocked;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current || !orderOk || !departmentId) return;
    running.current = true; setBusy(true); setError(null);
    const body = {
      departmentId, beforeImagePath: before.trim(), afterImagePath: after.trim(), serviceId: serviceId || null, caseKind: kind,
      consentConfirmed: consent, isPublished: willPublish, displayOrder: Number(order), translations: trToPayload(tr, KEYS, g?.translations),
    };
    try {
      if (g) await admin.gallery.update(g.id, body);
      else await admin.gallery.create(body);
      onSaved(t(g ? 'gal.saved.updated' : 'gal.saved.created'));
      onClose();
    } catch (err) { setError(err); }
    finally { running.current = false; setBusy(false); }
  }
  const { fields, rest } = formErrors(i18n, error, { INVALID_IMAGE_PATH: 'beforeImagePath', CONSENT_REQUIRED: 'consentConfirmed' });
  return (
    <form onSubmit={submit} className="stack" noValidate>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <SelectField label={t('gal.department')} required value={departmentId} onChange={(e) => { setDepartmentId(e.target.value); setServiceId(''); }} error={fields.departmentId}>
        <option value="">{t('gal.department.choose')}</option>
        {departments.map((d) => <option key={d.id} value={d.id}>{pickName(d.translations, i18n.locale, d.slug)}</option>)}
      </SelectField>
      {departmentId ? (
        <SelectField label={t('gal.service')} optional value={serviceId} onChange={(e) => setServiceId(e.target.value)} error={fields.serviceId}>
          <option value="">{t('gal.service.none')}</option>
          {(services.data ?? []).map((s) => <option key={s.id} value={s.id}>{pickName(s.translations, i18n.locale)}</option>)}
        </SelectField>
      ) : null}
      <TextField label={t('gal.before')} hint={t('admin.image.hint')} dir="ltr" required value={before} onChange={(e) => setBefore(e.target.value)} error={fields.beforeImagePath} />
      <TextField label={t('gal.after')} dir="ltr" required value={after} onChange={(e) => setAfter(e.target.value)} error={fields.afterImagePath} />
      <SelectField label={t('gal.kind')} value={kind} onChange={(e) => setKind(e.target.value as 'real' | 'sample')}>
        <option value="real">{t('gal.kind.real')}</option>
        <option value="sample">{t('gal.kind.sample')}</option>
      </SelectField>
      {kind === 'real' ? (
        <div className="stack">
          <label className="check"><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} /><span>{t('gal.consent')}</span></label>
          {fields.consentConfirmed ? <span className="field__error">{fields.consentConfirmed}</span> : null}
        </div>
      ) : null}
      <div className="stack">
        <label className="check"><input type="checkbox" checked={willPublish} disabled={publishBlocked} onChange={(e) => setPublished(e.target.checked)} /><span>{t('gal.published')}</span></label>
        {publishBlocked ? <p className="muted" style={{ margin: 0 }}>{t('gal.published.blocked')}</p> : null}
      </div>
      <TextField label={t('gal.order')} inputMode="numeric" dir="ltr" value={order} onChange={(e) => setOrder(e.target.value)} error={orderOk ? fields.displayOrder : t('gal.order.invalid')} />
      <TranslationFields legend={t('gal.tr.legend')} value={tr} onChange={setTr} errors={fields}
        fields={[
          { key: 'title', label: t('gal.tr.title'), maxLength: 160 },
          { key: 'description', label: t('gal.tr.description'), multiline: true, maxLength: 2000 },
          { key: 'altBefore', label: t('gal.tr.altBefore'), hint: t('gal.tr.altHint'), maxLength: 300 },
          { key: 'altAfter', label: t('gal.tr.altAfter'), hint: t('gal.tr.altHint'), maxLength: 300 },
        ]} />
      <div className="row">
        <Button type="submit" loading={busy} disabled={!orderOk || !departmentId || !before.trim() || !after.trim()}>{t('common.save')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
