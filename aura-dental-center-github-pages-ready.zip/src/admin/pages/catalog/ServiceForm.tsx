import { useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, SelectField, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminDepartment, AdminService } from '../../api/types.js';
import { TranslationFields } from '../../components/TranslationFields.js';
import { formErrors } from '../../lib/formErrors.js';
import { trToForm, trToPayload } from '../../lib/translations.js';
import { useT } from '../../i18n/useT.js';
import { pickName, validOrder } from './shared.js';

const KEYS = ['name', 'description'] as const;
const PRICE_RE = /^\d{1,8}(\.\d{1,2})?$/;

export function ServiceDialog({ open, service, departments, defaultDepartmentId, currency, onClose, onSaved }: {
  open: boolean; service: AdminService | null; departments: AdminDepartment[]; defaultDepartmentId: string; currency: string; onClose: () => void; onSaved: (message: string) => void;
}) {
  const t = useT();
  return (
    <Dialog open={open} title={service ? t('svc.form.editTitle') : t('svc.form.createTitle')} onClose={onClose}>
      {open ? <Form service={service} departments={departments} defaultDepartmentId={defaultDepartmentId} currency={currency} onClose={onClose} onSaved={onSaved} /> : null}
    </Dialog>
  );
}

function Form({ service: s, departments, defaultDepartmentId, currency, onClose, onSaved }: {
  service: AdminService | null; departments: AdminDepartment[]; defaultDepartmentId: string; currency: string; onClose: () => void; onSaved: (message: string) => void;
}) {
  const t = useT();
  const i18n = useI18n();
  const [departmentId, setDepartmentId] = useState(s?.departmentId ?? defaultDepartmentId);
  const [price, setPrice] = useState(s?.price == null ? '' : String(s.price));
  const [order, setOrder] = useState(String(s?.displayOrder ?? 0));
  const [isActive, setIsActive] = useState(s?.isActive ?? true);
  const [imagePath, setImagePath] = useState(s?.imagePath ?? '');
  const [tr, setTr] = useState(() => trToForm(s?.translations, KEYS));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);
  const orderOk = validOrder(order);
  const priceText = price.trim().replace(',', '.');
  const priceOk = priceText === '' || PRICE_RE.test(priceText);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current || !orderOk || !priceOk || !departmentId) return;
    running.current = true; setBusy(true); setError(null);
    const body = { departmentId, price: priceText === '' ? null : Number(priceText), displayOrder: Number(order), isActive, imagePath: imagePath.trim() || null, translations: trToPayload(tr, KEYS, s?.translations) };
    try {
      const saved = s ? await admin.services.update(s.id, body) : await admin.services.create(body);
      onSaved(t(s ? 'svc.saved.updated' : 'svc.saved.created', { name: pickName(saved.translations, i18n.locale) }));
      onClose();
    } catch (err) { setError(err); }
    finally { running.current = false; setBusy(false); }
  }
  const { fields, rest } = formErrors(i18n, error, { INVALID_PRICE: 'price', INVALID_IMAGE_PATH: 'imagePath' });
  return (
    <form onSubmit={submit} className="stack" noValidate>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <SelectField label={t('svc.department')} required value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} error={fields.departmentId}>
        <option value="">{t('svc.department.choose')}</option>
        {departments.map((d) => <option key={d.id} value={d.id}>{pickName(d.translations, i18n.locale, d.slug)}</option>)}
      </SelectField>
      <TextField label={t('svc.price')} optional inputMode="decimal" dir="ltr" hint={t('svc.price.hint', { currency })} value={price} onChange={(e) => setPrice(e.target.value)} error={priceOk ? fields.price : t('err.INVALID_PRICE')} />
      <TextField label={t('svc.order')} inputMode="numeric" dir="ltr" value={order} onChange={(e) => setOrder(e.target.value)} error={orderOk ? fields.displayOrder : t('svc.order.invalid')} />
      <TextField label={t('svc.image')} optional hint={t('admin.image.hint')} dir="ltr" value={imagePath} onChange={(e) => setImagePath(e.target.value)} error={fields.imagePath} />
      <label className="check"><input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} /><span>{t('svc.active')}</span></label>
      <TranslationFields legend={t('svc.tr.legend')} value={tr} onChange={setTr} errors={fields}
        fields={[{ key: 'name', label: t('svc.tr.name'), maxLength: 120 }, { key: 'description', label: t('svc.tr.description'), multiline: true, maxLength: 2000 }]} />
      {fields.translations ? <Alert tone="error">{fields.translations}</Alert> : null}
      <div className="row">
        <Button type="submit" loading={busy} disabled={!orderOk || !priceOk || !departmentId}>{t('common.save')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
