import { useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { toApiError } from '../../../shared/lib/useAsync.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminDepartment } from '../../api/types.js';
import { TranslationFields } from '../../components/TranslationFields.js';
import { WEEK, WeekdayPicker, normalizeDays, sameDays } from '../../components/WeekdayPicker.js';
import { formErrors } from '../../lib/formErrors.js';
import { trToForm, trToPayload } from '../../lib/translations.js';
import { useT } from '../../i18n/useT.js';
import { pickName, validOrder } from './shared.js';

const KEYS = ['name', 'description'] as const;
const BY_CODE = { SLUG_TAKEN: 'slug', INVALID_SLUG: 'slug', INVALID_IMAGE_PATH: 'imagePath', AT_LEAST_ONE_WORKING_DAY: 'workingDays' };

export function DepartmentDialog({ open, department, onClose, onSaved }: { open: boolean; department: AdminDepartment | null; onClose: () => void; onSaved: (message: string) => void }) {
  const t = useT();
  return (
    <Dialog open={open} title={department ? t('dep.form.editTitle') : t('dep.form.createTitle')} onClose={onClose}>
      {open ? <Form department={department} onClose={onClose} onSaved={onSaved} /> : null}
    </Dialog>
  );
}

/**
 * Switching a weekday off while appointments are booked on it is a two-step action, exactly like closing dates: the first
 * attempt never carries the acknowledgement. If the backend reports booked appointments, the form shows how many and asks for
 * an explicit confirmation; only then is the request repeated with `acknowledgeExistingAppointments`. Nothing is cancelled.
 */
function Form({ department: d, onClose, onSaved }: { department: AdminDepartment | null; onClose: () => void; onSaved: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const [slug, setSlug] = useState(d?.slug ?? '');
  const [order, setOrder] = useState(String(d?.displayOrder ?? 0));
  const [isActive, setIsActive] = useState(d?.isActive ?? true);
  const [imagePath, setImagePath] = useState(d?.imagePath ?? '');
  const [days, setDays] = useState<number[]>(() => normalizeDays(d?.workingDays ?? WEEK));
  const [existing, setExisting] = useState<number | null>(null);
  const [ack, setAck] = useState(false);
  const [tr, setTr] = useState(() => trToForm(d?.translations, KEYS));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);
  const orderOk = validOrder(order);
  const daysOk = days.length > 0;
  const daysChanged = d ? !sameDays(days, d.workingDays) : true;
  const waitingForAck = existing !== null && !ack;
  // The count belongs to the days that were submitted: choosing other days withdraws the warning.
  const changeDays = (next: number[]) => { setDays(next); setExisting(null); setAck(false); setError(null); };

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current || !orderOk || !daysOk || waitingForAck) return;
    running.current = true; setBusy(true); setError(null);
    const translations = trToPayload(tr, KEYS, d?.translations);
    try {
      const common = { slug: slug.trim(), displayOrder: Number(order), isActive, imagePath: imagePath.trim() || null, translations };
      const saved = d
        ? await admin.departments.update(d.id, { ...common, ...(daysChanged ? { workingDays: normalizeDays(days) } : {}), ...(existing !== null ? { acknowledgeExistingAppointments: true } : {}) })
        : await admin.departments.create({ ...common, workingDays: normalizeDays(days) });
      onSaved(t(d ? 'dep.saved.updated' : 'dep.saved.created', { name: pickName(saved.translations, i18n.locale, saved.slug) }));
      onClose();
    } catch (err) {
      const api = toApiError(err);
      if (api.code === 'WORKING_DAYS_HAVE_APPOINTMENTS') {
        const n = (api.details as { count?: unknown } | undefined)?.count;
        setExisting(typeof n === 'number' ? n : 0); setAck(false);
      } else setError(err);
    }
    finally { running.current = false; setBusy(false); }
  }
  const { fields, rest } = formErrors(i18n, error, BY_CODE);
  return (
    <form onSubmit={submit} className="stack" noValidate>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <TextField label={t('dep.slug')} hint={t('dep.slug.hint')} dir="ltr" autoCapitalize="none" spellCheck={false} required value={slug} onChange={(e) => setSlug(e.target.value)} error={fields.slug} />
      <TextField label={t('dep.order')} hint={t('dep.order.hint')} inputMode="numeric" dir="ltr" value={order} onChange={(e) => setOrder(e.target.value)} error={orderOk ? fields.displayOrder : t('dep.order.invalid')} />
      <TextField label={t('dep.image')} optional hint={t('admin.image.hint')} dir="ltr" value={imagePath} onChange={(e) => setImagePath(e.target.value)} error={fields.imagePath} />
      <WeekdayPicker legend={t('dep.workingDays')} hint={t('dep.workingDays.hint')} value={days} onChange={changeDays}
        error={!daysOk ? t('err.AT_LEAST_ONE_WORKING_DAY') : fields.workingDays} />
      {existing !== null ? (
        <Alert tone="warning" title={i18n.tn('dep.workingDays.ack', existing, { count: existing })}>
          <span>{t('dep.workingDays.ack.note')}</span>
          <label className="check" style={{ marginBlockStart: 'var(--space-2)' }}>
            <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} /><span>{t('dep.workingDays.ack.confirm')}</span>
          </label>
        </Alert>
      ) : null}
      <label className="check"><input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} /><span>{t('dep.active')}</span></label>
      <TranslationFields legend={t('dep.tr.legend')} value={tr} onChange={setTr} errors={fields}
        fields={[{ key: 'name', label: t('dep.tr.name'), maxLength: 120 }, { key: 'description', label: t('dep.tr.description'), multiline: true, maxLength: 2000 }]} />
      {fields.translations ? <Alert tone="error">{fields.translations}</Alert> : null}
      <div className="row">
        <Button type="submit" loading={busy} disabled={!orderOk || !slug.trim() || !daysOk || waitingForAck}>{existing !== null ? t('dep.workingDays.ack.submit') : t('common.save')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
