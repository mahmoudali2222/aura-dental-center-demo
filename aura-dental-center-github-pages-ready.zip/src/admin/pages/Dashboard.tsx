import { Link } from 'react-router-dom';
import { Alert, Button, EmptyState, Loading, StatusBadge } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin } from '../api/index.js';
import { useT } from '../i18n/useT.js';

export function Dashboard() {
  const t = useT();
  const i18n = useI18n();
  const state = useAsync((signal) => admin.dashboard(i18n.locale, signal), [i18n.locale]);
  const d = state.data;

  if (!d) {
    return state.status === 'error'
      ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, state.error)} <Button small variant="secondary" onClick={state.reload}>{t('common.retry')}</Button></Alert>
      : <Loading />;
  }
  const counts: ('booked' | 'completed' | 'no_show' | 'cancelled')[] = ['booked', 'completed', 'no_show', 'cancelled'];
  return (
    <div className="stack">
      <h1>{t('dash.heading', { date: i18n.date(d.date) })}</h1>
      {state.status === 'error' ? <Alert tone="error">{errorText(i18n, state.error)}</Alert> : null}

      <section aria-labelledby="dash-counts" className="stack">
        <h2 id="dash-counts" className="visually-hidden">{t('dash.counts')}</h2>
        <div className="stat-grid">
          {counts.map((c) => (
            <div className="stat" key={c} data-testid={`count-${c}`}>
              <span className="muted">{t(`status.${c}`)}</span>
              <strong>{d.counts[c]}</strong>
            </div>
          ))}
        </div>
      </section>

      <section aria-labelledby="dash-appts" className="stack">
        <h2 id="dash-appts">{t('dash.appointments')}</h2>
        {d.appointments.length === 0 ? <EmptyState>{t('dash.none')}</EmptyState> : (
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th scope="col">{t('admin.col.time')}</th><th scope="col">{t('admin.col.patient')}</th>
                <th scope="col">{t('admin.col.department')}</th><th scope="col">{t('admin.col.status')}</th>
              </tr></thead>
              <tbody>
                {d.appointments.map((a) => (
                  <tr key={a.id}>
                    <td>{i18n.range(a.startTime, a.endTime)}</td>
                    <td>{a.patient.fullName}<br /><span className="muted ltr">{a.patient.phone}</span></td>
                    <td>{a.department.name}</td>
                    <td><StatusBadge status={a.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p><Link to="/appointments">{t('dash.all')}</Link></p>
      </section>

      <div className="two-col">
        <section aria-labelledby="dash-load" className="stack">
          <h2 id="dash-load">{t('dash.load')}</h2>
          <ul className="stack" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {d.departments.map((dep) => (
              <li key={dep.id} className="row" style={{ justifyContent: 'space-between' }}>
                <span>{dep.name}</span>
                <span className={dep.activeToday >= dep.capacity ? 'badge badge--no_show' : 'badge'}>{t('dash.load.item', { count: dep.activeToday, capacity: dep.capacity })}</span>
              </li>
            ))}
          </ul>
        </section>
        <section aria-labelledby="dash-next" className="stack">
          <h2 id="dash-next">{t('dash.next7')}</h2>
          {d.next7Days.length === 0 ? <p className="muted">{t('dash.next7.none')}</p> : (
            <ul className="stack" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {d.next7Days.map((n) => (
                <li key={n.date} className="row" style={{ justifyContent: 'space-between' }}>
                  <span>{i18n.date(n.date)}</span>
                  <span>{i18n.tn('dash.next7.item', n.booked)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
