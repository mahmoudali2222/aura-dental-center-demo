import { useState } from 'react';
import { Alert, AssetImage, Button, EmptyState, Loading } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin } from '../api/index.js';
import type { AdminDepartment } from '../api/types.js';
import { ConfirmDialog } from '../components/ConfirmDialog.js';
import { useAction } from '../lib/useAction.js';
import { useT } from '../i18n/useT.js';
import { DentistDialog, type DentistMode } from './catalog/DentistForm.js';
import { DepartmentDialog } from './catalog/DepartmentForm.js';
import { pickName } from './catalog/shared.js';

export function Departments() {
  const t = useT();
  const i18n = useI18n();
  const list = useAsync((signal) => admin.departments.list(signal), []);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<AdminDepartment | 'new' | null>(null);
  const [dentist, setDentist] = useState<{ mode: DentistMode; department: AdminDepartment } | null>(null);
  const [confirm, setConfirm] = useState<{ kind: 'replace' | 'deactivate'; department: AdminDepartment } | null>(null);
  const deactivate = useAction((id: string) => admin.dentists.update(id, { isActive: false }));
  const name = (d: AdminDepartment) => pickName(d.translations, i18n.locale, d.slug);
  const saved = (m: string) => { setNotice(m); list.reload(); };

  return (
    <div className="stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1 style={{ margin: 0 }}>{t('dep.title')}</h1>
        <Button onClick={() => { setNotice(null); setEditing('new'); }}>{t('dep.add')}</Button>
      </div>
      <p className="muted">{t('dep.intro')}</p>
      {notice ? <Alert tone="success">{notice}</Alert> : null}
      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data && list.data.length === 0 ? <EmptyState>{t('dep.empty')}</EmptyState> : null}

      <ul className="stack" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
        {(list.data ?? []).map((d) => {
          const dn = d.dentist ? pickName(d.dentist.translations, i18n.locale, t('dep.dentist.unnamed')) : '';
          return (
            <li key={d.id} className="card stack" aria-label={name(d)}>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <h2 style={{ margin: 0 }}>{name(d)}</h2>
                <div className="row">
                  <span className={d.isActive ? 'badge badge--completed' : 'badge badge--cancelled'}>{d.isActive ? t('dep.badge.active') : t('dep.badge.inactive')}</span>
                  <span className={d.bookable ? 'badge badge--booked' : 'badge badge--no_show'}>{d.bookable ? t('dep.badge.bookable') : t('dep.badge.notBookable')}</span>
                </div>
              </div>
              <div className="row">
                <AssetImage src={d.imagePath} alt="" width={64} height={64} />
                <p className="muted" style={{ margin: 0 }}>
                  <span className="ltr">{t('dep.meta.slug', { slug: d.slug })}</span> · {t('dep.meta.order', { order: d.displayOrder })} · {i18n.tn('dep.services', d.serviceCount)}
                </p>
              </div>
              <p style={{ margin: 0 }}>{d.workingDays.length === 7 ? t('dep.workingDays.everyDay') : t('dep.workingDays.summary', { days: i18n.list(d.workingDays.map((n) => i18n.weekday(n, 'long'))) })}</p>
              {!d.bookable ? <Alert tone="warning">{!d.isActive ? t('dep.notBookable.inactive') : t('dep.notBookable.noDentist')}</Alert> : null}
              <div className="row"><Button small variant="secondary" aria-label={t('dep.editAria', { name: name(d) })} onClick={() => { setNotice(null); setEditing(d); }}>{t('common.edit')}</Button></div>

              <section className="stack" aria-label={t('dep.dentist.title')}>
                <h3 style={{ margin: 0 }}>{t('dep.dentist.title')}</h3>
                {d.dentist ? (
                  <>
                    <p style={{ margin: 0 }}><strong>{dn}</strong> {d.dentist.isSample ? <span className="badge badge--no_show">{t('common.sample')}</span> : null}</p>
                    {d.dentist.isSample ? <p className="muted" style={{ margin: 0 }}>{t('dep.dentist.sample')}</p> : null}
                    {d.dentist.photoPath ? <p className="muted ltr" style={{ margin: 0 }}>{t('dep.dentist.photoPath', { path: d.dentist.photoPath })}</p> : null}
                    <div className="row">
                      <Button small variant="secondary" aria-label={t('dep.dentist.editAria', { department: name(d) })} onClick={() => { setNotice(null); setDentist({ mode: 'edit', department: d }); }}>{t('dep.dentist.edit')}</Button>
                      <Button small variant="secondary" aria-label={t('dep.dentist.replaceAria', { department: name(d) })} onClick={() => { setNotice(null); setConfirm({ kind: 'replace', department: d }); }}>{t('dep.dentist.replace')}</Button>
                      <Button small variant="danger" aria-label={t('dep.dentist.deactivateAria', { department: name(d) })} onClick={() => { setNotice(null); setConfirm({ kind: 'deactivate', department: d }); }}>{t('dep.dentist.deactivate')}</Button>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="muted" style={{ margin: 0 }}>{t('dep.dentist.none')}</p>
                    <div className="row"><Button small aria-label={t('dep.dentist.assignAria', { department: name(d) })} onClick={() => { setNotice(null); setDentist({ mode: 'assign', department: d }); }}>{t('dep.dentist.assign')}</Button></div>
                  </>
                )}
              </section>
            </li>
          );
        })}
      </ul>

      <DepartmentDialog open={editing !== null} department={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSaved={saved} />
      <DentistDialog mode={dentist?.mode ?? null} department={dentist?.department ?? null} onClose={() => setDentist(null)} onSaved={saved} />

      {confirm?.kind === 'replace' ? (
        <ConfirmDialog open title={t('dep.dentist.replace.title', { department: name(confirm.department) })} confirmLabel={t('dep.dentist.replace.confirm')}
          onClose={() => setConfirm(null)} onConfirm={() => { setDentist({ mode: 'replace', department: confirm.department }); setConfirm(null); }}>
          <p>{t('dep.dentist.replace.text', { name: pickName(confirm.department.dentist?.translations, i18n.locale, t('dep.dentist.unnamed')) })}</p>
        </ConfirmDialog>
      ) : null}
      {confirm?.kind === 'deactivate' && confirm.department.dentist ? (
        <ConfirmDialog open danger title={t('dep.dentist.deactivate.title', { department: name(confirm.department) })} confirmLabel={t('dep.dentist.deactivate.confirm')}
          busy={deactivate.busy} error={deactivate.error}
          onClose={() => { deactivate.reset(); setConfirm(null); }}
          onConfirm={async () => {
            if (await deactivate.attempt(confirm.department.dentist!.id)) { saved(t('dep.dentist.saved.deactivated', { department: name(confirm.department) })); setConfirm(null); }
          }}>
          <p>{t('dep.dentist.deactivate.text', { name: pickName(confirm.department.dentist.translations, i18n.locale, t('dep.dentist.unnamed')) })}</p>
        </ConfirmDialog>
      ) : null}
    </div>
  );
}
