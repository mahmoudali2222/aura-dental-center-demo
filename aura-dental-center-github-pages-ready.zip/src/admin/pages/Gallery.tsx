import { useState } from 'react';
import { Alert, AssetImage, Button, EmptyState, Loading } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin } from '../api/index.js';
import type { AdminGalleryCase } from '../api/types.js';
import { ConfirmDialog } from '../components/ConfirmDialog.js';
import { useAction } from '../lib/useAction.js';
import { useT } from '../i18n/useT.js';
import { GalleryDialog } from './catalog/GalleryForm.js';
import { pickText } from './catalog/shared.js';
import { pickName } from './catalog/shared.js';

export function Gallery() {
  const t = useT();
  const i18n = useI18n();
  const list = useAsync((signal) => admin.gallery.list(signal), []);
  const depts = useAsync((signal) => admin.departments.list(signal), []);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<AdminGalleryCase | 'new' | null>(null);
  const [removing, setRemoving] = useState<AdminGalleryCase | null>(null);
  const remove = useAction((id: string) => admin.gallery.remove(id));
  const departments = depts.data ?? [];
  const rows = list.data ?? [];
  const deptName = (c: AdminGalleryCase) => { const d = departments.find((x) => x.id === c.departmentId); return d ? pickName(d.translations, i18n.locale, d.slug) : c.departmentSlug; };
  const title = (c: AdminGalleryCase) => pickText(c.translations, i18n.locale, 'title') || t('gal.untitled');
  const saved = (m: string) => { setNotice(m); list.reload(); };

  return (
    <div className="stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1 style={{ margin: 0 }}>{t('gal.title')}</h1>
        <Button onClick={() => { setNotice(null); setEditing('new'); }}>{t('gal.add')}</Button>
      </div>
      <p className="muted">{t('gal.intro')}</p>
      {rows.some((c) => c.caseKind === 'sample') ? <Alert tone="info">{t('gal.sampleNote')}</Alert> : null}
      {notice ? <Alert tone="success">{notice}</Alert> : null}
      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data && rows.length === 0 ? <EmptyState>{t('gal.empty')}</EmptyState> : null}

      <ul className="stack" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
        {rows.map((c) => (
          <li key={c.id} className="card stack" aria-label={title(c)}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <h2 style={{ margin: 0 }}>{title(c)}</h2>
              <div className="row">
                {c.caseKind === 'sample' ? <span className="badge badge--no_show">{t('common.sample')}</span> : null}
                <span className={c.isPublished ? 'badge badge--completed' : 'badge badge--cancelled'}>{c.isPublished ? t('gal.badge.published') : t('gal.badge.draft')}</span>
                {c.caseKind === 'real' ? <span className={c.consentConfirmed ? 'badge badge--completed' : 'badge badge--no_show'}>{c.consentConfirmed ? t('gal.consent.yes') : t('gal.consent.no')}</span> : null}
              </div>
            </div>
            <p className="muted" style={{ margin: 0 }}>{deptName(c)} · {t('gal.meta.order', { order: c.displayOrder })}</p>
            <div className="row">
              <AssetImage src={c.beforeImagePath} alt={t('gal.thumb.before')} width={96} height={96} />
              <AssetImage src={c.afterImagePath} alt={t('gal.thumb.after')} width={96} height={96} />
            </div>
            <div className="row">
              <Button small variant="secondary" aria-label={t('gal.editAria', { name: title(c) })} onClick={() => { setNotice(null); setEditing(c); }}>{t('common.edit')}</Button>
              <Button small variant="danger" aria-label={t('gal.deleteAria', { name: title(c) })} onClick={() => { setNotice(null); remove.reset(); setRemoving(c); }}>{t('gal.delete')}</Button>
            </div>
          </li>
        ))}
      </ul>

      <GalleryDialog open={editing !== null} galleryCase={editing === 'new' ? null : editing} departments={departments} onClose={() => setEditing(null)} onSaved={saved} />
      {removing ? (
        <ConfirmDialog open danger title={t('gal.delete.title', { name: title(removing) })} confirmLabel={t('gal.delete.confirm')} busy={remove.busy} error={remove.error}
          onClose={() => { remove.reset(); setRemoving(null); }}
          onConfirm={async () => { if (await remove.attempt(removing.id)) { saved(t('gal.saved.deleted')); setRemoving(null); } }}>
          <p>{t('gal.delete.text')}</p>
        </ConfirmDialog>
      ) : null}
    </div>
  );
}
