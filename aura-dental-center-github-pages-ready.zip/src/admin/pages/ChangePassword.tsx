import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert, Button, TextField } from '../../shared/ui/index.js';
import { errorText, fieldErrors } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { auth } from '../api/index.js';
import { useSession } from '../app/session.js';
import { useT } from '../i18n/useT.js';

export function ChangePassword() {
  const t = useT();
  const i18n = useI18n();
  const navigate = useNavigate();
  const { user, update } = useSession();
  const forced = !!user?.mustChangePassword;
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [again, setAgain] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [done, setDone] = useState(false);
  const mismatch = again !== '' && next !== again;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy || mismatch || !user) return;
    setBusy(true); setError(null);
    try {
      await auth.changePassword({ currentPassword: current, newPassword: next });
      update({ ...user, mustChangePassword: false });
      setDone(true); setCurrent(''); setNext(''); setAgain('');
      if (forced) navigate('/', { replace: true });
    } catch (err) { setError(err); }
    finally { setBusy(false); }
  }
  const fields = fieldErrors(i18n, error);
  return (
    <form onSubmit={submit} className="stack" style={{ maxInlineSize: '28rem' }} noValidate>
      <h1>{t('pw.title')}</h1>
      {forced ? <Alert tone="warning">{t('pw.forced')}</Alert> : null}
      {done ? <Alert tone="success">{t('pw.done')}</Alert> : null}
      {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
      <TextField label={t('pw.current')} name="currentPassword" type="password" autoComplete="current-password" dir="ltr" required value={current} onChange={(e) => setCurrent(e.target.value)} error={fields.currentPassword} />
      <TextField label={t('pw.new')} name="newPassword" type="password" autoComplete="new-password" dir="ltr" required minLength={12} hint={t('pw.hint')} value={next} onChange={(e) => setNext(e.target.value)} error={fields.newPassword ?? fields.password} />
      <TextField label={t('pw.confirm')} name="confirmPassword" type="password" autoComplete="new-password" dir="ltr" required value={again} onChange={(e) => setAgain(e.target.value)} error={mismatch ? t('pw.mismatch') : undefined} />
      <Button type="submit" loading={busy} disabled={!current || !next || !again || mismatch}>{t('pw.submit')}</Button>
    </form>
  );
}
