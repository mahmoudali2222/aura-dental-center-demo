import { useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, EmptyState, Loading, SelectField, TextAreaField } from '../../../shared/ui/index.js';
import { useAsync } from '../../../shared/lib/useAsync.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminAppointment, MedicalRecord } from '../../api/types.js';
import { useT } from '../../i18n/useT.js';
import { CENTER_ZONE } from './shared.js';

const SECTIONS = [
  ['medicalHistory', 'mr.history'], ['allergies', 'mr.allergies'], ['diagnosis', 'mr.diagnosis'], ['treatment', 'mr.treatment'], ['notes', 'mr.notes'],
] as const;
type Field = (typeof SECTIONS)[number][0];

/**
 * Medical records of one patient. Administrators only: the backend refuses everyone else and audits every access.
 * Clinical text is rendered as plain text, kept only in component state, never in storage, URLs or logs, and the editing
 * form is unmounted (and so forgotten) as soon as its dialog closes. Records are never deleted; they are corrected by editing.
 */
export function MedicalRecords({ patientId }: { patientId: string }) {
  const t = useT();
  const i18n = useI18n();
  const records = useAsync((signal) => admin.medicalRecords.list(patientId, signal), [patientId]);
  const appts = useAsync((signal) => admin.appointments.list({ patientId, sort: 'desc' }, i18n.locale, 1, 50, signal).then((r) => r.data), [patientId, i18n.locale]);
  const [editing, setEditing] = useState<MedicalRecord | 'new' | null>(null);
  const [notice, setNotice] = useState(false);
  const apptLabel = (a: AdminAppointment) => `${i18n.date(a.date, 'short')} · ${i18n.range(a.startTime, a.endTime)} · ${a.department.name}`;

  return (
    <section className="stack" aria-labelledby="mr-title">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2 id="mr-title" style={{ margin: 0 }}>{t('mr.title')}</h2>
        <Button onClick={() => { setNotice(false); setEditing('new'); }}>{t('mr.add')}</Button>
      </div>
      <Alert tone="info">{t('mr.notice')}</Alert>
      {notice ? <Alert tone="success">{t('mr.saved')}</Alert> : null}
      {records.status === 'loading' && !records.data ? <Loading /> : null}
      {records.status === 'error' ? <Alert tone="error">{t('mr.loadFailed')} {errorText(i18n, records.error)} <Button small variant="secondary" onClick={records.reload}>{t('common.retry')}</Button></Alert> : null}
      {records.data && records.data.length === 0 ? <EmptyState>{t('mr.empty')}</EmptyState> : null}
      <ul className="stack" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
        {(records.data ?? []).map((r) => {
          const linked = r.appointmentId ? (appts.data ?? []).find((a) => a.id === r.appointmentId) : undefined;
          return (
            <li key={r.id} className="card stack" data-testid="medical-record">
              <p className="muted" style={{ margin: 0 }}>{t('mr.created', { name: r.createdBy.username, when: i18n.instant(r.createdAt, CENTER_ZONE) })}</p>
              {r.updatedAt !== r.createdAt ? <p className="muted" style={{ margin: 0 }}>{t('mr.updated', { name: r.updatedBy.username, when: i18n.instant(r.updatedAt, CENTER_ZONE) })}</p> : null}
              {linked ? <p style={{ margin: 0 }}>{t('mr.appointment.label', { label: apptLabel(linked) })}</p> : null}
              {SECTIONS.map(([field, key]) => (r[field].trim() !== '' ? (
                <div key={field}><h3 style={{ marginBlockEnd: 'var(--space-1)' }}>{t(key)}</h3><p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{r[field]}</p></div>
              ) : null))}
              <div className="row"><Button small variant="secondary" onClick={() => { setNotice(false); setEditing(r); }}>{t('mr.edit')}</Button></div>
            </li>
          );
        })}
      </ul>
      <Dialog open={editing !== null} title={editing === 'new' ? t('mr.create.title') : t('mr.edit.title')} onClose={() => setEditing(null)}>
        {editing !== null ? (
          <RecordForm patientId={patientId} record={editing === 'new' ? null : editing} appointments={appts.data ?? []} label={apptLabel}
            onClose={() => setEditing(null)} onSaved={() => { setEditing(null); setNotice(true); records.reload(); }} />
        ) : null}
      </Dialog>
    </section>
  );
}

function RecordForm({ patientId, record, appointments, label, onClose, onSaved }: {
  patientId: string; record: MedicalRecord | null; appointments: AdminAppointment[]; label: (a: AdminAppointment) => string; onClose: () => void; onSaved: () => void;
}) {
  const t = useT();
  const i18n = useI18n();
  const [values, setValues] = useState<Record<Field, string>>({
    medicalHistory: record?.medicalHistory ?? '', allergies: record?.allergies ?? '', diagnosis: record?.diagnosis ?? '', treatment: record?.treatment ?? '', notes: record?.notes ?? '',
  });
  const [appointmentId, setAppointmentId] = useState(record?.appointmentId ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);
  const empty = SECTIONS.every(([f]) => values[f].trim() === '');

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current) return;
    running.current = true; setBusy(true); setError(null);
    const body = { ...values, appointmentId: appointmentId || null };
    try {
      if (record) await admin.medicalRecords.update(record.id, body);
      else await admin.medicalRecords.create(patientId, body);
      onSaved();
    } catch (err) { setError(err); }
    finally { running.current = false; setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="stack" noValidate>
      {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
      {SECTIONS.map(([field, key]) => (
        <TextAreaField key={field} label={t(key)} hint={t('mr.plainText')} maxLength={20000} autoComplete="off" spellCheck value={values[field]} onChange={(e) => setValues((v) => ({ ...v, [field]: e.target.value }))} />
      ))}
      <SelectField label={t('mr.appointment')} optional value={appointmentId} onChange={(e) => setAppointmentId(e.target.value)}>
        <option value="">{t('mr.appointment.none')}</option>
        {appointments.map((a) => <option key={a.id} value={a.id}>{label(a)}</option>)}
      </SelectField>
      <div className="row">
        <Button type="submit" loading={busy} disabled={empty}>{t('mr.save')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
