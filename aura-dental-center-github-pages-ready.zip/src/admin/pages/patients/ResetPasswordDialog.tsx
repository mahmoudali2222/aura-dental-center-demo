import { useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import { useT } from '../../i18n/useT.js';
import { formErrors } from './shared.js';

const BY_CODE = { PASSWORD_TOO_SHORT: 'newPassword', PASSWORD_TOO_WEAK: 'newPassword' };

/**
 * Staff-assisted password recovery: the only recovery path (no SMS, email or OTP exists). The password lives only in this
 * form's state; closing the dialog unmounts it, so it is not kept anywhere after the request.
 */
export function ResetPasswordDialog({ open, patientId, onClose, onDone }: { open: boolean; patientId: string; onClose: () => void; onDone: () => void }) {
  const t = useT();
  return (
    <Dialog open={open} title={t('pat.reset.title')} onClose={onClose}>
      {open ? <Form patientId={patientId} onClose={onClose} onDone={onDone} /> : null}
    </Dialog>
  );
}

function Form({ patientId, onClose, onDone }: { patientId: string; onClose: () => void; onDone: () => void }) {
  const t = useT();
  const i18n = useI18n();
  const [password, setPassword] = useState('');
  const [verified, setVerified] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current || !verified || !password) return;
    running.current = true; setBusy(true); setError(null);
    try {
      await admin.patients.resetPassword(patientId, { newPassword: password, identityVerified: true });
      setPassword('');
      onDone(); onClose();
    } catch (err) { setError(err); }
    finally { running.current = false; setBusy(false); }
  }
  const { fields, rest } = formErrors(i18n, error, BY_CODE);
  return (
    <form onSubmit={submit} className="stack" noValidate>
      <Alert tone="info">{t('pat.reset.intro')}</Alert>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <TextField label={t('pat.reset.new')} name="newPassword" type="password" autoComplete="new-password" dir="ltr" required hint={t('pat.reset.hint')} value={password} onChange={(e) => setPassword(e.target.value)} error={fields.newPassword ?? fields.password} />
      <label className="check"><input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} /><span>{t('pat.reset.identity')}</span></label>
      <div className="row">
        <Button type="submit" loading={busy} disabled={!verified || !password}>{t('pat.reset.submit')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
