import { useRef, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert, Button, Dialog, SelectField, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { LOCALES, type Locale } from '../../../shared/api/types.js';
import { LOCALE_META } from '../../../shared/i18n/types.js';
import { admin } from '../../api/index.js';
import { useT } from '../../i18n/useT.js';
import { formErrors } from './shared.js';

const BY_CODE = { INVALID_PHONE: 'phone', PHONE_ALREADY_REGISTERED: 'phone', PASSWORD_TOO_SHORT: 'password', PASSWORD_TOO_WEAK: 'password' };

export function CreatePatientDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useT();
  return (
    <Dialog open={open} title={t('pat.create.title')} onClose={onClose}>
      {open ? <Form onClose={onClose} /> : null}
    </Dialog>
  );
}

function Form({ onClose }: { onClose: () => void }) {
  const t = useT();
  const i18n = useI18n();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [language, setLanguage] = useState<'' | Locale>('');
  const [reveal, setReveal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current) return;
    running.current = true; setBusy(true); setError(null);
    try {
      const p = await admin.patients.create({ fullName: fullName.trim(), phone: phone.trim(), password, ...(language ? { preferredLocale: language } : {}) });
      onClose();
      navigate(`/patients/${p.id}`);
    } catch (err) { setError(err); }
    finally { running.current = false; setBusy(false); }
  }
  const { fields, rest } = formErrors(i18n, error, BY_CODE);
  return (
    <form onSubmit={submit} className="stack" noValidate>
      <p className="muted">{t('pat.create.intro')}</p>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <TextField label={t('pat.field.fullName')} name="fullName" autoComplete="off" required value={fullName} onChange={(e) => setFullName(e.target.value)} error={fields.fullName} />
      <TextField label={t('pat.field.phone')} name="phone" type="tel" inputMode="tel" autoComplete="off" dir="ltr" required hint={t('pat.field.phone.hint')} value={phone} onChange={(e) => setPhone(e.target.value)} error={fields.phone} />
      <TextField label={t('pat.field.password')} name="password" type={reveal ? 'text' : 'password'} autoComplete="new-password" dir="ltr" required hint={t('pat.create.password.hint')} value={password} onChange={(e) => setPassword(e.target.value)} error={fields.password} />
      <label className="check"><input type="checkbox" checked={reveal} onChange={(e) => setReveal(e.target.checked)} /><span>{t('pat.showPassword')}</span></label>
      <SelectField label={t('pat.field.language')} optional value={language} onChange={(e) => setLanguage(e.target.value as '' | Locale)}>
        <option value="">{t('pat.language.none')}</option>
        {LOCALES.map((l) => <option key={l} value={l} lang={l}>{LOCALE_META[l].nativeName}</option>)}
      </SelectField>
      <div className="row">
        <Button type="submit" loading={busy} disabled={!fullName.trim() || !phone.trim() || !password}>{t('pat.create.submit')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
