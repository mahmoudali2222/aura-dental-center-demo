import { useState, type FormEvent } from 'react';
import { Alert, Button, EmptyState, Loading, SelectField, TextField } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin } from '../api/index.js';
import type { AuditEvent } from '../api/types.js';
import { Pagination } from '../components/Pagination.js';
import { CENTER_ZONE } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';

const PAGE_SIZE = 50;

interface Filters { action: string; entityType: string; entityId: string; actorId: string; outcome: '' | AuditEvent['outcome']; from: string; to: string }
const NONE: Filters = { action: '', entityType: '', entityId: '', actorId: '', outcome: '', from: '', to: '' };

const ACTOR = {
  admin: 'aud.actor.admin', patient: 'aud.actor.patient', integration: 'aud.actor.integration', system: 'aud.actor.system', anonymous: 'aud.actor.anonymous',
} as const;
const OUTCOME = { success: 'aud.outcome.success', failure: 'aud.outcome.failure', denied: 'aud.outcome.denied' } as const;
const OUTCOME_BADGE = { success: 'badge badge--completed', failure: 'badge badge--no_show', denied: 'badge badge--cancelled' } as const;

/** Only the filters that were filled in are sent. */
function toQuery(f: Filters) {
  const q: Record<string, string> = {};
  for (const [k, v] of Object.entries(f)) if (v.trim() !== '') q[k] = v.trim();
  return q;
}

export function Audit() {
  const t = useT();
  const i18n = useI18n();
  const [form, setForm] = useState<Filters>(NONE);
  const [applied, setApplied] = useState<Filters>(NONE);
  const [page, setPage] = useState(1);
  const list = useAsync((signal) => admin.audit.list(toQuery(applied), page, PAGE_SIZE, signal), [applied, page]);
  const rangeInvalid = form.from !== '' && form.to !== '' && form.from > form.to;
  const set = <K extends keyof Filters>(k: K, v: Filters[K]) => setForm({ ...form, [k]: v });

  function search(e: FormEvent) { e.preventDefault(); if (rangeInvalid) return; setPage(1); setApplied({ ...form }); }
  function clear() { setForm(NONE); setApplied(NONE); setPage(1); }

  return (
    <div className="stack">
      <h1 style={{ margin: 0 }}>{t('aud.title')}</h1>
      <p className="muted" style={{ margin: 0 }}>{t('aud.intro')}</p>
      <form onSubmit={search} className="stack" aria-label={t('aud.filter.legend')} noValidate>
        <div className="toolbar">
          <TextField label={t('aud.filter.action')} hint={t('aud.filter.action.hint')} dir="ltr" maxLength={80} value={form.action} onChange={(e) => set('action', e.target.value)} />
          <TextField label={t('aud.filter.entityType')} dir="ltr" maxLength={60} value={form.entityType} onChange={(e) => set('entityType', e.target.value)} />
          <TextField label={t('aud.filter.entityId')} dir="ltr" maxLength={80} value={form.entityId} onChange={(e) => set('entityId', e.target.value)} />
          <TextField label={t('aud.filter.actorId')} dir="ltr" maxLength={80} value={form.actorId} onChange={(e) => set('actorId', e.target.value)} />
        </div>
        <div className="toolbar">
          <SelectField label={t('aud.filter.outcome')} value={form.outcome} onChange={(e) => set('outcome', e.target.value as Filters['outcome'])}>
            <option value="">{t('aud.filter.outcome.all')}</option>
            <option value="success">{t(OUTCOME.success)}</option>
            <option value="failure">{t(OUTCOME.failure)}</option>
            <option value="denied">{t(OUTCOME.denied)}</option>
          </SelectField>
          <TextField label={t('aud.filter.from')} type="date" value={form.from} onChange={(e) => set('from', e.target.value)} />
          <TextField label={t('aud.filter.to')} type="date" value={form.to} onChange={(e) => set('to', e.target.value)} error={rangeInvalid ? t('aud.filter.rangeInvalid') : undefined} />
          <Button type="submit" disabled={rangeInvalid}>{t('common.search')}</Button>
          <Button variant="ghost" onClick={clear}>{t('common.clear')}</Button>
        </div>
      </form>

      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data ? <p aria-live="polite" className="muted">{i18n.tn('admin.results', list.data.meta.total)}</p> : null}
      {list.data && list.data.data.length === 0 ? <EmptyState>{t('aud.empty')}</EmptyState> : null}
      {list.data && list.data.data.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead><tr>
              <th scope="col">{t('aud.col.time')}</th><th scope="col">{t('aud.col.actor')}</th><th scope="col">{t('aud.col.action')}</th>
              <th scope="col">{t('aud.col.record')}</th><th scope="col">{t('aud.col.result')}</th><th scope="col">{t('aud.col.details')}</th>
            </tr></thead>
            <tbody>
              {list.data.data.map((e) => (
                <tr key={e.id}>
                  <td>{i18n.instant(e.occurredAt, CENTER_ZONE)}</td>
                  <td>{t(ACTOR[e.actorType] ?? 'aud.actor.system')}{e.actorId ? <> <span className="ltr muted">{e.actorId}</span></> : null}</td>
                  <td><span className="ltr">{e.action}</span></td>
                  <td>{e.entityType ? <span className="ltr">{e.entityType}{e.entityId ? ` · ${e.entityId}` : ''}</span> : <span className="muted">{t('common.none')}</span>}</td>
                  <td><span className={OUTCOME_BADGE[e.outcome] ?? 'badge'}>{t(OUTCOME[e.outcome] ?? 'aud.outcome.failure')}</span></td>
                  <td><Details event={e} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      <Pagination meta={list.data?.meta} onPage={setPage} />
    </div>
  );
}

/** The recorded metadata, shown as plain text (never interpreted as markup), with the address it came from. */
function Details({ event }: { event: AuditEvent }) {
  const t = useT();
  const empty = Object.keys(event.metadata ?? {}).length === 0;
  if (empty && !event.ip) return <span className="muted">{t('aud.details.none')}</span>;
  return (
    <details>
      <summary>{t('aud.details.show')}</summary>
      {event.ip ? <p className="ltr" style={{ margin: 0 }}>{t('aud.ip', { ip: event.ip })}</p> : null}
      {empty ? null : <pre className="ltr" style={{ margin: 0, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{JSON.stringify(event.metadata, null, 2)}</pre>}
    </details>
  );
}
