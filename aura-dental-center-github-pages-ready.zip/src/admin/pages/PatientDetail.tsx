import { useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Alert, Button, EmptyState, Loading, SelectField, StatusBadge, TextField } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { LOCALES, type Locale } from '../../shared/api/types.js';
import { LOCALE_META } from '../../shared/i18n/types.js';
import { admin } from '../api/index.js';
import type { AdminPatient } from '../api/types.js';
import { ConfirmDialog } from '../components/ConfirmDialog.js';
import { useAction } from '../lib/useAction.js';
import { useT } from '../i18n/useT.js';
import { MedicalRecords } from './patients/MedicalRecords.js';
import { ResetPasswordDialog } from './patients/ResetPasswordDialog.js';
import { CENTER_ZONE, formErrors } from './patients/shared.js';

const BY_CODE = { INVALID_PHONE: 'phone', PHONE_ALREADY_REGISTERED: 'phone' };

export function PatientDetail() {
  const t = useT();
  const i18n = useI18n();
  const { id = '' } = useParams();
  const state = useAsync((signal) => admin.patients.get(id, signal), [id]);
  const p = state.data;
  const [notice, setNotice] = useState<string | null>(null);

  if (!p) {
    return (
      <div className="stack">
        <p><Link to="/patients">{t('pat.back')}</Link></p>
        {state.status === 'error'
          ? <Alert tone="error">{t('pat.loadFailed')} {errorText(i18n, state.error)} <Button small variant="secondary" onClick={state.reload}>{t('common.retry')}</Button></Alert>
          : <Loading />}
      </div>
    );
  }
  const done = (m: string) => { setNotice(m); state.reload(); };
  return (
    <div className="stack">
      <p><Link to="/patients">{t('pat.back')}</Link></p>
      <h1>{p.fullName}</h1>
      {notice ? <Alert tone="success">{notice}</Alert> : null}
      <div className="two-col">
        <Profile patient={p} onSaved={() => done(t('pat.profile.saved'))} />
        <Account patient={p} onChanged={done} />
      </div>
      <Appointments patientId={p.id} />
      <MedicalRecords patientId={p.id} />
    </div>
  );
}

function Profile({ patient: p, onSaved }: { patient: AdminPatient; onSaved: () => void }) {
  const t = useT();
  const i18n = useI18n();
  const [fullName, setFullName] = useState(p.fullName);
  const [phone, setPhone] = useState(p.phone);
  const [language, setLanguage] = useState<'' | Locale>(p.preferredLocale ?? '');
  const save = useAction(() => {
    const changes = {
      ...(fullName.trim() !== p.fullName ? { fullName: fullName.trim() } : {}),
      ...(phone.trim() !== p.phone ? { phone: phone.trim() } : {}),
      ...((language || null) !== p.preferredLocale ? { preferredLocale: language || null } : {}),
    };
    return admin.patients.update(p.id, changes);
  });
  async function submit(e: FormEvent) { e.preventDefault(); if (await save.attempt()) onSaved(); }
  const { fields, rest } = formErrors(i18n, save.error, BY_CODE);
  return (
    <form onSubmit={submit} className="card stack" noValidate aria-labelledby="pat-profile">
      <h2 id="pat-profile">{t('pat.profile.title')}</h2>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <TextField label={t('pat.field.fullName')} value={fullName} onChange={(e) => setFullName(e.target.value)} error={fields.fullName} />
      <TextField label={t('pat.field.phone')} type="tel" dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} error={fields.phone} />
      <SelectField label={t('pat.field.language')} value={language} onChange={(e) => setLanguage(e.target.value as '' | Locale)}>
        <option value="">{t('pat.language.none')}</option>
        {LOCALES.map((l) => <option key={l} value={l} lang={l}>{LOCALE_META[l].nativeName}</option>)}
      </SelectField>
      <div className="row"><Button type="submit" loading={save.busy} disabled={!fullName.trim() || !phone.trim()}>{t('pat.profile.save')}</Button></div>
    </form>
  );
}

function Account({ patient: p, onChanged }: { patient: AdminPatient; onChanged: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const [dialog, setDialog] = useState<'deactivate' | 'reset' | 'telegram' | null>(null);
  const toggle = useAction((isActive: boolean) => admin.patients.update(p.id, { isActive }));
  const unlink = useAction(() => admin.patients.revokeTelegram(p.id));
  const close = () => { setDialog(null); toggle.reset(); unlink.reset(); };

  return (
    <section className="card stack" aria-labelledby="pat-account">
      <h2 id="pat-account">{t('pat.account.title')}</h2>
      <p style={{ margin: 0 }}><span className={p.isActive ? 'badge badge--completed' : 'badge badge--cancelled'}>{p.isActive ? t('pat.active') : t('pat.inactive')}</span></p>
      <p className="muted" style={{ margin: 0 }}>{t('pat.account.created', { when: i18n.instant(p.createdAt, CENTER_ZONE) })}</p>
      <p className="muted" style={{ margin: 0 }}>{t('pat.account.lastLogin', { when: p.lastLoginAt ? i18n.instant(p.lastLoginAt, CENTER_ZONE) : t('pat.never') })}</p>
      <div className="row">
        <Button variant="secondary" onClick={() => setDialog('reset')}>{t('pat.reset.button')}</Button>
        {p.isActive
          ? <Button variant="danger" onClick={() => setDialog('deactivate')}>{t('pat.deactivate')}</Button>
          : <Button variant="secondary" loading={toggle.busy} onClick={async () => { if (await toggle.attempt(true)) onChanged(t('pat.reactivated')); }}>{t('pat.reactivate')}</Button>}
      </div>
      {toggle.error && dialog === null ? <Alert tone="error">{errorText(i18n, toggle.error)}</Alert> : null}

      <h3>{t('pat.telegram.title')}</h3>
      <p style={{ margin: 0 }}>{p.telegramLinked ? t('pat.telegram.linked') : t('pat.telegram.notLinked')}</p>
      {p.telegramLinked ? <div className="row"><Button variant="secondary" onClick={() => setDialog('telegram')}>{t('pat.telegram.unlink')}</Button></div> : null}

      <ConfirmDialog open={dialog === 'deactivate'} title={t('pat.deactivate.title')} confirmLabel={t('pat.deactivate.confirm')} danger busy={toggle.busy} error={toggle.error}
        onClose={close} onConfirm={async () => { if (await toggle.attempt(false)) { close(); onChanged(t('pat.deactivated')); } }}>
        <p>{t('pat.deactivate.text')}</p>
      </ConfirmDialog>
      <ConfirmDialog open={dialog === 'telegram'} title={t('pat.telegram.unlink.title')} confirmLabel={t('pat.telegram.unlink.confirm')} danger busy={unlink.busy} error={unlink.error}
        onClose={close} onConfirm={async () => { if (await unlink.attempt()) { close(); onChanged(t('pat.telegram.unlinked')); } }}>
        <p>{t('pat.telegram.unlink.text')}</p>
      </ConfirmDialog>
      <ResetPasswordDialog open={dialog === 'reset'} patientId={p.id} onClose={close} onDone={() => onChanged(t('pat.reset.done'))} />
    </section>
  );
}

function Appointments({ patientId }: { patientId: string }) {
  const t = useT();
  const i18n = useI18n();
  const list = useAsync((signal) => admin.appointments.list({ patientId, sort: 'desc' }, i18n.locale, 1, 10, signal), [patientId, i18n.locale]);
  return (
    <section className="stack" aria-labelledby="pat-appts">
      <h2 id="pat-appts">{t('pat.appts.title')}</h2>
      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data && list.data.data.length === 0 ? <EmptyState>{t('pat.appts.empty')}</EmptyState> : null}
      {list.data && list.data.data.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">{t('admin.col.date')}</th><th scope="col">{t('admin.col.time')}</th><th scope="col">{t('admin.col.department')}</th><th scope="col">{t('admin.col.status')}</th></tr></thead>
            <tbody>
              {list.data.data.map((a) => (
                <tr key={a.id}><td>{i18n.date(a.date, 'short')}</td><td>{i18n.range(a.startTime, a.endTime)}</td><td>{a.department.name}</td><td><StatusBadge status={a.status} /></td></tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      {list.data && list.data.meta.total > list.data.data.length ? <p className="muted">{t('pat.appts.more', { shown: list.data.data.length, total: list.data.meta.total })}</p> : null}
    </section>
  );
}
