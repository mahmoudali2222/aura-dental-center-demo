import { useI18n } from '../../shared/i18n/I18nProvider.js';
import type { AdminKey } from './messages.js';

/** Typed translation function: an unknown key is a compile error. (Formatting helpers come from useI18n().) */
export function useT() {
  return useI18n<AdminKey>().t;
}
