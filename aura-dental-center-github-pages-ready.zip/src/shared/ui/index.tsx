import { forwardRef, useEffect, useId, useRef, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';
import { LOCALES, type Locale } from '../api/types.js';
import { useI18n } from '../i18n/I18nProvider.js';
import { LOCALE_META } from '../i18n/types.js';

/** Neutral, accessible building blocks. Styling lives in styles/*.css and uses design tokens only. */

export function Spinner({ label }: { label?: string }) {
  return <span role="status" aria-live="polite"><span className="spinner" aria-hidden="true" />{label ? <span className="visually-hidden">{label}</span> : null}</span>;
}

export function Loading() {
  const { t } = useI18n();
  return <p role="status" aria-live="polite" className="muted"><span className="spinner" aria-hidden="true" /> {t('common.loading')}</p>;
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; small?: boolean; loading?: boolean };

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button({ variant = 'primary', small, loading, disabled, className, children, type = 'button', ...rest }, ref) {
  const cls = ['btn', variant !== 'primary' ? `btn--${variant}` : '', small ? 'btn--small' : '', className ?? ''].filter(Boolean).join(' ');
  return (
    <button ref={ref} type={type} className={cls} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading ? <span className="spinner" aria-hidden="true" /> : null}
      {children}
    </button>
  );
});

type Tone = 'error' | 'success' | 'info' | 'warning';
export function Alert({ tone = 'info', children, title }: { tone?: Tone; children: ReactNode; title?: string }) {
  // errors interrupt screen readers, everything else is announced politely
  return (
    <div className={`alert alert--${tone}`} role={tone === 'error' ? 'alert' : 'status'}>
      {title ? <strong>{title}</strong> : null}
      {title ? ' ' : null}
      {children}
    </div>
  );
}

interface FieldShell { label: string; hint?: string; error?: string; optional?: boolean }

function describedBy(id: string, hint?: string, error?: string): string | undefined {
  const ids = [hint ? `${id}-hint` : '', error ? `${id}-error` : ''].filter(Boolean);
  return ids.length ? ids.join(' ') : undefined;
}

function FieldFrame({ id, label, hint, error, optional, children }: FieldShell & { id: string; children: ReactNode }) {
  const { t } = useI18n();
  return (
    <div className="field">
      <label htmlFor={id}>{label}{optional ? <span className="muted"> ({t('common.optional')})</span> : null}</label>
      {children}
      {hint ? <span id={`${id}-hint`} className="field__hint">{hint}</span> : null}
      {error ? <span id={`${id}-error`} className="field__error">{error}</span> : null}
    </div>
  );
}

export const TextField = forwardRef<HTMLInputElement, FieldShell & InputHTMLAttributes<HTMLInputElement>>(function TextField({ label, hint, error, optional, ...rest }, ref) {
  const id = useId();
  return (
    <FieldFrame id={id} label={label} hint={hint} error={error} optional={optional}>
      <input ref={ref} id={id} aria-invalid={error ? true : undefined} aria-describedby={describedBy(id, hint, error)} {...rest} />
    </FieldFrame>
  );
});

export function SelectField({ label, hint, error, optional, children, ...rest }: FieldShell & SelectHTMLAttributes<HTMLSelectElement>) {
  const id = useId();
  return (
    <FieldFrame id={id} label={label} hint={hint} error={error} optional={optional}>
      <select id={id} aria-invalid={error ? true : undefined} aria-describedby={describedBy(id, hint, error)} {...rest}>{children}</select>
    </FieldFrame>
  );
}

export function TextAreaField({ label, hint, error, optional, ...rest }: FieldShell & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const id = useId();
  return (
    <FieldFrame id={id} label={label} hint={hint} error={error} optional={optional}>
      <textarea id={id} aria-invalid={error ? true : undefined} aria-describedby={describedBy(id, hint, error)} {...rest} />
    </FieldFrame>
  );
}

/** Language selector. Each language is named in itself so a visitor can always find theirs. No account needed. */
export function LanguageSwitcher() {
  const { locale, setLocale, t } = useI18n();
  const id = useId();
  return (
    <div className="row">
      <label htmlFor={id} className="visually-hidden">{t('lang.label')}</label>
      <select id={id} value={locale} onChange={(e) => setLocale(e.target.value as Locale)} style={{ minBlockSize: '2.25rem' }}>
        {LOCALES.map((l) => <option key={l} value={l} lang={l}>{LOCALE_META[l].nativeName}</option>)}
      </select>
    </div>
  );
}

/** Modal built on the native <dialog>: focus is trapped, Escape closes it, and focus returns to the opener. */
export function Dialog({ open, title, onClose, children }: { open: boolean; title: string; onClose: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) (d.showModal ? d.showModal() : d.setAttribute('open', ''));
    if (!open && d.open) (d.close ? d.close() : d.removeAttribute('open'));
  }, [open]);
  return (
    <dialog ref={ref} aria-labelledby={titleId} onClose={onClose} onCancel={(e) => { e.preventDefault(); onClose(); }}>
      <h2 id={titleId}>{title}</h2>
      {open ? children : null}
    </dialog>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return <span className={`badge badge--${status}`}>{t(`status.${status}`) || status}</span>;
}

export function EmptyState({ children }: { children: ReactNode }) {
  return <p className="muted card" style={{ textAlign: 'center' }}>{children}</p>;
}

/**
 * Image referenced by a site-relative /assets/... path. If the file has not been supplied yet (see docs/IMAGE_ASSETS.md) it is
 * simply not shown; a placeholder is never presented as a real photograph.
 */
export function AssetImage({ src, alt, className, width, height }: { src: string | null | undefined; alt: string; className?: string; width?: number; height?: number }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  if (!src || failed) return null;
  return <img src={src} alt={alt} className={className} width={width} height={height} loading="lazy" decoding="async" onError={() => setFailed(true)} />;
}
