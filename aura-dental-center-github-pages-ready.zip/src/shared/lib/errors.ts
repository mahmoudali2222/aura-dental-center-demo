import { ApiError } from '../api/http.js';
import type { I18n } from '../i18n/I18nProvider.js';
import { toApiError } from './useAsync.js';

/**
 * Turns anything thrown by an API call into text in the user's language. The backend's `message` is for developers and is
 * never shown. `overrides` lets a form give one code a more specific meaning (e.g. INVALID_CREDENTIALS on "change password").
 */
export function errorText(i18n: I18n, err: unknown, overrides: Record<string, string> = {}): string {
  const e = toApiError(err);
  const key = overrides[e.code] ?? `err.${e.code}`;
  return i18n.t(key) || (e.status >= 500 ? i18n.t('err.INTERNAL_ERROR') : i18n.t('err.generic'));
}

/** Per-field messages from a VALIDATION_ERROR answer: { phone: "Enter a valid phone…" }. First issue per field wins. */
export function fieldErrors(i18n: I18n, err: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (!(err instanceof ApiError)) return out;
  for (const issue of err.fieldIssues) {
    if (out[issue.field]) continue;
    out[issue.field] = i18n.t(`err.${issue.code}`) || i18n.t('err.VALIDATION_ERROR');
  }
  return out;
}
