import { LOCALES, type Locale } from '../api/types.js';

export function isLocale(value: unknown): value is Locale {
  return typeof value === 'string' && (LOCALES as readonly string[]).includes(value);
}

/** "fr-CA" -> "fr", "AR" -> "ar"; anything unsupported -> null. */
export function baseLocale(tag: string | null | undefined): Locale | null {
  const base = (tag ?? '').toLowerCase().split(/[-_]/)[0];
  return isLocale(base) ? base : null;
}

export interface DetectInput {
  /** Explicit choice stored in this browser. */
  stored?: string | null;
  /** The signed-in patient's saved preference. */
  account?: string | null;
  /** navigator.languages, in order of preference. */
  browser?: readonly string[];
  /** The center's default language, once known. */
  centerDefault?: string | null;
}

/**
 * Language policy (documented in docs/FRONTEND.md):
 *   explicit choice in this browser > signed-in account preference > browser language > center default > Arabic.
 * Nobody has to sign up to change the language.
 */
export function detectLocale(i: DetectInput): Locale {
  const stored = baseLocale(i.stored);
  if (stored) return stored;
  const account = baseLocale(i.account);
  if (account) return account;
  for (const tag of i.browser ?? []) {
    const l = baseLocale(tag);
    if (l) return l;
  }
  return baseLocale(i.centerDefault) ?? 'ar';
}
