import type { Locale } from '../api/types.js';
import { LOCALE_META } from './types.js';

/** Interpolates {name} placeholders. Unknown placeholders are left empty, never printed as "{name}". */
export function interpolate(template: string, vars?: Record<string, string | number>): string {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (_, k: string) => (k in vars ? String(vars[k]) : ''));
}

const dtfCache = new Map<string, Intl.DateTimeFormat>();
function dtf(locale: Locale, options: Intl.DateTimeFormatOptions): Intl.DateTimeFormat {
  const key = `${locale}|${JSON.stringify(options)}`;
  let f = dtfCache.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat(LOCALE_META[locale].tag, options);
    dtfCache.set(key, f);
  }
  return f;
}

const DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/;

/** A calendar date ("2026-11-10") carries no time zone: format it as the same calendar day for everyone. */
function plainDateToUtc(date: string): Date | null {
  const m = DATE_RE.exec(date);
  if (!m) return null;
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  return Number.isNaN(d.getTime()) ? null : d;
}

export function formatDate(date: string, locale: Locale, style: 'short' | 'long' | 'weekday' = 'long'): string {
  const d = plainDateToUtc(date);
  if (!d) return date;
  const options: Intl.DateTimeFormatOptions =
    style === 'short' ? { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'UTC' }
    : style === 'weekday' ? { weekday: 'long', timeZone: 'UTC' }
    : { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' };
  return dtf(locale, options).format(d);
}

/** Wall-clock "HH:mm" as the center states it, shown the way the language prefers (12 h in ar/en, 24 h in fr). */
export function formatClock(hhmm: string, locale: Locale): string {
  const m = /^(\d{1,2}):(\d{2})$/.exec(hhmm);
  if (!m) return hhmm;
  const d = new Date(Date.UTC(2000, 0, 1, Number(m[1]), Number(m[2])));
  const options: Intl.DateTimeFormatOptions = LOCALE_META[locale].hour12
    ? { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: 'UTC' }
    : { hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: 'UTC' }; // "00:00", never "0:00" or "24:00"
  return dtf(locale, options).format(d);
}

export function formatTimeRange(start: string, end: string, locale: Locale): string {
  return `${formatClock(start, locale)} – ${formatClock(end, locale)}`;
}

/** An instant (e.g. a cancellation deadline) shown in the center's time zone, never the browser's. */
export function formatInstant(iso: string, locale: Locale, timeZone: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const clock: Intl.DateTimeFormatOptions = LOCALE_META[locale].hour12
    ? { hour: 'numeric', minute: '2-digit', hour12: true }
    : { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }; // "09:00" and "00:00", never "9:00" or "24:00"
  return dtf(locale, { weekday: 'short', day: 'numeric', month: 'short', ...clock, timeZone }).format(d);
}

export function formatPrice(amount: number, currency: string, locale: Locale): string {
  try {
    return new Intl.NumberFormat(LOCALE_META[locale].tag, { style: 'currency', currency, maximumFractionDigits: 2 }).format(amount);
  } catch {
    return `${amount} ${currency}`;
  }
}

/** ISO weekday (1 = Monday ... 7 = Sunday) as a localized day name. 2026-11-02 is a Monday. */
export function weekdayName(isoWeekday: number, locale: Locale, width: 'long' | 'short' = 'long'): string {
  return dtf(locale, { weekday: width, timeZone: 'UTC' }).format(new Date(Date.UTC(2026, 10, 1 + isoWeekday)));
}

/** Phone numbers stay left-to-right inside right-to-left text. */
export function isolateLtr(text: string): string {
  return `⁦${text}⁩`;
}

export function pluralCategory(count: number, locale: Locale): Intl.LDMLPluralRule {
  return new Intl.PluralRules(LOCALE_META[locale].tag).select(count);
}

/** "Mon, Tue and Wed" in the language's own list style. */
export function formatList(items: string[], locale: Locale): string {
  return new Intl.ListFormat(LOCALE_META[locale].tag, { style: 'short', type: 'conjunction' }).format(items);
}
