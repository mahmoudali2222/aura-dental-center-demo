import { createContext, useCallback, useContext, useLayoutEffect, useMemo, useState, type ReactNode } from 'react';
import type { Locale } from '../api/types.js';
import { LOCALES } from '../api/types.js';
import { detectLocale } from './detect.js';
import { formatClock, formatDate, formatInstant, formatList, formatPrice, formatTimeRange, interpolate, pluralCategory, weekdayName } from './format.js';
import { LOCALE_META, type Dict, type Messages } from './types.js';

export interface I18n<K extends string = string> {
  locale: Locale;
  dir: 'ltr' | 'rtl';
  setLocale: (l: Locale) => void;
  /** Looks a message up. Falls back to English, then to an empty string: an internal key is never shown to a user. */
  t: (key: K, vars?: Record<string, string | number>) => string;
  /** Plural-aware lookup: uses `${key}_${category}` for the language's CLDR category, falling back to `${key}_other`. */
  tn: (key: string, count: number, vars?: Record<string, string | number>) => string;
  date: (isoDate: string, style?: 'short' | 'long' | 'weekday') => string;
  clock: (hhmm: string) => string;
  range: (start: string, end: string) => string;
  instant: (iso: string, timeZone: string) => string;
  price: (amount: number, currency: string) => string;
  weekday: (isoWeekday: number, width?: 'long' | 'short') => string;
  list: (items: string[]) => string;
}

const Ctx = createContext<I18n | null>(null);

export interface I18nProviderProps {
  messages: Messages;
  /** localStorage key that remembers the choice in this browser. */
  storageKey: string;
  /** Preference of the signed-in user (patients only). */
  accountLocale?: string | null;
  /** The center's default language, once loaded. */
  centerDefault?: string | null;
  children: ReactNode;
}

function readStored(key: string): string | null {
  try { return localStorage.getItem(key); } catch { return null; }
}
function writeStored(key: string, value: string): void {
  try { localStorage.setItem(key, value); } catch { /* private mode: the choice just will not persist */ }
}

export function I18nProvider({ messages, storageKey, accountLocale, centerDefault, children }: I18nProviderProps) {
  // An explicit choice made in this browser wins over everything else and survives reloads.
  const [explicit, setExplicit] = useState<Locale | null>(() => {
    const s = readStored(storageKey);
    return (LOCALES as readonly string[]).includes(s ?? '') ? (s as Locale) : null;
  });
  const locale = detectLocale({ stored: explicit, account: accountLocale, browser: typeof navigator !== 'undefined' ? navigator.languages : [], centerDefault });
  const dir = LOCALE_META[locale].dir;

  // Keep <html lang dir> in sync: this is what makes the browser lay the whole page out right-to-left for Arabic.
  useLayoutEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
  }, [locale, dir]);

  const setLocale = useCallback((l: Locale) => {
    writeStored(storageKey, l);
    setExplicit(l);
  }, [storageKey]);

  const value = useMemo<I18n>(() => {
    const lookup = (key: string): string | undefined => (messages[locale] as Dict)[key] ?? (messages.en as Dict)[key];
    return {
      locale,
      dir,
      setLocale,
      t: (key, vars) => interpolate(lookup(key) ?? '', vars),
      tn: (key, count, vars) => {
        const cat = pluralCategory(count, locale);
        const template = lookup(`${key}_${cat}`) ?? lookup(`${key}_other`) ?? '';
        return interpolate(template, { count, ...vars });
      },
      date: (d, style) => formatDate(d, locale, style),
      clock: (h) => formatClock(h, locale),
      range: (a, b) => formatTimeRange(a, b, locale),
      instant: (iso, tz) => formatInstant(iso, locale, tz),
      price: (amount, currency) => formatPrice(amount, currency, locale),
      weekday: (n, w) => weekdayName(n, locale, w),
      list: (items) => formatList(items, locale),
    };
  }, [messages, locale, dir, setLocale]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n<K extends string = string>(): I18n<K> {
  const v = useContext(Ctx);
  if (!v) throw new Error('useI18n must be used inside <I18nProvider>');
  return v as unknown as I18n<K>;
}
