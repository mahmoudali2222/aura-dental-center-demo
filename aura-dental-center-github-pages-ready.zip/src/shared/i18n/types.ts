import type { Locale } from '../api/types.js';

export type Dict = Record<string, string>;

/**
 * Message bundles are written as { en, ar, fr }. English is the source of truth: the type of `ar` and `fr` is derived from
 * the keys of `en`, so a missing or misspelled key in any language is a compile error, not a blank label in production.
 */
export interface MessageBundle<T extends Dict> {
  en: T;
  ar: Record<keyof T & string, string>;
  fr: Record<keyof T & string, string>;
}

export function defineMessages<const T extends Dict>(bundle: MessageBundle<T>): MessageBundle<T> {
  return bundle;
}

export type Messages = Record<Locale, Dict>;

export interface LocaleMeta {
  /** BCP 47 tag used for Intl formatting. Arabic uses Latin digits on purpose (see docs/FRONTEND.md). */
  tag: string;
  dir: 'ltr' | 'rtl';
  /** The language's own name, always shown in that language so a patient can find theirs. */
  nativeName: string;
  hour12: boolean;
}

export const LOCALE_META: Record<Locale, LocaleMeta> = {
  ar: { tag: 'ar-EG-u-nu-latn', dir: 'rtl', nativeName: 'العربية', hour12: true },
  en: { tag: 'en-GB', dir: 'ltr', nativeName: 'English', hour12: true },
  fr: { tag: 'fr-FR', dir: 'ltr', nativeName: 'Français', hour12: false },
};
