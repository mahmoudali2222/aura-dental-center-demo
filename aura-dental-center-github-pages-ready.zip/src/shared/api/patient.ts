import type { HttpClient, PageMeta } from './http.js';
import type { Appointment, Locale, PatientProfile } from './types.js';

export interface PatientSessionResponse {
  patient: PatientProfile;
  csrfToken: string;
}

export interface TelegramStatus {
  linked: boolean;
  linkedAt: string | null;
}

export interface LinkToken {
  code: string;
  expiresAt: string;
  ttlSeconds: number;
}

export interface BookInput {
  departmentId: string;
  serviceId?: string | null;
  date: string;
  slotNumber: number;
  patientNote?: string;
}

export type AppointmentScope = 'upcoming' | 'history' | 'all';

/** Everything a signed-in patient can do. Authorization is the backend's job; the UI only reflects what it answers. */
export function patientApi(http: HttpClient) {
  return {
    register: (input: { fullName: string; phone: string; password: string; locale?: Locale }) => http.post<PatientSessionResponse>('/patient/auth/register', input),
    login: (input: { phone: string; password: string }) => http.post<PatientSessionResponse>('/patient/auth/login', input),
    logout: () => http.post('/patient/auth/logout'),
    me: (signal?: AbortSignal) => http.get<PatientSessionResponse>('/patient/me', { signal }),
    updateProfile: (input: { fullName?: string; preferredLocale?: Locale | null }) => http.patch<{ patient: PatientProfile }>('/patient/me', input),
    changePassword: (input: { currentPassword: string; newPassword: string }) => http.post('/patient/auth/password', input),
    appointments: (scope: AppointmentScope, locale: Locale, page = 1, pageSize = 50, signal?: AbortSignal): Promise<{ data: Appointment[]; meta: PageMeta }> =>
      http.getPaged<Appointment>('/patient/appointments', { query: { scope, locale, page, pageSize }, signal }),
    book: (input: BookInput, locale: Locale) => http.post<Appointment>('/patient/appointments', input, { query: { locale } }),
    cancel: (id: string, locale: Locale) => http.post<Appointment>(`/patient/appointments/${encodeURIComponent(id)}/cancel`, {}, { query: { locale } }),
    reschedule: (id: string, input: { date: string; slotNumber: number }, locale: Locale) =>
      http.post<Appointment>(`/patient/appointments/${encodeURIComponent(id)}/reschedule`, input, { query: { locale } }),
    telegramStatus: (signal?: AbortSignal) => http.get<TelegramStatus>('/patient/telegram', { signal }),
    createTelegramLinkCode: () => http.post<LinkToken>('/patient/telegram/link-token'),
    unlinkTelegram: () => http.del('/patient/telegram'),
  };
}
export type PatientApi = ReturnType<typeof patientApi>;
