import type { HttpClient } from './http.js';

export interface AdminPrincipal {
  id: string;
  username: string;
  fullName: string;
  mustChangePassword: boolean;
}

export interface AdminSessionResponse {
  admin: AdminPrincipal;
  csrfToken: string;
}

/** Admin API calls. Extended page by page in the dashboard modules (see src/admin/api). */
export function adminAuthApi(http: HttpClient) {
  return {
    login: (input: { username: string; password: string }) => http.post<AdminSessionResponse>('/admin/auth/login', input),
    logout: () => http.post('/admin/auth/logout'),
    me: (signal?: AbortSignal) => http.get<AdminSessionResponse>('/admin/auth/me', { signal }),
    changePassword: (input: { currentPassword: string; newPassword: string }) => http.post('/admin/auth/change-password', input),
  };
}
export type AdminAuthApi = ReturnType<typeof adminAuthApi>;
