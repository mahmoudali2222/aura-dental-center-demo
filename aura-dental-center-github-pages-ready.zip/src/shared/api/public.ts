import type { HttpClient } from './http.js';
import type { Availability, CenterInfo, DepartmentDetail, DepartmentSummary, GalleryCase, Locale } from './types.js';

/** Public, unauthenticated content. `locale` selects the content language; the backend applies the documented fallback chain. */
export function publicApi(http: HttpClient) {
  return {
    center: (locale: Locale, signal?: AbortSignal) => http.get<CenterInfo>('/public/center', { query: { locale }, signal }),
    departments: (locale: Locale, signal?: AbortSignal) => http.get<DepartmentSummary[]>('/public/departments', { query: { locale }, signal }),
    department: (slug: string, locale: Locale, signal?: AbortSignal) => http.get<DepartmentDetail>(`/public/departments/${encodeURIComponent(slug)}`, { query: { locale }, signal }),
    availability: (slug: string, range: { from?: string; to?: string } = {}, signal?: AbortSignal) =>
      http.get<Availability>(`/public/departments/${encodeURIComponent(slug)}/availability`, { query: range, signal }),
    gallery: (locale: Locale, department?: string, signal?: AbortSignal) => http.get<GalleryCase[]>('/public/gallery', { query: { locale, department }, signal }),
  };
}
export type PublicApi = ReturnType<typeof publicApi>;
