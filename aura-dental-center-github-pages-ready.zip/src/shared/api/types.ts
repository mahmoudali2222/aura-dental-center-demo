/** Shapes returned by the backend (see docs/API_REFERENCE.md). Only what the frontends use is listed here. */
export type Locale = 'ar' | 'en' | 'fr';
export const LOCALES: readonly Locale[] = ['ar', 'en', 'fr'] as const;

export interface SlotTemplate {
  slotNumber: number;
  startTime: string;
  endTime: string;
  endsNextDay: boolean;
}

export interface CenterInfo {
  name: string;
  address: string;
  addressConfigured: boolean;
  introduction: string;
  hoursNote: string;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  mapUrl: string | null;
  timezone: string;
  currency: string;
  defaultLocale: Locale;
  workingDays: number[];
  bookingHorizonDays: number;
  slots: SlotTemplate[];
  locales: Locale[];
}

export interface PublicDentist {
  id: string;
  name: string;
  bio: string;
  photoPath: string | null;
  isSample: boolean;
}

export interface DepartmentSummary {
  id: string;
  slug: string;
  name: string;
  description: string;
  imagePath: string | null;
  dentist: PublicDentist | null;
  serviceCount: number;
  bookable: boolean;
  /** ISO weekdays (1 = Monday ... 7 = Sunday) this department works; patients can book only on these days. */
  workingDays: number[];
}

export interface PublicService {
  id: string;
  name: string;
  description: string;
  price: number | null;
  currency: string | null;
  imagePath: string | null;
  isSample: boolean;
}

export interface GalleryCase {
  id: string;
  departmentSlug: string;
  serviceId: string | null;
  beforeImagePath: string | null;
  afterImagePath: string | null;
  caseKind: 'real' | 'sample';
  isSample: boolean;
  title: string;
  description: string;
  altBefore: string;
  altAfter: string;
}

export interface DepartmentDetail {
  id: string;
  slug: string;
  name: string;
  description: string;
  imagePath: string | null;
  dentist: PublicDentist | null;
  bookable: boolean;
  workingDays: number[];
  services: PublicService[];
  gallery: GalleryCase[];
}

export interface AvailableSlot {
  slotNumber: number;
  startTime: string;
  endTime: string;
  endsNextDay: boolean;
  startsAt: string;
  endsAt: string;
}

export type DayStatus = 'open' | 'full' | 'closed' | 'past' | 'beyond_horizon' | 'unavailable';

export interface AvailabilityDay {
  date: string;
  status: DayStatus;
  availableCount: number;
  slots: AvailableSlot[];
}

export interface Availability {
  department: { id: string; slug: string };
  timezone: string;
  from: string;
  to: string;
  days: AvailabilityDay[];
}

export type AppointmentStatus = 'booked' | 'completed' | 'cancelled' | 'no_show';

export interface SelfService {
  canCancel: boolean;
  canReschedule: boolean;
  deadline: string | null;
  blockedReason: string | null;
}

export interface Appointment {
  id: string;
  status: AppointmentStatus;
  department: { id: string; slug: string; name: string };
  dentist: { id: string; name: string } | null;
  service: { id: string; name: string } | null;
  date: string;
  slotNumber: number;
  startsAt: string;
  endsAt: string;
  startTime: string;
  endTime: string;
  endsNextDay: boolean;
  patientNote: string | null;
  createdVia: 'web' | 'admin' | 'telegram';
  rescheduledCount: number;
  cancelledAt: string | null;
  cancelledBy: 'patient' | 'admin' | 'telegram' | null;
  selfService: SelfService;
  /** Only present in admin responses. */
  patient?: { id: string; fullName: string; phone: string };
  cancelReason?: string | null;
}

export interface PatientProfile {
  id: string;
  fullName: string;
  phone: string;
  preferredLocale: Locale | null;
}

export interface Session<U> {
  csrfToken: string;
  user: U;
}
