import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { HttpClient } from '../api/http.js';
import { ApiError } from '../api/http.js';

export type SessionStatus = 'loading' | 'anonymous' | 'authenticated';

export interface SessionPayload<U> {
  user: U;
  csrfToken: string;
}

export interface SessionConfig<U, L> {
  http: HttpClient;
  /** Restores the session after a page reload (the HttpOnly cookie is sent automatically). */
  restore: (signal: AbortSignal) => Promise<SessionPayload<U>>;
  login: (input: L) => Promise<SessionPayload<U>>;
  logout: () => Promise<unknown>;
}

export interface SessionValue<U, L> {
  status: SessionStatus;
  user: U | null;
  /** True when the session ended on its own (expired, revoked) rather than because the user signed out. */
  expired: boolean;
  login: (input: L) => Promise<U>;
  /** For flows that sign in as a side effect (patient registration). */
  adopt: (payload: SessionPayload<U>) => void;
  update: (user: U) => void;
  logout: () => Promise<void>;
}

/**
 * Builds the provider + hook pair for one kind of session. The CSRF token is held in memory only and handed to the HTTP
 * client; the session cookie itself is HttpOnly and never visible to scripts.
 */
export function createSession<U, L>(config: SessionConfig<U, L>) {
  const Ctx = createContext<SessionValue<U, L> | null>(null);

  function SessionProvider({ children }: { children: ReactNode }) {
    const [status, setStatus] = useState<SessionStatus>('loading');
    const [user, setUser] = useState<U | null>(null);
    const [expired, setExpired] = useState(false);
    const statusRef = useRef(status);
    statusRef.current = status;

    const adopt = useCallback((p: SessionPayload<U>) => {
      config.http.setCsrfToken(p.csrfToken);
      setUser(p.user);
      setStatus('authenticated');
      setExpired(false);
    }, []);

    const clear = useCallback(() => {
      config.http.setCsrfToken(null);
      setUser(null);
      setStatus('anonymous');
    }, []);

    useEffect(() => {
      config.http.onSessionLost(() => {
        if (statusRef.current === 'authenticated') setExpired(true);
        clear();
      });
      const controller = new AbortController();
      config.restore(controller.signal).then(
        (p) => { if (!controller.signal.aborted) adopt(p); },
        (err: unknown) => {
          if (controller.signal.aborted) return;
          // 401 simply means "not signed in". Any other failure also leaves the visitor anonymous; protected calls will report it.
          void (err instanceof ApiError);
          clear();
        },
      );
      return () => { controller.abort(); config.http.onSessionLost(null); };
    }, [adopt, clear]);

    const login = useCallback(async (input: L) => {
      const p = await config.login(input);
      adopt(p);
      return p.user;
    }, [adopt]);

    const logout = useCallback(async () => {
      try { await config.logout(); } finally { clear(); setExpired(false); }
    }, [clear]);

    const value = useMemo<SessionValue<U, L>>(() => ({ status, user, expired, login, adopt, update: setUser, logout }), [status, user, expired, login, adopt, logout]);
    return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
  }

  function useSession(): SessionValue<U, L> {
    const v = useContext(Ctx);
    if (!v) throw new Error('useSession must be used inside its SessionProvider');
    return v;
  }

  return { SessionProvider, useSession };
}
