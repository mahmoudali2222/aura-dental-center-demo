import { afterEach, describe, expect, it, vi } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { fail, json, ok, startAdminBackend } from './helpers/adminBackend.js';
import { msg, renderAdmin } from './helpers/renderAdmin.js';
import type { AdminDepartment, AdminGalleryCase, AdminService } from '../src/admin/api/types.js';

afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

const lbl = (text: string) => new RegExp(text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
type User = ReturnType<typeof userEvent.setup>;
const noContent = () => new Response(null, { status: 204 });

const dept = (over: Partial<AdminDepartment> = {}): AdminDepartment => ({
  id: 'dep-1', slug: 'endodontics', displayOrder: 1, isActive: true, imagePath: null, workingDays: [1, 2, 3, 4, 5, 6, 7],
  translations: { en: { name: 'Endodontics', description: 'Root canal care' }, ar: { name: 'علاج الجذور', description: '' } },
  dentist: { id: 'dn-1', photoPath: null, isSample: false, translations: { en: { name: 'Dr. Hana Said', bio: '' } } },
  serviceCount: 2, bookable: true, createdAt: '2026-10-01T10:00:00+02:00', updatedAt: '2026-10-01T10:00:00+02:00', ...over,
});
const ortho = () => dept({ id: 'dep-2', slug: 'orthodontics', displayOrder: 2, translations: { en: { name: 'Orthodontics', description: '' } }, dentist: null, bookable: false, serviceCount: 0 });
const service = (over: Partial<AdminService> = {}): AdminService => ({
  id: 's1', departmentId: 'dep-1', price: 350, displayOrder: 1, isActive: true, isSample: true, imagePath: null,
  translations: { en: { name: 'Root canal', description: '' } }, ...over,
});
const galleryCase = (over: Partial<AdminGalleryCase> = {}): AdminGalleryCase => ({
  id: 'g1', departmentId: 'dep-1', departmentSlug: 'endodontics', serviceId: null, beforeImagePath: '/assets/gallery/a-before.jpg', afterImagePath: '/assets/gallery/a-after.jpg',
  caseKind: 'real', consentConfirmed: false, isPublished: false, displayOrder: 1,
  translations: { en: { title: 'Front tooth repair', description: '', altBefore: '', altAfter: '' } }, ...over,
});

function setup(opts: { departments?: AdminDepartment[]; services?: AdminService[]; gallery?: AdminGalleryCase[] } = {}) {
  const api = startAdminBackend();
  const departments = opts.departments ?? [dept(), ortho()];
  const services = opts.services ?? [service(), service({ id: 's2', price: null, isActive: false, isSample: false, displayOrder: 2, translations: { en: { name: 'Whitening', description: '' } } })];
  const gallery = opts.gallery ?? [galleryCase(), galleryCase({ id: 'g2', caseKind: 'sample', isPublished: true, displayOrder: 2, translations: { en: { title: 'Sample whitening', description: '', altBefore: '', altAfter: '' } } })];
  api.route((r) => {
    if (r.method === 'GET' && r.path === '/admin/departments') return ok(departments);
    if (r.method === 'POST' && r.path === '/admin/departments') { const d = dept({ id: 'dep-new', dentist: null, bookable: false, serviceCount: 0, ...r.body }); departments.push(d); return json(201, { data: d }); }
    const dm = /^\/admin\/departments\/([^/]+)$/.exec(r.path);
    if (r.method === 'PATCH' && dm) { const d = departments.find((x) => x.id === dm[1])!; Object.assign(d, r.body); return ok(d); }
    if (r.method === 'POST' && r.path === '/admin/dentists') {
      const d = departments.find((x) => x.id === r.body.departmentId)!;
      d.dentist = { id: 'dn-new', photoPath: r.body.photoPath, isSample: false, translations: r.body.translations }; d.bookable = d.isActive;
      return json(201, { data: { id: 'dn-new', departmentId: d.id, photoPath: r.body.photoPath, isActive: true, isSample: false, translations: r.body.translations } });
    }
    const dn = /^\/admin\/dentists\/([^/]+)$/.exec(r.path);
    if (r.method === 'PATCH' && dn) {
      const d = departments.find((x) => x.dentist?.id === dn[1])!;
      if (r.body.isActive === false) { d.dentist = null; d.bookable = false; } else if (r.body.translations) d.dentist = { ...d.dentist!, translations: r.body.translations, photoPath: r.body.photoPath ?? null };
      return ok({ id: dn[1], departmentId: d.id, photoPath: null, isActive: true, isSample: false, translations: r.body.translations ?? {} });
    }
    if (r.method === 'GET' && r.path === '/admin/settings/center') return ok({ currency: 'EGP', timezone: 'Africa/Cairo', defaultLocale: 'ar', translations: {} });
    if (r.method === 'GET' && r.path === '/admin/services') { const id = r.query.get('departmentId'); return ok(id ? services.filter((s) => s.departmentId === id) : services); }
    if (r.method === 'POST' && r.path === '/admin/services') { const s = service({ id: 's-new', isSample: false, ...r.body }); services.push(s); return json(201, { data: s }); }
    const sm = /^\/admin\/services\/([^/]+)$/.exec(r.path);
    if (r.method === 'PATCH' && sm) { const s = services.find((x) => x.id === sm[1])!; Object.assign(s, r.body); return ok(s); }
    if (r.method === 'GET' && r.path === '/admin/gallery') return ok(gallery);
    if (r.method === 'POST' && r.path === '/admin/gallery') { const g = galleryCase({ id: 'g-new', ...r.body }); gallery.push(g); return json(201, { data: g }); }
    const gm = /^\/admin\/gallery\/([^/]+)$/.exec(r.path);
    if (r.method === 'PATCH' && gm) { const g = gallery.find((x) => x.id === gm[1])!; Object.assign(g, r.body); return ok(g); }
    if (r.method === 'DELETE' && gm) { const i = gallery.findIndex((x) => x.id === gm[1]); if (i >= 0) gallery.splice(i, 1); return noContent(); }
    return undefined;
  });
  return { api, departments, services, gallery };
}

/** The group of fields for one language inside a translation form ("English", "العربية", "Français"). */
const language = (dialog: HTMLElement, name: string) => within(dialog).getByRole('group', { name });
const notSent = () => expect(screen.queryByText(/developer text/)).not.toBeInTheDocument();

describe('departments', () => {
  it('shows each department with its dentist, status and what blocks booking', async () => {
    setup();
    renderAdmin('/departments');
    const card = await screen.findByRole('listitem', { name: 'Endodontics' });
    expect(within(card).getByText(msg('dep.badge.bookable'))).toBeInTheDocument();
    expect(within(card).getByText('Dr. Hana Said')).toBeInTheDocument();
    expect(within(card).getByText(/2 active services/)).toBeInTheDocument();
    const other = screen.getByRole('listitem', { name: 'Orthodontics' });
    expect(within(other).getByText(msg('dep.badge.notBookable'))).toBeInTheDocument();
    expect(within(other).getByText(msg('dep.notBookable.noDentist'))).toBeInTheDocument();
    expect(within(other).getByText(msg('dep.dentist.none'))).toBeInTheDocument();
    expect(within(other).getByRole('button', { name: msg('dep.dentist.assignAria', 'en', { department: 'Orthodontics' }) })).toBeInTheDocument();
  });

  it('creates a department: only the filled languages are sent, with the CSRF header', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(screen.getByRole('button', { name: msg('dep.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.createTitle') });
    await user.type(within(dialog).getByLabelText(lbl(msg('dep.slug'))), 'periodontics');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('dep.tr.name'))), 'Periodontics');
    await user.type(within(language(dialog, 'العربية')).getByLabelText(lbl(msg('dep.tr.name'))), 'اللثة');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await screen.findByText(msg('dep.saved.created', 'en', { name: 'Periodontics' }))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/departments')[0]!;
    expect(call.body).toEqual({
      slug: 'periodontics', displayOrder: 0, isActive: true, imagePath: null, workingDays: [1, 2, 3, 4, 5, 6, 7],
      translations: { en: { name: 'Periodontics', description: '' }, ar: { name: 'اللثة', description: '' } },
    });
    expect(call.body.translations).not.toHaveProperty('fr');
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(await screen.findByRole('listitem', { name: 'Periodontics' })).toBeInTheDocument();
  });

  it('a taken web name is shown at that field and the backend text is never shown', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/departments' ? fail(409, 'SLUG_TAKEN') : undefined));
    const user = userEvent.setup();
    renderAdmin('/departments');
    await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(screen.getByRole('button', { name: msg('dep.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.createTitle') });
    await user.type(within(dialog).getByLabelText(lbl(msg('dep.slug'))), 'endodontics');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('dep.tr.name'))), 'Endo again');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    const slug = within(dialog).getByLabelText(lbl(msg('dep.slug')));
    await waitFor(() => expect(slug).toHaveAttribute('aria-invalid', 'true'));
    expect(within(dialog).getAllByText(msg('err.SLUG_TAKEN'))).toHaveLength(1);
    expect(dialog).toBeInTheDocument();
    notSent();
  });

  it('a department with no name in any language is refused with the translated reason and stays open', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/departments' ? fail(400, 'AT_LEAST_ONE_TRANSLATION') : undefined));
    const user = userEvent.setup();
    renderAdmin('/departments');
    await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(screen.getByRole('button', { name: msg('dep.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.createTitle') });
    await user.type(within(dialog).getByLabelText(lbl(msg('dep.slug'))), 'empty');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await within(dialog).findByRole('alert')).toHaveTextContent(msg('err.AT_LEAST_ONE_TRANSLATION'));
    notSent();
  });

  it('editing: an emptied language is sent empty (the backend removes it), an untouched absent language is left out', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(screen.getByRole('button', { name: msg('dep.editAria', 'en', { name: 'Endodontics' }) }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.editTitle') });
    expect(within(dialog).getByLabelText(lbl(msg('dep.slug')))).toHaveValue('endodontics');
    await user.clear(within(language(dialog, 'العربية')).getByLabelText(lbl(msg('dep.tr.name'))));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await screen.findByText(msg('dep.saved.updated', 'en', { name: 'Endodontics' }))).toBeInTheDocument();
    const call = api.calls('PATCH', '/admin/departments/dep-1')[0]!;
    expect(call.body).toEqual({
      slug: 'endodontics', displayOrder: 1, isActive: true, imagePath: null,
      translations: { en: { name: 'Endodontics', description: 'Root canal care' }, ar: { name: '', description: '' } },
    });
    expect(call.body.translations).not.toHaveProperty('fr');
  });

  it('pressing save twice quickly sends one request', async () => {
    const { api } = setup();
    let release!: () => void;
    const gate = new Promise<void>((r) => { release = r; });
    api.route(async (r) => { if (r.method === 'POST' && r.path === '/admin/departments') { await gate; return json(201, { data: dept({ id: 'dep-new', slug: 'x' }) }); } return undefined; });
    const user = userEvent.setup();
    renderAdmin('/departments');
    await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(screen.getByRole('button', { name: msg('dep.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.createTitle') });
    await user.type(within(dialog).getByLabelText(lbl(msg('dep.slug'))), 'x');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('dep.tr.name'))), 'X');
    await user.dblClick(within(dialog).getByRole('button', { name: msg('common.save') }));
    release();
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(api.calls('POST', '/admin/departments')).toHaveLength(1);
  });

  it('a display order that is not a whole number blocks saving without a request', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(screen.getByRole('button', { name: msg('dep.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.createTitle') });
    await user.type(within(dialog).getByLabelText(lbl(msg('dep.slug'))), 'x');
    const order = within(dialog).getByLabelText(lbl(msg('dep.order')));
    await user.clear(order);
    await user.type(order, '1.5');
    expect(within(dialog).getByText(msg('dep.order.invalid'))).toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: msg('common.save') })).toBeDisabled();
    expect(api.calls('POST', '/admin/departments')).toHaveLength(0);
  });
});

describe('department working days', () => {
  const day = (scope: HTMLElement, name: string) => within(scope).getByRole('checkbox', { name });
  const openEdit = async (user: User, name = 'Endodontics') => {
    await screen.findByRole('listitem', { name });
    await user.click(screen.getByRole('button', { name: msg('dep.editAria', 'en', { name }) }));
    return screen.findByRole('dialog', { name: msg('dep.form.editTitle') });
  };
  const busyOn = (c: ReturnType<typeof setup>['api'], id = 'dep-1') => c.route((r) => (r.method === 'PATCH' && r.path === `/admin/departments/${id}` && !r.body.acknowledgeExistingAppointments && r.body.workingDays
    ? json(409, { error: { code: 'WORKING_DAYS_HAVE_APPOINTMENTS', message: 'developer text', details: { count: 2 } } }) : undefined));

  it('each card says which days the department works: every day, or the days that are on', async () => {
    setup({ departments: [dept(), ortho(), dept({ id: 'dep-3', slug: 'perio', translations: { en: { name: 'Periodontics', description: '' } }, workingDays: [1, 3, 5] })] });
    renderAdmin('/departments');
    expect(within(await screen.findByRole('listitem', { name: 'Endodontics' })).getByText(msg('dep.workingDays.everyDay'))).toBeInTheDocument();
    const perio = screen.getByRole('listitem', { name: 'Periodontics' });
    expect(within(perio).getByText(/^Works: Monday, Wednesday,? (and |& )?Friday$/)).toBeInTheDocument();
    expect(within(perio).queryByText(msg('dep.workingDays.everyDay'))).not.toBeInTheDocument();
  });

  it('the edit form shows the saved days; leaving them alone sends no workingDays at all', async () => {
    const { api } = setup({ departments: [dept({ workingDays: [1, 2, 3, 4, 5] }), ortho()] });
    const user = userEvent.setup();
    renderAdmin('/departments');
    const dialog = await openEdit(user);
    const group = within(dialog).getByRole('group', { name: msg('dep.workingDays') });
    for (const d of ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']) expect(day(group, d)).toBeChecked();
    for (const d of ['Saturday', 'Sunday']) expect(day(group, d)).not.toBeChecked();
    expect(within(dialog).getByText(msg('dep.workingDays.hint'))).toBeInTheDocument();
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await screen.findByText(msg('dep.saved.updated', 'en', { name: 'Endodontics' }));
    expect(api.calls('PATCH', '/admin/departments/dep-1')[0]!.body).not.toHaveProperty('workingDays');
  });

  it('switching days on and off sends the new list, sorted; the card shows it afterwards', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    const dialog = await openEdit(user);
    const group = within(dialog).getByRole('group', { name: msg('dep.workingDays') });
    await user.click(day(group, 'Saturday'));
    await user.click(day(group, 'Tuesday'));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await screen.findByText(msg('dep.saved.updated', 'en', { name: 'Endodontics' }));
    expect(api.calls('PATCH', '/admin/departments/dep-1')[0]!.body.workingDays).toEqual([1, 3, 4, 5, 7]);
    expect(api.calls('PATCH', '/admin/departments/dep-1')[0]!.body).not.toHaveProperty('acknowledgeExistingAppointments');
    expect(await within(screen.getByRole('listitem', { name: 'Endodontics' })).findByText(/^Works: Monday, Wednesday, Thursday, Friday,? (and |& )?Sunday$/)).toBeInTheDocument();
  });

  it('a new department starts with every day on and can be created with fewer', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(screen.getByRole('button', { name: msg('dep.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.createTitle') });
    const group = within(dialog).getByRole('group', { name: msg('dep.workingDays') });
    expect(within(group).getAllByRole('checkbox')).toHaveLength(7);
    for (const box of within(group).getAllByRole('checkbox')) expect(box).toBeChecked();
    await user.type(within(dialog).getByLabelText(lbl(msg('dep.slug'))), 'periodontics');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('dep.tr.name'))), 'Periodontics');
    await user.click(day(group, 'Friday'));
    await user.click(day(group, 'Saturday'));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await screen.findByText(msg('dep.saved.created', 'en', { name: 'Periodontics' }));
    expect(api.calls('POST', '/admin/departments')[0]!.body.workingDays).toEqual([1, 2, 3, 4, 7]);
  });

  it('with no day ticked the form says so, cannot be saved, and sends nothing', async () => {
    const { api } = setup({ departments: [dept({ workingDays: [2] }), ortho()] });
    const user = userEvent.setup();
    renderAdmin('/departments');
    const dialog = await openEdit(user);
    await user.click(day(within(dialog).getByRole('group', { name: msg('dep.workingDays') }), 'Tuesday'));
    expect(within(dialog).getByText(msg('err.AT_LEAST_ONE_WORKING_DAY'))).toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: msg('common.save') })).toBeDisabled();
    await user.click(day(within(dialog).getByRole('group', { name: msg('dep.workingDays') }), 'Thursday'));
    expect(within(dialog).queryByText(msg('err.AT_LEAST_ONE_WORKING_DAY'))).not.toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: msg('common.save') })).toBeEnabled();
    expect(api.calls('PATCH', '/admin/departments/dep-1')).toHaveLength(0);
  });

  it('when booked appointments are on a day being switched off: shows how many, needs a confirmation, then repeats with the acknowledgement; nothing else changes', async () => {
    const { api } = setup();
    busyOn(api);
    const user = userEvent.setup();
    renderAdmin('/departments');
    const dialog = await openEdit(user);
    await user.click(day(within(dialog).getByRole('group', { name: msg('dep.workingDays') }), 'Saturday'));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));

    expect(await within(dialog).findByText(msg('dep.workingDays.ack_other', 'en', { count: 2 }))).toBeInTheDocument();
    expect(within(dialog).getByText(msg('dep.workingDays.ack.note'))).toBeInTheDocument();
    const confirm = within(dialog).getByRole('button', { name: msg('dep.workingDays.ack.submit') });
    expect(confirm).toBeDisabled();
    expect(api.calls('PATCH', '/admin/departments/dep-1')).toHaveLength(1);
    expect(api.calls('PATCH', '/admin/departments/dep-1')[0]!.body).not.toHaveProperty('acknowledgeExistingAppointments');
    notSent();
    expect(screen.queryByText(msg('dep.saved.updated', 'en', { name: 'Endodontics' }))).not.toBeInTheDocument();

    await user.click(within(dialog).getByLabelText(msg('dep.workingDays.ack.confirm')));
    await user.click(confirm);
    expect(await screen.findByText(msg('dep.saved.updated', 'en', { name: 'Endodontics' }))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/departments/dep-1')).toHaveLength(2);
    expect(api.calls('PATCH', '/admin/departments/dep-1')[1]!.body).toMatchObject({ workingDays: [1, 2, 3, 4, 5, 7], acknowledgeExistingAppointments: true, slug: 'endodontics' });
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('choosing other days after the warning withdraws it, so the acknowledgement never covers days that were not checked', async () => {
    const { api } = setup();
    busyOn(api);
    const user = userEvent.setup();
    renderAdmin('/departments');
    const dialog = await openEdit(user);
    const group = () => within(dialog).getByRole('group', { name: msg('dep.workingDays') });
    await user.click(day(group(), 'Saturday'));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await within(dialog).findByText(msg('dep.workingDays.ack_other', 'en', { count: 2 }));
    await user.click(within(dialog).getByLabelText(msg('dep.workingDays.ack.confirm')));

    await user.click(day(group(), 'Sunday'));
    expect(within(dialog).queryByText(msg('dep.workingDays.ack_other', 'en', { count: 2 }))).not.toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: msg('common.save') })).toBeEnabled();
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await within(dialog).findByText(msg('dep.workingDays.ack_other', 'en', { count: 2 })); // asked again for the new days
    expect(api.calls('PATCH', '/admin/departments/dep-1')).toHaveLength(2);
    expect(api.calls('PATCH', '/admin/departments/dep-1')[1]!.body).not.toHaveProperty('acknowledgeExistingAppointments');
  });

  it('switching a day back on never asks anything', async () => {
    const { api } = setup({ departments: [dept({ workingDays: [1, 2, 3, 4, 5] }), ortho()] });
    busyOn(api); // would refuse any request that carries days and no acknowledgement, but adding a day is not refused by the real API
    api.route((r) => (r.method === 'PATCH' && r.path === '/admin/departments/dep-1' ? ok({ ...dept(), ...r.body }) : undefined));
    const user = userEvent.setup();
    renderAdmin('/departments');
    const dialog = await openEdit(user);
    await user.click(day(within(dialog).getByRole('group', { name: msg('dep.workingDays') }), 'Saturday'));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await screen.findByText(msg('dep.saved.updated', 'en', { name: 'Endodontics' }));
    expect(api.calls('PATCH', '/admin/departments/dep-1')[0]!.body.workingDays).toEqual([1, 2, 3, 4, 5, 6]);
  });

  it('any other failure is shown translated in the form, never the backend text, and the warning does not appear', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'PATCH' && r.path === '/admin/departments/dep-1' ? json(400, { error: { code: 'VALIDATION_ERROR', message: 'developer text', details: [{ field: 'workingDays', code: 'INVALID_WEEKDAY' }] } }) : undefined));
    const user = userEvent.setup();
    renderAdmin('/departments');
    const dialog = await openEdit(user);
    await user.click(day(within(dialog).getByRole('group', { name: msg('dep.workingDays') }), 'Saturday'));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await within(dialog).findByText(msg('err.INVALID_WEEKDAY'))).toBeInTheDocument();
    expect(within(dialog).queryByText(msg('dep.workingDays.ack.note'))).not.toBeInTheDocument();
    notSent();
  });

  it('shows the same screen in Arabic: Arabic day names, right-to-left, and the count in the Arabic plural form', async () => {
    const { api } = setup({ departments: [dept({ workingDays: [6, 7, 1] }), ortho()] });
    busyOn(api);
    const user = userEvent.setup();
    renderAdmin('/departments', 'ar');
    const card = await screen.findByRole('listitem', { name: 'علاج الجذور' });
    expect(within(card).getByText(/^أيام العمل: /)).toHaveTextContent(/الاثنين/);
    await user.click(within(card).getByRole('button', { name: msg('dep.editAria', 'ar', { name: 'علاج الجذور' }) }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.form.editTitle', 'ar') });
    expect(within(dialog).getByRole('group', { name: msg('dep.workingDays', 'ar') })).toBeInTheDocument();
    await user.click(within(dialog).getByRole('checkbox', { name: 'الأحد' }));
    await user.click(within(dialog).getByRole('button', { name: msg('common.save', 'ar') }));
    expect(await within(dialog).findByText(msg('dep.workingDays.ack_two', 'ar'))).toBeInTheDocument(); // exactly two: the dual form
    expect(document.documentElement.dir).toBe('rtl');
  });
});

describe('dentists', () => {
  it('assigns a dentist to a department that has none', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    const card = await screen.findByRole('listitem', { name: 'Orthodontics' });
    await user.click(within(card).getByRole('button', { name: msg('dep.dentist.assignAria', 'en', { department: 'Orthodontics' }) }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.dentist.form.assignTitle', 'en', { department: 'Orthodontics' }) });
    const save = within(dialog).getByRole('button', { name: msg('common.save') });
    expect(save).toBeDisabled(); // a dentist needs a name in at least one language
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('dep.dentist.tr.name'))), 'Dr. Omar Fathy');
    await user.click(save);
    expect(await screen.findByText(msg('dep.dentist.saved.assigned', 'en', { department: 'Orthodontics' }))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/dentists')[0]!;
    expect(call.body).toEqual({ departmentId: 'dep-2', photoPath: null, translations: { en: { name: 'Dr. Omar Fathy', bio: '' } } });
    expect(call.body).not.toHaveProperty('replaceExisting');
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    expect(await within(await screen.findByRole('listitem', { name: 'Orthodontics' })).findByText('Dr. Omar Fathy')).toBeInTheDocument();
  });

  it('replacing asks first; only after confirming does the new-dentist form send replaceExisting', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    const card = await screen.findByRole('listitem', { name: 'Endodontics' });
    const replace = within(card).getByRole('button', { name: msg('dep.dentist.replaceAria', 'en', { department: 'Endodontics' }) });

    await user.click(replace);
    let confirm = await screen.findByRole('dialog', { name: msg('dep.dentist.replace.title', 'en', { department: 'Endodontics' }) });
    expect(within(confirm).getByText(msg('dep.dentist.replace.text', 'en', { name: 'Dr. Hana Said' }))).toBeInTheDocument();
    await user.click(within(confirm).getByRole('button', { name: msg('common.cancel') }));
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(api.calls('POST', '/admin/dentists')).toHaveLength(0);

    await user.click(replace);
    confirm = await screen.findByRole('dialog', { name: msg('dep.dentist.replace.title', 'en', { department: 'Endodontics' }) });
    await user.click(within(confirm).getByRole('button', { name: msg('dep.dentist.replace.confirm') }));
    const form = await screen.findByRole('dialog', { name: msg('dep.dentist.form.replaceTitle', 'en', { department: 'Endodontics' }) });
    expect(api.calls('POST', '/admin/dentists')).toHaveLength(0);
    expect(within(language(form, 'English')).getByLabelText(lbl(msg('dep.dentist.tr.name')))).toHaveValue(''); // a new person, not the old one's data
    await user.type(within(language(form, 'English')).getByLabelText(lbl(msg('dep.dentist.tr.name'))), 'Dr. Mona Aziz');
    await user.click(within(form).getByRole('button', { name: msg('common.save') }));
    expect(await screen.findByText(msg('dep.dentist.saved.replaced', 'en', { department: 'Endodontics' }))).toBeInTheDocument();
    expect(api.calls('POST', '/admin/dentists')[0]!.body).toEqual({ departmentId: 'dep-1', replaceExisting: true, photoPath: null, translations: { en: { name: 'Dr. Mona Aziz', bio: '' } } });
  });

  it('editing the current dentist updates it in place (no replacement flag)', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    const card = await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(within(card).getByRole('button', { name: msg('dep.dentist.editAria', 'en', { department: 'Endodontics' }) }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.dentist.form.editTitle', 'en', { department: 'Endodontics' }) });
    const name = within(language(dialog, 'English')).getByLabelText(lbl(msg('dep.dentist.tr.name')));
    expect(name).toHaveValue('Dr. Hana Said');
    await user.type(within(dialog).getByLabelText(lbl(msg('dep.dentist.photo'))), '/assets/dentists/hana.jpg');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('dep.dentist.tr.bio'))), 'Endodontist');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await screen.findByText(msg('dep.dentist.saved.updated', 'en', { department: 'Endodontics' }))).toBeInTheDocument();
    expect(api.calls('POST', '/admin/dentists')).toHaveLength(0);
    expect(api.calls('PATCH', '/admin/dentists/dn-1')[0]!.body).toEqual({ photoPath: '/assets/dentists/hana.jpg', translations: { en: { name: 'Dr. Hana Said', bio: 'Endodontist' } } });
  });

  it('deactivating the dentist needs a confirmation that says booking stops, and then the department is not bookable', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/departments');
    const card = await screen.findByRole('listitem', { name: 'Endodontics' });
    await user.click(within(card).getByRole('button', { name: msg('dep.dentist.deactivateAria', 'en', { department: 'Endodontics' }) }));
    const dialog = await screen.findByRole('dialog', { name: msg('dep.dentist.deactivate.title', 'en', { department: 'Endodontics' }) });
    expect(within(dialog).getByText(msg('dep.dentist.deactivate.text', 'en', { name: 'Dr. Hana Said' }))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/dentists/dn-1')).toHaveLength(0);
    await user.click(within(dialog).getByRole('button', { name: msg('dep.dentist.deactivate.confirm') }));
    expect(await screen.findByText(msg('dep.dentist.saved.deactivated', 'en', { department: 'Endodontics' }))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/dentists/dn-1')[0]!.body).toEqual({ isActive: false });
    const after = await screen.findByRole('listitem', { name: 'Endodontics' });
    await waitFor(() => expect(within(after).getByText(msg('dep.badge.notBookable'))).toBeInTheDocument());
  });
});

describe('services', () => {
  it('lists services with price, a "not shown" marker for no price, the sample marker and the active state', async () => {
    setup();
    renderAdmin('/services');
    const row = await screen.findByRole('row', { name: /Root canal/ });
    expect(within(row).getByText(/350/)).toBeInTheDocument();
    expect(within(row).getByText(msg('common.sample'))).toBeInTheDocument();
    expect(within(row).getByText(msg('svc.badge.active'))).toBeInTheDocument();
    const other = screen.getByRole('row', { name: /Whitening/ });
    expect(within(other).getByText(msg('svc.price.notShown'))).toBeInTheDocument();
    expect(within(other).getByText(msg('svc.badge.inactive'))).toBeInTheDocument();
    expect(within(other).getByRole('button', { name: msg('svc.activateAria', 'en', { name: 'Whitening' }) })).toBeInTheDocument();
    expect(screen.getByText(msg('svc.sampleNote'))).toBeInTheDocument();
  });

  it('filters by department with a query parameter', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/services');
    await screen.findByRole('row', { name: /Root canal/ });
    expect(api.calls('GET', '/admin/services')[0]!.query.get('departmentId')).toBeNull();
    await user.selectOptions(await screen.findByLabelText(msg('svc.filter.department')), 'dep-2');
    await waitFor(() => expect(api.calls('GET', '/admin/services').at(-1)!.query.get('departmentId')).toBe('dep-2'));
    expect(await screen.findByText(msg('svc.empty'))).toBeInTheDocument();
  });

  async function openCreate(user: User) {
    await screen.findByRole('row', { name: /Root canal/ });
    await user.click(screen.getByRole('button', { name: msg('svc.add') }));
    return screen.findByRole('dialog', { name: msg('svc.form.createTitle') });
  }

  it('creates a service without a price (null) in the chosen department', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/services');
    const dialog = await openCreate(user);
    await user.selectOptions(await within(dialog).findByLabelText(lbl(msg('svc.department'))), 'dep-1');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('svc.tr.name'))), 'Scaling');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await screen.findByText(msg('svc.saved.created', 'en', { name: 'Scaling' }))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/services')[0]!;
    expect(call.body).toEqual({ departmentId: 'dep-1', price: null, displayOrder: 0, isActive: true, imagePath: null, translations: { en: { name: 'Scaling', description: '' } } });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
  });

  it('sends the price as a number, accepting a decimal comma', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/services');
    const dialog = await openCreate(user);
    await user.selectOptions(await within(dialog).findByLabelText(lbl(msg('svc.department'))), 'dep-1');
    await user.type(within(dialog).getByLabelText(lbl(msg('svc.price'))), '250,5');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('svc.tr.name'))), 'Filling');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await waitFor(() => expect(api.calls('POST', '/admin/services')).toHaveLength(1));
    expect(api.calls('POST', '/admin/services')[0]!.body.price).toBe(250.5);
  });

  it('a price that is not an amount is refused in the form, with no request', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/services');
    const dialog = await openCreate(user);
    await user.selectOptions(await within(dialog).findByLabelText(lbl(msg('svc.department'))), 'dep-1');
    await user.type(within(dialog).getByLabelText(lbl(msg('svc.price'))), '12abc');
    expect(within(dialog).getByText(msg('err.INVALID_PRICE'))).toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: msg('common.save') })).toBeDisabled();
    expect(api.calls('POST', '/admin/services')).toHaveLength(0);
  });

  it('a price the backend rejects is shown at the price field', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/services' ? fail(400, 'INVALID_PRICE') : undefined));
    const user = userEvent.setup();
    renderAdmin('/services');
    const dialog = await openCreate(user);
    await user.selectOptions(await within(dialog).findByLabelText(lbl(msg('svc.department'))), 'dep-1');
    await user.type(within(dialog).getByLabelText(lbl(msg('svc.price'))), '99999999');
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('svc.tr.name'))), 'Too dear');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await waitFor(() => expect(within(dialog).getByLabelText(lbl(msg('svc.price')))).toHaveAttribute('aria-invalid', 'true'));
    expect(within(dialog).getAllByText(msg('err.INVALID_PRICE'))).toHaveLength(1);
    notSent();
  });

  it('removing the price while editing sends null', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/services');
    await screen.findByRole('row', { name: /Root canal/ });
    await user.click(screen.getByRole('button', { name: msg('svc.editAria', 'en', { name: 'Root canal' }) }));
    const dialog = await screen.findByRole('dialog', { name: msg('svc.form.editTitle') });
    const price = within(dialog).getByLabelText(lbl(msg('svc.price')));
    expect(price).toHaveValue('350');
    await user.clear(price);
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await waitFor(() => expect(api.calls('PATCH', '/admin/services/s1')).toHaveLength(1));
    expect(api.calls('PATCH', '/admin/services/s1')[0]!.body.price).toBeNull();
  });

  it('deactivating asks first; activating does not', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/services');
    await screen.findByRole('row', { name: /Root canal/ });
    await user.click(screen.getByRole('button', { name: msg('svc.deactivateAria', 'en', { name: 'Root canal' }) }));
    let dialog = await screen.findByRole('dialog', { name: msg('svc.deactivate.title', 'en', { name: 'Root canal' }) });
    await user.click(within(dialog).getByRole('button', { name: msg('common.cancel') }));
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(api.calls('PATCH', '/admin/services/s1')).toHaveLength(0);

    await user.click(screen.getByRole('button', { name: msg('svc.deactivateAria', 'en', { name: 'Root canal' }) }));
    dialog = await screen.findByRole('dialog', { name: msg('svc.deactivate.title', 'en', { name: 'Root canal' }) });
    await user.click(within(dialog).getByRole('button', { name: msg('svc.deactivate.confirm') }));
    expect(await screen.findByText(msg('svc.saved.deactivated', 'en', { name: 'Root canal' }))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/services/s1')[0]!.body).toEqual({ isActive: false });

    await user.click(screen.getByRole('button', { name: msg('svc.activateAria', 'en', { name: 'Whitening' }) }));
    expect(await screen.findByText(msg('svc.saved.activated', 'en', { name: 'Whitening' }))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/services/s2')[0]!.body).toEqual({ isActive: true });
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('a failed deactivation says why inside the confirmation and keeps it open', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'PATCH' && r.path === '/admin/services/s1' ? fail(500, 'INTERNAL_ERROR') : undefined));
    const user = userEvent.setup();
    renderAdmin('/services');
    await screen.findByRole('row', { name: /Root canal/ });
    await user.click(screen.getByRole('button', { name: msg('svc.deactivateAria', 'en', { name: 'Root canal' }) }));
    const dialog = await screen.findByRole('dialog', { name: msg('svc.deactivate.title', 'en', { name: 'Root canal' }) });
    await user.click(within(dialog).getByRole('button', { name: msg('svc.deactivate.confirm') }));
    expect(await within(dialog).findByRole('alert')).toBeInTheDocument();
    notSent();
  });
});

describe('gallery', () => {
  it('lists cases with publication, consent and sample markers and their thumbnails', async () => {
    setup();
    renderAdmin('/gallery');
    const real = await screen.findByRole('listitem', { name: 'Front tooth repair' });
    expect(within(real).getByText(msg('gal.badge.draft'))).toBeInTheDocument();
    expect(within(real).getByText(msg('gal.consent.no'))).toBeInTheDocument();
    expect(within(real).getByAltText(msg('gal.thumb.before'))).toHaveAttribute('src', '/assets/gallery/a-before.jpg');
    const sample = screen.getByRole('listitem', { name: 'Sample whitening' });
    expect(within(sample).getByText(msg('common.sample'))).toBeInTheDocument();
    expect(within(sample).getByText(msg('gal.badge.published'))).toBeInTheDocument();
    expect(within(sample).queryByText(msg('gal.consent.no'))).not.toBeInTheDocument(); // consent only concerns real patients
    expect(screen.getByText(msg('gal.sampleNote'))).toBeInTheDocument();
  });

  async function openCreate(user: User) {
    await screen.findByRole('listitem', { name: 'Front tooth repair' });
    await user.click(screen.getByRole('button', { name: msg('gal.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('gal.form.createTitle') });
    await user.selectOptions(await within(dialog).findByLabelText(lbl(msg('gal.department'))), 'dep-1');
    await user.type(within(dialog).getByLabelText(lbl(msg('gal.before'))), '/assets/gallery/new-before.jpg');
    await user.type(within(dialog).getByLabelText(lbl(msg('gal.after'))), '/assets/gallery/new-after.jpg');
    return dialog;
  }

  it('a real case cannot be published until the patient consent is ticked', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/gallery');
    const dialog = await openCreate(user);
    const publish = within(dialog).getByLabelText(msg('gal.published'));
    expect(publish).toBeDisabled();
    expect(within(dialog).getByText(msg('gal.published.blocked'))).toBeInTheDocument();

    await user.click(within(dialog).getByLabelText(msg('gal.consent')));
    expect(publish).toBeEnabled();
    await user.click(publish);
    expect(publish).toBeChecked();

    // taking the consent back un-publishes the case again, so the form can never send "published without consent"
    await user.click(within(dialog).getByLabelText(msg('gal.consent')));
    expect(publish).not.toBeChecked();
    expect(publish).toBeDisabled();
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await waitFor(() => expect(api.calls('POST', '/admin/gallery')).toHaveLength(1));
    expect(api.calls('POST', '/admin/gallery')[0]!.body).toMatchObject({ caseKind: 'real', consentConfirmed: false, isPublished: false });
  });

  it('creates a published real case with consent, including the alternative texts', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/gallery');
    const dialog = await openCreate(user);
    await user.click(within(dialog).getByLabelText(msg('gal.consent')));
    await user.click(within(dialog).getByLabelText(msg('gal.published')));
    const en = language(dialog, 'English');
    await user.type(within(en).getByLabelText(lbl(msg('gal.tr.title'))), 'Bleaching result');
    await user.type(within(en).getByLabelText(lbl(msg('gal.tr.altBefore'))), 'Yellowed teeth before bleaching');
    await user.type(within(en).getByLabelText(lbl(msg('gal.tr.altAfter'))), 'Lighter teeth after bleaching');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await screen.findByText(msg('gal.saved.created'))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/gallery')[0]!;
    expect(call.body).toEqual({
      departmentId: 'dep-1', beforeImagePath: '/assets/gallery/new-before.jpg', afterImagePath: '/assets/gallery/new-after.jpg', serviceId: null,
      caseKind: 'real', consentConfirmed: true, isPublished: true, displayOrder: 0,
      translations: { en: { title: 'Bleaching result', description: '', altBefore: 'Yellowed teeth before bleaching', altAfter: 'Lighter teeth after bleaching' } },
    });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
  });

  it('a sample case needs no consent and can be published', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/gallery');
    const dialog = await openCreate(user);
    await user.selectOptions(within(dialog).getByLabelText(lbl(msg('gal.kind'))), 'sample');
    expect(within(dialog).queryByLabelText(msg('gal.consent'))).not.toBeInTheDocument();
    const publish = within(dialog).getByLabelText(msg('gal.published'));
    expect(publish).toBeEnabled();
    await user.click(publish);
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('gal.tr.title'))), 'Placeholder');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    await waitFor(() => expect(api.calls('POST', '/admin/gallery')).toHaveLength(1));
    expect(api.calls('POST', '/admin/gallery')[0]!.body).toMatchObject({ caseKind: 'sample', isPublished: true });
  });

  it('when the backend refuses for missing consent, the reason is shown at the consent box', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/gallery' ? fail(400, 'CONSENT_REQUIRED') : undefined));
    const user = userEvent.setup();
    renderAdmin('/gallery');
    const dialog = await openCreate(user);
    await user.click(within(dialog).getByLabelText(msg('gal.consent')));
    await user.type(within(language(dialog, 'English')).getByLabelText(lbl(msg('gal.tr.title'))), 'x');
    await user.click(within(dialog).getByRole('button', { name: msg('common.save') }));
    expect(await within(dialog).findByText(msg('err.CONSENT_REQUIRED'))).toBeInTheDocument();
    notSent();
  });

  it('the save button stays off until both image paths and a department are given', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/gallery');
    await screen.findByRole('listitem', { name: 'Front tooth repair' });
    await user.click(screen.getByRole('button', { name: msg('gal.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('gal.form.createTitle') });
    expect(within(dialog).getByRole('button', { name: msg('common.save') })).toBeDisabled();
    expect(api.calls('POST', '/admin/gallery')).toHaveLength(0);
  });

  it('removing a case asks first; cancelling sends nothing; confirming deletes it and the list refreshes', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/gallery');
    await screen.findByRole('listitem', { name: 'Front tooth repair' });
    const remove = screen.getByRole('button', { name: msg('gal.deleteAria', 'en', { name: 'Front tooth repair' }) });
    await user.click(remove);
    let dialog = await screen.findByRole('dialog', { name: msg('gal.delete.title', 'en', { name: 'Front tooth repair' }) });
    await user.click(within(dialog).getByRole('button', { name: msg('common.cancel') }));
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(api.calls('DELETE', '/admin/gallery/g1')).toHaveLength(0);

    await user.click(remove);
    dialog = await screen.findByRole('dialog', { name: msg('gal.delete.title', 'en', { name: 'Front tooth repair' }) });
    await user.click(within(dialog).getByRole('button', { name: msg('gal.delete.confirm') }));
    expect(await screen.findByText(msg('gal.saved.deleted'))).toBeInTheDocument();
    expect(api.calls('DELETE', '/admin/gallery/g1')).toHaveLength(1);
    expect(api.calls('DELETE', '/admin/gallery/g1')[0]!.headers['x-csrf-token']).toBe('csrf-admin');
    await waitFor(() => expect(screen.queryByRole('listitem', { name: 'Front tooth repair' })).not.toBeInTheDocument());
  });
});

describe('Arabic', () => {
  it('shows the department page in Arabic, right-to-left, with the Arabic names', async () => {
    setup();
    renderAdmin('/departments', 'ar');
    expect(await screen.findByRole('heading', { level: 1, name: msg('dep.title', 'ar') })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('rtl');
    expect(document.documentElement.lang).toBe('ar');
    expect(await screen.findByRole('listitem', { name: 'علاج الجذور' })).toBeInTheDocument();
  });
});
