import { afterEach, describe, expect, it, vi } from 'vitest';
import { fireEvent, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { fail, json, ok, startAdminBackend } from './helpers/adminBackend.js';
import { msg, renderAdmin } from './helpers/renderAdmin.js';
import type { AdminDepartment, AdminSlot, AuditEvent, CenterSettings, Closure } from '../src/admin/api/types.js';

afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

const lbl = (text: string) => new RegExp(text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
const noContent = () => new Response(null, { status: 204 });
const meta = (total: number, page = 1, totalPages = 1) => ({ page, pageSize: 50, total, totalPages });
const notShown = () => expect(screen.queryByText(/developer text/)).not.toBeInTheDocument();
const setDate = (el: HTMLElement, value: string) => fireEvent.change(el, { target: { value } });
const language = (root: HTMLElement | Document, name: string) => within(root as HTMLElement).getByRole('group', { name });

const centerFixture = (over: Partial<CenterSettings> = {}): CenterSettings => ({
  phone: '+20 100 000 0001', whatsapp: null, email: 'info@example.test', mapUrl: null, defaultLocale: 'ar', currency: 'EGP', bookingHorizonDays: 60,
  workingDays: [1, 2, 3, 4, 5, 6, 7], timezone: 'Africa/Cairo',
  translations: {
    en: { name: 'Test Center', address: '12 Example Street, Cairo', introduction: 'Welcome', hoursNote: '' },
    ar: { name: 'مركز الاختبار', address: '', introduction: '', hoursNote: '' },
  }, ...over,
});
const slotsFixture = (): AdminSlot[] => [
  { slotNumber: 1, startTime: '16:00', endTime: '18:00', endsNextDay: false, isActive: true },
  { slotNumber: 2, startTime: '18:00', endTime: '20:00', endsNextDay: false, isActive: true },
  { slotNumber: 3, startTime: '20:00', endTime: '22:00', endsNextDay: false, isActive: true },
  { slotNumber: 4, startTime: '22:00', endTime: '00:00', endsNextDay: true, isActive: true },
];
const dept = (): AdminDepartment => ({
  id: 'dep-1', slug: 'endodontics', displayOrder: 1, isActive: true, imagePath: null, workingDays: [1, 2, 3, 4, 5, 6, 7], translations: { en: { name: 'Endodontics', description: '' } },
  dentist: null, serviceCount: 0, bookable: false, createdAt: '2026-10-01T10:00:00+02:00', updatedAt: '2026-10-01T10:00:00+02:00',
});
const closureFixtures = (): Closure[] => [
  { id: 'c1', dateFrom: '2026-12-24', dateTo: '2026-12-26', departmentId: null, reason: 'Holiday' },
  { id: 'c2', dateFrom: '2026-12-30', dateTo: '2026-12-30', departmentId: 'dep-1', reason: '' },
];

function setup(opts: { center?: CenterSettings; slots?: AdminSlot[]; closures?: Closure[] } = {}) {
  const api = startAdminBackend();
  const center = opts.center ?? centerFixture();
  const slots = opts.slots ?? slotsFixture();
  const closures = opts.closures ?? closureFixtures();
  api.route((r) => {
    if (r.method === 'GET' && r.path === '/admin/settings/center') return ok(center);
    if (r.method === 'PUT' && r.path === '/admin/settings/center') {
      const { translations, ...plain } = r.body;
      Object.assign(center, plain);
      for (const [l, entry] of Object.entries(translations ?? {})) (center.translations as any)[l] = { name: '', address: '', introduction: '', hoursNote: '', ...(center.translations as any)[l], ...(entry as object) };
      return ok(center);
    }
    if (r.method === 'GET' && r.path === '/admin/settings/slots') return ok(slots);
    const sm = /^\/admin\/settings\/slots\/(\d)$/.exec(r.path);
    if (r.method === 'PATCH' && sm) { slots.find((s) => s.slotNumber === Number(sm[1]))!.isActive = r.body.isActive; return ok(slots); }
    if (r.method === 'GET' && r.path === '/admin/departments') return ok([dept()]);
    if (r.method === 'GET' && r.path === '/admin/closures') return ok(closures);
    if (r.method === 'POST' && r.path === '/admin/closures') { const c: Closure = { id: 'c-new', dateFrom: r.body.dateFrom, dateTo: r.body.dateTo, departmentId: r.body.departmentId ?? null, reason: r.body.reason ?? '' }; closures.push(c); return json(201, { data: c }); }
    const cm = /^\/admin\/closures\/([^/]+)$/.exec(r.path);
    if (r.method === 'DELETE' && cm) { const i = closures.findIndex((c) => c.id === cm[1]); if (i >= 0) closures.splice(i, 1); return noContent(); }
    return undefined;
  });
  return { api, center, slots, closures };
}

const profile = async () => (await screen.findByRole('button', { name: msg('set.save') })).closest('form') as HTMLElement;

describe('center profile', () => {
  it('shows the saved values and offers nothing to save until something changes', async () => {
    setup();
    renderAdmin('/settings');
    const form = await profile();
    expect(within(form).getByLabelText(lbl(msg('set.phone')))).toHaveValue('+20 100 000 0001');
    expect(within(form).getByLabelText(lbl(msg('set.email')))).toHaveValue('info@example.test');
    expect(within(language(form, 'English')).getByLabelText(lbl(msg('set.tr.address')))).toHaveValue('12 Example Street, Cairo');
    expect(within(form).getByLabelText(lbl(msg('set.currency')))).toHaveValue('EGP');
    expect(within(form).getByLabelText(lbl(msg('set.horizon')))).toHaveValue('60');
    expect(within(form).getByRole('button', { name: msg('set.save') })).toBeDisabled();
    expect(within(form).getByText(msg('set.unchanged'))).toBeInTheDocument();
    expect(screen.getByText(msg('set.timezone', 'en', { zone: 'Africa/Cairo' }))).toBeInTheDocument();
    expect(screen.queryByText(msg('set.addressMissing'))).not.toBeInTheDocument();
  });

  it('sends only what changed, with the CSRF header, and then starts again from the saved profile', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const form = await profile();
    const phone = within(form).getByLabelText(lbl(msg('set.phone')));
    await user.clear(phone);
    await user.type(phone, '+20 100 000 0002');
    await user.click(within(form).getByRole('button', { name: msg('set.save') }));
    expect(await screen.findByText(msg('set.saved'))).toBeInTheDocument();
    const call = api.calls('PUT', '/admin/settings/center')[0]!;
    expect(call.body).toEqual({ phone: '+20 100 000 0002' });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    const after = await profile();
    expect(within(after).getByLabelText(lbl(msg('set.phone')))).toHaveValue('+20 100 000 0002');
    expect(within(after).getByRole('button', { name: msg('set.save') })).toBeDisabled();
  });

  it('clearing an optional contact field sends null, not an empty string', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const form = await profile();
    await user.clear(within(form).getByLabelText(lbl(msg('set.email'))));
    await user.click(within(form).getByRole('button', { name: msg('set.save') }));
    await waitFor(() => expect(api.calls('PUT', '/admin/settings/center')).toHaveLength(1));
    expect(api.calls('PUT', '/admin/settings/center')[0]!.body).toEqual({ email: null });
  });

  it('texts are sent per changed field and language; an emptied text stays a (blank) text and no language is dropped', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const form = await profile();
    const en = language(form, 'English');
    await user.clear(within(en).getByLabelText(lbl(msg('set.tr.introduction'))));
    await user.type(within(language(form, 'العربية')).getByLabelText(lbl(msg('set.tr.address'))), 'شارع المثال، القاهرة');
    await user.click(within(form).getByRole('button', { name: msg('set.save') }));
    await waitFor(() => expect(api.calls('PUT', '/admin/settings/center')).toHaveLength(1));
    const body = api.calls('PUT', '/admin/settings/center')[0]!.body;
    expect(body).toEqual({ translations: { en: { introduction: '' }, ar: { address: 'شارع المثال، القاهرة' } } });
    expect(body.translations).not.toHaveProperty('fr');
  });

  it('warns while no address is entered in any language', async () => {
    setup({ center: centerFixture({ translations: { en: { name: 'Test Center', address: '', introduction: '', hoursNote: '' } } }) });
    renderAdmin('/settings');
    expect(await screen.findByText(msg('set.addressMissing'))).toBeInTheDocument();
  });

  it('the currency is upper-cased and must be three letters; the booking window must be 1 to 365 days — nothing is sent otherwise', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const form = await profile();
    const currency = within(form).getByLabelText(lbl(msg('set.currency')));
    await user.clear(currency);
    await user.type(currency, 'usd');
    expect(currency).toHaveValue('USD');
    await user.clear(currency);
    await user.type(currency, 'us');
    expect(within(form).getByText(msg('err.INVALID_CURRENCY'))).toBeInTheDocument();
    expect(within(form).getByRole('button', { name: msg('set.save') })).toBeDisabled();

    await user.clear(currency);
    await user.type(currency, 'USD');
    const horizon = within(form).getByLabelText(lbl(msg('set.horizon')));
    for (const bad of ['0', '366', 'abc']) {
      await user.clear(horizon);
      await user.type(horizon, bad);
      expect(within(form).getByText(msg('err.INVALID_HORIZON'))).toBeInTheDocument();
      expect(within(form).getByRole('button', { name: msg('set.save') })).toBeDisabled();
    }
    expect(api.calls('PUT', '/admin/settings/center')).toHaveLength(0);

    await user.clear(horizon);
    await user.type(horizon, '90');
    await user.click(within(form).getByRole('button', { name: msg('set.save') }));
    await waitFor(() => expect(api.calls('PUT', '/admin/settings/center')).toHaveLength(1));
    expect(api.calls('PUT', '/admin/settings/center')[0]!.body).toEqual({ currency: 'USD', bookingHorizonDays: 90 });
  });

  it('working days: at least one must stay ticked; changes are sent sorted', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const form = await profile();
    const days = within(within(form).getByRole('group', { name: msg('set.workingDays') }));
    await user.click(days.getByLabelText('Friday'));
    await user.click(within(form).getByRole('button', { name: msg('set.save') }));
    await waitFor(() => expect(api.calls('PUT', '/admin/settings/center')).toHaveLength(1));
    expect(api.calls('PUT', '/admin/settings/center')[0]!.body).toEqual({ workingDays: [1, 2, 3, 4, 6, 7] });

    const after = await profile();
    const group = within(within(after).getByRole('group', { name: msg('set.workingDays') }));
    for (const name of ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Saturday']) await user.click(group.getByLabelText(name));
    await user.click(group.getByLabelText('Sunday'));
    expect(within(after).getByText(msg('err.AT_LEAST_ONE_WORKING_DAY'))).toBeInTheDocument();
    expect(within(after).getByRole('button', { name: msg('set.save') })).toBeDisabled();
    expect(api.calls('PUT', '/admin/settings/center')).toHaveLength(1);
  });

  it('a validation answer from the backend is shown at the field it names, in the user’s language, without the backend text', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'PUT' && r.path === '/admin/settings/center'
      ? json(400, { error: { code: 'VALIDATION_ERROR', message: 'developer text', details: [{ field: 'email', code: 'INVALID_EMAIL' }] } }) : undefined));
    const user = userEvent.setup();
    renderAdmin('/settings');
    const form = await profile();
    const email = within(form).getByLabelText(lbl(msg('set.email')));
    await user.clear(email);
    await user.type(email, 'not-an-email');
    await user.click(within(form).getByRole('button', { name: msg('set.save') }));
    await waitFor(() => expect(email).toHaveAttribute('aria-invalid', 'true'));
    expect(within(form).getByText(msg('err.INVALID_EMAIL'))).toBeInTheDocument();
    notShown();
  });

  it('pressing save twice quickly sends one request', async () => {
    const { api } = setup();
    let release!: () => void;
    const gate = new Promise<void>((r) => { release = r; });
    api.route(async (r) => { if (r.method === 'PUT' && r.path === '/admin/settings/center') { await gate; return ok(centerFixture({ phone: '+20 1' })); } return undefined; });
    const user = userEvent.setup();
    renderAdmin('/settings');
    const form = await profile();
    const phone = within(form).getByLabelText(lbl(msg('set.phone')));
    await user.clear(phone);
    await user.type(phone, '+20 1');
    await user.dblClick(within(form).getByRole('button', { name: msg('set.save') }));
    release();
    expect(await screen.findByText(msg('set.saved'))).toBeInTheDocument();
    expect(api.calls('PUT', '/admin/settings/center')).toHaveLength(1);
  });
});

describe('daily slots', () => {
  it('lists the four slots; switching one off sends only that change and says that appointments are untouched', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const boxes = await screen.findAllByRole('checkbox', { name: /^Slot \d/ });
    expect(boxes).toHaveLength(4);
    boxes.forEach((b) => expect(b).toBeChecked());
    await user.click(screen.getByRole('checkbox', { name: /^Slot 3/ }));
    expect(await screen.findByText(msg('slot.saved.off', 'en', { number: 3 }))).toBeInTheDocument();
    const call = api.calls('PATCH', '/admin/settings/slots/3')[0]!;
    expect(call.body).toEqual({ isActive: false });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    await waitFor(() => expect(screen.getByRole('checkbox', { name: /^Slot 3/ })).not.toBeChecked());
    await user.click(screen.getByRole('checkbox', { name: /^Slot 3/ }));
    expect(await screen.findByText(msg('slot.saved.on', 'en', { number: 3 }))).toBeInTheDocument();
  });

  it('the last active slot cannot be switched off: the reason is shown and the slot stays on', async () => {
    const { api } = setup({ slots: slotsFixture().map((s) => ({ ...s, isActive: s.slotNumber === 1 })) });
    api.route((r) => (r.method === 'PATCH' && r.path === '/admin/settings/slots/1' ? fail(422, 'AT_LEAST_ONE_SLOT') : undefined));
    const user = userEvent.setup();
    renderAdmin('/settings');
    const first = await screen.findByRole('checkbox', { name: /^Slot 1/ });
    await user.click(first);
    expect(await screen.findByText(msg('err.AT_LEAST_ONE_SLOT'))).toBeInTheDocument();
    expect(first).toBeChecked();
    notShown();
  });
});

describe('closed dates', () => {
  const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());

  it('lists closures from today on, names the department or the whole center, and can include past ones', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const row = await screen.findByRole('row', { name: /Holiday/ });
    expect(within(row).getByText(msg('clo.scope.all'))).toBeInTheDocument();
    expect(within(row).getByText(/24 December 2026/)).toBeInTheDocument();
    expect(within(screen.getByRole('row', { name: /Endodontics/ })).getByText(/30 December 2026/)).toBeInTheDocument();
    expect(api.calls('GET', '/admin/closures')[0]!.query.get('from')).toBe(today());
    await user.click(screen.getByLabelText(msg('clo.showPast')));
    await waitFor(() => expect(api.calls('GET', '/admin/closures').at(-1)!.query.get('from')).toBeNull());
  });

  async function openDialog(user: ReturnType<typeof userEvent.setup>) {
    await screen.findByRole('row', { name: /Holiday/ });
    await user.click(screen.getByRole('button', { name: msg('clo.add') }));
    return screen.findByRole('dialog', { name: msg('clo.form.title') });
  }

  it('closes a range for the whole center; the first request carries no acknowledgement', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const dialog = await openDialog(user);
    setDate(within(dialog).getByLabelText(lbl(msg('clo.from'))), '2027-01-07');
    setDate(within(dialog).getByLabelText(lbl(msg('clo.to'))), '2027-01-09');
    await user.type(within(dialog).getByLabelText(lbl(msg('clo.reason'))), 'Maintenance');
    await user.click(within(dialog).getByRole('button', { name: msg('clo.submit') }));
    expect(await screen.findByText(msg('clo.saved'))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/closures')[0]!;
    expect(call.body).toEqual({ dateFrom: '2027-01-07', dateTo: '2027-01-09', departmentId: null, reason: 'Maintenance' });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(await screen.findByRole('row', { name: /Maintenance/ })).toBeInTheDocument();
  });

  it('can close just one department', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const dialog = await openDialog(user);
    await user.selectOptions(await within(dialog).findByRole('option', { name: 'Endodontics' }).then(() => within(dialog).getByLabelText(lbl(msg('clo.department')))), 'dep-1');
    await user.click(within(dialog).getByRole('button', { name: msg('clo.submit') }));
    await waitFor(() => expect(api.calls('POST', '/admin/closures')).toHaveLength(1));
    expect(api.calls('POST', '/admin/closures')[0]!.body.departmentId).toBe('dep-1');
  });

  it('a last day before the first day is refused in the form, with no request', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const dialog = await openDialog(user);
    setDate(within(dialog).getByLabelText(lbl(msg('clo.from'))), '2027-01-10');
    setDate(within(dialog).getByLabelText(lbl(msg('clo.to'))), '2027-01-05');
    expect(within(dialog).getByText(msg('clo.range.invalid'))).toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: msg('clo.submit') })).toBeDisabled();
    expect(api.calls('POST', '/admin/closures')).toHaveLength(0);
  });

  it('when booked appointments are in the range, it shows how many, needs an explicit confirmation, and only then repeats with the acknowledgement', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/closures' && !r.body.acknowledgeExistingAppointments
      ? json(409, { error: { code: 'CLOSURE_HAS_APPOINTMENTS', message: 'developer text', details: { count: 3 } } }) : undefined));
    const user = userEvent.setup();
    renderAdmin('/settings');
    const dialog = await openDialog(user);
    setDate(within(dialog).getByLabelText(lbl(msg('clo.from'))), '2027-02-01');
    setDate(within(dialog).getByLabelText(lbl(msg('clo.to'))), '2027-02-03');
    await user.click(within(dialog).getByRole('button', { name: msg('clo.submit') }));

    expect(await within(dialog).findByText(msg('clo.ack_other', 'en', { count: 3 }))).toBeInTheDocument();
    expect(within(dialog).getByText(msg('clo.ack.note'))).toBeInTheDocument();
    const confirm = within(dialog).getByRole('button', { name: msg('clo.ack.submit') });
    expect(confirm).toBeDisabled();
    expect(api.calls('POST', '/admin/closures')).toHaveLength(1);
    expect(api.calls('POST', '/admin/closures')[0]!.body).not.toHaveProperty('acknowledgeExistingAppointments');
    notShown();

    await user.click(within(dialog).getByLabelText(msg('clo.ack.confirm')));
    await user.click(confirm);
    expect(await screen.findByText(msg('clo.saved'))).toBeInTheDocument();
    expect(api.calls('POST', '/admin/closures')).toHaveLength(2);
    expect(api.calls('POST', '/admin/closures')[1]!.body).toEqual({ dateFrom: '2027-02-01', dateTo: '2027-02-03', departmentId: null, acknowledgeExistingAppointments: true });
  });

  it('changing the dates after the warning withdraws it, so the acknowledgement never applies to a range that was not checked', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/closures' && !r.body.acknowledgeExistingAppointments
      ? json(409, { error: { code: 'CLOSURE_HAS_APPOINTMENTS', message: 'developer text', details: { count: 1 } } }) : undefined));
    const user = userEvent.setup();
    renderAdmin('/settings');
    const dialog = await openDialog(user);
    setDate(within(dialog).getByLabelText(lbl(msg('clo.from'))), '2027-02-01');
    setDate(within(dialog).getByLabelText(lbl(msg('clo.to'))), '2027-02-01');
    await user.click(within(dialog).getByRole('button', { name: msg('clo.submit') }));
    await within(dialog).findByText(msg('clo.ack_one'));
    await user.click(within(dialog).getByLabelText(msg('clo.ack.confirm')));

    setDate(within(dialog).getByLabelText(lbl(msg('clo.to'))), '2027-02-05');
    expect(within(dialog).queryByText(msg('clo.ack_one'))).not.toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: msg('clo.submit') })).toBeInTheDocument();
    await user.click(within(dialog).getByRole('button', { name: msg('clo.submit') }));
    await within(dialog).findByText(msg('clo.ack_one')); // asked again for the new range
    expect(api.calls('POST', '/admin/closures')).toHaveLength(2);
    expect(api.calls('POST', '/admin/closures')[1]!.body).not.toHaveProperty('acknowledgeExistingAppointments');
  });

  it('reopening asks first; cancelling sends nothing; confirming deletes the closure', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/settings');
    const row = await screen.findByRole('row', { name: /Holiday/ });
    const reopen = within(row).getByRole('button', { name: /^Reopen/ });
    await user.click(reopen);
    let dialog = await screen.findByRole('dialog', { name: msg('clo.reopen.title') });
    await user.click(within(dialog).getByRole('button', { name: msg('common.cancel') }));
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(api.calls('DELETE', '/admin/closures/c1')).toHaveLength(0);

    await user.click(reopen);
    dialog = await screen.findByRole('dialog', { name: msg('clo.reopen.title') });
    await user.click(within(dialog).getByRole('button', { name: msg('clo.reopen.confirm') }));
    expect(await screen.findByText(msg('clo.reopened'))).toBeInTheDocument();
    expect(api.calls('DELETE', '/admin/closures/c1')[0]!.headers['x-csrf-token']).toBe('csrf-admin');
    await waitFor(() => expect(screen.queryByRole('row', { name: /Holiday/ })).not.toBeInTheDocument());
  });
});

const event = (over: Partial<AuditEvent> = {}): AuditEvent => ({
  id: '101', occurredAt: '2026-11-10T16:00:00.000Z', actorType: 'admin', actorId: 'adm-1', action: 'appointment.cancelled', entityType: 'appointment', entityId: 'a1',
  outcome: 'success', metadata: { reason: 'patient called' }, ip: '203.0.113.9', ...over,
});

function auditSetup(events: AuditEvent[] = [event(), event({ id: '100', actorType: 'patient', actorId: null, action: 'patient.login', entityType: null, entityId: null, outcome: 'failure', metadata: {}, ip: null })], pages = 1) {
  const api = startAdminBackend();
  api.route((r) => (r.method === 'GET' && r.path === '/admin/audit-events' ? ok(events, meta(events.length, Number(r.query.get('page') ?? 1), pages)) : undefined));
  return api;
}

describe('audit log', () => {
  it('lists entries newest first with who, what, which record and the result, in Cairo time', async () => {
    auditSetup();
    renderAdmin('/audit');
    const row = await screen.findByRole('row', { name: /appointment\.cancelled/ });
    expect(within(row).getByText(/6:00\s?PM/i)).toBeInTheDocument(); // 16:00 UTC is 18:00 in Cairo (UTC+2), whatever the browser's zone is
    expect(within(row).getByText(msg('aud.actor.admin'))).toBeInTheDocument();
    expect(within(row).getByText(/appointment · a1/)).toBeInTheDocument();
    expect(within(row).getByText(msg('aud.outcome.success'))).toBeInTheDocument();
    const other = screen.getByRole('row', { name: /patient\.login/ });
    expect(within(other).getByText(msg('aud.outcome.failure'))).toBeInTheDocument();
    expect(within(other).getByText(msg('aud.details.none'))).toBeInTheDocument();
    expect(screen.getByText('2 results')).toBeInTheDocument();
  });

  it('shows recorded details as plain text — markup in them is never interpreted', async () => {
    auditSetup([event({ metadata: { note: '<script>window.__pwned = 1</script><img src=x onerror=alert(1)>' } })]);
    const user = userEvent.setup();
    const { container } = renderAdmin('/audit');
    const row = await screen.findByRole('row', { name: /appointment\.cancelled/ });
    await user.click(within(row).getByText(msg('aud.details.show')));
    expect(within(row).getByText(/<script>window\.__pwned = 1<\/script>/)).toBeInTheDocument();
    expect(within(row).getByText(msg('aud.ip', 'en', { ip: '203.0.113.9' }))).toBeInTheDocument();
    expect(container.querySelector('script')).toBeNull();
    expect(container.querySelector('img[src="x"]')).toBeNull();
  });

  it('sends only the filters that were filled in, starts again from page 1, and clears them', async () => {
    const api = auditSetup(undefined, 3);
    const user = userEvent.setup();
    renderAdmin('/audit');
    await screen.findByRole('row', { name: /appointment\.cancelled/ });
    expect([...api.calls('GET', '/admin/audit-events')[0]!.query.keys()].sort()).toEqual(['page', 'pageSize']);
    expect(api.calls('GET', '/admin/audit-events')[0]!.query.get('pageSize')).toBe('50');

    await user.click(screen.getByRole('button', { name: msg('common.next') }));
    await waitFor(() => expect(api.calls('GET', '/admin/audit-events').at(-1)!.query.get('page')).toBe('2'));

    await user.type(screen.getByLabelText(lbl(msg('aud.filter.action'))), ' appointment.cancelled ');
    await user.selectOptions(screen.getByLabelText(lbl(msg('aud.filter.outcome'))), 'denied');
    setDate(screen.getByLabelText(lbl(msg('aud.filter.from'))), '2026-11-01');
    setDate(screen.getByLabelText(lbl(msg('aud.filter.to'))), '2026-11-30');
    await user.click(screen.getByRole('button', { name: msg('common.search') }));
    await waitFor(() => {
      const q = api.calls('GET', '/admin/audit-events').at(-1)!.query;
      expect(Object.fromEntries(q.entries())).toEqual({ action: 'appointment.cancelled', outcome: 'denied', from: '2026-11-01', to: '2026-11-30', page: '1', pageSize: '50' });
    });

    await user.click(screen.getByRole('button', { name: msg('common.clear') }));
    await waitFor(() => expect([...api.calls('GET', '/admin/audit-events').at(-1)!.query.keys()].sort()).toEqual(['page', 'pageSize']));
    expect(screen.getByLabelText(lbl(msg('aud.filter.action')))).toHaveValue('');
  });

  it('a "from" date after the "to" date is refused in the form', async () => {
    const api = auditSetup();
    const user = userEvent.setup();
    renderAdmin('/audit');
    await screen.findByRole('row', { name: /appointment\.cancelled/ });
    const before = api.calls('GET', '/admin/audit-events').length;
    setDate(screen.getByLabelText(lbl(msg('aud.filter.from'))), '2026-12-01');
    setDate(screen.getByLabelText(lbl(msg('aud.filter.to'))), '2026-11-01');
    expect(screen.getByText(msg('aud.filter.rangeInvalid'))).toBeInTheDocument();
    expect(screen.getByRole('button', { name: msg('common.search') })).toBeDisabled();
    await user.click(screen.getByRole('button', { name: msg('common.search') }));
    expect(api.calls('GET', '/admin/audit-events')).toHaveLength(before);
  });

  it('says so when nothing matches, and offers a retry when the log cannot be loaded', async () => {
    auditSetup([]);
    renderAdmin('/audit');
    expect(await screen.findByText(msg('aud.empty'))).toBeInTheDocument();

    vi.unstubAllGlobals();
    const api = startAdminBackend();
    let down = true;
    api.route((r) => (r.path === '/admin/audit-events' ? (down ? fail(503, 'SERVICE_UNAVAILABLE') : ok([event()], meta(1))) : undefined));
    const user = userEvent.setup();
    renderAdmin('/audit');
    const retry = await screen.findByRole('button', { name: msg('common.retry') });
    notShown();
    down = false;
    await user.click(retry);
    expect(await screen.findByRole('row', { name: /appointment\.cancelled/ })).toBeInTheDocument();
  });
});

describe('Arabic', () => {
  it('shows settings and the audit log in Arabic, right-to-left', async () => {
    setup();
    renderAdmin('/settings', 'ar');
    expect(await screen.findByRole('heading', { level: 1, name: msg('set.title', 'ar') })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('rtl');
    expect(await screen.findByRole('heading', { level: 2, name: msg('slot.title', 'ar') })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: msg('set.save', 'ar') })).toBeInTheDocument();
  });

  it('the audit log in Arabic uses Arabic labels', async () => {
    auditSetup();
    renderAdmin('/audit', 'ar');
    expect(await screen.findByRole('heading', { level: 1, name: msg('aud.title', 'ar') })).toBeInTheDocument();
    expect(await screen.findAllByText(msg('aud.actor.admin', 'ar'))).not.toHaveLength(0);
  });
});
