import { afterEach, describe, expect, it, vi } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { adminAppointmentFixture, dashboardFixture, fail, startAdminBackend } from './helpers/adminBackend.js';
import { msg, renderAdmin } from './helpers/renderAdmin.js';

afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

describe('dashboard sign-in', () => {
  it('sends a visitor who is not signed in to the sign-in page, and back to the page they wanted afterwards', async () => {
    const api = startAdminBackend({ signedIn: false });
    const user = userEvent.setup();
    renderAdmin('/appointments');
    expect(await screen.findByRole('heading', { name: msg('login.title') })).toBeInTheDocument();
    await user.type(screen.getByLabelText(msg('login.username')), 'admin');
    await user.type(screen.getByLabelText(msg('login.password')), 'correct-password-123');
    await user.click(screen.getByRole('button', { name: msg('login.submit') }));
    expect(await screen.findByRole('heading', { name: msg('admin.nav.appointments') })).toBeInTheDocument();
    expect(api.calls('POST', '/admin/auth/login')).toHaveLength(1);
  });

  it('a wrong password shows the translated message, not the server text, and stays on the sign-in page', async () => {
    startAdminBackend({ signedIn: false });
    const user = userEvent.setup();
    renderAdmin('/login');
    await user.type(await screen.findByLabelText(msg('login.username')), 'admin');
    await user.type(screen.getByLabelText(msg('login.password')), 'wrong');
    await user.click(screen.getByRole('button', { name: msg('login.submit') }));
    expect(await screen.findByText(msg('err.INVALID_CREDENTIALS'))).toBeInTheDocument();
    expect(screen.queryByText(/developer text/)).not.toBeInTheDocument();
    expect(screen.getByRole('heading', { name: msg('login.title') })).toBeInTheDocument();
  });

  it('too many attempts is explained in plain words', async () => {
    const api = startAdminBackend({ signedIn: false });
    api.route((r) => (r.path === '/admin/auth/login' ? fail(429, 'TOO_MANY_ATTEMPTS') : undefined));
    const user = userEvent.setup();
    renderAdmin('/login');
    await user.type(await screen.findByLabelText(msg('login.username')), 'admin');
    await user.type(screen.getByLabelText(msg('login.password')), 'x');
    await user.click(screen.getByRole('button', { name: msg('login.submit') }));
    expect(await screen.findByText(msg('err.TOO_MANY_ATTEMPTS'))).toBeInTheDocument();
  });

  it('the first sign-in forces a password change before any other page, and the change then opens the dashboard', async () => {
    const api = startAdminBackend({ signedIn: true, mustChangePassword: true });
    const user = userEvent.setup();
    renderAdmin('/patients');
    expect(await screen.findByRole('heading', { name: msg('pw.title') })).toBeInTheDocument();
    expect(screen.getByText(msg('pw.forced'))).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: msg('admin.nav.patients') })).not.toBeInTheDocument(); // no navigation while the change is pending

    await user.type(screen.getByLabelText(msg('pw.current')), 'correct-password-123');
    await user.type(screen.getByLabelText(msg('pw.new')), 'a-brand-new-passphrase-1');
    await user.type(screen.getByLabelText(msg('pw.confirm')), 'a-brand-new-passphrase-2');
    expect(await screen.findByText(msg('pw.mismatch'))).toBeInTheDocument();
    expect(screen.getByRole('button', { name: msg('pw.submit') })).toBeDisabled();
    await user.clear(screen.getByLabelText(msg('pw.confirm')));
    await user.type(screen.getByLabelText(msg('pw.confirm')), 'a-brand-new-passphrase-1');
    await user.click(screen.getByRole('button', { name: msg('pw.submit') }));

    expect(await screen.findByRole('heading', { level: 1, name: /2026/ })).toBeInTheDocument(); // dashboard heading carries the date
    const sent = api.calls('POST', '/admin/auth/change-password')[0]!;
    expect(sent.body).toEqual({ currentPassword: 'correct-password-123', newPassword: 'a-brand-new-passphrase-1' });
    expect(sent.headers['x-csrf-token']).toBe('csrf-admin');
    expect(screen.getByRole('link', { name: msg('admin.nav.patients') })).toBeInTheDocument();
  });

  it('a too-short new password is refused with a clear message', async () => {
    startAdminBackend({ signedIn: true, mustChangePassword: false });
    const user = userEvent.setup();
    renderAdmin('/change-password');
    await user.type(await screen.findByLabelText(msg('pw.current')), 'correct-password-123');
    await user.type(screen.getByLabelText(msg('pw.new')), 'short');
    await user.type(screen.getByLabelText(msg('pw.confirm')), 'short');
    await user.click(screen.getByRole('button', { name: msg('pw.submit') }));
    expect(await screen.findByText(msg('err.PASSWORD_TOO_SHORT'))).toBeInTheDocument();
  });

  it('signing out sends the CSRF token and returns to sign-in', async () => {
    const api = startAdminBackend();
    const user = userEvent.setup();
    renderAdmin('/');
    await user.click(await screen.findByRole('button', { name: msg('admin.logout') }));
    expect(await screen.findByRole('heading', { name: msg('login.title') })).toBeInTheDocument();
    expect(api.calls('POST', '/admin/auth/logout')[0]!.headers['x-csrf-token']).toBe('csrf-admin');
  });

  it('a session that ends while using the dashboard returns to sign-in with an explanation', async () => {
    const api = startAdminBackend();
    api.route((r) => (r.path === '/admin/dashboard' ? fail(401, 'SESSION_EXPIRED') : undefined));
    renderAdmin('/');
    expect(await screen.findByRole('heading', { name: msg('login.title') })).toBeInTheDocument();
    expect(screen.getByText(msg('login.expired'))).toBeInTheDocument();
  });
});

describe('dashboard page', () => {
  it('shows today\'s counts, appointments, department load and the coming days from the API', async () => {
    startAdminBackend({
      dashboard: dashboardFixture({
        counts: { booked: 3, completed: 1, no_show: 2, cancelled: 4 },
        appointments: [adminAppointmentFixture({ patient: { id: 'p1', fullName: 'Layla Hassan', phone: '+201000000001' } })],
        departments: [{ id: 'd', slug: 'x', name: 'Orthodontics', activeToday: 4, capacity: 4 }],
        next7Days: [{ date: '2026-11-12', booked: 1 }, { date: '2026-11-13', booked: 5 }],
      }),
    });
    renderAdmin('/');
    await screen.findByText('Layla Hassan');
    expect(within(screen.getByTestId('count-booked')).getByText('3')).toBeInTheDocument();
    expect(within(screen.getByTestId('count-cancelled')).getByText('4')).toBeInTheDocument();
    expect(screen.getByText('Orthodontics')).toBeInTheDocument();
    expect(screen.getByText(msg('dash.load.item', 'en', { count: 4, capacity: 4 }))).toBeInTheDocument();
    expect(screen.getByText('1 appointment')).toBeInTheDocument();
    expect(screen.getByText('5 appointments')).toBeInTheDocument();
  });

  it('says so when there is nothing today, and offers a retry when the page cannot load', async () => {
    const api = startAdminBackend({ dashboard: dashboardFixture({ appointments: [], next7Days: [] }) });
    renderAdmin('/');
    expect(await screen.findByText(msg('dash.none'))).toBeInTheDocument();
    expect(screen.getByText(msg('dash.next7.none'))).toBeInTheDocument();

    let down = true;
    api.route((r) => (down && r.path === '/admin/dashboard' ? fail(503, 'SERVICE_UNAVAILABLE') : undefined));
    const user = userEvent.setup();
    renderAdmin('/');
    const retry = await screen.findByRole('button', { name: msg('common.retry') });
    down = false;
    await user.click(retry);
    await waitFor(() => expect(screen.getAllByText(msg('dash.none')).length).toBeGreaterThan(0));
  });
});

describe('language and direction', () => {
  it('Arabic is right-to-left; switching to French or English turns it left-to-right and is remembered', async () => {
    startAdminBackend();
    const user = userEvent.setup();
    renderAdmin('/', 'ar');
    expect(await screen.findByRole('link', { name: msg('admin.nav.appointments', 'ar') })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('rtl');
    await user.selectOptions(screen.getByLabelText(msg('lang.label', 'ar')), 'fr');
    expect(await screen.findByRole('link', { name: msg('admin.nav.appointments', 'fr') })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('ltr');
    expect(localStorage.getItem('dc.admin.locale')).toBe('fr');
  });
});
