import { vi } from 'vitest';
import type { Appointment, Availability, CenterInfo, DepartmentDetail, DepartmentSummary, PatientProfile } from '../../src/shared/api/types.js';

/**
 * A small in-memory stand-in for the REST API, answering with the exact response envelopes the real backend uses
 * ({ data }, { data, meta }, { error: { code, message } }). It records every request so tests can assert what the UI sent.
 * The real backend is exercised separately (backend integration tests and the browser tests against the running stack).
 */
export interface Req { method: string; path: string; query: URLSearchParams; body: any; headers: Record<string, string> }
export type Override = (req: Req) => Response | undefined | Promise<Response | undefined>;

export const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
export const ok = (data: unknown, meta?: unknown) => json(200, meta ? { data, meta } : { data });
export const fail = (status: number, code: string) => json(status, { error: { code, message: `developer text for ${code}` } });

export const SLOTS = [
  { slotNumber: 1, startTime: '16:00', endTime: '18:00', endsNextDay: false },
  { slotNumber: 2, startTime: '18:00', endTime: '20:00', endsNextDay: false },
  { slotNumber: 3, startTime: '20:00', endTime: '22:00', endsNextDay: false },
  { slotNumber: 4, startTime: '22:00', endTime: '00:00', endsNextDay: true },
];

export function centerFixture(over: Partial<CenterInfo> = {}): CenterInfo {
  return {
    name: 'Test Dental Center', address: '12 Example Street, Cairo', addressConfigured: true, introduction: 'Welcome to the test center.', hoursNote: '',
    phone: '+201000000001', whatsapp: null, email: 'info@example.test', mapUrl: null, timezone: 'Africa/Cairo', currency: 'EGP', defaultLocale: 'ar',
    workingDays: [1, 2, 3, 4, 5, 6, 7], bookingHorizonDays: 60, slots: SLOTS, locales: ['ar', 'en', 'fr'], ...over,
  };
}

export const DEPT_ID = '11111111-1111-4111-8111-111111111111';
export const dentist = { id: 'd1', name: 'Dr. Sample', bio: '', photoPath: null, isSample: true };
export const deptSummary: DepartmentSummary = { id: DEPT_ID, slug: 'endodontics', name: 'Endodontics', description: 'Root canal care', imagePath: null, dentist, serviceCount: 1, bookable: true, workingDays: [1, 2, 3, 4, 5, 6, 7] };
export const deptDetail: DepartmentDetail = { ...deptSummary, services: [{ id: 's1', name: 'Root canal', description: '', price: 350, currency: 'EGP', imagePath: null, isSample: true }], gallery: [] };

export function availabilityFixture(slotsPerDay = [1, 2, 3, 4]): Availability {
  const day = (date: string) => ({
    date, status: 'open' as const, availableCount: slotsPerDay.length,
    slots: SLOTS.filter((s) => slotsPerDay.includes(s.slotNumber)).map((s) => ({ ...s, startsAt: `${date}T${s.startTime}:00+02:00`, endsAt: `${date}T${s.endTime}:00+02:00` })),
  });
  return { department: { id: DEPT_ID, slug: 'endodontics' }, timezone: 'Africa/Cairo', from: '2026-11-10', to: '2026-11-11', days: [day('2026-11-10'), day('2026-11-11')] };
}

export function appointmentFixture(over: Partial<Appointment> = {}): Appointment {
  return {
    id: 'a1', status: 'booked', department: { id: DEPT_ID, slug: 'endodontics', name: 'Endodontics' }, dentist: { id: 'd1', name: 'Dr. Sample' }, service: null,
    date: '2026-11-10', slotNumber: 2, startsAt: '2026-11-10T18:00:00+02:00', endsAt: '2026-11-10T20:00:00+02:00', startTime: '18:00', endTime: '20:00', endsNextDay: false,
    patientNote: null, createdVia: 'web', rescheduledCount: 0, cancelledAt: null, cancelledBy: null,
    selfService: { canCancel: true, canReschedule: true, deadline: '2026-11-09T18:00:00+02:00', blockedReason: null }, ...over,
  };
}

export const PATIENT: PatientProfile = { id: 'p1', fullName: 'Test Patient', phone: '+201000000009', preferredLocale: null };

export function startFakeBackend(opts: { signedIn?: boolean; center?: CenterInfo; appointments?: Appointment[]; availability?: Availability } = {}) {
  const state = {
    signedIn: opts.signedIn ?? false,
    center: opts.center ?? centerFixture(),
    appointments: opts.appointments ?? [],
    availability: opts.availability ?? availabilityFixture(),
    patient: { ...PATIENT },
  };
  const log: Req[] = [];
  const overrides: Override[] = [];

  const route = (r: Req): Response => {
    const m = (re: RegExp) => re.exec(r.path);
    if (r.method === 'GET' && r.path === '/public/center') return ok(state.center);
    if (r.method === 'GET' && r.path === '/public/departments') return ok([deptSummary]);
    if (r.method === 'GET' && m(/^\/public\/departments\/[^/]+\/availability$/)) return ok(state.availability);
    if (r.method === 'GET' && m(/^\/public\/departments\/endodontics$/)) return ok(deptDetail);
    if (r.method === 'GET' && r.path === '/patient/me') return state.signedIn ? ok({ patient: state.patient, csrfToken: 'csrf-1' }) : fail(401, 'UNAUTHENTICATED');
    if (r.method === 'PATCH' && r.path === '/patient/me') { state.patient = { ...state.patient, ...r.body }; return ok({ patient: state.patient }); }
    if (r.method === 'POST' && r.path === '/patient/auth/login') {
      if (r.body.password !== 'correct-password') return fail(401, 'INVALID_CREDENTIALS');
      state.signedIn = true; return ok({ patient: state.patient, csrfToken: 'csrf-1' });
    }
    if (r.method === 'POST' && r.path === '/patient/auth/register') {
      state.signedIn = true; state.patient = { ...state.patient, fullName: r.body.fullName, phone: r.body.phone }; return json(201, { data: { patient: state.patient, csrfToken: 'csrf-1' } });
    }
    if (r.method === 'POST' && r.path === '/patient/auth/logout') { state.signedIn = false; return new Response(null, { status: 204 }); }
    if (!state.signedIn && r.path.startsWith('/patient/')) return fail(401, 'UNAUTHENTICATED');
    if (r.method === 'GET' && r.path === '/patient/appointments') {
      const scope = r.query.get('scope');
      const rows = state.appointments.filter((a) => (scope === 'history' ? a.status !== 'booked' : a.status === 'booked'));
      return ok(rows, { page: 1, pageSize: 50, total: rows.length, totalPages: 1 });
    }
    if (r.method === 'POST' && r.path === '/patient/appointments') {
      const a = appointmentFixture({ id: 'new1', date: r.body.date, slotNumber: r.body.slotNumber });
      state.appointments.push(a); return json(201, { data: a });
    }
    const cancel = m(/^\/patient\/appointments\/([^/]+)\/cancel$/);
    if (r.method === 'POST' && cancel) {
      const a = state.appointments.find((x) => x.id === cancel[1]);
      if (!a) return fail(404, 'NOT_FOUND');
      a.status = 'cancelled'; return ok(a);
    }
    return fail(404, 'NOT_FOUND');
  };

  const fetchFn = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input), 'http://localhost');
    const req: Req = {
      method: (init?.method ?? 'GET').toUpperCase(), path: url.pathname.replace(/^\/api\/v1/, ''), query: url.searchParams,
      body: typeof init?.body === 'string' ? JSON.parse(init.body) : undefined, headers: (init?.headers ?? {}) as Record<string, string>,
    };
    log.push(req);
    for (const o of overrides) { const r = await o(req); if (r) return r; }
    return route(req);
  });
  vi.stubGlobal('fetch', fetchFn);

  return {
    state, log,
    /** Handlers added here run before the default routes; return undefined to fall through. */
    override: (o: Override) => { overrides.unshift(o); },
    calls: (method: string, path: string | RegExp) => log.filter((r) => r.method === method && (typeof path === 'string' ? r.path === path : path.test(r.path))),
  };
}
