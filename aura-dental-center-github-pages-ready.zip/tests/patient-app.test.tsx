import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { PatientProviders, LOCALE_STORAGE_KEY } from '../src/patient/app/Providers.js';
import { PatientRoutes } from '../src/patient/App.js';
import { http } from '../src/patient/api.js';
import { patientMessages, type PatientKey } from '../src/patient/i18n/messages.js';
import { appointmentFixture, centerFixture, deptDetail, fail, ok, startFakeBackend } from './helpers/fakeBackend.js';

/** Looks texts up in the same bundle the app uses, so these tests check behaviour and do not break when wording is improved. */
const text = (l: 'en' | 'ar' | 'fr', key: PatientKey): string => {
  const v = (patientMessages[l] as Record<string, string>)[key];
  if (v === undefined) throw new Error(`test refers to a message key that does not exist: ${key}`);
  return v;
};
const en = (key: PatientKey) => text('en', key);
const patient = { en: new Proxy({}, { get: (_t, k) => text('en', k as PatientKey) }) as Record<PatientKey, string>, ar: new Proxy({}, { get: (_t, k) => text('ar', k as PatientKey) }) as Record<PatientKey, string>, fr: new Proxy({}, { get: (_t, k) => text('fr', k as PatientKey) }) as Record<PatientKey, string> };

function renderApp(path = '/', locale: 'en' | 'ar' | 'fr' | null = 'en') {
  if (locale) localStorage.setItem(LOCALE_STORAGE_KEY, locale);
  return render(
    <MemoryRouter initialEntries={[path]}>
      <PatientProviders><PatientRoutes /></PatientProviders>
    </MemoryRouter>,
  );
}

beforeEach(() => { http.setCsrfToken(null); });
afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

describe('language and direction', () => {
  it('opens in Arabic, right-to-left, when nothing else says otherwise (center default)', async () => {
    vi.spyOn(navigator, 'languages', 'get').mockReturnValue(['de-DE']);
    startFakeBackend();
    renderApp('/', null);
    await waitFor(() => expect(document.documentElement.lang).toBe('ar'));
    expect(document.documentElement.dir).toBe('rtl');
    expect(await screen.findByRole('heading', { level: 1, name: patient.ar['home.hero'] })).toBeInTheDocument();
  });

  it('switching language updates text, lang, dir and is remembered in this browser; the content is re-requested in that language', async () => {
    const api = startFakeBackend();
    const user = userEvent.setup();
    renderApp('/', 'en');
    expect(await screen.findByRole('heading', { level: 1, name: en('home.hero') })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('ltr');

    await user.click(screen.getByRole('button', { name: 'العربية' }));
    expect(await screen.findByRole('heading', { level: 1, name: patient.ar['home.hero'] })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('rtl');
    expect(document.documentElement.lang).toBe('ar');
    expect(localStorage.getItem(LOCALE_STORAGE_KEY)).toBe('ar');
    await waitFor(() => expect(api.calls('GET', '/public/departments').some((r) => r.query.get('locale') === 'ar')).toBe(true));

    expect(screen.getByRole('button', { name: 'العربية' })).toHaveAttribute('aria-pressed', 'true');
    await user.click(screen.getByRole('button', { name: 'Français' }));
    expect(await screen.findByRole('heading', { level: 1, name: patient.fr['home.hero'] })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('ltr');
  });
});

describe('public pages', () => {
  it('shows the address and phone that the API returned, never a built-in one', async () => {
    startFakeBackend({ center: centerFixture({ address: '99 Configured Road, Somewhere', phone: '+201234500000' }) });
    renderApp('/');
    expect(await screen.findByText('99 Configured Road, Somewhere')).toBeInTheDocument();
    expect(screen.getByText(/\+201234500000/)).toBeInTheDocument();
  });

  it('says honestly that the address is not set yet instead of inventing one', async () => {
    startFakeBackend({ center: centerFixture({ address: '', addressConfigured: false }) });
    renderApp('/');
    expect(await screen.findByText(en('footer.addressMissing'))).toBeInTheDocument();
  });

  it('lists departments, and a failed request shows a readable error with a working retry', async () => {
    const api = startFakeBackend();
    let down = true;
    api.override((r) => (down && r.path === '/public/departments' ? fail(503, 'SERVICE_UNAVAILABLE') : undefined));
    const user = userEvent.setup();
    renderApp('/');
    const retry = await screen.findByRole('button', { name: en('common.retry') });
    expect(screen.queryByText(/developer text/)).not.toBeInTheDocument(); // backend wording is never shown
    down = false;
    await user.click(retry);
    expect(await screen.findByRole('link', { name: 'Endodontics' })).toBeInTheDocument();
  });

  it('explains a network failure in plain words', async () => {
    const api = startFakeBackend();
    api.override((r) => { if (r.path === '/public/departments') throw new TypeError('Failed to fetch'); return undefined; });
    renderApp('/');
    expect(await screen.findByText(patient.en['err.NETWORK_ERROR'])).toBeInTheDocument();
  });
});

describe('sign-in and registration', () => {
  it('sends a visitor who is not signed in from /book to sign-in, with an explanation, and back after signing in', async () => {
    startFakeBackend();
    const user = userEvent.setup();
    renderApp('/book?department=endodontics');
    expect(await screen.findByText(en('auth.signInToContinue'))).toBeInTheDocument();
    await user.type(screen.getByLabelText(new RegExp(en('auth.phone'))), '01000000009');
    await user.type(screen.getByLabelText(new RegExp(en('auth.password'))), 'correct-password');
    await user.click(screen.getByRole('button', { name: en('auth.login.submit') }));
    expect(await screen.findByRole('heading', { name: en('book.title') })).toBeInTheDocument();
  });

  it('a wrong password shows the translated message, not the server text, and keeps the visitor signed out', async () => {
    const api = startFakeBackend();
    const user = userEvent.setup();
    renderApp('/login');
    await user.type(await screen.findByLabelText(new RegExp(en('auth.phone'))), '01000000009');
    await user.type(screen.getByLabelText(new RegExp(en('auth.password'))), 'nope');
    await user.click(screen.getByRole('button', { name: en('auth.login.submit') }));
    expect(await screen.findByText(patient.en['err.INVALID_CREDENTIALS'])).toBeInTheDocument();
    expect(screen.queryByText(/developer text/)).not.toBeInTheDocument();
    expect(api.state.signedIn).toBe(false);
  });

  it('registers with only name, phone and password (no OTP step) and lands signed in', async () => {
    const api = startFakeBackend();
    const user = userEvent.setup();
    renderApp('/register');
    await user.type(await screen.findByLabelText(new RegExp(en('auth.fullName'))), 'Sara Ali');
    await user.type(screen.getByLabelText(new RegExp(en('auth.phone'))), '01000000009');
    await user.type(screen.getByLabelText(new RegExp(en('auth.password'))), 'long-enough-pw');
    expect(screen.queryByText(/OTP|verification code|SMS|رمز التحقق/i)).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: en('auth.register.submit') }));
    expect(await screen.findByRole('heading', { name: en('appts.title') })).toBeInTheDocument();
    const sent = api.calls('POST', '/patient/auth/register')[0]!.body;
    expect(Object.keys(sent).sort()).toEqual(['fullName', 'locale', 'password', 'phone']);
    expect(sent.locale).toBe('en');
  });

  it('shows server-side field problems next to the field', async () => {
    const api = startFakeBackend();
    api.override((r) => (r.path === '/patient/auth/register' ? new Response(JSON.stringify({ error: { code: 'INVALID_PHONE', message: 'x', details: [{ field: 'phone', code: 'INVALID_PHONE' }] } }), { status: 400, headers: { 'content-type': 'application/json' } }) : undefined));
    const user = userEvent.setup();
    renderApp('/register');
    await user.type(await screen.findByLabelText(new RegExp(en('auth.fullName'))), 'Sara Ali');
    await user.type(screen.getByLabelText(new RegExp(en('auth.phone'))), '123');
    await user.type(screen.getByLabelText(new RegExp(en('auth.password'))), 'long-enough-pw');
    await user.click(screen.getByRole('button', { name: en('auth.register.submit') }));
    // shown once, at the phone field (the real backend answers with the same code at the top and at the field)
    expect(await screen.findAllByText(patient.en['err.INVALID_PHONE'], { selector: '*' })).toHaveLength(1);
    expect(screen.getByLabelText(new RegExp(en('auth.phone')))).toHaveAccessibleDescription(new RegExp(patient.en['err.INVALID_PHONE']));
  });

  it('signing out returns to the anonymous menu and sends the CSRF token', async () => {
    const api = startFakeBackend({ signedIn: true });
    const user = userEvent.setup();
    renderApp('/appointments');
    await user.click(await screen.findByRole('button', { name: en('nav.logout') }));
    await screen.findByRole('link', { name: en('nav.login') });
    expect(api.calls('POST', '/patient/auth/logout')[0]!.headers['x-csrf-token']).toBe('csrf-1');
  });
});

describe('booking', () => {
  async function chooseSlot(user: ReturnType<typeof userEvent.setup>) {
    await user.click(await screen.findByRole('radio', { name: /10 November 2026/ }));
    await user.click(await screen.findByRole('radio', { name: /^6:00\s?pm/i }));
  }

  it('books the chosen day and time and shows a confirmation', async () => {
    const api = startFakeBackend({ signedIn: true });
    const user = userEvent.setup();
    renderApp('/book?department=endodontics');
    await chooseSlot(user);
    await user.click(screen.getByRole('button', { name: en('book.submit') }));
    expect(await screen.findByText(en('book.success'))).toBeInTheDocument();
    const call = api.calls('POST', '/patient/appointments')[0]!;
    expect(call.body).toEqual({ departmentId: '11111111-1111-4111-8111-111111111111', serviceId: null, date: '2026-11-10', slotNumber: 2 });
    expect(call.headers['x-csrf-token']).toBe('csrf-1');
  });

  it('the confirm button stays disabled until a time is chosen', async () => {
    startFakeBackend({ signedIn: true });
    renderApp('/book?department=endodontics');
    const submit = await screen.findByRole('button', { name: en('book.submit') });
    await screen.findByRole('radio', { name: /10 November 2026/ });
    expect(submit).toBeDisabled();
  });

  it('a slot taken meanwhile is refused clearly, the stale choice is dropped and availability is reloaded', async () => {
    const api = startFakeBackend({ signedIn: true });
    api.override((r) => (r.method === 'POST' && r.path === '/patient/appointments' ? fail(409, 'SLOT_UNAVAILABLE') : undefined));
    const user = userEvent.setup();
    renderApp('/book?department=endodontics');
    await chooseSlot(user);
    const before = api.calls('GET', /availability$/).length;
    await user.click(screen.getByRole('button', { name: en('book.submit') }));
    expect(await screen.findByText(patient.en['err.SLOT_UNAVAILABLE'])).toBeInTheDocument();
    expect(screen.queryByText(en('book.success'))).not.toBeInTheDocument();
    await waitFor(() => expect(api.calls('GET', /availability$/).length).toBeGreaterThan(before));
    expect(screen.getByRole('button', { name: en('book.submit') })).toBeDisabled();
  });

  it('a double click sends one booking request, not two', async () => {
    const api = startFakeBackend({ signedIn: true });
    api.override(async (r) => { if (r.method === 'POST' && r.path === '/patient/appointments') await new Promise((res) => setTimeout(res, 50)); return undefined; });
    const user = userEvent.setup();
    renderApp('/book?department=endodontics');
    await chooseSlot(user);
    const submit = screen.getByRole('button', { name: en('book.submit') });
    await user.dblClick(submit);
    await screen.findByText(en('book.success'));
    expect(api.calls('POST', '/patient/appointments')).toHaveLength(1);
  });

  it('shows the days returned by the API only, with the booked-out time slots absent', async () => {
    const { availabilityFixture } = await import('./helpers/fakeBackend.js');
    startFakeBackend({ signedIn: true, availability: availabilityFixture([3, 4]) });
    const user = userEvent.setup();
    renderApp('/book?department=endodontics');
    await user.click(await screen.findByRole('radio', { name: /10 November 2026/ }));
    const group = await screen.findByRole('radiogroup', { name: en('book.time') });
    expect(within(group).getAllByRole('radio')).toHaveLength(2);
    expect(within(group).queryByRole('radio', { name: /^4:00\s?pm/i })).not.toBeInTheDocument();
  });
});

describe('department working days (patient site)', () => {
  const limited = { ...deptDetail, workingDays: [1, 3, 5] };

  it('the department page names the days a limited department works', async () => {
    const api = startFakeBackend({});
    api.override((r) => (r.method === 'GET' && r.path === '/public/departments/endodontics' ? ok(limited) : undefined));
    renderApp('/departments/endodontics');
    expect(await screen.findByText(/^Working days: Monday, Wednesday,? (and |& )?Friday$/)).toBeInTheDocument();
  });

  it('a department that works every day shows no working-days line', async () => {
    startFakeBackend({});
    renderApp('/departments/endodontics');
    await screen.findByRole('heading', { name: 'Endodontics' });
    expect(screen.queryByText(/^Working days:/)).not.toBeInTheDocument();
  });

  it('the booking page shows the same line, and offers only the days the API reports as open (a day off is not offered)', async () => {
    const { availabilityFixture } = await import('./helpers/fakeBackend.js');
    const availability = availabilityFixture();
    availability.days = [{ ...availability.days[0]!, status: 'closed', availableCount: 0, slots: [] }, availability.days[1]!];
    const api = startFakeBackend({ signedIn: true, availability });
    api.override((r) => (r.method === 'GET' && r.path === '/public/departments/endodontics' ? ok(limited) : undefined));
    renderApp('/book?department=endodontics');
    expect(await screen.findByText(/^Working days: Monday/)).toBeInTheDocument();
    expect(await screen.findByRole('radio', { name: /11 November 2026/ })).toBeInTheDocument();
    expect(screen.queryByRole('radio', { name: /10 November 2026/ })).not.toBeInTheDocument();
  });

  it('if the backend still refuses (a day switched off a moment ago) the translated reason is shown and the booking is not shown as made', async () => {
    const api = startFakeBackend({ signedIn: true });
    api.override((r) => (r.method === 'POST' && r.path === '/patient/appointments' ? fail(422, 'DEPARTMENT_NOT_WORKING_DAY') : undefined));
    const user = userEvent.setup();
    renderApp('/book?department=endodontics');
    await user.click(await screen.findByRole('radio', { name: /10 November 2026/ }));
    await user.click(await screen.findByRole('radio', { name: /^6:00\s?pm/i }));
    await user.click(screen.getByRole('button', { name: en('book.submit') }));
    expect(await screen.findByText(patient.en['err.DEPARTMENT_NOT_WORKING_DAY'])).toBeInTheDocument();
    expect(screen.queryByText(en('book.success'))).not.toBeInTheDocument();
  });

  it('the refusal and the working-days line exist in all three languages, each in its own words', () => {
    for (const key of ['err.DEPARTMENT_NOT_WORKING_DAY', 'departments.workingDays'] as const) {
      const [e, a, f] = [patient.en[key], patient.ar[key], patient.fr[key]];
      expect(new Set([e, a, f]).size, key).toBe(3);
      expect(e.length * a.length * f.length, key).toBeGreaterThan(0);
    }
  });
});

describe('my appointments', () => {
  it('lists upcoming appointments and cancels one after confirmation (CSRF sent, list refreshed)', async () => {
    const api = startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    const user = userEvent.setup();
    renderApp('/appointments');
    const card = await screen.findByRole('article', { name: /Endodontics/ });
    await user.click(within(card).getByRole('button', { name: en('appts.cancel') }));
    const dialog = await screen.findByRole('dialog', { name: en('appts.cancel.title') });
    await user.click(within(dialog).getByRole('button', { name: en('appts.cancel.confirm') }));
    expect(await screen.findByText(en('appts.cancelled'))).toBeInTheDocument();
    const call = api.calls('POST', '/patient/appointments/a1/cancel')[0]!;
    expect(call.headers['x-csrf-token']).toBe('csrf-1');
    await waitFor(() => expect(screen.queryByRole('article', { name: /Endodontics/ })).not.toBeInTheDocument());
    expect(screen.getByText(en('appts.empty.upcoming'))).toBeInTheDocument();
  });

  it('keeping the appointment sends nothing', async () => {
    const api = startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    const user = userEvent.setup();
    renderApp('/appointments');
    await user.click(await screen.findByRole('button', { name: en('appts.cancel') }));
    await user.click(await screen.findByRole('button', { name: en('appts.cancel.keep') }));
    expect(api.calls('POST', /cancel$/)).toHaveLength(0);
  });

  it('inside the 24-hour window the page offers no cancel or change, and says to contact the center', async () => {
    startFakeBackend({ signedIn: true, appointments: [appointmentFixture({ selfService: { canCancel: false, canReschedule: false, deadline: null, blockedReason: 'WITHIN_24H' } })] });
    renderApp('/appointments');
    expect(await screen.findByText(en('appts.locked'))).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: en('appts.cancel') })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: en('appts.reschedule') })).not.toBeInTheDocument();
  });

  it('if the backend refuses a cancel because of the 24-hour rule, the message says so and the appointment stays', async () => {
    const api = startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    api.override((r) => (r.path.endsWith('/cancel') ? fail(409, 'WITHIN_24H_WINDOW') : undefined));
    const user = userEvent.setup();
    renderApp('/appointments');
    await user.click(await screen.findByRole('button', { name: en('appts.cancel') }));
    await user.click(await screen.findByRole('button', { name: en('appts.cancel.confirm') }));
    const dialog = await screen.findByRole('dialog');
    expect(await within(dialog).findByText(patient.en['err.WITHIN_24H_WINDOW'])).toBeInTheDocument();
    expect(screen.getByRole('article', { name: /Endodontics/ })).toBeInTheDocument();
  });

  it('a session that ends while using the page sends the patient to sign in with an explanation', async () => {
    const api = startFakeBackend({ signedIn: true });
    api.override((r) => (r.path === '/patient/appointments' ? fail(401, 'SESSION_EXPIRED') : undefined));
    renderApp('/appointments');
    expect(await screen.findByRole('heading', { name: en('auth.login.title') })).toBeInTheDocument();
    expect(screen.getByText(en('auth.sessionExpired'))).toBeInTheDocument();
  });
});

describe('Arabic rendering of dynamic content', () => {
  it('shows times and dates in Arabic with Latin digits, and keeps phone numbers left-to-right', async () => {
    startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    renderApp('/appointments', 'ar');
    const card = await screen.findByRole('article');
    expect(card.textContent).toMatch(/6:00 م/);
    expect(card.textContent).toMatch(/نوفمبر/);
    expect(card.textContent).not.toMatch(/[٠-٩]/);
    expect(document.documentElement.dir).toBe('rtl');
  });
});
