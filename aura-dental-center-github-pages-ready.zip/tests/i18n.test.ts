import { describe, expect, it } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { baseLocale, detectLocale } from '../src/shared/i18n/detect.js';
import { formatClock, formatDate, formatInstant, formatList, formatPrice, formatTimeRange, interpolate, isolateLtr, pluralCategory, weekdayName } from '../src/shared/i18n/format.js';
import { common } from '../src/shared/i18n/messages/common.js';
import { patient } from '../src/patient/i18n/messages.js';
import { adminBundles } from '../src/admin/i18n/messages.js';
import { defineMessages } from '../src/shared/i18n/types.js';
import { LOCALES } from '../src/shared/api/types.js';

describe('language detection policy', () => {
  it('explicit browser choice > account preference > browser language > center default > Arabic', () => {
    expect(detectLocale({ stored: 'fr', account: 'en', browser: ['ar'], centerDefault: 'en' })).toBe('fr');
    expect(detectLocale({ account: 'en', browser: ['ar'], centerDefault: 'fr' })).toBe('en');
    expect(detectLocale({ browser: ['de-DE', 'fr-CA', 'ar'], centerDefault: 'en' })).toBe('fr');
    expect(detectLocale({ browser: ['de'], centerDefault: 'en' })).toBe('en');
    expect(detectLocale({ browser: ['de'] })).toBe('ar');
    expect(detectLocale({})).toBe('ar');
  });
  it('ignores unsupported or malformed values', () => {
    expect(detectLocale({ stored: 'zz', account: '<script>', browser: ['xx'], centerDefault: 'yy' })).toBe('ar');
    expect(baseLocale('AR-eg')).toBe('ar');
    expect(baseLocale('en_US')).toBe('en');
    expect(baseLocale(null)).toBeNull();
  });
});

describe('formatting', () => {
  it('formats plain dates the same calendar day for everyone (no time-zone shift)', () => {
    expect(formatDate('2026-11-10', 'en')).toBe('Tuesday, 10 November 2026');
    expect(formatDate('2026-11-10', 'fr')).toBe('mardi 10 novembre 2026');
    expect(formatDate('2026-11-10', 'ar')).toContain('10');
    expect(formatDate('2026-11-10', 'ar')).toContain('نوفمبر');
    expect(formatDate('2026-11-10', 'en', 'short')).toBe('10/11/2026');
    expect(formatDate('2026-12-31', 'en', 'weekday')).toBe('Thursday');
    expect(formatDate('not-a-date', 'en')).toBe('not-a-date');
    expect(formatDate('2026-02-31', 'en')).not.toContain('Feb'); // invalid calendar day is not silently rolled into March in a misleading way
  });
  it('shows clock times in 12 h for ar/en and 24 h for fr, including midnight', () => {
    expect(formatClock('18:00', 'en')).toMatch(/^6:00 ?pm$/i);
    expect(formatClock('18:00', 'ar')).toBe('6:00 م');
    expect(formatClock('18:00', 'fr')).toBe('18:00');
    expect(formatClock('00:00', 'fr')).toBe('00:00');
    expect(formatClock('00:00', 'en')).toMatch(/^12:00 ?am$/i);
    expect(formatClock('00:00', 'ar')).toBe('12:00 ص');
    expect(formatTimeRange('22:00', '00:00', 'fr')).toBe('22:00 – 00:00');
    expect(formatClock('bad', 'en')).toBe('bad');
  });
  it('shows instants in the center time zone, not the browser zone', () => {
    // 2026-11-10T14:00:00Z is 16:00 in Cairo (UTC+2 in November)
    expect(formatInstant('2026-11-10T14:00:00Z', 'fr', 'Africa/Cairo')).toContain('16:00');
    expect(formatInstant('2026-11-10T14:00:00Z', 'fr', 'America/New_York')).toContain('09:00');
    expect(formatInstant('garbage', 'en', 'Africa/Cairo')).toBe('garbage');
  });
  it('formats prices, weekdays and lists per language', () => {
    expect(formatPrice(350, 'EGP', 'en')).toContain('350');
    expect(formatPrice(350, 'EGP', 'fr')).toContain('350,00');
    expect(formatPrice(1, 'NOT_A_CURRENCY', 'en')).toBe('1 NOT_A_CURRENCY');
    expect(weekdayName(1, 'en')).toBe('Monday');
    expect(weekdayName(7, 'fr')).toBe('dimanche');
    expect(weekdayName(6, 'ar')).toBe('السبت');
    expect(formatList(['a', 'b', 'c'], 'en')).toBe('a, b and c');
  });
  it('isolates left-to-right text (phone numbers) inside right-to-left text', () => {
    expect(isolateLtr('+20 100 000 0000')).toBe('⁦+20 100 000 0000⁩');
  });
  it('interpolates placeholders and never prints a raw {name}', () => {
    expect(interpolate('Hello {name}, {count} left', { name: 'Sara', count: 3 })).toBe('Hello Sara, 3 left');
    expect(interpolate('Hello {name}', {})).toBe('Hello ');
    expect(interpolate('plain')).toBe('plain');
  });
  it('knows the Arabic plural categories', () => {
    expect([0, 1, 2, 3, 11, 100].map((n) => pluralCategory(n, 'ar'))).toEqual(['zero', 'one', 'two', 'few', 'many', 'other']);
    expect([1, 2].map((n) => pluralCategory(n, 'en'))).toEqual(['one', 'other']);
  });
});

describe('message bundles', () => {
  type Bundle = Record<'en' | 'ar' | 'fr', Record<string, string>>;
  // Every text the website and the admin dashboard show, one bundle per area.
  const bundles: Record<string, Bundle> = {
    common, patient,
    ...Object.fromEntries(Object.entries(adminBundles).map(([area, b]) => [`admin.${area}`, b])),
  } as Record<string, Bundle>;
  const placeholders = (s: string) => [...s.matchAll(/\{(\w+)\}/g)].map((m) => m[1]!).sort().join(',');

  for (const [name, b] of Object.entries(bundles)) {
    it(`${name}: ar and fr define exactly the keys of en`, () => {
      const keys = Object.keys(b.en).sort();
      expect(Object.keys(b.ar).sort()).toEqual(keys);
      expect(Object.keys(b.fr).sort()).toEqual(keys);
    });
    it(`${name}: no empty text, and the same placeholders in every language`, () => {
      for (const [key, en] of Object.entries(b.en)) {
        for (const l of LOCALES) {
          const text = (b[l] as Record<string, string>)[key]!;
          expect(text.trim(), `${name}.${l}.${key}`).not.toBe('');
          // Plural forms may legitimately drop {count} ("موعد واحد متاح" = "one free time"); every other text keeps exactly the same placeholders.
          const isPlural = /_(zero|one|two|few|many|other)$/.test(key);
          const mine = placeholders(text); const theirs = placeholders(en);
          if (isPlural) expect(mine.split(',').filter(Boolean).every((x) => theirs.split(',').includes(x)), `${name}.${l}.${key}`).toBe(true);
          else expect(mine, `${name}.${l}.${key}`).toBe(theirs);
        }
      }
    });
    it(`${name}: Arabic and French texts really are in their language (not copied English)`, () => {
      const words = (v: string) => v.replace(/\{\w+\}/g, ''); // a template made only of placeholders and separators is language-neutral
      const same = Object.entries(b.en).filter(([k, v]) => /[A-Za-z]{4,}/.test(words(v)) && (b.ar as Record<string, string>)[k] === v && !/^(lang|common\.none)/.test(k));
      expect(same.map(([k]) => k), 'Arabic identical to English').toEqual([]);
      const sameFr = Object.entries(b.en).filter(([k, v]) => words(v).trim().length > 12 && (b.fr as Record<string, string>)[k] === v);
      expect(sameFr.map(([k]) => k), 'French identical to English').toEqual([]);
      for (const v of Object.values(b.ar)) expect(/[؀-ۿ]/.test(v) || !/[A-Za-z]{3,}/.test(v) || /\/link|\{|WhatsApp/.test(v), v).toBe(true);
    });
  }

  it('plural groups define every category their language needs', () => {
    let checked = 0;
    for (const [name, b] of Object.entries(bundles)) {
      const groups = new Set(Object.keys(b.en).filter((k) => /_(one|other)$/.test(k)).map((k) => k.replace(/_(one|other)$/, '')));
      for (const g of groups) {
        checked += 1;
        for (const l of LOCALES) {
          const needed = l === 'ar' ? ['zero', 'one', 'two', 'few', 'many', 'other'] : ['one', 'other'];
          for (const c of needed) expect(b[l][`${g}_${c}`], `${name}.${l}.${g}_${c}`).toBeTruthy();
        }
      }
    }
    expect(checked, "plural groups found across all bundles").toBeGreaterThanOrEqual(4);
  });

  it('covers the dashboard: every area has texts, and the areas are the ones the dashboard really has', () => {
    expect(Object.keys(adminBundles).sort()).toEqual(['appointments', 'catalog', 'core', 'patients', 'settings']);
    for (const [area, b] of Object.entries(adminBundles)) expect(Object.keys(b.en).length, area).toBeGreaterThan(10);
  });

  it('defineMessages rejects a bundle where a language misses or misspells a key (compile-time guarantee)', () => {
    defineMessages({
      en: { a: 'A', b: 'B' },
      // @ts-expect-error  ar is missing key "b"
      ar: { a: 'أ' },
      fr: { a: 'A', b: 'B' },
    });
    expect(true).toBe(true);
  });
});

describe('every error code the backend can emit has a user-facing translation in all languages', () => {
  const root = join(__dirname, '..', '..', 'backend', 'src');
  function walk(dir: string): string[] {
    return readdirSync(dir).flatMap((f) => {
      const p = join(dir, f);
      return statSync(p).isDirectory() ? walk(p) : p.endsWith('.ts') ? [p] : [];
    });
  }
  /** Quoted UPPER_SNAKE words in the backend that are not error codes (SQL, HTTP verbs, process signals, internals). */
  const NOT_CODES = new Set(['ASC', 'DESC', 'BEGIN', 'COMMIT', 'ROLLBACK', 'DELETE', 'GET', 'POST', 'PUT', 'PATCH', 'SIGINT', 'SIGTERM', 'ABCDEFGHJKMNPQRSTUVWXYZ23456789',
    'FST_ERR_CTP_BODY_TOO_LARGE', 'FST_ERR_CTP_EMPTY_JSON_BODY', 'FST_ERR_CTP_INVALID_JSON_BODY', 'FST_ERR_CTP_INVALID_MEDIA_TYPE']);

  it('covers all codes found in the backend source (so a new backend code cannot ship untranslated)', () => {
    const codes = new Set<string>();
    for (const file of walk(root)) {
      for (const m of readFileSync(file, 'utf8').matchAll(/'([A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+)'|'([A-Z]{4,})'/g)) codes.add((m[1] ?? m[2])!);
    }
    for (const c of NOT_CODES) codes.delete(c);
    expect(codes.size).toBeGreaterThan(60);
    const missing = [...codes].filter((c) => !(`err.${c}` in common.en));
    expect(missing).toEqual([]);
  });

  it('covers the machine-readable list in docs/openapi.json too', () => {
    const spec = JSON.parse(readFileSync(join(__dirname, '..', '..', 'docs', 'openapi.json'), 'utf8')) as unknown;
    const codes = new Set<string>();
    (function scan(x: unknown) {
      if (Array.isArray(x)) x.forEach(scan);
      else if (x && typeof x === 'object') for (const [k, v] of Object.entries(x)) { if (k === 'x-error-codes' && Array.isArray(v)) v.forEach((c) => codes.add(String(c))); else scan(v); }
    })(spec);
    expect(codes.size).toBeGreaterThan(30);
    expect([...codes].filter((c) => !(`err.${c}` in common.en))).toEqual([]);
  });

  it('every client-side network failure code has text, and no error text mentions internals', () => {
    for (const code of ['NETWORK_ERROR', 'TIMEOUT', 'UPSTREAM_ERROR', 'REQUEST_FAILED']) expect(common.en[`err.${code}` as keyof typeof common.en]).toBeTruthy();
    for (const l of LOCALES) for (const [k, v] of Object.entries(common[l] as Record<string, string>)) if (k.startsWith('err.')) expect(v, `${l}.${k}`).not.toMatch(/stack ?trace|\bsql\b|postgres|undefined|\bnull\b|\[object/i);
  });
});
