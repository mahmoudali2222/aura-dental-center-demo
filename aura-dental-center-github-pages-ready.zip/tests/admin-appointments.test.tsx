import { afterEach, describe, expect, it, vi } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { adminAppointmentFixture, fail, json, ok, startAdminBackend } from './helpers/adminBackend.js';
import { availabilityFixture } from './helpers/fakeBackend.js';
import { msg, renderAdmin } from './helpers/renderAdmin.js';
import type { AdminAppointment, AdminDepartment } from '../src/admin/api/types.js';

afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

const DEPT: AdminDepartment = {
  id: '11111111-1111-4111-8111-111111111111', slug: 'endodontics', displayOrder: 1, isActive: true, imagePath: null, workingDays: [1, 2, 3, 4, 5, 6, 7],
  translations: { en: { name: 'Endodontics', description: '' } }, dentist: { id: 'd1', photoPath: null, isSample: true, translations: { en: { name: 'Dr. Sample', bio: '' } } },
  serviceCount: 1, bookable: true, createdAt: '2026-01-01T00:00:00Z', updatedAt: '2026-01-01T00:00:00Z',
};
/** Label matcher that tolerates the " (optional)" suffix and regex characters in the message. */
const lbl = (text: string) => new RegExp(text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
const meta = (total: number, page = 1, totalPages = 1) => ({ page, pageSize: 25, total, totalPages });

/** Admin API for this area: appointments kept in memory so writes are visible on the next list call. */
function setup(initial: AdminAppointment[] = [adminAppointmentFixture()], opts: { totalPages?: number } = {}) {
  const api = startAdminBackend();
  const rows = [...initial];
  api.route((r) => {
    if (r.method === 'GET' && r.path === '/admin/appointments') return ok(rows, meta(rows.length, Number(r.query.get('page') ?? 1), opts.totalPages ?? 1));
    if (r.method === 'GET' && r.path === '/admin/departments') return ok([DEPT]);
    if (r.method === 'GET' && r.path === '/admin/services') return ok([]);
    if (r.method === 'GET' && /^\/public\/departments\/[^/]+\/availability$/.test(r.path)) return ok(availabilityFixture());
    const act = /^\/admin\/appointments\/([^/]+)\/(cancel|reschedule|status)$/.exec(r.path);
    if (r.method === 'POST' && act) {
      const a = rows.find((x) => x.id === act[1]);
      if (!a) return fail(404, 'APPOINTMENT_NOT_FOUND');
      if (act[2] === 'cancel') { a.status = 'cancelled'; a.cancelReason = r.body.reason ?? null; a.cancelledBy = 'admin'; }
      if (act[2] === 'reschedule') { a.date = r.body.date; a.slotNumber = r.body.slotNumber; }
      if (act[2] === 'status') a.status = r.body.status;
      return ok(a);
    }
    return undefined;
  });
  return { api, rows };
}

async function openManage(user: ReturnType<typeof userEvent.setup>, name = 'Test Patient') {
  await user.click(await screen.findByRole('button', { name: new RegExp(`${name}`) }));
  return screen.findByRole('dialog', { name: msg('appts.detail.title') });
}

describe('appointment list', () => {
  it('opens on today..today+7 (the center calendar), lists the rows and says how many there are', async () => {
    const { api } = setup();
    renderAdmin('/appointments');
    expect(await screen.findByText('Test Patient')).toBeInTheDocument();
    const q = api.calls('GET', '/admin/appointments')[0]!.query;
    expect(q.get('from')).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    const from = new Date(`${q.get('from')}T00:00:00Z`).getTime();
    expect(new Date(`${q.get('to')}T00:00:00Z`).getTime() - from).toBe(7 * 86_400_000);
    expect(q.get('page')).toBe('1');
    expect(q.get('sort')).toBe('asc');
    expect(screen.getByText('1 result')).toBeInTheDocument();
    expect(within(screen.getByRole('table')).getByText('Endodontics')).toBeInTheDocument();
  });

  it('applies filters only on Search, sends them in the query and goes back to page 1', async () => {
    const { api } = setup(undefined, { totalPages: 2 });
    const user = userEvent.setup();
    renderAdmin('/appointments');
    await screen.findByText('Test Patient');
    await user.click(screen.getByRole('button', { name: msg('common.next') }));
    await waitFor(() => expect(api.calls('GET', '/admin/appointments').at(-1)!.query.get('page')).toBe('2'));

    await user.selectOptions(screen.getByLabelText(msg('appts.filter.department')), DEPT.id);
    await user.selectOptions(screen.getByLabelText(msg('appts.filter.status')), 'cancelled');
    await user.type(screen.getByLabelText(msg('appts.filter.search')), 'layla');
    expect(api.calls('GET', '/admin/appointments').at(-1)!.query.get('status')).toBeNull(); // not applied yet
    await user.click(screen.getByRole('button', { name: msg('common.search') }));
    await waitFor(() => {
      const q = api.calls('GET', '/admin/appointments').at(-1)!.query;
      expect(q.get('departmentId')).toBe(DEPT.id);
      expect(q.get('status')).toBe('cancelled');
      expect(q.get('q')).toBe('layla');
      expect(q.get('page')).toBe('1');
    });
  });

  it('refuses a date range that ends before it starts', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/appointments');
    await screen.findByText('Test Patient');
    await user.clear(screen.getByLabelText(msg('appts.filter.to')));
    await user.type(screen.getByLabelText(msg('appts.filter.to')), '2000-01-01');
    expect(screen.getByText(msg('appts.filter.rangeInvalid'))).toBeInTheDocument();
    expect(screen.getByRole('button', { name: msg('common.search') })).toBeDisabled();
    expect(api.calls('GET', '/admin/appointments').every((c) => c.query.get('to') !== '2000-01-01')).toBe(true);
  });

  it('says so when nothing matches', async () => {
    setup([]);
    renderAdmin('/appointments');
    expect(await screen.findByText(msg('appts.empty'))).toBeInTheDocument();
  });
});

describe('cancel', () => {
  it('cancels without any override when the backend allows it, then refreshes the list', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.cancel') }));
    await user.type(within(dialog).getByLabelText(lbl(msg('appts.cancel.reason'))), 'Patient called');
    await user.click(within(dialog).getByRole('button', { name: msg('appts.cancel.confirm') }));
    expect(await screen.findByText(msg('appts.cancel.done'))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/appointments/a1/cancel')[0]!;
    expect(call.body).toEqual({ reason: 'Patient called' });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    await waitFor(() => expect(screen.getAllByText(msg('status.cancelled')).length).toBeGreaterThan(0));
  });

  it('inside the 24-hour window the first attempt has no override; the exception needs a reason and an explicit confirmation', async () => {
    const { api } = setup();
    let first = true;
    api.route((r) => {
      if (r.method === 'POST' && r.path === '/admin/appointments/a1/cancel' && !r.body.override) { first = false; return fail(409, 'WITHIN_24H_WINDOW'); }
      return undefined;
    });
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.cancel') }));
    await user.click(within(dialog).getByRole('button', { name: msg('appts.cancel.confirm') }));

    expect(await within(dialog).findByText(msg('appts.override.title'))).toBeInTheDocument();
    expect(first).toBe(false);
    expect(api.calls('POST', /cancel$/)[0]!.body).not.toHaveProperty('override');
    expect(within(dialog).queryByText(msg('err.WITHIN_24H_WINDOW'))).not.toBeInTheDocument(); // turned into the exception step, not a dead-end error

    const go = within(dialog).getByRole('button', { name: msg('appts.override.cancel') });
    expect(go).toBeDisabled();
    await user.type(within(dialog).getByLabelText(lbl(msg('appts.override.reason'))), 'Doctor is ill');
    expect(go).toBeDisabled(); // reason alone is not enough
    await user.click(within(dialog).getByRole('checkbox', { name: msg('appts.override.confirm') }));
    expect(go).toBeEnabled();
    await user.click(go);

    await screen.findByText(msg('appts.cancel.done'));
    const sent = api.calls('POST', /cancel$/);
    expect(sent).toHaveLength(2);
    expect(sent[1]!.body).toEqual({ reason: 'Doctor is ill', override: true });
  });

  it('keeping the appointment sends nothing', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.cancel') }));
    await user.click(within(dialog).getByRole('button', { name: msg('appts.cancel.keep') }));
    expect(api.calls('POST', /cancel$/)).toHaveLength(0);
    expect(within(dialog).getByRole('button', { name: msg('appts.action.cancel') })).toBeInTheDocument();
  });

  it('a double click sends one request and the backend text is never shown on failure', async () => {
    const { api } = setup();
    api.route(async (r) => { if (r.path.endsWith('/cancel')) { await new Promise((res) => setTimeout(res, 40)); return fail(500, 'INTERNAL_ERROR'); } return undefined; });
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.cancel') }));
    await user.dblClick(within(dialog).getByRole('button', { name: msg('appts.cancel.confirm') }));
    expect(await within(dialog).findByText(msg('err.INTERNAL_ERROR'))).toBeInTheDocument();
    expect(api.calls('POST', /cancel$/)).toHaveLength(1);
    expect(screen.queryByText(/developer text/)).not.toBeInTheDocument();
  });

  it('a cancelled appointment shows who cancelled it and why, and offers no actions', async () => {
    setup([adminAppointmentFixture({ status: 'cancelled', cancelledBy: 'telegram', cancelledAt: '2026-11-01T10:00:00+02:00', cancelReason: 'Changed plans' })]);
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    expect(within(dialog).getByText(msg('appts.by.telegram'))).toBeInTheDocument();
    expect(within(dialog).getByText('Changed plans')).toBeInTheDocument();
    expect(within(dialog).queryByRole('button', { name: msg('appts.action.cancel') })).not.toBeInTheDocument();
    expect(within(dialog).queryByRole('button', { name: msg('appts.action.reschedule') })).not.toBeInTheDocument();
  });
});

describe('reschedule', () => {
  async function pick(dialog: HTMLElement, user: ReturnType<typeof userEvent.setup>) {
    await user.click(await within(dialog).findByRole('radio', { name: /11\/11\/2026/ }));
    await user.click(await within(dialog).findByRole('radio', { name: /^8:00\s?pm/i }));
  }

  it('moves the appointment to a slot taken from real availability', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.reschedule') }));
    await pick(dialog, user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.resched.confirm') }));
    expect(await screen.findByText(msg('appts.resched.done'))).toBeInTheDocument();
    expect(api.calls('POST', '/admin/appointments/a1/reschedule')[0]!.body).toEqual({ date: '2026-11-11', slotNumber: 3 });
    expect(api.calls('POST', /reschedule$/)[0]!.headers['x-csrf-token']).toBe('csrf-admin');
  });

  it('a slot taken in the meantime is refused, the stale choice is dropped and availability reloads', async () => {
    const { api } = setup();
    api.route((r) => (r.path.endsWith('/reschedule') ? fail(409, 'SLOT_UNAVAILABLE') : undefined));
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.reschedule') }));
    await pick(dialog, user);
    const before = api.calls('GET', /availability$/).length;
    await user.click(within(dialog).getByRole('button', { name: msg('appts.resched.confirm') }));
    expect(await within(dialog).findByText(msg('err.SLOT_UNAVAILABLE'))).toBeInTheDocument();
    await waitFor(() => expect(api.calls('GET', /availability$/).length).toBeGreaterThan(before));
    expect(within(dialog).getByRole('button', { name: msg('appts.resched.confirm') })).toBeDisabled();
  });

  it('inside the 24-hour window the move needs the same reasoned exception, with override sent only the second time', async () => {
    const { api } = setup();
    api.route((r) => (r.path.endsWith('/reschedule') && !r.body.override ? fail(409, 'WITHIN_24H_WINDOW') : undefined));
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.reschedule') }));
    await pick(dialog, user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.resched.confirm') }));
    await within(dialog).findByText(msg('appts.override.title'));
    await user.type(within(dialog).getByLabelText(lbl(msg('appts.override.reason'))), 'Clinic closed that day');
    await user.click(within(dialog).getByRole('checkbox'));
    await user.click(within(dialog).getByRole('button', { name: msg('appts.override.reschedule') }));
    await screen.findByText(msg('appts.resched.done'));
    const sent = api.calls('POST', /reschedule$/);
    expect(sent[0]!.body).not.toHaveProperty('override');
    expect(sent[1]!.body).toEqual({ date: '2026-11-11', slotNumber: 3, reason: 'Clinic closed that day', override: true });
  });
});

describe('status', () => {
  it('marks an appointment completed after confirmation', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.complete') }));
    await user.click(within(dialog).getByRole('button', { name: msg('appts.status.confirm') }));
    expect(await screen.findByText(msg('appts.status.done'))).toBeInTheDocument();
    expect(api.calls('POST', '/admin/appointments/a1/status')[0]!.body).toEqual({ status: 'completed' });
  });

  it('a status that cannot be set yet is explained, and no-show sends no_show', async () => {
    const { api } = setup();
    api.route((r) => (r.path.endsWith('/status') ? fail(409, 'APPOINTMENT_NOT_STARTED') : undefined));
    const user = userEvent.setup();
    renderAdmin('/appointments');
    const dialog = await openManage(user);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.action.noShow') }));
    await user.click(within(dialog).getByRole('button', { name: msg('appts.status.confirm') }));
    expect(await within(dialog).findByText(msg('err.APPOINTMENT_NOT_STARTED'))).toBeInTheDocument();
    expect(api.calls('POST', /status$/)[0]!.body).toEqual({ status: 'no_show' });
  });
});

describe('book for a patient', () => {
  const patient = { id: 'p9', phone: '+201000000042', fullName: 'Nour Adel', preferredLocale: null, isActive: true, lastLoginAt: null, createdAt: '2026-01-01T00:00:00Z' };

  async function fill(user: ReturnType<typeof userEvent.setup>, dialog: HTMLElement) {
    await user.type(within(dialog).getByLabelText(lbl(msg('appts.book.patient.search'))), 'nour');
    await user.click(await within(dialog).findByRole('button', { name: /Nour Adel/ }));
    await user.selectOptions(within(dialog).getByLabelText(msg('appts.book.department')), DEPT.id);
    await user.click(await within(dialog).findByRole('radio', { name: /10\/11\/2026/ }));
    await user.click(await within(dialog).findByRole('radio', { name: /^6:00\s?pm/i }));
  }

  it('finds the patient, takes the slot from availability and books it', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'GET' && r.path === '/admin/patients' ? ok([patient], meta(1)) : undefined));
    api.route((r) => (r.method === 'POST' && r.path === '/admin/appointments' ? json(201, { data: adminAppointmentFixture({ id: 'new', patient: { id: 'p9', fullName: 'Nour Adel', phone: patient.phone } }) }) : undefined));
    const user = userEvent.setup();
    renderAdmin('/appointments');
    await screen.findByText('Test Patient');
    await user.click(screen.getByRole('button', { name: msg('appts.book') }));
    const dialog = await screen.findByRole('dialog', { name: msg('appts.book.title') });
    await fill(user, dialog);
    await user.click(within(dialog).getByRole('button', { name: msg('appts.book.submit') }));
    expect(await within(dialog).findByText(msg('appts.book.done'))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/appointments')[0]!;
    expect(call.body).toEqual({ patientId: 'p9', departmentId: DEPT.id, serviceId: null, date: '2026-11-10', slotNumber: 2 });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    expect(api.calls('GET', '/admin/patients')[0]!.query.get('q')).toBe('nour');
  });

  it('does not search for fewer than two characters, and the submit button needs patient, department and time', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/appointments');
    await screen.findByText('Test Patient');
    await user.click(screen.getByRole('button', { name: msg('appts.book') }));
    const dialog = await screen.findByRole('dialog', { name: msg('appts.book.title') });
    await user.type(within(dialog).getByLabelText(lbl(msg('appts.book.patient.search'))), 'n');
    await new Promise((res) => setTimeout(res, 400));
    expect(api.calls('GET', '/admin/patients')).toHaveLength(0);
    expect(within(dialog).getByRole('button', { name: msg('appts.book.submit') })).toBeDisabled();
  });

  it('a patient who already has an appointment then is told so in staff words, and a double click sends one request', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'GET' && r.path === '/admin/patients' ? ok([patient], meta(1)) : undefined));
    api.route(async (r) => { if (r.method === 'POST' && r.path === '/admin/appointments') { await new Promise((res) => setTimeout(res, 40)); return fail(409, 'PATIENT_OVERLAP'); } return undefined; });
    const user = userEvent.setup();
    renderAdmin('/appointments');
    await screen.findByText('Test Patient');
    await user.click(screen.getByRole('button', { name: msg('appts.book') }));
    const dialog = await screen.findByRole('dialog', { name: msg('appts.book.title') });
    await fill(user, dialog);
    await user.dblClick(within(dialog).getByRole('button', { name: msg('appts.book.submit') }));
    expect(await within(dialog).findByText(msg('appts.err.PATIENT_OVERLAP'))).toBeInTheDocument();
    expect(within(dialog).queryByText(msg('err.PATIENT_OVERLAP'))).not.toBeInTheDocument(); // the patient-facing wording ("You already have...") is not used here
    expect(api.calls('POST', '/admin/appointments')).toHaveLength(1);
  });

  it('only departments that can take bookings are offered', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'GET' && r.path === '/admin/departments'
      ? ok([DEPT, { ...DEPT, id: 'x2', slug: 'nodentist', translations: { en: { name: 'Orthodontics', description: '' } }, dentist: null, bookable: false }])
      : undefined));
    const user = userEvent.setup();
    renderAdmin('/appointments');
    await screen.findByText('Test Patient');
    await user.click(screen.getByRole('button', { name: msg('appts.book') }));
    const dialog = await screen.findByRole('dialog', { name: msg('appts.book.title') });
    const select = within(dialog).getByLabelText(msg('appts.book.department'));
    await within(select).findByRole('option', { name: 'Endodontics' });
    expect(within(select).queryByRole('option', { name: 'Orthodontics' })).not.toBeInTheDocument();
  });
});

describe('Arabic', () => {
  it('renders right-to-left with Latin digits and Arabic labels', async () => {
    setup();
    renderAdmin('/appointments', 'ar');
    await screen.findByText('Test Patient');
    expect(document.documentElement.dir).toBe('rtl');
    expect(screen.getByRole('heading', { name: msg('admin.nav.appointments', 'ar') })).toBeInTheDocument();
    const row = screen.getByText('Test Patient').closest('tr')!;
    expect(row.textContent).toMatch(/6:00 م/);
    expect(row.textContent).not.toMatch(/[٠-٩]/);
  });
});
