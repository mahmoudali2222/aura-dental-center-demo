import { describe, expect, it, vi } from 'vitest';
import { ApiError, buildUrl, createHttpClient } from '../src/shared/api/http.js';

const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });

function client(handler: (url: string, init: RequestInit) => Response | Promise<Response>) {
  const calls: { url: string; init: RequestInit }[] = [];
  const fetchImpl = vi.fn(async (url: RequestInfo | URL, init?: RequestInit) => {
    calls.push({ url: String(url), init: init ?? {} });
    return handler(String(url), init ?? {});
  }) as unknown as typeof fetch;
  return { http: createHttpClient({ fetchImpl, timeoutMs: 200 }), calls };
}

describe('HTTP client', () => {
  it('unwraps { data } and { data, meta }, and returns undefined for 204', async () => {
    const { http } = client((url) => (url.includes('paged') ? json(200, { data: [1, 2], meta: { page: 1, pageSize: 25, total: 2, totalPages: 1 } }) : url.includes('empty') ? new Response(null, { status: 204 }) : json(200, { data: { a: 1 } })));
    expect(await http.get('/x')).toEqual({ a: 1 });
    expect(await http.getPaged('/paged')).toEqual({ data: [1, 2], meta: { page: 1, pageSize: 25, total: 2, totalPages: 1 } });
    expect(await http.post('/empty')).toBeUndefined();
  });

  it('builds query strings without empty values and sends cookies same-origin only', async () => {
    expect(buildUrl('/api/v1', '/a', { x: 1, y: '', z: undefined, w: null, v: 'a b' })).toBe('/api/v1/a?x=1&v=a+b');
    const { http, calls } = client(() => json(200, { data: null }));
    await http.get('/a', { query: { locale: 'ar', page: 2 } });
    expect(calls[0]!.url).toBe('/api/v1/a?locale=ar&page=2');
    expect(calls[0]!.init.credentials).toBe('same-origin');
  });

  it('sends the CSRF token on every non-GET request and never on GET', async () => {
    const { http, calls } = client(() => json(200, { data: null }));
    http.setCsrfToken('tok-123');
    await http.get('/a');
    await http.post('/a', { x: 1 });
    await http.patch('/a', {});
    await http.put('/a', {});
    await http.del('/a');
    const headers = calls.map((c) => (c.init.headers as Record<string, string>)['x-csrf-token']);
    expect(headers).toEqual([undefined, 'tok-123', 'tok-123', 'tok-123', 'tok-123']);
    http.setCsrfToken(null);
    await http.post('/a');
    expect((calls[5]!.init.headers as Record<string, string>)['x-csrf-token']).toBeUndefined();
  });

  it('sends JSON bodies with the right content type', async () => {
    const { http, calls } = client(() => json(201, { data: { id: 1 } }));
    await http.post('/a', { date: '2026-11-10' });
    expect(calls[0]!.init.body).toBe('{"date":"2026-11-10"}');
    expect((calls[0]!.init.headers as Record<string, string>)['content-type']).toBe('application/json');
  });

  it('turns backend errors into ApiError with the stable code and field issues, never the server message as UI text', async () => {
    const { http } = client(() => json(400, { error: { code: 'VALIDATION_ERROR', message: 'Request validation failed', details: [{ field: 'phone', code: 'INVALID_PHONE' }, { nope: 1 }] } }));
    const err = await http.post('/a', {}).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ApiError);
    const e = err as ApiError;
    expect(e.status).toBe(400);
    expect(e.code).toBe('VALIDATION_ERROR');
    expect(e.fieldIssues).toEqual([{ field: 'phone', code: 'INVALID_PHONE' }]);
    expect(e.isTransient).toBe(false);
  });

  it('classifies unreachable servers, timeouts and proxy error pages as transient', async () => {
    const down = createHttpClient({ fetchImpl: (async () => { throw new TypeError('Failed to fetch'); }) as unknown as typeof fetch });
    const e1 = (await down.get('/a').catch((e: unknown) => e)) as ApiError;
    expect([e1.code, e1.status, e1.isTransient]).toEqual(['NETWORK_ERROR', 0, true]);

    const slow = createHttpClient({ timeoutMs: 20, fetchImpl: ((_u: unknown, init?: RequestInit) => new Promise((_res, rej) => { init!.signal!.addEventListener('abort', () => rej(init!.signal!.reason)); })) as unknown as typeof fetch });
    const e2 = (await slow.get('/a').catch((e: unknown) => e)) as ApiError;
    expect(e2.code).toBe('TIMEOUT');

    const { http } = client(() => new Response('<html>Bad gateway</html>', { status: 502 }));
    const e3 = (await http.get('/a').catch((e: unknown) => e)) as ApiError;
    expect([e3.code, e3.isTransient]).toEqual(['UPSTREAM_ERROR', true]);

    const odd = client(() => json(200, { hello: 'world' }));
    const e4 = (await odd.http.get('/a').catch((e: unknown) => e)) as ApiError;
    expect(e4.code).toBe('UPSTREAM_ERROR');
  });

  it('does not report a caller-cancelled request as an error to display', async () => {
    const ctl = new AbortController();
    const http = createHttpClient({ fetchImpl: ((_u: unknown, init?: RequestInit) => new Promise((_res, rej) => { init!.signal!.addEventListener('abort', () => rej(init!.signal!.reason ?? new DOMException('aborted', 'AbortError'))); })) as unknown as typeof fetch });
    const p = http.get('/a', { signal: ctl.signal }).catch((e: unknown) => e);
    ctl.abort();
    const e = await p;
    expect(e).not.toBeInstanceOf(ApiError);
  });

  it('calls the session-lost handler only for a 401 that means "no valid session"', async () => {
    const lost = vi.fn();
    const answers: Response[] = [json(401, { error: { code: 'SESSION_EXPIRED', message: 'x' } }), json(401, { error: { code: 'INVALID_CREDENTIALS', message: 'x' } }), json(403, { error: { code: 'CSRF_INVALID', message: 'x' } }), json(401, { error: { code: 'UNAUTHENTICATED', message: 'x' } })];
    const { http } = client(() => answers.shift()!);
    http.onSessionLost(lost);
    for (let i = 0; i < 4; i++) await http.get('/a').catch(() => undefined);
    expect(lost).toHaveBeenCalledTimes(2);
  });
});
