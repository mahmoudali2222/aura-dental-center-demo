import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import '../shared/styles/tokens.css';
import '../shared/styles/base.css';
import { PatientProviders } from './app/Providers.js';
import { PatientRoutes } from './App.js';
import './styles/index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <PatientProviders>
        <PatientRoutes />
      </PatientProviders>
    </BrowserRouter>
  </StrictMode>,
);
