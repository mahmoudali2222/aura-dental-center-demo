import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

const here = (p: string) => fileURLToPath(new URL(p, import.meta.url));
/** Where the backend listens during `npm run dev` / `npm run preview` (the production web container proxies the same way). */
const backend = process.env.DC_BACKEND_URL ?? 'http://127.0.0.1:3480';
const proxy = { '/api': { target: backend, changeOrigin: false } };

/**
 * One package, two single-page apps that share one code base (API client, i18n, UI primitives):
 *   /        patient website   (index.html)
 *   /admin/  admin dashboard   (admin/index.html)
 * Each is its own bundle with its own router; nothing from the admin app is shipped to patients.
 */
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@shared': here('./src/shared'), '@patient': here('./src/patient'), '@admin': here('./src/admin') },
  },
  server: { port: 5173, proxy },
  preview: { port: 4173, proxy },
  build: {
    outDir: 'dist',
    // Built bundles go to /static/ so that /assets/ stays exclusively for the center's own images (docs/IMAGE_ASSETS.md).
    assetsDir: 'static',
    sourcemap: false,
    rollupOptions: { input: { patient: here('./index.html'), admin: here('./admin/index.html') } },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./tests/setup.ts'],
    include: ['tests/**/*.test.{ts,tsx}'],
    css: false,
  },
});
