-- 0003_department_working_days_and_seven_departments.sql
--
-- 1. Every department gets its own working days (ISO weekday: 1 = Monday ... 7 = Sunday).
--    A day can be booked in a department only if it is a working day of BOTH the center (center_profile.working_days)
--    and the department (departments.working_days); closures still apply on top. Existing departments keep working
--    every day, so nothing changes until an administrator edits them.
--
-- 2. The center offers exactly seven departments. Any other department is deleted COMPLETELY (its translations, dentist
--    profile, services, gallery cases and closed dates go with it). The seven kept slugs are:
--      restorative-dentistry, endodontics, orthodontics, periodontics, pediatric-dentistry, prosthodontics, oral-surgery
--    A department that already has appointments is NOT deleted silently: appointments are patient history and this
--    migration must never destroy them, so it stops with a clear message and rolls back (see below).
--    On a new installation there is nothing to delete; the sample catalog creates exactly the seven departments.

ALTER TABLE departments
  ADD COLUMN working_days smallint[] NOT NULL DEFAULT ARRAY[1,2,3,4,5,6,7]::smallint[];

ALTER TABLE departments
  ADD CONSTRAINT departments_working_days_valid
  CHECK (cardinality(working_days) BETWEEN 1 AND 7 AND working_days <@ ARRAY[1,2,3,4,5,6,7]::smallint[]);

DO $$
DECLARE
  keep    constant text[] := ARRAY['restorative-dentistry','endodontics','orthodontics','periodontics','pediatric-dentistry','prosthodontics','oral-surgery'];
  blocked text;
  doomed  record;
BEGIN
  SELECT string_agg(d.slug || ' (' || n.cnt || ' appointments)', ', ' ORDER BY d.slug)
    INTO blocked
    FROM departments d
    JOIN LATERAL (SELECT count(*) AS cnt FROM appointments a WHERE a.department_id = d.id) n ON n.cnt > 0
   WHERE d.slug <> ALL (keep);
  IF blocked IS NOT NULL THEN
    RAISE EXCEPTION 'Cannot delete departments that still have appointments: %. Appointments are patient history and are never deleted by a migration. Decide what to do with them first (for example export them with scripts/backup, then remove them deliberately), then run the migration again.', blocked;
  END IF;

  FOR doomed IN SELECT id, slug FROM departments WHERE slug <> ALL (keep) ORDER BY slug LOOP
    DELETE FROM gallery_cases WHERE department_id = doomed.id;   -- its translations are deleted with it
    DELETE FROM services      WHERE department_id = doomed.id;   -- its translations are deleted with it
    DELETE FROM dentists      WHERE department_id = doomed.id;   -- its translations are deleted with it
    DELETE FROM departments   WHERE id = doomed.id;              -- department translations and closed dates are deleted with it
    INSERT INTO audit_events (actor_type, action, entity_type, entity_id, outcome, metadata)
    VALUES ('system', 'department.deleted', 'department', doomed.id::text, 'success',
            jsonb_build_object('slug', doomed.slug, 'reason', 'the center offers exactly seven departments (migration 0003)'));
  END LOOP;
END $$;
