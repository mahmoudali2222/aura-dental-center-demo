-- 0001_init.sql
-- Dental Center Management System: initial schema.
-- Forward-only. Never drops user data. See docs/DATABASE.md for the rationale behind each table.

CREATE EXTENSION IF NOT EXISTS btree_gist;   -- needed for the EXCLUDE constraints on appointments

-- ---------------------------------------------------------------------------
-- Shared helpers
-- ---------------------------------------------------------------------------
CREATE FUNCTION set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

-- ---------------------------------------------------------------------------
-- Center profile (single row = the single source of truth for public details)
-- ---------------------------------------------------------------------------
CREATE TABLE center_profile (
  id                    smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  phone                 text,
  whatsapp              text,
  email                 text,
  map_url               text,
  default_locale        text NOT NULL DEFAULT 'ar' CHECK (default_locale IN ('ar','en','fr')),
  currency              text NOT NULL DEFAULT 'EGP' CHECK (currency ~ '^[A-Z]{3}$'),
  booking_horizon_days  integer NOT NULL DEFAULT 60 CHECK (booking_horizon_days BETWEEN 1 AND 365),
  -- ISO weekdays: 1 = Monday ... 7 = Sunday
  working_days          smallint[] NOT NULL DEFAULT '{1,2,3,4,5,6,7}'
                          CHECK (cardinality(working_days) BETWEEN 1 AND 7
                                 AND working_days <@ ARRAY[1,2,3,4,5,6,7]::smallint[]),
  updated_at            timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER center_profile_updated BEFORE UPDATE ON center_profile
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE center_profile_translations (
  locale      text PRIMARY KEY CHECK (locale IN ('ar','en','fr')),
  name        text NOT NULL DEFAULT '',
  address     text NOT NULL DEFAULT '',
  introduction text NOT NULL DEFAULT '',
  hours_note  text NOT NULL DEFAULT ''
);

-- ---------------------------------------------------------------------------
-- Scheduling configuration
-- ---------------------------------------------------------------------------
-- The four daily slots. Only start_time is stored: the end is always start + 120 minutes,
-- so the final slot (22:00) never needs a "24:00" value and midnight is never mistaken for a new day.
CREATE TABLE slot_templates (
  slot_number       smallint PRIMARY KEY CHECK (slot_number BETWEEN 1 AND 4),
  start_time        time NOT NULL,
  duration_minutes  smallint NOT NULL DEFAULT 120 CHECK (duration_minutes = 120),
  is_active         boolean NOT NULL DEFAULT true,
  UNIQUE (start_time)
);

-- ---------------------------------------------------------------------------
-- Departments, dentists, services (all localized through *_translations)
-- ---------------------------------------------------------------------------
CREATE TABLE departments (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug           text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  display_order  integer NOT NULL DEFAULT 0,
  is_active      boolean NOT NULL DEFAULT true,
  image_path     text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER departments_updated BEFORE UPDATE ON departments
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE department_translations (
  department_id  uuid NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  locale         text NOT NULL CHECK (locale IN ('ar','en','fr')),
  name           text NOT NULL CHECK (length(btrim(name)) > 0),
  description    text NOT NULL DEFAULT '',
  PRIMARY KEY (department_id, locale)
);

CREATE TABLE dentists (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id  uuid NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
  photo_path     text,
  is_active      boolean NOT NULL DEFAULT true,
  is_sample      boolean NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
-- Exactly one ACTIVE dentist per department (initial scope). Replacing a dentist = deactivate + create,
-- which keeps old appointments pointing at the dentist who was actually assigned at the time.
CREATE UNIQUE INDEX dentists_one_active_per_department ON dentists (department_id) WHERE is_active;
CREATE TRIGGER dentists_updated BEFORE UPDATE ON dentists
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE dentist_translations (
  dentist_id    uuid NOT NULL REFERENCES dentists(id) ON DELETE CASCADE,
  locale        text NOT NULL CHECK (locale IN ('ar','en','fr')),
  display_name  text NOT NULL CHECK (length(btrim(display_name)) > 0),
  bio           text NOT NULL DEFAULT '',
  PRIMARY KEY (dentist_id, locale)
);

CREATE TABLE services (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id  uuid NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
  price          numeric(10,2) CHECK (price IS NULL OR price >= 0),
  display_order  integer NOT NULL DEFAULT 0,
  is_active      boolean NOT NULL DEFAULT true,
  is_sample      boolean NOT NULL DEFAULT false,
  image_path     text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX services_department_idx ON services (department_id, display_order);
CREATE TRIGGER services_updated BEFORE UPDATE ON services
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE service_translations (
  service_id   uuid NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  locale       text NOT NULL CHECK (locale IN ('ar','en','fr')),
  name         text NOT NULL CHECK (length(btrim(name)) > 0),
  description  text NOT NULL DEFAULT '',
  PRIMARY KEY (service_id, locale)
);

-- Closed dates. department_id NULL = the whole center is closed.
CREATE TABLE closures (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date_from      date NOT NULL,
  date_to        date NOT NULL,
  department_id  uuid REFERENCES departments(id) ON DELETE CASCADE,
  reason         text NOT NULL DEFAULT '',
  created_at     timestamptz NOT NULL DEFAULT now(),
  CHECK (date_to >= date_from)
);
CREATE INDEX closures_range_idx ON closures (date_from, date_to);

-- ---------------------------------------------------------------------------
-- Before / after gallery
-- ---------------------------------------------------------------------------
CREATE TABLE gallery_cases (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id      uuid NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
  service_id         uuid REFERENCES services(id) ON DELETE SET NULL,
  before_image_path  text NOT NULL,
  after_image_path   text NOT NULL,
  -- 'real'   = an actual treated case; may only be published after consent is recorded
  -- 'sample' = placeholder/illustrative content; always labelled as sample by the API
  case_kind          text NOT NULL DEFAULT 'sample' CHECK (case_kind IN ('real','sample')),
  consent_confirmed  boolean NOT NULL DEFAULT false,
  is_published       boolean NOT NULL DEFAULT false,
  display_order      integer NOT NULL DEFAULT 0,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT is_published OR case_kind = 'sample' OR consent_confirmed)
);
CREATE INDEX gallery_cases_department_idx ON gallery_cases (department_id, display_order);
CREATE TRIGGER gallery_cases_updated BEFORE UPDATE ON gallery_cases
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE gallery_case_translations (
  case_id      uuid NOT NULL REFERENCES gallery_cases(id) ON DELETE CASCADE,
  locale       text NOT NULL CHECK (locale IN ('ar','en','fr')),
  title        text NOT NULL DEFAULT '',
  description  text NOT NULL DEFAULT '',
  alt_before   text NOT NULL DEFAULT '',
  alt_after    text NOT NULL DEFAULT '',
  PRIMARY KEY (case_id, locale)
);

-- ---------------------------------------------------------------------------
-- Accounts and sessions
-- ---------------------------------------------------------------------------
CREATE TABLE patients (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_e164        text NOT NULL UNIQUE CHECK (phone_e164 ~ '^\+[1-9][0-9]{6,14}$'),
  full_name         text NOT NULL CHECK (length(btrim(full_name)) BETWEEN 2 AND 120),
  password_hash     text NOT NULL,
  preferred_locale  text CHECK (preferred_locale IN ('ar','en','fr')),
  is_active         boolean NOT NULL DEFAULT true,
  last_login_at     timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX patients_name_idx ON patients (lower(full_name));
CREATE TRIGGER patients_updated BEFORE UPDATE ON patients
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE admin_users (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username              text NOT NULL UNIQUE CHECK (username = lower(username) AND username ~ '^[a-z0-9._-]{3,64}$'),
  full_name             text NOT NULL DEFAULT '',
  password_hash         text NOT NULL,
  must_change_password  boolean NOT NULL DEFAULT true,
  is_active             boolean NOT NULL DEFAULT true,
  last_login_at         timestamptz,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER admin_users_updated BEFORE UPDATE ON admin_users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Server-side sessions. Only the SHA-256 of the cookie token is stored.
CREATE TABLE sessions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash   text NOT NULL UNIQUE,
  kind         text NOT NULL CHECK (kind IN ('patient','admin')),
  patient_id   uuid REFERENCES patients(id) ON DELETE CASCADE,
  admin_id     uuid REFERENCES admin_users(id) ON DELETE CASCADE,
  csrf_token   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  revoked_at   timestamptz,
  CHECK ((kind = 'patient' AND patient_id IS NOT NULL AND admin_id IS NULL)
      OR (kind = 'admin'   AND admin_id   IS NOT NULL AND patient_id IS NULL))
);
CREATE INDEX sessions_patient_idx ON sessions (patient_id) WHERE patient_id IS NOT NULL;
CREATE INDEX sessions_admin_idx   ON sessions (admin_id)   WHERE admin_id   IS NOT NULL;
CREATE INDEX sessions_expiry_idx  ON sessions (expires_at);

-- ---------------------------------------------------------------------------
-- Telegram linking
-- ---------------------------------------------------------------------------
CREATE TABLE telegram_link_tokens (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash  text NOT NULL UNIQUE,
  patient_id  uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz
);
CREATE INDEX telegram_link_tokens_patient_idx ON telegram_link_tokens (patient_id);

CREATE TABLE telegram_links (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id        uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  telegram_user_id  bigint NOT NULL CHECK (telegram_user_id > 0),
  created_at        timestamptz NOT NULL DEFAULT now(),
  revoked_at        timestamptz,
  revoked_by        text CHECK (revoked_by IN ('patient','admin','replaced','integration'))
);
-- One active link per Telegram account and one active link per patient; a new link replaces the old one.
CREATE UNIQUE INDEX telegram_links_active_telegram_uq ON telegram_links (telegram_user_id) WHERE revoked_at IS NULL;
CREATE UNIQUE INDEX telegram_links_active_patient_uq  ON telegram_links (patient_id)       WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------
-- Appointments
-- ---------------------------------------------------------------------------
CREATE TABLE appointments (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id        uuid NOT NULL REFERENCES patients(id)    ON DELETE RESTRICT,
  department_id     uuid NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
  dentist_id        uuid REFERENCES dentists(id)             ON DELETE RESTRICT,
  service_id        uuid REFERENCES services(id)             ON DELETE RESTRICT,
  -- Cairo local calendar date on which the slot STARTS. Capacity is counted per (department, appointment_date),
  -- never by date(ends_at), so the 22:00-00:00 slot belongs to the day it starts.
  appointment_date  date NOT NULL,
  slot_number       smallint NOT NULL CHECK (slot_number BETWEEN 1 AND 4),
  starts_at         timestamptz NOT NULL,
  ends_at           timestamptz NOT NULL,
  status            text NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','cancelled','completed','no_show')),
  patient_note      text CHECK (patient_note IS NULL OR length(patient_note) <= 500),
  created_via       text NOT NULL CHECK (created_via IN ('web','admin','telegram')),
  created_by_admin  uuid REFERENCES admin_users(id) ON DELETE RESTRICT,
  rescheduled_count integer NOT NULL DEFAULT 0 CHECK (rescheduled_count >= 0),
  cancelled_at      timestamptz,
  cancelled_by      text CHECK (cancelled_by IN ('patient','admin','telegram')),
  cancel_reason     text CHECK (cancel_reason IS NULL OR length(cancel_reason) <= 500),
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  CHECK (extract(epoch FROM (ends_at - starts_at)) = 7200),     -- exactly two real hours
  CHECK ((status = 'cancelled') = (cancelled_at IS NOT NULL))
);
CREATE INDEX appointments_patient_idx    ON appointments (patient_id, starts_at DESC);
CREATE INDEX appointments_dept_date_idx  ON appointments (department_id, appointment_date);
CREATE INDEX appointments_starts_idx     ON appointments (starts_at);
CREATE INDEX appointments_status_idx     ON appointments (status, starts_at);
CREATE TRIGGER appointments_updated BEFORE UPDATE ON appointments
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- A cancelled appointment releases its slot and its capacity; every other status keeps it.
-- (1) A department can never hold two active appointments in the same slot on the same day.
--     With slot_number limited to 1..4 this also caps a department at four active appointments per day.
CREATE UNIQUE INDEX appointments_active_slot_uq
  ON appointments (department_id, appointment_date, slot_number)
  WHERE status IN ('booked','completed','no_show');

-- (2) No two active appointments of one department may overlap in time, whatever slot numbers say.
ALTER TABLE appointments ADD CONSTRAINT appointments_no_department_overlap
  EXCLUDE USING gist (department_id WITH =, tstzrange(starts_at, ends_at) WITH &&)
  WHERE (status IN ('booked','completed','no_show'));

-- (3) One patient cannot be in two places at once (across departments).
ALTER TABLE appointments ADD CONSTRAINT appointments_no_patient_overlap
  EXCLUDE USING gist (patient_id WITH =, tstzrange(starts_at, ends_at) WITH &&)
  WHERE (status IN ('booked','completed','no_show'));

-- Status lifecycle guard (mirrors the service layer so raw SQL cannot corrupt history):
--   booked    -> cancelled | completed | no_show
--   no_show   -> completed   (admin correction)
--   cancelled, completed -> terminal
CREATE FUNCTION appointments_guard_status() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF NOT ( (OLD.status = 'booked'  AND NEW.status IN ('cancelled','completed','no_show'))
          OR (OLD.status = 'no_show' AND NEW.status = 'completed') ) THEN
      RAISE EXCEPTION 'illegal appointment status transition % -> %', OLD.status, NEW.status
        USING ERRCODE = 'check_violation', CONSTRAINT = 'appointments_status_transition';
    END IF;
  ELSIF OLD.status IN ('cancelled','completed')
        AND (NEW.starts_at IS DISTINCT FROM OLD.starts_at OR NEW.slot_number IS DISTINCT FROM OLD.slot_number
             OR NEW.department_id IS DISTINCT FROM OLD.department_id OR NEW.patient_id IS DISTINCT FROM OLD.patient_id) THEN
    RAISE EXCEPTION 'a % appointment cannot be moved or reassigned', OLD.status
      USING ERRCODE = 'check_violation', CONSTRAINT = 'appointments_terminal_immutable';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER appointments_status_guard BEFORE UPDATE ON appointments
  FOR EACH ROW EXECUTE FUNCTION appointments_guard_status();

-- ---------------------------------------------------------------------------
-- Medical records (Admin Dashboard only)
-- ---------------------------------------------------------------------------
CREATE TABLE medical_records (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id       uuid NOT NULL REFERENCES patients(id)     ON DELETE RESTRICT,
  appointment_id   uuid REFERENCES appointments(id)          ON DELETE RESTRICT,
  medical_history  text NOT NULL DEFAULT '' CHECK (length(medical_history) <= 20000),
  allergies        text NOT NULL DEFAULT '' CHECK (length(allergies)       <= 20000),
  diagnosis        text NOT NULL DEFAULT '' CHECK (length(diagnosis)       <= 20000),
  treatment        text NOT NULL DEFAULT '' CHECK (length(treatment)       <= 20000),
  notes            text NOT NULL DEFAULT '' CHECK (length(notes)           <= 20000),
  created_by       uuid NOT NULL REFERENCES admin_users(id)  ON DELETE RESTRICT,
  updated_by       uuid NOT NULL REFERENCES admin_users(id)  ON DELETE RESTRICT,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX medical_records_patient_idx ON medical_records (patient_id, created_at DESC);
CREATE TRIGGER medical_records_updated BEFORE UPDATE ON medical_records
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Audit log (append-only)
-- ---------------------------------------------------------------------------
CREATE TABLE audit_events (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  occurred_at  timestamptz NOT NULL DEFAULT now(),
  actor_type   text NOT NULL CHECK (actor_type IN ('admin','patient','integration','system','anonymous')),
  actor_id     text,
  action       text NOT NULL,
  entity_type  text,
  entity_id    text,
  outcome      text NOT NULL CHECK (outcome IN ('success','failure','denied')),
  metadata     jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip           text
);
CREATE INDEX audit_events_time_idx   ON audit_events (occurred_at DESC);
CREATE INDEX audit_events_action_idx ON audit_events (action, occurred_at DESC);
CREATE INDEX audit_events_entity_idx ON audit_events (entity_type, entity_id);

CREATE FUNCTION audit_events_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit_events is append-only' USING ERRCODE = 'insufficient_privilege';
END $$;
CREATE TRIGGER audit_events_no_update_delete BEFORE UPDATE OR DELETE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION audit_events_immutable();
CREATE TRIGGER audit_events_no_truncate BEFORE TRUNCATE ON audit_events
  FOR EACH STATEMENT EXECUTE FUNCTION audit_events_immutable();
