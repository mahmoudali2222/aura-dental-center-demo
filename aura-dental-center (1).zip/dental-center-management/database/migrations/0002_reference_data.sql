-- 0002_reference_data.sql
-- Rows the application cannot run without. Idempotent: ON CONFLICT DO NOTHING, never overwrites admin edits.

-- The four standard two-hour slots (4:00 PM - 12:00 AM, Africa/Cairo). Only start times are stored;
-- the end is start + 120 minutes, so the last slot (10:00 PM - 12:00 AM) needs no "24:00" value.
INSERT INTO slot_templates (slot_number, start_time) VALUES
  (1, '16:00'), (2, '18:00'), (3, '20:00'), (4, '22:00')
ON CONFLICT DO NOTHING;

-- Single-row center profile. Address/phone stay empty until the admin configures them:
-- the website and the AI assistant must report "not configured" rather than guess.
INSERT INTO center_profile (id) VALUES (1) ON CONFLICT DO NOTHING;

INSERT INTO center_profile_translations (locale) VALUES ('ar'), ('en'), ('fr') ON CONFLICT DO NOTHING;
