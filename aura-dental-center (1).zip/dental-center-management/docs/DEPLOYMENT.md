# Deployment

Two supported ways to run the system: **(A)** on a Windows PC with Docker Desktop (PowerShell), **(B)** on a VPS. Both use
the same `docker-compose.yml`. Read [`PROJECT_STATUS.md`](PROJECT_STATUS.md) first: it says exactly what was run and what
could not be run in the environment where this project was built (the Docker images were **not** built there; the first
`docker compose up --build` on your machine is the first real container run, and `scripts/verify-docker.ps1` is the check for it).

The stack: `db` (PostgreSQL 16) → `migrate` (one-shot job: migrations + sample catalog) → `backend` (API) → `web` (nginx: patient
site `/`, dashboard `/admin/`, API proxy `/api/`). Compose project name `dental-center`; own network `dental_center_net`; own
volume `dental_center_pgdata`. It never touches other Docker projects, in particular not the old `dental-clinic-dashboard`.

## A. Windows 10/11 with Docker Desktop (PowerShell)

### A1. Requirements

- Docker Desktop (WSL 2 backend) running; `docker compose version` must work (Compose v2).
- About 4 GB of free RAM and 3 GB of disk for the images; more for backups.
- Port **8480** free (change `WEB_PORT` otherwise). Check:
  `Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 8480` prints nothing when it is free.
- This project folder, for example `C:\dental-center-management`. Open PowerShell **in that folder** for every command below.

### A2. First installation

```powershell
# 1. Create your private settings file (never share it, never commit it)
Copy-Item .env.example .env

# 2. Generate two secrets (one for the database, one for n8n) and note them
powershell -ExecutionPolicy Bypass -File .\scripts\new-secret.ps1      # database password
powershell -ExecutionPolicy Bypass -File .\scripts\new-secret.ps1      # integration key (only if you use n8n)

# 3. Edit .env
notepad .env
#    POSTGRES_PASSWORD=<first secret>             (letters and digits only; it is fixed when the database is first created)
#    INTEGRATION_API_KEY=<second secret>          (or leave empty to switch the n8n integration off)
#    ADMIN_BOOTSTRAP_USERNAME=<your admin user name, e.g. owner>
#    ADMIN_BOOTSTRAP_PASSWORD=<a long initial password, at least 12 characters, no $ sign>
#    PUBLIC_APP_URL=http://localhost:8480          (keep: it must equal the address you type in the browser)

# 4. Build and start (first time takes several minutes: it downloads images and compiles the apps)
docker compose up -d --build

# 5. Wait until db, backend and web say "healthy"
docker compose ps

# 6. Create the first administrator (runs once; does nothing if one exists)
docker compose run --rm bootstrap-admin
```

Then open **http://localhost:8480/admin/**, sign in with the user name and initial password from `.env`; you are made to
choose a new password immediately. Afterwards **delete `ADMIN_BOOTSTRAP_PASSWORD` from `.env`**. The patient website is
**http://localhost:8480/**.

Use the exact address from `PUBLIC_APP_URL` in the browser. `http://127.0.0.1:8480` is a different origin from
`http://localhost:8480`; sign-in forms sent from it are refused unless you add it to `ALLOWED_ORIGINS`.

### A3. Configure the center (in the dashboard, no code)

1. **Center settings:** names (Arabic/English/French), **address**, phone, WhatsApp, email, map link, default language,
   booking horizon and the **center's working days**.
2. **Departments & dentists:** the seven departments exist. For each, set its **working days** (the days it works are the days patients can
   book), replace the sample dentist (deactivate the sample, create the real dentist), edit the descriptions.
3. **Services:** replace the generic sample services and add prices if you wish (prices are optional and shown only when set).
4. **Gallery:** only real cases with recorded patient consent can be published.
5. Pictures: see [`IMAGE_ASSETS.md`](IMAGE_ASSETS.md).
6. Closed dates (holidays): Center settings → closed dates.

Everything on the website that mentions the address or phone comes from the center settings: change it once there.

### A4. Daily use

| Task | Command |
|---|---|
| Start (after a reboot Docker Desktop restarts it by itself) | `docker compose up -d` |
| Status | `docker compose ps` |
| Follow the API log | `docker compose logs -f backend` |
| Stop, keeping all data | `docker compose down` |
| Restart one part | `docker compose restart backend` (or `web`) |
| Backup now | `.\scripts\backup.ps1` ([`BACKUP_RESTORE.md`](BACKUP_RESTORE.md)) |

**Never run `docker compose down -v` and never `docker volume rm dental_center_pgdata`** unless you intend to erase the whole
database: the `-v`/volume removal deletes the patients and appointments.

### A5. Updating to a new version of the system

```powershell
.\scripts\backup.ps1                  # 1. backup first
docker compose up -d --build          # 2. rebuild and restart; new database migrations are applied by the "migrate" job
docker compose ps                     # 3. everything healthy?
```

Migrations are forward-only and checksummed: an update never edits old migrations. Migration `0003` (the seven departments)
stops with a clear message, changing nothing, if a department that is to be removed still has appointments (see
`DATABASE.md`). To go back to an older version, restore the backup taken in step 1 ([`BACKUP_RESTORE.md`](BACKUP_RESTORE.md)).

### A6. Other devices on your network (optional)

`WEB_BIND=127.0.0.1` (default) means only this computer can open the site. To let phones/PCs on your network use it: set
`WEB_BIND=0.0.0.0`, set `PUBLIC_APP_URL=http://<this PC's LAN address>:8480` (and keep `COOKIE_SECURE=false` because it is plain
HTTP), `docker compose up -d`, and allow the port in Windows Firewall for the private network only. Plain HTTP on a network is
acceptable for a trusted private network only; use section B for anything public.

## B. VPS (Ubuntu/Debian example)

### B1. Prepare

1. A server with Docker Engine + Compose plugin, a domain name pointing at it (A/AAAA record), ports 80/443 open, port 8480 **not**
   open to the internet. Firewall example: `ufw allow OpenSSH && ufw allow 80,443/tcp && ufw enable`.
2. Copy the project folder to the server (for example `/opt/dental-center`), then `cp .env.example .env` and edit:

```
POSTGRES_PASSWORD=<48 hex characters>
PUBLIC_APP_URL=https://clinic.example.com        # your real domain, exactly as visitors type it, no trailing slash
COOKIE_SECURE=true
WEB_BIND=127.0.0.1                               # only the reverse proxy on this machine may reach the container
WEB_PORT=8480
INTEGRATION_API_KEY=<48 hex characters or empty>
ADMIN_BOOTSTRAP_USERNAME=owner
ADMIN_BOOTSTRAP_PASSWORD=<long initial password>
```

   Generate secrets with `sh scripts/new-secret.sh` (48 hex characters). With `PUBLIC_APP_URL` not on localhost the backend
   **refuses to start** unless the URL is `https://` and `COOKIE_SECURE=true`: a safety net, not a bug.

3. `docker compose up -d --build`, wait for `healthy`, `docker compose run --rm bootstrap-admin`.

### B2. HTTPS reverse proxy on the same machine

The web container speaks plain HTTP on `127.0.0.1:8480`; HTTPS is terminated by a proxy that forwards to it. Two examples
(not run in the build environment; adapt the domain).

**Caddy** (obtains and renews certificates by itself; `/etc/caddy/Caddyfile`):

```
clinic.example.com {
    encode gzip
    header Strict-Transport-Security "max-age=31536000"
    reverse_proxy 127.0.0.1:8480
}
```

**nginx on the host + certbot**:

```nginx
server {
    listen 443 ssl;
    server_name clinic.example.com;
    # ssl_certificate / ssl_certificate_key: as written by certbot
    add_header Strict-Transport-Security "max-age=31536000" always;
    client_max_body_size 300k;
    location / {
        proxy_pass http://127.0.0.1:8480;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto https;
    }
}
server { listen 80; server_name clinic.example.com; return 301 https://$host$request_uri; }
```

Add HSTS only once HTTPS works for you (browsers remember it).

### B3. The real visitor address (important behind a proxy)

Without this, every visitor appears to come from the proxy: they share one login rate limit and the audit log records the
proxy's address. Edit `frontend/nginx/real-ip.conf`: remove the `#` before its three directives (the default `172.16.0.0/12`
is the range Docker uses for a connection from the host to a published port), then `docker compose restart web`. Verified
on nginx 1.24 here with a stand-in backend: with the lines enabled the forwarded visitor address is used and a forged
`X-Forwarded-For` from outside the trusted range is ignored; with them commented out (default) the forged header is ignored.
Check on your server by looking at the IP shown in the dashboard's audit log after a login.

### B4. n8n

If the existing n8n runs on another server, set `baseUrl` to `https://clinic.example.com/api/v1/integrations` and restrict the
route to the n8n host in `frontend/nginx/integrations-access.conf` (`allow <n8n address>; deny all;`, then
`docker compose restart web`). See [`N8N_INTEGRATION.md`](N8N_INTEGRATION.md).

### B5. Backups on a schedule

Nothing schedules them for you. Example cron entry (daily at 03:15, keeps 14, then copy the folder off the server):

```
15 3 * * *  cd /opt/dental-center && sh scripts/backup.sh >> backups/backup.log 2>&1
```

Copy `backups/` to another machine or storage regularly: a backup that only lives on the same disk is lost with it.

### B6. Updates

Same as A5 (`sh scripts/backup.sh`, then `docker compose up -d --build`). Keep the operating system and Docker updated.

## Settings reference

| `.env` variable | Meaning |
|---|---|
| `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` | Database name/user/password. The password is stored in the volume at first start; changing it in `.env` later does **not** change it in the database (`TROUBLESHOOTING.md`). |
| `PUBLIC_APP_URL`, `ALLOWED_ORIGINS` | The address(es) the browser uses. Anything else is refused (CSRF defence). |
| `COOKIE_SECURE` | `true` for HTTPS, `false` for plain-http localhost. |
| `WEB_PORT`, `WEB_BIND` | Published port and the interface it listens on. |
| `CENTER_TIMEZONE` | Default `Africa/Cairo`. |
| `LOG_LEVEL` | `info` by default. |
| `INTEGRATION_API_KEY`, `INTEGRATION_API_KEY_NEXT` | n8n key (empty = integration off) and the optional rotation key. |
| `ADMIN_BOOTSTRAP_USERNAME`, `ADMIN_BOOTSTRAP_PASSWORD` | Used only by `docker compose run --rm bootstrap-admin`. |
| `SEED_SAMPLE_CATALOG` | `true` = whenever the one-shot `migrate` job runs (it is part of `docker compose up`), create the seven departments with sample dentists/services **if they are missing**. Never overwrites edits. Set `false` once you have your own data if you do not want missing departments recreated. |
| `SESSION_*` | Optional session lengths. |
| `DB_VOLUME_NAME`, `NETWORK_NAME` | Advanced: used by `scripts/verify-docker.ps1` for an isolated throw-away copy. |

## Verifying a deployment

On the Windows PC: `powershell -ExecutionPolicy Bypass -File .\scripts\verify-docker.ps1` builds and starts a **separate,
throw-away** copy (own project name, volume, network and port), runs `scripts/smoke-api.mjs` against it, restarts it to
prove the data persists, tests backup and restore on that copy, then removes only that copy. It never touches the real
`dental-center` stack or its data. See [`TESTING.md`](TESTING.md).
