# Requirements Checklist & Business-Rule Register

Source of truth: [`MASTER_SPEC.md`](MASTER_SPEC.md) (verbatim copy of the master specification).
This file turns the spec into traceable items. Delivery status is tracked in `PROJECT_STATUS.md`, not here.

"Layer" says where a rule is enforced. A rule that lists only "service" is enforceable by bypassing the app,
so every booking-critical rule also has a database-level guarantee.

---

## 1. Business-rule register

| ID | Rule | Spec § | Enforced in | Verified by |
|---|---|---|---|---|
| BR-01 | Center is open 16:00–24:00 `Africa/Cairo` | 5.1 | `slot_templates` table, availability service | unit + integration |
| BR-02 | Exactly four 2-hour slots/day: 16-18, 18-20, 20-22, 22-24 | 5.2 | `slot_templates` CHECK (duration = 120, slot 1..4) | unit |
| BR-03 | Max 4 active appointments per **department** per calendar day (not center-wide) | 5.3 | partial unique index + per-(department, date) advisory lock + count check | concurrency tests |
| BR-04 | No duplicate or overlapping booking for the same department | 5.3 | partial unique index on (department, date, slot) | integration |
| BR-05 | Rules enforced server-side and safe under concurrent requests | 5.3 | transaction + unique index; 23505 mapped to `409 SLOT_UNAVAILABLE` | concurrency tests |
| BR-06 | Lifecycle: booked, cancelled, completed, no_show. Cancelled releases slot and capacity | 5.4 | status CHECK + transition table in service | unit + integration |
| BR-07 | Patient may cancel/reschedule only if >= 24 h remain before start (server clock, absolute instants) | 5.5 | appointment service; same code path for web and Telegram | boundary tests (23:59:59 / 24:00:00 / 24:00:01 before start) |
| BR-08 | No bookings in the past | 5.6 | service + CHECK on creation path | unit |
| BR-09 | Midnight handled: slot 4 belongs to the day it starts, ends at 00:00 next day | 5.1, 5.6 | `appointment_date` column = Cairo local start date; `ends_at` = `starts_at + 2h` | midnight tests |
| BR-10 | Registration by phone + password only; no OTP / SMS / verification; phone normalized and unique | 6.1 | `libphonenumber-js`, unique index on E.164 | unit + integration |
| BR-11 | Password recovery only via authenticated admin, in person; no unauthenticated reset endpoint | 6.3 | admin route only; sessions revoked; audited | auth tests |
| BR-12 | Initial admin created once by bootstrap command; forced password change before any other admin action | 7.1 | `must_change_password` gate middleware | auth tests |
| BR-13 | Medical records are admin-only | 7.3 | admin-session middleware on every route; no patient or integration route exposes them | authorization tests |
| BR-14 | Audit log is append-only and never contains passwords, tokens, secrets or clinical detail | 8.1 | DB triggers block UPDATE/DELETE/TRUNCATE; redaction in audit service | DB + unit tests |
| BR-15 | Arabic (RTL), English, French across site and admin | 10 | i18n resources + localized content tables | localization tests |
| BR-16 | No AI chatbot on the website; AI conversations happen only via Telegram/n8n | 2.10 | nothing built; reviewed at QA | review |
| BR-17 | One center address, configurable, single source of truth, never hardcoded in code or prompts | 2.6, 13.4 | `center_profile` table, served by public and integration endpoints | integration + review |
| BR-18 | Each department has exactly one assigned dentist (initially); no dentist login | 2.7, 2.8 | `dentists.department_id` UNIQUE (relaxable later) | integration |
| BR-19 | Telegram personal data/actions require secure account linking | 13.3 | single-use hashed link tokens, `telegram_links` | integration tests |
| BR-20 | n8n never bypasses backend rules; assistant may not claim success without backend confirmation | 13.1 | integration routes call the same services as the website | integration tests |
| BR-21 | Admin overrides of patient restrictions are explicit and audited | 7.2 | `override: true` flag + reason required; audit event | integration |
| BR-22 | A date is bookable in a department only if it is a working day of **both** the center and the department (then closures, slot, past, horizon, capacity apply). Existing appointments are never cancelled by a working-days change | user request 2026-10-30 | `slotUnavailableReason` (one function for availability and booking); `FOR SHARE`/`FOR UPDATE` on the department row; `WORKING_DAYS_HAVE_APPOINTMENTS` acknowledgement | backend integration tests, browser tests |
| BR-23 | The center offers exactly seven departments; others are deleted completely, never silently when they hold appointments | user request 2026-10-30 | migration 0003 (aborts and rolls back if a doomed department has appointments); sample catalog | db tests |

---

## 2. Functional requirements

Phases: **P2** database + backend, **P3** Docker + integration, **P4** frontend foundation, **P5** patient site + admin UI, **P6** QA.

| ID | Requirement | Spec § | Phase |
|---|---|---|---|
| FR-01 | Exactly seven departments (Restorative Dentistry, Endodontics, Orthodontics, Periodontics, Pediatric Dentistry, Prosthodontics, Oral Surgery), trilingual names/descriptions, display order, active flag, image refs. Any other department is deleted completely (migration 0003) | 4 | P2 |
| FR-02 | Services per department, trilingual, optional price, active flag | 4 | P2 |
| FR-03 | One dentist per department, trilingual display name/bio, replaceable without code changes | 4 | P2 |
| FR-04 | Admin CRUD for departments, services, dentists | 7.2 | P2 API / P5 UI |
| FR-05 | Availability endpoint returns only genuinely bookable slots (honours closures, inactive departments, past times, capacity) | 5.3 | P2 |
| FR-06 | Patient register / login / logout / profile | 6 | P2 API / P5 UI |
| FR-07 | Patient books, lists (upcoming + history), cancels, reschedules own appointments | 6.4 | P2 API / P5 UI |
| FR-08 | Patient isolation: no access to other patients' data via ID tampering | 6.4 | P2 |
| FR-09 | Admin login, forced first password change, session handling | 7.1 | P2 |
| FR-10 | Admin appointment management (create, edit, cancel, status changes) with booking rules preserved | 7.2 | P2 API / P5 UI |
| FR-11 | Admin patient management and staff-assisted password reset | 6.3, 7.2 | P2 API / P5 UI |
| FR-12 | Working-hours/closure management and general settings | 7.2 | P2 API / P5 UI |
| FR-12a | **Department working days** configurable in the Admin Dashboard; the effective working day is the center's working days ∩ the department's; they control availability and booking on the website, in the admin dashboard and through Telegram. Existing appointments are never auto-cancelled; removing a day that has bookings needs an explicit acknowledgement | user change request (2026-10-30) | P2 API / P5 UI |
| FR-13 | Medical records CRUD (history, allergies, diagnosis, treatment, notes, authorship, timestamps) | 7.3 | P2 API / P5 UI |
| FR-14 | Audit log recording + admin viewer | 8.1 | P2 API / P5 UI |
| FR-15 | Backup and restore procedures (documented, scripted, tested in isolation) | 8.2 | P3 |
| FR-16 | Centralized center profile (name, address, phone, hours text) served to site and n8n | 13.4 | P2 |
| FR-17 | Before/after gallery with consent + "real case" metadata; nothing fabricated | 9.4 | P2 data model / P5 UI |
| FR-18 | Image asset folder structure + manifest doc | 9.5 | P4 |
| FR-19 | n8n integration API (info, availability, link, book, cancel, reschedule, status) behind a service credential | 13 | P2 |
| FR-20 | Telegram linking flow (short-lived single-use token, revoke/replace) | 13.3 | P2 API / P5 UI |
| FR-21 | i18n for all UI strings, RTL layout for Arabic, language persistence | 10 | P4 / P5 |
| FR-22 | OpenAPI spec + `docs/API.md` | 11.2 | P2 |
| FR-23 | Docker Compose stack: web (nginx), backend, PostgreSQL; health checks; dedicated project name and volume | 14 | P3 |
| FR-24 | Windows PowerShell + VPS documentation | 14.2, 14.3 | P3 |
| FR-25 | `.env.example`, startup config validation | 19 | P2 |
| FR-26 | Full documentation set | 18 | continuous |

---

## 3. Security boundaries

| Actor | Credential | May access | Must never access |
|---|---|---|---|
| Anonymous visitor | none | public center profile, departments, services, dentists, published gallery, availability, register, login | any patient, appointment, or medical data; any admin route |
| Patient | session cookie (`dc_patient`) + CSRF token | own profile, own appointments, own Telegram link | other patients' data; medical records; admin routes; integration routes |
| Admin | session cookie (`dc_admin`) + CSRF token; blocked until password changed | all admin routes, including medical records and audit log | nothing is hidden from admin, but every sensitive action is audited |
| n8n | `Authorization: Bearer <integration key>` | only `/api/v1/integrations/*` | admin routes, medical records, patient password data, other patients' data |
| Telegram user (via n8n) | linked `telegram_user_id` | own linked patient's appointments and bookings | anything before linking beyond public info |

Residual trust assumption (documented, not eliminated): n8n is trusted to pass the real Telegram user ID that Telegram
supplied. A compromised n8n instance or leaked integration key could impersonate linked users. Mitigations: key
rotation, rate limits, audit events for every integration action, minimal response payloads.

Known limitation (by design, per spec): phone ownership is **not** verified, so anyone can register with a number
they don't own. This is documented in `docs/SECURITY.md`.
