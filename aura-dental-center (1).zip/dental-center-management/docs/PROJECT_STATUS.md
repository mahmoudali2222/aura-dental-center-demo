# Project status

Last updated: 1 November 2026. This file separates **what was actually run** from **what was only written**. Where a check could
not be run in the development environment, it says so; those checks are listed in section 3 with the command that runs them on your machine.

## 1. Deliverables

| Area | Status |
|---|---|
| Database (PostgreSQL 16, 3 migrations, sample catalog) | Done, tested against a real PostgreSQL |
| Backend API (Fastify/TypeScript): auth, catalog, scheduling, booking, admin, medical records, audit, integration | Done, tested against a real PostgreSQL |
| Department **working days**, configurable in the Admin Dashboard, controlling availability and booking (web, admin, Telegram) | Done and tested (backend, unit, real browser) |
| Exactly **seven departments** (others deleted completely by migration 0003; sample catalog creates the seven) | Done and tested |
| Admin Dashboard (appointments, patients, medical records, departments, services, gallery, settings, audit) | Done and tested (component tests + real browser) |
| Patient website (browse, register/login, book, cancel/reschedule, account, Telegram link) in ar/en/fr | **Done and tested, with the premium white and color-wheel design** (2 Nov 2026): calendar over real availability, the supplied department pictures and precautions picture, Section 10 contributors, Telegram link. **Places kept ready, not filled: the official logo and the hero video were not supplied** (`FRONTEND.md`) |
| n8n + Telegram integration (two workflows, key-protected API) | Done; tested with simulator and once inside a real n8n; real Telegram not tested |
| Docker Compose stack (db, migrate, backend, web) + Dockerfiles + nginx | Written, `docker compose config` validated; **images never built here** |
| Backup / restore scripts (shell + PowerShell) | Shell versions tested with real PostgreSQL; PowerShell versions never executed |
| `scripts/verify-docker.ps1` (isolated Docker verification on your PC) | Written; **never executed** (needs your machine) |
| Documentation (this folder) | Complete set; see the index in `PROJECT_DOCUMENTATION.md` |

## 2. What was verified, and how (real runs, 31 October – 2 November 2026)

| Check | Result |
|---|---|
| Backend: `npm --prefix backend test` (15 files, real PostgreSQL 16, migrations applied to an empty database each run) | **203 / 203 passed**; `tsc --noEmit` clean |
| Frontend: `npm --prefix frontend test` (10 files, Vitest + Testing Library, fake backends) | **216 / 216 passed**; `tsc --noEmit` clean; production build succeeds |
| n8n: `npm test` in `integrations/n8n` (node:test) and `node build.cjs --check` | **35 / 35 passed**; exported workflows identical to the sources |
| Browser tests: `scripts/e2e-local.sh` (Playwright 1.63 / Chromium; **real backend + the real web-container nginx configuration + a fresh PostgreSQL database**; desktop and a 393 px phone) | **61 / 61 passed** (patient journey, admin, working days, three languages, mobile and tablet layout, 11 HTTP-header checks, and the patient redesign checks) |
| Backup/restore: `backend/tests/integration/backup-restore.test.ts` and `scripts/tests/test-backup-scripts.sh` | 5 / 5 and **25 / 25 passed** (real `pg_dump`/`pg_restore`; the scripts run against a test double of `docker compose`) |
| Real n8n 2.45.4 against the real backend (`integrations/n8n/test/real-n8n-check.cjs`) | 34 checks passed (run before the working-days change; see `N8N_INTEGRATION.md` §11) |
| `docker compose config` with a throw-away `.env` | Valid; default services `db, migrate, backend, web`; tool services `bootstrap-admin`, `reset-admin-password` only with `--profile tools` / `run` |
| `scripts/smoke-api.mjs` (27 checks) against a throw-away local stack: real backend + real nginx configuration + fresh PostgreSQL | **Passed** (26 pass, 1 skipped: "day-off refusal" needs a department that does not work every day, which is the default state). Run with and without the integration key |
| Real nginx 1.24 with the shipped `default.conf`/snippets, including the optional real-visitor-address snippet | Works (tested with a stand-in backend) |
| OpenAPI | `docs/openapi.json` and `docs/API_REFERENCE.md` regenerated; a unit test fails if they drift |

Mutation checks (temporarily break the code, see the test fail, restore) were done for the key new behaviours: working-days enforcement,
duplicate-error fix, blank environment values, admin password reset.

Real defects the tests found (and that are fixed): every `/api` answer carried **two sets of security headers** (nginx and the backend), some in conflict (`X-Frame-Options` `SAMEORIGIN` and `DENY`, two `Referrer-Policy` values, two Content-Security-Policy headers, HSTS over plain HTTP); found by the smoke test, fixed in `frontend/nginx/proxy-api.conf`, guarded by `e2e/tests/05-http-headers.spec.ts`; a duplicated error message on the register/login forms (browser test);
the `bootstrap-admin` Docker command would not have received its password from `.env` (found while writing the deployment guide; now a
dedicated `bootstrap-admin` service); empty `.env` entries such as `INTEGRATION_API_KEY=` reached the backend as empty strings and would
have stopped it from starting (now treated as unset; regression test); the backup-script test had a hard-coded migration count.

## 3. NOT verified (be aware before relying on it)

These were written carefully but **have not been executed**, because the development environment has no Docker daemon (Docker Hub and the
Docker download site are blocked by the network policy there) and no PowerShell:

1. **Docker image builds** (`backend/Dockerfile`, `frontend/Dockerfile`), container start-up, health checks, the `migrate` job, volume persistence
   across `docker compose down`/`up`, bind mounts and the `nginxinc/nginx-unprivileged` runtime behaviour. The nginx **configuration** itself was run (nginx 1.24 locally), the container around it was not.
2. **All spec §17.6 Docker checks (DOCK-01..12)**: run `scripts/verify-docker.ps1` on your Windows PC. It uses a separate throw-away project, so your data is not touched.
3. **PowerShell scripts**: `backup.ps1`, `restore.ps1`, `new-secret.ps1`, `verify-docker.ps1`. They follow the tested shell scripts' steps but were never run.
4. **Real Telegram**: bot token, the Telegram trigger webhook, persistence of the bot's language/list memory across messages in an *active* n8n workflow.
5. **`scripts/smoke-api.mjs` against the Docker stack.** The script itself passed against a local stack (section 2); what is untested is the Docker stack it is meant to check (`verify-docker.ps1` calls it).
6. **HTTPS reverse-proxy examples** (Caddy/nginx in `DEPLOYMENT.md`) and a VPS installation.
7. **Accessibility conformance** (no axe/Lighthouse run, no screen-reader pass) and browsers other than Chromium (Firefox/Safari/real phones).
8. **Load/performance** beyond the concurrency tests (24 parallel requests per slot; 24 patients × 4 slots × 3 days).
9. A vulnerability scan of dependencies and images; an external security review.
10. The department-working-days change has not been re-run inside the **real n8n** (only the simulator and unit tests).

## 4. Known limitations and decisions to be aware of

- Phone numbers are not verified (specified: no OTP/SMS); no two-factor for admins; one database role (`SECURITY.md` §6).
- Working days of the **whole center** are applied immediately without the confirmation step used for departments and closed dates (`BOOKING_RULES.md` §2).
- Admin accounts can be created only by the bootstrap command (no screen yet); the lock-out recovery is `docker compose run --rm reset-admin-password`.
- No image upload screen: copy files into `frontend/public/assets/` (as the specification asks) and enter the path in the dashboard.
- The dashboard has no screen for backups; use the scripts.
- A patient cannot hold two overlapping appointments in different departments (decision D7); remove the constraint if you disagree.
- Medical records can be created and edited but not deleted (corrections are updates with authorship and audit).
- Department deletion is not offered in the dashboard (deactivate instead); the only deletion is migration 0003.
- Rate limits and login throttles are in memory (reset on restart).
- Migration 0003 stops (changing nothing) if a department outside the seven still has appointments.

## 5. Open questions for you

1. **Official logo and hero background video.** Not supplied, so the patient website has clean, empty places for them (no stand-in logo, no fake video). Copy the files and set two lines in `frontend/src/patient/config.ts` (`FRONTEND.md`, "Places kept ready"). Also: are the supplied before/after pictures real patients (then consent is needed before they stay public) or illustrations?
2. **Which weekdays is the center open?** Defaults to all seven; set the real days in Center settings, then per department.
3. **Default language** (assumed Arabic) and **full name at registration** (assumed required).
4. **Where does your n8n run** (Docker Desktop on the same PC, another machine, VPS, n8n Cloud)? It decides the `baseUrl` (`N8N_INTEGRATION.md` §4); n8n Cloud needs a public HTTPS address.
5. Real content: center address/phone, dentist names, services and prices, pictures (all optional to start).

## 6. What to do next on your machine

```powershell
Copy-Item .env.example .env            # then edit it (DEPLOYMENT.md)
powershell -ExecutionPolicy Bypass -File .\scripts\verify-docker.ps1     # isolated check of the Docker stack (needs Docker Desktop)
docker compose up -d --build           # the real stack
docker compose run --rm bootstrap-admin
```

Then open `http://localhost:8480/admin/`. If anything in `verify-docker.ps1` fails, send its report file (it contains no secrets or patient data).
