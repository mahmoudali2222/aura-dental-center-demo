# Database Design

The authoritative schema is the SQL in `database/migrations/` (three files today). This document explains it. If the two
ever disagree, the SQL wins; the test `backend/tests/integration/db.test.ts` applies the real migrations to an empty
PostgreSQL 16 database and checks the constraints described here.

Database: PostgreSQL 16, one dedicated database (`dental_center`), one dedicated Docker volume (`dental_center_pgdata`).
Extension: `btree_gist` (needed for the overlap constraints). All timestamps are `timestamptz`. Primary keys are UUIDs
(`gen_random_uuid()`), except small lookup tables and the audit log.

## Migrations at a glance

| File | What it does |
|---|---|
| `0001_init.sql` | Every table, constraint, index and trigger below, except `departments.working_days`. |
| `0002_reference_data.sql` | The four slot templates (16:00, 18:00, 20:00, 22:00), the single `center_profile` row and its three empty translation rows. Idempotent. |
| `0003_department_working_days_and_seven_departments.sql` | Adds `departments.working_days` (default all seven days). Deletes every department that is not one of the seven the center offers, **completely** (translations, dentist, services, gallery cases, closed dates), and refuses to run (rolling back) if any such department has appointments. |

Rules of the runner (`backend/src/database/migrate.ts`):

- Files named `NNNN_description.sql` are applied in filename order, each in its own transaction.
- Each applied file is recorded in `schema_migrations(version, checksum)` with a SHA-256 checksum. **Editing an applied
  migration aborts the run** ("checksum mismatch"). To change the schema, add a new file.
- A session-level advisory lock stops two processes (for example two containers) from migrating at the same time.
- Forward-only: no down-migrations, and migrations never drop user data on their own.

## Entities

### Content and configuration

| Table | Purpose | Key columns / constraints |
|---|---|---|
| `center_profile` | One row (`id = 1`): the single source of truth for public details | `phone`, `whatsapp`, `email`, `map_url`, `default_locale` (ar/en/fr, default `ar`), `currency` (default `EGP`), `booking_horizon_days` 1–365 (default 60), `working_days smallint[]` (ISO 1 = Mon … 7 = Sun, 1–7 distinct-range values, default all seven) |
| `center_profile_translations` | Localized name, address, introduction, hours note | PK `(locale)` |
| `slot_templates` | The four daily slots | `slot_number` PK 1..4, `start_time time` UNIQUE, `duration_minutes` CHECK = 120, `is_active`. Only the start is stored; the end is always start + 120 min, so "24:00" never exists as a value. |
| `departments` | One row per department | `slug` UNIQUE (kebab-case CHECK), `display_order`, `is_active`, `image_path`, **`working_days smallint[]`** (ISO weekdays; CHECK 1–7 entries, each 1..7; default all seven) |
| `department_translations` | Localized name / description | PK `(department_id, locale)`, name non-blank, `ON DELETE CASCADE` |
| `dentists` | The assigned dentist (no login) | FK `department_id`, `photo_path`, `is_active`, `is_sample`; **partial UNIQUE index `dentists_one_active_per_department` on `(department_id) WHERE is_active`** = exactly one active dentist per department. Replacing a dentist = deactivate + create, so old appointments keep pointing at the person who was assigned at the time. |
| `dentist_translations` | Localized display name / bio | PK `(dentist_id, locale)` |
| `services` | Services a department offers | FK `department_id`, `price numeric(10,2)` NULL (>= 0), `display_order`, `is_active`, `is_sample`, `image_path` |
| `service_translations` | Localized name / description | PK `(service_id, locale)` |
| `closures` | Closed dates | `date_from`, `date_to` (CHECK `date_to >= date_from`), `department_id` NULL = the whole center is closed, `reason` |
| `gallery_cases` | Before/after cases | FK `department_id`, `case_kind IN ('real','sample')`, `consent_confirmed`, `is_published`; CHECK `NOT is_published OR case_kind = 'sample' OR consent_confirmed` (a real case cannot be published without recorded consent; sample cases are always labelled as samples by the API) |
| `gallery_case_translations` | Localized title, description, alt texts | PK `(case_id, locale)` |

### People and access

| Table | Purpose | Key columns / constraints |
|---|---|---|
| `patients` | Patient accounts | `phone_e164` UNIQUE (`^\+[1-9][0-9]{6,14}$`), `full_name` 2–120 chars, `password_hash` (Argon2id), `preferred_locale`, `is_active`, `last_login_at` |
| `admin_users` | Staff accounts. The first one comes from the bootstrap command, never from a migration or seed. | `username` UNIQUE lower-case, `password_hash`, `must_change_password` (default true), `is_active` |
| `sessions` | Server-side sessions | `token_hash` UNIQUE (only the SHA-256 of the cookie token is stored), `kind IN ('patient','admin')`, CHECK that exactly the matching owner column is set, `csrf_token`, `expires_at`, `last_seen_at`, `revoked_at` |
| `telegram_link_tokens` | One-time linking codes | `token_hash` UNIQUE (hashed), `patient_id`, `expires_at`, `used_at` |
| `telegram_links` | Linked Telegram accounts | `telegram_user_id bigint`, `patient_id`, `revoked_at`, `revoked_by IN ('patient','admin','replaced','integration')`; partial UNIQUE indexes allow one **active** link per Telegram account and one per patient |

### Appointments, records, audit

| Table | Purpose | Key columns / constraints |
|---|---|---|
| `appointments` | Bookings | `patient_id`, `department_id`, `dentist_id` (who was assigned at the time), `service_id` NULL, `appointment_date` (the Cairo calendar date on which the slot **starts**), `slot_number` 1..4, `starts_at`, `ends_at`, `status IN ('booked','cancelled','completed','no_show')`, `patient_note` ≤ 500, `created_via IN ('web','admin','telegram')`, `rescheduled_count`, `cancelled_at/by/reason` |
| `medical_records` | Admin-only clinical data | `patient_id`, optional `appointment_id`, `medical_history`, `allergies`, `diagnosis`, `treatment`, `notes` (each ≤ 20 000 chars), `created_by`, `updated_by`, timestamps. No route outside the admin API reads this table. |
| `audit_events` | Append-only audit trail | `occurred_at`, `actor_type IN ('admin','patient','integration','system','anonymous')`, `actor_id`, `action`, `entity_type`, `entity_id`, `outcome IN ('success','failure','denied')`, `metadata jsonb`, `ip` |

## Booking integrity (the important part)

```sql
-- statuses that keep a slot and count toward daily capacity: booked, completed, no_show   (cancelled releases)
CREATE UNIQUE INDEX appointments_active_slot_uq
  ON appointments (department_id, appointment_date, slot_number)
  WHERE status IN ('booked','completed','no_show');

ALTER TABLE appointments ADD CONSTRAINT appointments_no_department_overlap
  EXCLUDE USING gist (department_id WITH =, tstzrange(starts_at, ends_at) WITH &&)
  WHERE (status IN ('booked','completed','no_show'));

ALTER TABLE appointments ADD CONSTRAINT appointments_no_patient_overlap
  EXCLUDE USING gist (patient_id WITH =, tstzrange(starts_at, ends_at) WITH &&)
  WHERE (status IN ('booked','completed','no_show'));
```

- `slot_number` is limited to 1..4 and the unique index allows one active appointment per slot, so **a department can
  never exceed four active appointments on a day and can never double-book a slot**, whatever the application does.
- The department-overlap constraint is a second net: two active appointments of one department cannot overlap in time even
  if slot numbers were changed in the future.
- The patient-overlap constraint stops one patient from holding two overlapping active appointments in different departments.
- `CHECK (extract(epoch FROM (ends_at - starts_at)) = 7200)`: exactly two **real** hours. On the two Egyptian DST-change
  nights the 22:00 slot still lasts two real hours; its wall-clock end label is then 23:00 or 01:00 instead of 00:00
  (see `ARCHITECTURE.md` §4).
- `CHECK ((status = 'cancelled') = (cancelled_at IS NOT NULL))`.
- A trigger (`appointments_guard_status`) rejects illegal status transitions and any attempt to move or reassign a
  cancelled/completed appointment, so a manual SQL update cannot silently corrupt history. Allowed:
  `booked → cancelled | completed | no_show`, and `no_show → completed` (admin correction). `cancelled` and `completed` are terminal.
- The application adds, on top of these guarantees, a per-(department, date) advisory lock and a `FOR SHARE` lock on the
  department row while booking. See `BOOKING_RULES.md` for the exact sequence and error codes.
- **Working days are not a database constraint.** They are checked inside the booking transaction (one function,
  `slotUnavailableReason`, shared with the availability endpoint). Existing appointments are never invalidated by a
  later change of working days.

## Deletion behavior

| Entity | Rule |
|---|---|
| Patients | Never hard-deleted by the app; deactivated (`is_active = false`). FKs from appointments and medical records are `ON DELETE RESTRICT`. |
| Departments, services, dentists | The admin API has no delete: deactivate instead (FKs from appointments are `RESTRICT`). The only deletion path is migration 0003, which removes departments outside the seven kept slugs and aborts if one has appointments. Translations cascade with their parent. |
| Gallery cases | The admin can delete a case (it is content, not patient history). |
| Closures | The admin can delete a closure. |
| Appointments | Never deleted by the app or a migration; cancelled status keeps history. |
| Medical records | No delete endpoint; corrections are updates with authorship and an audit event. |
| Sessions | Expired/revoked sessions are deleted automatically by the backend every 6 hours (`pruneSessions`). Link tokens expire after 10 minutes and are ignored afterwards. |
| Audit events | Immutable (below). |

## Audit immutability

`BEFORE UPDATE OR DELETE` (row level) and `BEFORE TRUNCATE` triggers on `audit_events` raise an exception, so application
code, including a bug or SQL injection through the app role, cannot rewrite history. Honest limit: **the database owner
can still disable triggers.** This stack connects as the single PostgreSQL superuser it creates (`POSTGRES_USER`), used by
both the migration job and the backend. Splitting this into an owner role and a restricted application role is a documented
hardening step (`SECURITY.md`), not something that exists today.

## Seeds

`database/seeds/catalog.sample.json` is the sample catalog, applied by `node dist/cli/seed.js` (Compose runs it after the
migrations when `SEED_SAMPLE_CATALOG=true`):

- it creates **exactly the seven departments** (Restorative Dentistry, Endodontics, Orthodontics, Periodontics, Pediatric
  Dentistry, Prosthodontics, Oral Surgery) with Arabic/English/French names and descriptions, one placeholder dentist each
  and a few generic services, all flagged `is_sample = true`; no prices, no real people, no patient data;
- a department is inserted **only if its slug does not exist**, so re-running never overwrites what the administrator edited
  (including working days, names, dentist, services and the picture path). New departments get `image_path`
  `/assets/departments/<slug>-before-after.jpg` (the supplied picture, which ships in `frontend/public`); clearing it in the dashboard
  stays cleared;
- the center name is filled only where still empty;
- the administrator account is **not** seeded; it comes from `node dist/cli/bootstrap-admin.js` using environment values
  (see `DEPLOYMENT.md`).

## Where each rule lives

| Rule | Database | Application |
|---|---|---|
| ≤ 4 active appointments per department per day, no double booking | unique index + overlap constraint | advisory lock, clear error codes |
| 2-hour slots, 16:00–24:00 | slot template CHECKs, duration CHECK | slot window computed in `Africa/Cairo` |
| Cancelled releases the slot | index/constraints are partial on active statuses | status lifecycle service |
| Working days (center ∩ department), closures, past, horizon | — | `slotUnavailableReason` |
| 24-hour cancel/reschedule rule | — | appointment service (absolute instants) |
| One active dentist per department | partial unique index | dentist service maps the violation to `DEPARTMENT_HAS_DENTIST` |
| Real gallery case needs consent before publishing | CHECK | gallery routes |
| Audit log append-only | triggers | `recordAudit` redacts secrets by key name |
