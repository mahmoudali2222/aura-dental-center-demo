# Security

What is protected, how, and, just as important, what is **not** protected. Nothing here was penetration-tested by an
outside party; the controls below are covered by the automated tests listed at the end, run against a real database.

## 1. Who can do what

| Actor | Credential | May access | Never |
|---|---|---|---|
| Visitor | none | center info, departments, services, published gallery, availability, register, login | any patient, appointment or medical data |
| Patient | cookie `dc_patient` + CSRF token | own profile, own appointments, own Telegram link | other patients' data (another patient's id answers `404`, not `403`), medical records, admin routes, integration routes |
| Administrator | cookie `dc_admin` + CSRF token; blocked until the first password change | everything in `/api/v1/admin/*` including medical records and the audit log; every sensitive action is audited | n/a |
| n8n | `Authorization: Bearer <INTEGRATION_API_KEY>` | only `/api/v1/integrations/*` | admin routes, medical records, password data, other patients' data |
| Telegram user (through n8n) | a linked `telegram_user_id` | the linked patient's own appointments and bookings | anything personal before linking |

There is **no dentist login**: dentists are information on the website only. **Medical records are readable and writable
only by an administrator session**; no patient route, public route or integration route reads that table.

## 2. Accounts and passwords

- **Hashing:** Argon2id (19 MiB, 2 iterations, 1 lane = the OWASP minimum profile). Hashes carry their parameters, so the
  cost can be raised later. Passwords are never logged, returned, audited or stored in clear text.
- **Policy:** patients 8–128 characters, administrators 12–128; trivially guessable values (common strings, one repeated
  character, the phone number itself, the admin's own user name) are refused.
- **Login errors are generic** (`INVALID_CREDENTIALS`); a login for an unknown account burns the same CPU as a real check so
  timing does not reveal which phone numbers are registered. (Registration still answers `PHONE_ALREADY_REGISTERED`,
  which is unavoidable with phone-only accounts; the registration rate limit limits probing.)
- **Initial administrator:** created once by `docker compose run --rm bootstrap-admin` (it runs `node dist/cli/bootstrap-admin.js`) from
  `ADMIN_BOOTSTRAP_USERNAME` / `ADMIN_BOOTSTRAP_PASSWORD` in `.env`; only that short-lived container receives the password. It is a no-op when any admin exists, never resets an account, and the account is forced to
  choose a new password at first login (every other admin route answers `PASSWORD_CHANGE_REQUIRED` until then). The password is
  not in any file of this project; **remove it from `.env` after the first login**.
- **Staff-assisted recovery:** there is no "forgot password" link and no endpoint that resets a password without an
  administrator session. A staff member verifies the person at the desk, sets a new password in the dashboard, all of the
  patient's sessions are revoked, and an audit event (without the password) is written.
- **Sessions:** random 256-bit tokens in an `HttpOnly`, `SameSite=Lax` cookie (`Secure` when `COOKIE_SECURE=true`); only the
  SHA-256 of the token is stored. Patient sessions last 7 days (24 h idle), administrator sessions 8 hours (30 min idle); both
  configurable. Logout, password change and reset revoke sessions at once. Patient and admin cookies are separate and a
  token of one kind never authenticates the other.
- **Throttling:** 20 logins / 15 min per IP, 8 failures / 15 min per account, 10 registrations / hour per IP, 240
  integration calls / minute, 600 API calls / minute per IP. Limits are in memory (reset on restart, one backend instance).
  Trade-off: someone who deliberately fails 8 logins for a victim's phone locks that login for up to 15 minutes.

## 3. Browser protections

- **Single origin:** nginx serves both apps and proxies `/api/`, so cookies are first-party and the API has no open CORS surface.
- **CSRF:** `SameSite=Lax` cookie + `Origin` check against `PUBLIC_APP_URL`/`ALLOWED_ORIGINS` + a per-session token in
  `X-CSRF-Token` on every state-changing request. (Therefore `PUBLIC_APP_URL` must be the exact address people type; forms sent
  from any other address are refused. See `TROUBLESHOOTING.md`.)
- **Headers** (set by nginx on every response): strict `Content-Security-Policy` (`default-src 'self'`, no inline script, no
  third-party host), `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy`.
  `/admin/` is `noindex`. API responses are `no-store`. nginx is the **only** owner of these headers: the backend also sends a set
  (helmet) and `frontend/nginx/proxy-api.conf` removes the backend's copies from proxied answers, because two sets reach the browser
  as repeated, partly conflicting headers (found by the smoke test; guarded by `e2e/tests/05-http-headers.spec.ts`, SEC-HDR).
- **HSTS is not set by the web container** (it speaks plain HTTP; the backend's own HSTS header is removed by the same rule). On a
  VPS, set `Strict-Transport-Security` where HTTPS is terminated (`DEPLOYMENT.md`).
- Content from the database is rendered as text by React (never as HTML); the only URLs taken from the database are image
  paths that must start with `/assets/` and the map link, which must be `http(s)://`.

## 4. Data protection

- **Audit log:** append-only (database triggers reject UPDATE, DELETE and TRUNCATE). It records who/what/when/outcome and ids,
  never passwords, tokens, secrets or clinical text. Redaction is **by key name** (`password`, `token`, `secret`, `hash`,
  `authorization`, `cookie`, `csrf`, `api key`, `credential`, `medical`, `history`, `allergy`, `diagnosis`, `treatment`,
  `clinical`, `note(s)`) and values are truncated to 200 characters. **Free text typed in a field that is not on that list is
  kept**: the "reason" of a cancellation or of a 24-hour override is stored in the appointment and in the audit event, so staff
  must not type clinical details there. Medical records are audited as "record created/updated for patient X" without content.
- **Logs:** the backend's structured log redacts the `Authorization` and `Cookie` request headers and `Set-Cookie` responses.
  Request bodies are not logged.
- **Integration key:** compared in constant time; may be rotated without downtime with `INTEGRATION_API_KEY_NEXT`
  (`N8N_INTEGRATION.md` §8). Empty key = integration API off (`503`).
- **Telegram linking:** a logged-in patient creates a one-time code (10 minutes, stored hashed, single-use), sends it to the bot;
  n8n redeems it with the Telegram user id. One active link per Telegram account and per patient; the patient or an admin can
  revoke it at once. Redeeming attempts are throttled.
- **Gallery:** a "real" case cannot be published until consent is recorded (database CHECK + API); sample cases are always
  labelled as samples. No patient photos are included in this project.

## 5. Container and network hardening

- Only the web container publishes a port, bound to `127.0.0.1` by default (`WEB_BIND`). PostgreSQL has no published port.
- The backend runs as the unprivileged `node` user with a read-only root filesystem, `cap_drop: ALL`,
  `no-new-privileges`; the web container uses the non-root nginx image and also drops all capabilities.
- Optional second lock on the n8n routes: `frontend/nginx/integrations-access.conf` (IP allow/deny) in front of the key.
- Secrets exist only in your `.env` (ignored by git and by the Docker build context). `.env.example` holds placeholders only.
  The n8n workflow exports contain no key or token; you enter them in n8n's credential store.

## 6. Known limitations and residual risks (not hidden)

1. **Phone numbers are not verified** (specified: no OTP/SMS). Anyone can register with a number they do not own, and a person
   who registers someone else's number first blocks that person from registering (staff can fix this in person). Anyone who
   knows a patient's phone and password can book; there is no second factor.
2. **n8n is trusted** to pass the real Telegram user id. A compromised n8n instance or a leaked integration key can act as any
   *linked* patient. Mitigations: key rotation, IP lock, rate limit, audit of every integration action, and the integration API
   exposes only appointment operations and public information.
3. **One database role.** The migration job and the backend connect as the PostgreSQL superuser created by the image. A bug or
   SQL injection could therefore also disable the audit triggers. Hardening step for production: create a non-owner,
   non-superuser role with only DML rights for the backend. (Not implemented here: it needs a deployment decision about who
   owns the schema; the code uses only parameterised queries.)
4. **Rate limits are per process and in memory**; they reset on restart and do not follow users across several replicas.
5. **No TLS in the stack itself.** Local use over `http://localhost` is fine; for any network use put HTTPS in front
   (`DEPLOYMENT.md`) and set `COOKIE_SECURE=true`.
6. **No automatic backups.** The scripts exist and were tested, but nothing schedules them for you (`BACKUP_RESTORE.md`).
7. **Dependency and image updates are manual.** Run `npm audit` and rebuild the images regularly. No vulnerability scan of the
   images was possible in the development environment.
8. **No two-factor authentication for administrators** (not in the specification). Use a long unique passphrase.
9. Admin accounts are created only by the bootstrap command; there is no screen to add further administrators yet.
10. The administrator's session is not bound to an IP address or device.

## 7. Automated checks for these controls

| Control | Test |
|---|---|
| Hashing, policy, generic login error, throttling, session expiry, logout | `backend/tests/integration/auth.test.ts` |
| CSRF/origin, cookie flags, admin gate, patient/admin separation, route table has no unauthenticated reset | `auth.test.ts`, `admin.test.ts` |
| Medical records admin-only, no clinical text in other responses, logs or audit | `admin.test.ts` |
| Audit immutability and redaction | `db.test.ts`, `admin.test.ts`, `backend/tests/unit/misc.test.ts` |
| Integration key, linking, cross-patient isolation, no access to admin routes | `integration-api.test.ts`, `n8n-e2e.test.ts` |
| Startup fails on bad configuration | `backend/tests/unit/config.test.ts`, `server-process.test.ts` |
| Security headers, hidden files, single origin, CSRF flow in a real browser | `e2e/tests/*.spec.ts` (real nginx config) |

Report a vulnerability to the center's administrator; do not post details (or any key/password) in a public place.
