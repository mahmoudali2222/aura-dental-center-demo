# Project documentation

A guided map of the whole project: what it is, where everything lives, and where to change what. Operational how-tos are in
the other documents (see the index at the end).

## 1. What this is

A complete management system for a dental center:

- a **patient website** (Arabic RTL / English / French): browse the seven departments, register with phone + password,
  book, view, cancel and reschedule appointments, link a Telegram account;
- a separate **Admin Dashboard** (`/admin/`): appointments, patients (including admin-only medical records and staff-assisted
  password reset), departments with **working days** and dentists, services, gallery, center settings and closed dates, audit log;
- a **REST API** (Node 22, TypeScript, Fastify) that is the only place business rules live;
- its **own PostgreSQL 16 database**, started by Docker Compose with a dedicated volume;
- an **integration** for your existing n8n + Telegram assistant (two importable workflows and a key-protected API group);
- scripts for backup/restore, secrets, smoke tests and browser tests.

It is independent of any older project: its own folder, Compose project name (`dental-center`), network, volume and database.

Fixed business rules (details in [`BOOKING_RULES.md`](BOOKING_RULES.md)): open 4 PM – 12 AM `Africa/Cairo`; four 2-hour slots a
day; at most four active appointments per department per day; race-safe; cancelling releases the slot; patients cancel or
reschedule at least 24 hours ahead (web and Telegram alike); a department can be booked only on days that are working days of the
center and of the department; exactly one assigned dentist per department, who has no login; no AI chatbot on the website.

## 2. How the pieces fit

```
Browser ─► web (nginx, port 8480) ─┬─ /          patient website (React single-page app)
                                   ├─ /admin/    admin dashboard (second single-page app)
                                   ├─ /assets/   your pictures (a mounted folder)
                                   └─ /api/ ───► backend (Fastify, :3480, internal) ─► db (PostgreSQL 16, internal)
n8n ──► same address, /api/v1/integrations/ (Bearer key) ─────────────────┘
```

One public address, one origin: cookies stay first-party. More in [`ARCHITECTURE.md`](ARCHITECTURE.md).

## 3. Repository map

```
dental-center-management/
├── README.md                     start here (quick start)
├── docker-compose.yml            db, migrate (job), backend, web; tools: bootstrap-admin, reset-admin-password
├── .env.example                  every setting, with comments (copy to .env; never commit .env)
├── .gitignore / .dockerignore
├── database/
│   ├── migrations/               0001_init.sql, 0002_reference_data.sql, 0003_department_working_days_and_seven_departments.sql
│   └── seeds/catalog.sample.json the seven departments with sample dentists/services (trilingual)
├── backend/                      the API
│   ├── Dockerfile
│   ├── src/
│   │   ├── server.ts             process entry, graceful shutdown, session pruning every 6 h
│   │   ├── app.ts                builds the Fastify app: security plugins, CSRF/origin check, error handler, registers routes
│   │   ├── types.ts              AppContext, Actor
│   │   ├── config/env.ts         environment parsing and validation (fails fast, never prints secrets)
│   │   ├── database/             pool.ts (transactions), migrate.ts (runner), seed.ts
│   │   ├── cli/                  migrate, seed, bootstrap-admin, reset-admin-password, openapi (command-line entry points)
│   │   ├── lib/                  routes.ts (route() helper + registry), errors.ts, validation.ts, time.ts (Cairo/slot/24 h math),
│   │   │                         locale.ts, translations.ts, phone.ts, crypto.ts, clock.ts, request-locale.ts, openapi.ts
│   │   ├── middleware/           attempt-limiter.ts (per-account login throttle)
│   │   └── modules/
│   │       ├── auth/             patient + admin login, sessions, password policy/hashing, admin bootstrap and reset
│   │       ├── patients/         patient self-service routes, admin patient routes (incl. password reset, Telegram revoke)
│   │       ├── appointments/     appointment.service.ts: THE only writer of the appointments table (book, cancel, reschedule, status)
│   │       ├── scheduling/       scheduling.service.ts: slotUnavailableReason (working days, closures, past, horizon, capacity), availability
│   │       ├── center/           center profile + slot templates
│   │       ├── departments/ dentists/ services/ gallery/   catalog services
│   │       ├── medical-records/  admin-only routes
│   │       ├── audit/            append-only writer (redaction) + admin reader
│   │       ├── public/           anonymous routes (center, departments, availability, gallery)
│   │       ├── integrations/     n8n routes + Telegram linking
│   │       └── admin/            admin route groups: appointments, catalog, settings
│   └── tests/                    unit/ and integration/ (real PostgreSQL); helpers/harness.ts builds a throw-away database
├── frontend/                     one Vite package, two single-page apps
│   ├── Dockerfile                builds both apps, then nginx-unprivileged
│   ├── index.html, admin/index.html, vite.config.ts
│   ├── nginx/                    default.conf, security-headers.conf, proxy-api.conf, integrations-access.conf, real-ip.conf
│   ├── public/assets/            branding/, departments/, services/, gallery/   (your pictures; empty at first)
│   ├── src/shared/               api clients (http.ts, public/patient/admin.ts, types.ts), i18n provider and common messages,
│   │                             UI primitives (ui/index.tsx), styles (tokens.css, base.css), session factory
│   ├── src/patient/              patient site: pages/, components/, app/, i18n/messages.ts
│   ├── src/admin/                dashboard: pages/, components/, api/, i18n/messages*.ts, admin.css
│   └── tests/                    Vitest + Testing Library with fake backends
├── integrations/n8n/
│   ├── src/                      api-wrapper.js, telegram-commands.js  (the logic inside the workflow Code nodes)
│   ├── build.cjs                 regenerates the two workflow files from src/ (--check detects drift)
│   ├── workflows/                the two importable exports (no keys, no tokens)
│   └── test/                     node:test suites, simulator, real-n8n check
├── e2e/                          Playwright browser tests (patient, admin, working days, languages, mobile)
├── scripts/
│   ├── backup.sh/.ps1, restore.sh/.ps1   verified backups and safe/live restore
│   ├── new-secret.sh/.ps1                random secrets
│   ├── smoke-api.mjs                     end-to-end HTTP smoke test of a running stack
│   ├── verify-docker.ps1                 isolated verification of the Docker stack on Windows
│   ├── e2e-local.sh, run-local-web.sh    browser tests / real nginx config without Docker
│   └── tests/                            tests of the backup scripts
└── docs/                         this documentation (+ MASTER_SPEC.md, the original specification, unchanged)
```

## 4. Where do I change X?

| I want to change… | Do this |
|---|---|
| **Center address, phone, WhatsApp, email, map, names** | Dashboard → Center settings. Never in code: the website and the Telegram bot read it from the database. |
| **Working days of the whole center** | Dashboard → Center settings → working days. |
| **Working days of one department** | Dashboard → Departments & dentists → the department → working days. Effective days = center ∩ department. |
| **Closed dates / holidays** | Dashboard → Center settings → closed dates (center-wide or one department). |
| **Booking horizon (how far ahead)** | Dashboard → Center settings. |
| **Disable one of the four slots** | Dashboard → Center settings → slots (at least one must stay on). |
| **Slot times (4 PM – 12 AM) or the 2-hour length, or the 4-per-day capacity** | Not a setting; they are structural (slot table, constraints, tests). A change needs a new migration, `DAILY_CAPACITY`/slot handling in `scheduling.service.ts` and updated tests. Ask for it as a feature. |
| **The 24-hour rule** | `SELF_SERVICE_NOTICE_MS` in `backend/src/lib/time.ts`; boundary tests in `backend/tests/integration/booking.test.ts`. |
| **Add or edit a department / dentist / service / gallery case** | Dashboard (names in all three languages). To change the **sample data of a new installation**: `database/seeds/catalog.sample.json`. |
| **Replace the sample dentist** | Departments & dentists → the department → deactivate the sample dentist, add the real one. |
| **A picture** | Copy the file into `frontend/public/assets/<folder>/` and type its `/assets/...` path in the dashboard ([`IMAGE_ASSETS.md`](IMAGE_ASSETS.md)). |
| **Website texts (buttons, labels, errors)** | Patient site: `frontend/src/patient/i18n/messages.ts`. Dashboard: `frontend/src/admin/i18n/messages*.ts`. Shared (errors, statuses, weekdays): `frontend/src/shared/i18n/messages/common.ts`. Arabic and French must define every English key; the compiler and a test enforce it. |
| **Add a new language** | A project, not a setting: `LOCALES` in `backend/src/lib/locale.ts`, the `locale IN ('ar','en','fr')` CHECKs in a new migration, a full set of messages in each frontend message file, direction/format rules in `frontend/src/shared/i18n/`. |
| **Colors, fonts, spacing of the sites** | `frontend/src/shared/styles/tokens.css` (design tokens) and `base.css`; page-specific rules in `frontend/src/admin/admin.css`. The patient site's own look is in `frontend/src/patient/styles/` (scoped to `html[data-app="patient"]`); the logo and hero-video places are in `frontend/src/patient/config.ts` (`FRONTEND.md`). |
| **Password rules** | `backend/src/modules/auth/password.ts`. |
| **Session lengths** | `.env` (`SESSION_*`). |
| **Rate limits** | `backend/src/config/env.ts` (`rateLimits`). |
| **A secret, URL, port or cookie flag** | `.env` (see [`DEPLOYMENT.md`](DEPLOYMENT.md) settings table), then `docker compose up -d`. |
| **The n8n API (what the bot may do)** | `backend/src/modules/integrations/integration.routes.ts`; then `npm --prefix backend run openapi`. The bot's wording and commands: `integrations/n8n/src/telegram-commands.js`, then `cd integrations/n8n && npm run build` and re-import the workflows in n8n. |
| **A new API endpoint** | Add a `route({...})` in the module's routes file (auth level, zod schemas, documented error codes), register the group in `backend/src/app.ts`, add tests, run `npm --prefix backend run openapi` (a test fails if `docs/openapi.json` is stale). |
| **A new database change** | Add `database/migrations/0004_what_it_does.sql`. Never edit an applied file (the runner refuses). Add a test to `backend/tests/integration/db.test.ts` (update `ALL_MIGRATIONS`). |
| **A new business rule in booking** | Only in `scheduling.service.ts` (`slotUnavailableReason`) or `appointment.service.ts`. Both availability and booking go through them, so the screens and the server cannot disagree. Add the error code to `REASON_ERRORS`, the frontend messages and the docs. |
| **Add an administrator account** | Not available in the dashboard (documented limitation). The first one comes from `bootstrap-admin`. |
| **Backups** | `scripts/backup.*`, [`BACKUP_RESTORE.md`](BACKUP_RESTORE.md). |

## 5. Conventions worth knowing

- **Errors are codes.** The backend answers `{ "error": { "code": "SLOT_UNAVAILABLE" } }`; the frontends translate codes. Never
  reword an existing code; add a new one and its three translations.
- **Translations of content** (departments, services, dentists, center) live in `*_translations` tables, one row per language.
  Missing translations fall back: requested → center default → English → Arabic → French.
- **Dates and times** are Cairo calendar dates and ISO instants with the Cairo offset. The 22:00 slot belongs to the day it starts.
- **SQL is hand-written and parameterised** (no ORM); transactions use `withTransaction`.
- **Logging** never includes passwords, tokens, cookies or clinical text.
- **Arabic UI** uses Latin digits and logical CSS properties (so right-to-left and left-to-right share one stylesheet).

## 6. Documentation index

| Document | Content |
|---|---|
| [`../README.md`](../README.md) | Quick start |
| [`FINAL_REPORT.md`](FINAL_REPORT.md) | The final report required by the specification (§23) |
| [`PROJECT_STATUS.md`](PROJECT_STATUS.md) | What is done, what was verified and how, what is **not** verified, open questions |
| [`MASTER_SPEC.md`](MASTER_SPEC.md) | The original specification (unchanged) |
| [`REQUIREMENTS.md`](REQUIREMENTS.md) | Rules and requirements register with traceability |
| [`ARCHITECTURE.md`](ARCHITECTURE.md) | Design and decisions |
| [`DATABASE.md`](DATABASE.md) | Tables, constraints, migrations, seeds |
| [`BOOKING_RULES.md`](BOOKING_RULES.md) | Every booking rule, working-days semantics, concurrency |
| [`API.md`](API.md), [`API_REFERENCE.md`](API_REFERENCE.md), [`openapi.json`](openapi.json) | API guide, generated reference, OpenAPI |
| [`FRONTEND.md`](FRONTEND.md) | Patient site and dashboard internals |
| [`N8N_INTEGRATION.md`](N8N_INTEGRATION.md) | Telegram/n8n setup and operation |
| [`SECURITY.md`](SECURITY.md) | Controls and honest limitations |
| [`DEPLOYMENT.md`](DEPLOYMENT.md) | Windows (Docker Desktop) and VPS |
| [`BACKUP_RESTORE.md`](BACKUP_RESTORE.md) | Backup and restore |
| [`TESTING.md`](TESTING.md) | Test catalogue, how to run everything, results |
| [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md) | Problems and fixes |
| [`IMAGE_ASSETS.md`](IMAGE_ASSETS.md) | Picture folders, filenames, sizes, how to replace |
| [`IMPLEMENTATION_PLAN.md`](IMPLEMENTATION_PLAN.md) | The original phased plan and decisions |
