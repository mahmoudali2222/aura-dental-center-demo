# API guide

This is the hand-written guide to how the API behaves. The complete, always-current list of endpoints is generated from
the code:

- [`API_REFERENCE.md`](API_REFERENCE.md): every route, who may call it, its purpose and its error codes (readable).
- [`openapi.json`](openapi.json): the same as OpenAPI 3 (machine-readable; import it into Postman/Insomnia/n8n).
- Regenerate both after changing a route: `npm --prefix backend run openapi`. A test fails if they drift from the code.

Base path: `/api/v1`. In the Docker stack the browser and n8n reach it through the one public address
(`http://localhost:8480/api/v1/...`); the backend container itself is not published.

## Route groups and who may call them

| Prefix | Caller | Credential |
|---|---|---|
| `/api/v1/public/*` | anyone | none (center info, departments, availability, published gallery) |
| `/api/v1/patient/auth/*` | visitor | register / login / logout / change password |
| `/api/v1/patient/*` | a logged-in patient | cookie `dc_patient` + `X-CSRF-Token` on writes |
| `/api/v1/admin/auth/*` | staff | login / me / logout / change-password |
| `/api/v1/admin/*` | a logged-in administrator | cookie `dc_admin` + `X-CSRF-Token` on writes; blocked until the first password change is done |
| `/api/v1/integrations/*` | the existing n8n | `Authorization: Bearer <INTEGRATION_API_KEY>` |
| `/api/health`, `/api/ready` | monitoring | none (`ready` also checks the database) |

Nothing outside `/api/v1/admin/*` can reach medical records, the audit log or another patient's data.

## Response envelopes

| Case | Shape |
|---|---|
| One object | `{ "data": { ... } }` |
| A page of objects | `{ "data": [ ... ], "meta": { "page": 1, "pageSize": 20, "total": 57, "totalPages": 3 } }` |
| Nothing to return | HTTP `204`, empty body |
| Error | `{ "error": { "code": "SLOT_UNAVAILABLE", "message": "...", "details": ... } }` |

`error.code` is a stable machine-readable string; the website translates it (Arabic/English/French). `error.message` is a
short English text for developers and logs, never shown to patients as-is. `details` is present only when useful, for
example a list of `{ field, code }` for validation errors or `{ count }` for `WORKING_DAYS_HAVE_APPOINTMENTS`.

## Authentication details

- **Sessions are server-side.** The cookie holds an opaque random token; only its SHA-256 is stored. Cookies are `HttpOnly`,
  `SameSite=Lax`, and `Secure` when `COOKIE_SECURE=true`.
- **CSRF.** Every state-changing browser request (`POST`/`PUT`/`PATCH`/`DELETE`) must (1) come from an allowed origin
  (`PUBLIC_APP_URL` or `ALLOWED_ORIGINS`) and (2) send the session's token in `X-CSRF-Token`. The token is returned by the
  login/`me` responses. Failing either gives `403 ORIGIN_NOT_ALLOWED` / `403 CSRF_INVALID`.
- **Admin first login.** The bootstrap administrator has `mustChangePassword = true`; every admin route except
  `change-password`, `me` and `logout` answers `403 PASSWORD_CHANGE_REQUIRED` until it is changed.
- **Passwords.** Patients: 8–128 characters; administrators: 12–128; obvious ones (`12345678`, the phone number, a single
  repeated character …) are rejected with `PASSWORD_TOO_WEAK`. Hashing is Argon2id.
- **Integration key.** Compared in constant time. Unset key → every integration route answers `503 INTEGRATION_DISABLED`.
  A wrong key → `401 INVALID_INTEGRATION_KEY`. Two keys can be active for zero-downtime rotation
  (`INTEGRATION_API_KEY` + `INTEGRATION_API_KEY_NEXT`).
- **No unauthenticated password-reset endpoint exists.** Recovery is an administrator action in person
  (`POST /api/v1/admin/patients/:id/reset-password`), which revokes the patient's sessions and is audited.

## Language of content

Content endpoints take `?locale=ar|en|fr`, otherwise the `Accept-Language` header, otherwise the caller's saved
preference, otherwise the center's default language. A missing translation falls back through the center default →
English → Arabic → French. Raw translation keys are never returned.

## Time

- Dates are `YYYY-MM-DD` in the center's calendar (`Africa/Cairo`); a slot belongs to the day on which it **starts**.
- Instants are ISO-8601 with the Cairo offset, for example `2026-11-02T22:00:00+02:00`.
- Slots are numbered 1–4 (16:00, 18:00, 20:00, 22:00); each lasts exactly two real hours.

## Availability

`GET /api/v1/public/departments/:slug/availability?from=YYYY-MM-DD&to=YYYY-MM-DD` (and the integration equivalent
`GET /api/v1/integrations/availability?department=<slug>&from=..&to=..`) returns one entry per day:

```json
{ "date": "2026-11-04", "status": "open", "availableCount": 3,
  "slots": [ { "slotNumber": 2, "startTime": "18:00", "endTime": "20:00", "endsNextDay": false,
               "startsAt": "2026-11-04T18:00:00+02:00", "endsAt": "2026-11-04T20:00:00+02:00" } ] }
```

`status` is one of `open`, `full`, `closed` (not a working day of the center or the department, or a closure),
`past`, `beyond_horizon`, `unavailable` (the department has no active dentist). Only **genuinely bookable** slots are
listed. At most 62 days can be requested at once (`RANGE_TOO_LARGE`). The same function decides availability and accepts
bookings, so what is shown can never disagree with what the server accepts. Details in `BOOKING_RULES.md`.

## Rate limits (production defaults)

| What | Limit |
|---|---|
| Login (patient + admin) | 20 requests / 15 min per IP, and 8 failures / 15 min per phone or username |
| Registration | 10 / hour per IP |
| Integration API | 240 / minute |
| Everything else | 600 / minute per IP |

A limit answers `429 RATE_LIMITED` or `429 TOO_MANY_ATTEMPTS`. Counters live in memory: they reset when the backend
restarts and are not shared between replicas (this stack runs one). Behind the web container the client IP is taken
from `X-Forwarded-For` (`TRUST_PROXY=true`); on a VPS with another reverse proxy in front, configure that proxy to pass the
real client address (`DEPLOYMENT.md`).

## Error codes

HTTP class, code, meaning. Codes marked "booking" are described in more detail in `BOOKING_RULES.md`.

| HTTP | Code | Meaning |
|---|---|---|
| 400 | `VALIDATION_ERROR` | Body/query failed validation; `details` lists `{ field, code }` |
| 400 | `INVALID_PHONE`, `PASSWORD_TOO_SHORT`, `PASSWORD_TOO_LONG`, `PASSWORD_TOO_WEAK`, `PASSWORD_UNCHANGED` | Account input problems |
| 400 | `INVALID_RANGE`, `RANGE_TOO_LARGE` | Availability range invalid or longer than 62 days |
| 400 | `INVALID_SLOT`, `RESCHEDULE_NO_CHANGE`, `SERVICE_NOT_IN_DEPARTMENT` | Booking input problems |
| 400 | `OVERRIDE_REASON_REQUIRED` | An admin override inside 24 h needs a reason (≥ 3 characters) |
| 400 | `AT_LEAST_ONE_WORKING_DAY`, `INVALID_WEEKDAY`, `AT_LEAST_ONE_SLOT`, `AT_LEAST_ONE_TRANSLATION`, `TRANSLATION_NAME_REQUIRED`, `CONSENT_REQUIRED`, `INVALID_USERNAME` | Settings and catalog validation |
| 401 | `UNAUTHENTICATED`, `SESSION_EXPIRED`, `INVALID_CREDENTIALS`, `INVALID_INTEGRATION_KEY` | Not signed in / wrong credentials. Login failures are always the same generic `INVALID_CREDENTIALS` (no account enumeration). |
| 403 | `FORBIDDEN`, `CSRF_INVALID`, `ORIGIN_NOT_ALLOWED`, `PASSWORD_CHANGE_REQUIRED`, `ACCOUNT_DISABLED`, `TELEGRAM_NOT_LINKED` | Not allowed |
| 404 | `*_NOT_FOUND` (`APPOINTMENT`, `DEPARTMENT`, `DENTIST`, `SERVICE`, `PATIENT`, `MEDICAL_RECORD`, `CLOSURE`, `GALLERY_CASE`), `LINK_CODE_INVALID` | Unknown id. A patient asking for another patient's appointment gets the same 404 as for a missing one. |
| 409 | `SLOT_UNAVAILABLE`, `DAILY_CAPACITY_REACHED`, `PATIENT_OVERLAP` (booking) | Lost the race / slot taken / four already booked / patient already has an overlapping appointment |
| 409 | `APPOINTMENT_NOT_ACTIVE`, `INVALID_STATUS_TRANSITION` | Appointment already cancelled/completed, or illegal transition |
| 409 | `PHONE_ALREADY_REGISTERED`, `SLUG_TAKEN`, `DEPARTMENT_HAS_DENTIST`, `LINK_CONFLICT` | Uniqueness conflicts |
| 409 | `CLOSURE_HAS_APPOINTMENTS`, `WORKING_DAYS_HAVE_APPOINTMENTS` | A closure / removed working day would cover existing appointments; repeat with `acknowledgeExistingAppointments: true` to proceed (nothing is cancelled automatically); `details.count` says how many |
| 422 | `SLOT_IN_PAST`, `BEYOND_BOOKING_HORIZON`, `DATE_CLOSED`, `DEPARTMENT_NOT_WORKING_DAY`, `DEPARTMENT_INACTIVE`, `NO_ACTIVE_DENTIST`, `SERVICE_INACTIVE` (booking) | Business rules forbid the booking |
| 422 | `WITHIN_24H_WINDOW` (booking) | Less than 24 hours before the start; patients and Telegram can never bypass it, an admin only with `override: true` + reason |
| 422 | `APPOINTMENT_NOT_STARTED` | Completed / no-show can only be set after the appointment has started |
| 429 | `RATE_LIMITED`, `TOO_MANY_ATTEMPTS` | Slow down |
| 503 | `INTEGRATION_DISABLED` | No integration key configured |

## Using the API from the command line (examples)

```bash
# Center details and the seven departments (no login)
curl -s http://localhost:8480/api/v1/public/center?locale=en
curl -s http://localhost:8480/api/v1/public/departments?locale=en

# Availability for one department
curl -s "http://localhost:8480/api/v1/public/departments/orthodontics/availability?from=2026-11-02&to=2026-11-08"

# n8n-style call (replace the key; never paste a real key into a chat or ticket)
curl -s -H "Authorization: Bearer $INTEGRATION_API_KEY" \
  "http://localhost:8480/api/v1/integrations/availability?department=orthodontics&from=2026-11-02&to=2026-11-08"
```

Browser-side calls (login, booking, admin) need the cookie and the CSRF header; the quickest working reference is
`scripts/smoke-api.mjs`, which logs in as a new patient, books, reschedules and cancels through the same HTTP calls.
