# Architecture

Status: **as built.** This document describes the system that exists in this folder. What was actually run, and what was only
written, is separated in `PROJECT_STATUS.md` (and §10 below). Detailed rules live in their own documents: `BOOKING_RULES.md`,
`DATABASE.md`, `API.md`, `SECURITY.md`, `FRONTEND.md`, `N8N_INTEGRATION.md`, `DEPLOYMENT.md`.

## 1. Topology

```
                         Browser (patient / admin)                    Existing n8n  <──  Telegram
                                   │                                       │
                                   ▼                                       │ HTTPS + Bearer key
                      ┌─────────────────────────┐                          │
                      │  web  (nginx, port 8080 │                          │
                      │  in the container)      │                          │
                      │   /        patient SPA  │                          │
                      │   /admin/  admin SPA    │                          │
                      │   /api/    ──proxy──┐   │                          │
                      └─────────────────────┼───┘                          │
                                            ▼                              │
                      ┌─────────────────────────────────────────────┐      │
                      │  backend (Fastify 5, Node 22, TypeScript)   │◄─────┘
                      │  /api/v1/public  /patient  /admin           │
                      │  /api/v1/integrations                       │
                      └──────────────────────┬──────────────────────┘
                                             │ SQL (pg, parameterized)
                                             ▼
                      ┌─────────────────────────────────────────────┐
                      │  db  (PostgreSQL 16, dedicated volume)      │
                      │  internal network only, no published port   │
                      └─────────────────────────────────────────────┘
```

Compose project `dental-center`, network `dental_center_net`, volume `dental_center_pgdata` (names never shared with the old
dental-clinic-dashboard project).

| Service | Kind | Purpose |
|---|---|---|
| `db` | long-running | PostgreSQL 16, health-checked, no published port |
| `migrate` | one-shot job | applies the forward-only SQL migrations, then exits; `backend` starts only after it completed |
| `backend` | long-running | the API; **not published** to the host (`expose` only), reached through `web` |
| `web` | long-running | nginx (unprivileged image) serving both apps and proxying `/api/`; the **only** published port, bound to `127.0.0.1:8480` by default (`WEB_BIND`/`WEB_PORT`) |
| `bootstrap-admin`, `reset-admin-password` | tools (`--profile tools`, run on demand) | create the first administrator; recover a locked-out one |

No n8n container: the existing n8n is reused and talks to the integration routes.

## 2. Key decisions

| # | Decision | Why |
|---|---|---|
| A1 | **Single origin**: nginx serves both SPAs and proxies `/api/` to the backend. nginx is the **only** owner of the security and cache headers (`proxy-api.conf` removes the backend's own copies). | Cookies are first-party, no CORS surface, CSRF reasoning is simple, and the browser never sees repeated or conflicting headers. Both UIs stay separate apps with separate bundles, routes and session cookies. |
| A2 | **Fastify 5 + TypeScript + zod 4** | Fast, schema-first validation, OpenAPI generated from the same schemas (a test fails if `docs/openapi.json` drifts). |
| A3 | **`pg` with hand-written parameterized SQL**, no ORM | Booking correctness depends on exact transaction, locking and constraint behavior. SQL is explicit and reviewable. |
| A4 | **Forward-only SQL migrations** in `database/migrations/` with a small runner (`schema_migrations` table, checksum, advisory lock) | No framework lock-in, safe to re-run, an applied file can never be silently edited. |
| A5 | **Server-side sessions in PostgreSQL** with opaque random tokens (only the SHA-256 is stored) | Immediate revocation (password reset, logout, link revoke), no JWT pitfalls. Expired sessions are pruned every 6 hours. |
| A6 | **Argon2id** (19 MiB, t = 2, p = 1) | Modern default per the spec. |
| A7 | **CSRF**: `SameSite=Lax` HttpOnly cookie + `Origin` check against `PUBLIC_APP_URL`/`ALLOWED_ORIGINS` + a per-session token in `X-CSRF-Token` on every state-changing request | Defense in depth. |
| A8 | **Rate limiting** with `@fastify/rate-limit` (per IP) plus a failed-attempt limiter per account (`middleware/attempt-limiter.ts`); both in memory | Adequate for one backend instance. Counters reset on restart and are not shared across replicas (a documented limitation). Values: `API.md`. |
| A9 | **React 19 + React Router 7 + Vite + TypeScript, one package, two SPAs**; own typed message catalogs (`defineMessages`), no i18n library | A missing translation is a compile error; see `FRONTEND.md`. |
| A10 | **The backend is the only place business rules live.** n8n calls the same service functions as the website through a narrower route group | Prevents rule drift between web, admin and Telegram. |
| A11 | **Center profile in the database**, one row, served by `GET /api/v1/public/center` and the integration equivalent | Single source of truth for address/contact. The assistant fetches it per conversation instead of embedding it in a prompt. |
| A12 | **Time**: `timestamptz` everywhere; the business day is the Cairo local date of the slot start; all conversions through IANA `Africa/Cairo` | See §4 for midnight and DST handling. |
| A13 | **Working days are data, not code**: the center has `working_days` and every department has its own; the effective set is the intersection | The administrator can change them in the dashboard and availability, booking, the website and Telegram all follow. |

## 3. Backend layout

```
backend/src/
  config/env.ts        environment parsing (zod); blank values mean "not set"; production fails fast on missing/invalid values
  database/            pool + transaction helper, migration runner, seed runner
  middleware/          attempt-limiter.ts (failed-login throttle per account)
  lib/                 clock, crypto (hashing, tokens, constant-time compare), errors (the error-code catalogue), locale
                       (content fallback chain), phone normalization, request-locale, routes (route helpers; CSRF/auth guards),
                       time (slot and DST arithmetic), translations, validation, openapi
  modules/
    auth/              patient + admin login, logout, sessions, password change, bootstrap and admin password reset
    patients/          profile, admin patient management, staff-assisted password reset
    center/            center profile + settings (including the center working days)
    departments/       departments, translations, working days
    services/  dentists/
    scheduling/        availability, `slotUnavailableReason` (the single source of truth for "can this slot be booked?")
    appointments/      booking, cancel, reschedule, status lifecycle (the only writer of `appointments`)
    medical-records/   admin-only
    gallery/           before/after cases (consent-gated publishing)
    audit/             append-only writer + admin reader
    integrations/      n8n routes, Telegram linking
    public/            the unauthenticated read routes (center, departments, services, availability)
    admin/             the dashboard's appointment, catalog and settings routes
  cli/                 migrate, seed, bootstrap-admin, reset-admin-password, openapi (generation)
  app.ts               builds the Fastify instance (used by the tests)
  server.ts            process entry, graceful shutdown, session pruning
```

Rule: **only `modules/appointments` writes to `appointments`.** The website, the dashboard and n8n all call it.

## 4. Scheduling model

- `slot_templates` holds the four slots: `slot_number` 1..4, `start_time` (16:00, 18:00, 20:00, 22:00) and a fixed 120-minute
  duration. No `24:00` value is stored; the end is derived. The administrator can disable a slot.
- For a Cairo date `D` and slot `n`: `starts_at` = `D + start_time` interpreted in `Africa/Cairo`,
  `ends_at = starts_at + 2 hours` (an absolute instant). `appointment_date = D`.
- Capacity buckets use `appointment_date`, **never** `date(ends_at)`. That is how slot 4 stays on the day it starts even though
  it ends at 00:00 the next day. At most 4 active appointments per department per day.
- **Working days.** The center's `working_days` and the department's `working_days` (ISO 1 = Monday … 7 = Sunday) are
  intersected. A day outside the intersection is closed for that department: it is reported as such by the availability API,
  offered by no page and refused by the booking API (`DEPARTMENT_NOT_WORKING_DAY` for a department day off, `DATE_CLOSED` for a
  center closed weekday, closed date or disabled slot). `slotUnavailableReason` is the one function that decides, in this order:
  slot disabled, closed weekday, department day off, closed date, past (`SLOT_IN_PAST`), beyond the horizon
  (`BEYOND_BOOKING_HORIZON`), already booked (`SLOT_UNAVAILABLE`), department full for the day (`DAILY_CAPACITY_REACHED`).
- Booking transaction (READ COMMITTED):
  1. `pg_advisory_xact_lock` on `(department, date)` serializes bookers for that department-day.
  2. `SELECT … FROM departments … FOR SHARE`: an administrator changing the department's working days takes a conflicting
     `FOR UPDATE`, so a booking and a working-day change cannot interleave.
  3. Read the settings, closures and the day's active appointments, then call `slotUnavailableReason` and the patient-overlap check.
  4. `INSERT`. The database is the last line of defense: the partial unique index `appointments_active_slot_uq`, the exclusion
     constraints `appointments_no_department_overlap` and `appointments_no_patient_overlap`, and a status-guard trigger.
     A `23505`/`23P01` becomes `409 SLOT_UNAVAILABLE` / `409 PATIENT_OVERLAP`.
- Removing a department's working day while future appointments exist is refused with `409 WORKING_DAYS_HAVE_APPOINTMENTS`
  (with the count) unless the dashboard resends it acknowledged. Nothing is ever cancelled automatically.
- 24-hour rule: allowed iff `starts_at - now() >= 24 hours` (inclusive boundary), computed with absolute instants on the server
  (`SELF_SERVICE_NOTICE_MS` in `lib/time.ts`), so DST cannot distort it. Tests inject a clock. The same rule serves the website
  and Telegram; staff may override it with a reason, which is audited.
- **DST (Egypt observes DST; the clocks change at local midnight).** Checked against the tz data of the development machine:
  clocks went back Thu 29 Oct 2026 (24:00 → 23:00), so the offset is UTC+2 from Fri 30 Oct, and go forward on the night of
  Thu 29 Apr 2027 (24:00 → 01:00). On those two Thursdays the 22:00 slot still lasts exactly two real hours, so its wall-clock
  end label is not "12:00 AM" (11:00 PM on the fall-back night, 1:00 AM on the spring-forward night). The UI renders the `ends_at`
  the API sends, in the Cairo zone, instead of printing a fixed "12:00 AM". Decision D6 in `IMPLEMENTATION_PLAN.md`.

## 5. Authentication and sessions

- Two independent session kinds, two cookies: `dc_patient` (cookie path `/api/v1/patient`) and `dc_admin` (cookie path
  `/api/v1/admin`), distinguished by a `kind` column. A patient token can never authenticate an admin route and vice versa, and
  the browser does not even send one cookie to the other's routes.
- Cookies: `HttpOnly`, `SameSite=Lax`, `Secure` when `COOKIE_SECURE=true` (required behind HTTPS; set it to `false` only for a
  plain-HTTP local test). Lifetimes (env-configurable): patient 7 days absolute / 24 h idle; administrator 8 h / 30 min.
- Login errors are generic ("invalid phone or password"); failed-attempt throttling per IP and per account.
- Admin: the bootstrap command creates the first administrator from environment values, only if none exists, with
  `must_change_password = true`. A gate rejects every admin route except `change-password`, `me` and `logout` until the flag is
  cleared. A locked-out administrator is recovered with `reset-admin-password` (revokes their sessions, forces a change, audited).
- Staff-assisted patient recovery: an admin-only endpoint sets a new password supplied by the staff member at the desk after an
  identity check, revokes all of that patient's sessions, and writes an audit event (never the password).

## 6. Internationalization

- Interface texts (ar/en/fr) are compiled message catalogs in the frontend (`defineMessages({ en, ar, fr })`): a key missing in a
  language does not compile, and a test checks that no text is empty and the placeholders match.
- Content (departments, services, dentists, center profile, gallery alt text): `*_translations` tables keyed by
  `(entity_id, locale)`.
- Fallback chain for missing content (`lib/locale.ts`): requested locale → center `default_locale` → `en` → `ar` → `fr`.
  Internal keys are never returned to patients; if every language is empty the text is blank.
- `dir="rtl"` and `lang` are set on `<html>` per language; the CSS uses logical properties. Arabic shows Latin digits.

## 7. n8n integration boundary

- Route group `/api/v1/integrations/*`, authenticated by a bearer key compared in constant time against the SHA-256 of the
  configured key(s). Two key slots (`INTEGRATION_API_KEY`, optional `INTEGRATION_API_KEY_NEXT`) allow zero-downtime rotation.
  Without a configured key the group answers `503 INTEGRATION_DISABLED`. nginx can additionally restrict it to the n8n host
  (`integrations-access.conf`).
- Anonymous-safe operations: center profile, departments (with working days)/services/dentists, availability.
- Personal operations (my appointments, book, cancel, reschedule) require a `telegram_user_id` that resolves to a non-revoked
  `telegram_links` row. Unlinked users get `403 TELEGRAM_NOT_LINKED`.
- Linking: the patient (signed in on the website) requests a code → shown once → sent to the bot → n8n redeems it with the
  Telegram user ID → single use, 10-minute lifetime, stored hashed. A Telegram account links to at most one patient; a new link
  replaces the old one; the patient or an administrator can revoke it.
- Linking and revocation are audited with actor `integration`; appointment changes made through Telegram go through the same
  service as the website and are audited like any other (actor `integration`/`n8n`). Plain reads are not audited.

## 8. Configuration

- Environment (`.env`) holds secrets and deployment settings only (database, ports, cookie flags, public URL, time zone,
  bootstrap administrator, integration key, session lifetimes, rate limits). It is validated at startup with zod; blank values
  count as unset; production fails fast on missing or invalid values. `.env` is never committed; `.env.example` has placeholders.
- Business-editable settings (address, phone, default language, center working days, booking horizon, currency, slots, closed
  dates) live in the database and are edited in the dashboard.

## 9. Ports and naming (defaults, all overridable)

| Item | Default | Notes |
|---|---|---|
| Compose project name | `dental-center` | `name:` in `docker-compose.yml`, never shared with the old project |
| DB volume | `dental_center_pgdata` | unique name |
| Web (nginx) | `127.0.0.1:8480` → container 8080 | `WEB_BIND` / `WEB_PORT`; check a free port with `Get-NetTCPConnection -State Listen \| Where-Object LocalPort -eq 8480` |
| Backend | container port 3480, **not published** | reached only through `web` on the internal network |
| PostgreSQL | none | internal network only |

## 10. What this environment can and cannot verify

The development sandbox has Node 22, npm, PostgreSQL 16 server binaries, nginx and Chromium, and a Docker **CLI without a
usable daemon** (Docker Hub and the Docker download site are blocked there). So these were genuinely executed: the backend, SQL,
concurrency, authentication, backup/restore with `pg_dump`/`pg_restore`, the frontend, the n8n workflows, and the browser tests,
which run the real backend behind the **real web-container nginx configuration** against a fresh database
(`scripts/e2e-local.sh`). These were **not**: Docker image builds, container health checks, volume persistence across
`docker compose down`/`up`, the `nginx-unprivileged` runtime, any PowerShell script, real Telegram. They are written, statically
validated (`docker compose config`), and shipped with `scripts/verify-docker.ps1` for the user's machine. Nothing Docker-related
is reported as passed unless it actually ran; the full list is in `PROJECT_STATUS.md` §3.
