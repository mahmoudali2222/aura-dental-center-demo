# Image assets

The system does **not** have an upload screen. Pictures are ordinary files you copy into a project folder; the dashboard stores
only the **path** of each picture. That keeps image handling simple and keeps business logic free of file handling.

**Only the pictures the center supplied are shipped:** the seven department before/after pictures (`departments/`) and the patient
precautions picture (`info/`). Everything else (logo, hero video, dentist photos, services, gallery cases) is still empty, and the page then
simply shows nothing there: a missing file is never replaced by a stock photo, and a placeholder is never shown as a real clinical case.

## Folders

| Folder (in the project) | Served at | Used for |
|---|---|---|
| `frontend/public/assets/branding/` | `/assets/branding/…` | The official **logo** and the hero **video** (and its poster). **Empty: not supplied yet.** The patient site already has places for them (`FRONTEND.md`, "Places kept ready"): set the path in `frontend/src/patient/config.ts` and nothing else changes. |
| `frontend/public/assets/departments/` | `/assets/departments/…` | Department pictures **and** dentist photos |
| `frontend/public/assets/info/` | `/assets/info/…` | Patient information pictures. Holds `patient-precautions.jpg` (Arabic/English "Important patient precautions before the procedure"), shown in the booking flow and in My appointments. |
| `frontend/public/assets/services/` | `/assets/services/…` | Service pictures (see the note below the manifest) |
| `frontend/public/assets/gallery/` | `/assets/gallery/…` | Before/after pictures of the gallery |

In Docker the folder `frontend/public/assets` is mounted into the web container read-only, so **a new or replaced file is
served immediately, without rebuilding anything**. (Pictures are cached for up to one hour by browsers; press Ctrl+F5.)

## Manifest

Filenames are only a **recommendation**: any file name works as long as the path you type in the dashboard matches the file. Use
lowercase letters, digits, `.`, `_`, `-` (no spaces, no Arabic letters in file names). The dashboard accepts only paths of the form
`/assets/<folder>/<file>` and refuses anything else.

| Image | Recommended file | Where you set the path | Shown on | Optional? | Format and size |
|---|---|---|---|---|---|
| Restorative Dentistry picture | `departments/restorative-dentistry-before-after.jpg` **(supplied)** | Departments & dentists → the department → Image (already set by the sample catalog when the department was created) | Home "Treatment results" strip, the department page "Treatment example" | yes | The supplied file is a single before/after picture with its own header and caption (about 400 × 420 px, 1230 × 358 for Prosthodontics). It is shown **at its own size, uncropped**; a replacement should be at least 800 px wide (it is never enlarged, so a larger file looks sharper). JPG or WebP, ≤ 300 KB |
| Endodontics picture | `departments/endodontics-before-after.jpg` **(supplied)** | same | same | yes | same |
| Orthodontics picture | `departments/orthodontics-before-after.jpg` **(supplied)** | same | same | yes | same |
| Periodontics picture | `departments/periodontics-before-after.jpg` **(supplied)** (its own header reads "Periodontology") | same | same | yes | same |
| Pediatric Dentistry picture | `departments/pediatric-dentistry-before-after.jpg` **(supplied)** | same | same | yes | same |
| Prosthodontics picture | `departments/prosthodontics-before-after.jpg` **(supplied, wide format)** | same | same | yes | same |
| Oral Surgery picture | `departments/oral-surgery-before-after.jpg` **(supplied)** | same | same | yes | same |
| Patient precautions picture | `info/patient-precautions.jpg` **(supplied)** | Not a dashboard setting: the path is in `frontend/src/patient/config.ts` | Booking page (confirm step), the confirmation, My appointments → "Before your visit" | no (the page works without it, but it is part of the patient journey) | 1048 × 1008 px, shown uncropped up to 34 rem wide; the text is also written out for screen readers and French readers |
| A dentist's photo | `departments/<department-slug>-dentist.jpg` | Departments & dentists → the department's dentist → Photo | Department page (shown as a 72 px circle) | yes | JPG or WebP, 400 × 400 px (square), ≤ 100 KB |
| Gallery "before" picture of a case | `gallery/<case>-before.jpg` | Gallery → the case → Before | Department page, before/after section | yes (a case needs both pictures) | JPG or WebP, 1200 × 900 px (4:3), ≤ 300 KB; **same size and framing as the "after"** |
| Gallery "after" picture of a case | `gallery/<case>-after.jpg` | Gallery → the case → After | same | yes | same |
| A service picture | `services/<service>.jpg` | Services → the service → Image | Stored and returned by the API, **not displayed by the current pages** (reserved; the current design does not show service pictures) | yes | JPG or WebP, 800 × 600 px (4:3), ≤ 200 KB |
| Official logo | `branding/logo.svg` | `frontend/src/patient/config.ts` → `logo` (**not supplied yet**; none was drawn or substituted) | Header and footer, instead of the plain-text name (the name stays for screen readers if the picture contains it) | yes | SVG (or PNG ≥ 2× the displayed height of 2.4 rem) |
| Hero background video | `branding/hero.mp4` (+ `branding/hero-poster.jpg`) | `frontend/src/patient/config.ts` → `heroVideo` (**not supplied yet**) | Behind the home page hero, muted and looped | yes | MP4 (H.264), ≤ 8 MB, muted track not needed; a poster JPG/WebP shown before it plays and to visitors who prefer reduced motion |
| Favicon | `branding/favicon.svg` | Not wired | — | yes | SVG |

Everything is optional. A department without a picture shows its name and description only.

## About the supplied department pictures

They are **department pictures** (one per department), not gallery cases, so the gallery's consent gate does not apply to them. They are
published as supplied, with their own English captions. Before going live, confirm that they are illustrations or that the people in them
agreed to publication. If any picture should not be public, clear its **Image** field in the dashboard and it disappears from the site.

## How to replace a placeholder with your real image

1. Copy the file into the right folder, for example `frontend/public/assets/departments/endodontics.jpg`.
2. Open the dashboard → **Departments & dentists** → Endodontics → Edit.
3. In **Image** type exactly `/assets/departments/endodontics.jpg` → Save.
4. Open the website (Ctrl+F5). Done. To remove the picture, clear the field and save.

To swap a picture for another one keep the same file name and overwrite the file (wait up to an hour or press Ctrl+F5 to bypass the
cache), or use a new name and update the path.

On a VPS the same applies on the server: copy the files into `frontend/public/assets/…` in the project folder there.

## Rules for gallery pictures (consent and honesty)

- A gallery case is either **real** or **sample** (`caseKind`). Sample cases are always labelled as samples by the API and the site.
- A **real** case cannot be published until patient consent is recorded in the dashboard; the database enforces this too.
- Only publish photographs of real patients with their written consent; remove identifying details (face, name tags) where possible.
- Alt texts (what a screen reader says) are entered per language in the same form. Describe the picture, do not repeat the title.

## If a picture does not show

See `TROUBLESHOOTING.md` ("My picture does not appear"): wrong path, file not in `frontend/public/assets/...`, or browser cache.
A saved path to a file that does not exist is hidden silently by the page (no broken-image icon), which is intended.
