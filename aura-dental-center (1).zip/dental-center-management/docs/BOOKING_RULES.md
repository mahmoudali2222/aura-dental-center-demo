# Booking rules

Every rule here is enforced **by the backend** (`backend/src/modules/appointments`, `backend/src/modules/scheduling`) and by
PostgreSQL constraints. The website, the admin dashboard and the Telegram/n8n integration call the same functions, so the
rules cannot drift between channels. The browser and n8n only display what the backend says.

## 1. The calendar

| Rule | Value |
|---|---|
| Time zone | `Africa/Cairo` (`CENTER_TIMEZONE`) |
| Opening hours | 4:00 PM – 12:00 AM (16:00–24:00) |
| Slots | Four, each exactly **2 real hours**: 1 = 16:00–18:00, 2 = 18:00–20:00, 3 = 20:00–22:00, 4 = 22:00–00:00 |
| Capacity | At most **4 active appointments per department per calendar day** (one per slot). The limit is per department, not for the whole center. |
| Which day a slot belongs to | The day on which it **starts**. Slot 4 (22:00–00:00) belongs to the day it starts, although it ends at midnight. |
| Active statuses | `booked`, `completed`, `no_show` keep their slot. `cancelled` releases the slot and the capacity at once. |
| Booking horizon | Configurable (`center_profile.booking_horizon_days`, default 60 days). |

Daylight-saving time: Egypt moves its clocks at local midnight. On the two transition nights the 22:00 slot still lasts
two real hours, so its wall-clock end shows as 11:00 PM or 1:00 AM instead of 12:00 AM; the screens print the real end time
the backend sends instead of a fixed "12:00 AM". The clocks went back on Thursday 29 October 2026 (24:00 → 23:00), so
from Friday 30 October 2026 the center is on UTC+2 until the next spring change on the night of Thursday 29 April 2027
(00:00 → 01:00). Both nights are covered by tests (BOOK-16). Dates were checked against the tz database on the development
machine; Egyptian DST rules can be changed by the government, so keep the server's tz data (the Docker images' base
packages) up to date.

## 2. Working days (configured in the Admin Dashboard)

A date is bookable in a department only when **all** of these hold, checked in this order by the single function
`slotUnavailableReason` (`scheduling.service.ts`):

1. the slot itself is enabled (`slot_templates.is_active`);
2. the weekday is a working day of the **center** (Settings → Center → working days);
3. the weekday is a working day of the **department** (Departments → edit → working days);
4. the date is not inside a **closure** (center-wide or for that department);
5. the slot has not started yet (no booking in the past);
6. the date is within the booking horizon;
7. the slot is not already taken by an active appointment;
8. the department has fewer than four active appointments that day.

The effective working days of a department are therefore **the center's working days ∩ the department's working days**.
Weekdays are ISO numbers (1 = Monday … 7 = Sunday); the admin screens show them as names in the chosen language.

What a patient sees follows from the same function:

| Situation | Availability `status` | Booking attempt |
|---|---|---|
| Department does not work that weekday | `closed` (no slots) | `422 DEPARTMENT_NOT_WORKING_DAY` |
| Center does not work that weekday, or closure, or slot disabled | `closed` | `422 DATE_CLOSED` |
| Slot already started / date passed | `past` | `422 SLOT_IN_PAST` |
| Beyond the horizon | `beyond_horizon` | `422 BEYOND_BOOKING_HORIZON` |
| Slot taken | not listed | `409 SLOT_UNAVAILABLE` |
| Four already booked | `full` | `409 DAILY_CAPACITY_REACHED` |
| Department has no active dentist | `unavailable` | `422 NO_ACTIVE_DENTIST` |

The booking page (website) only offers open days; the department page shows "Works every day" or "Works: Mon, Wed, Fri";
the Telegram `/departments` command shows `(works: Mon, Wed, Fri)` for departments that do not work every day. If someone
still sends a request for a closed day (an old tab, a script), the server refuses it with the codes above.

### Changing working days safely

- **Rules for the days list:** at least one day (`AT_LEAST_ONE_WORKING_DAY`), only values 1–7 (`INVALID_WEEKDAY`).
- **Existing appointments are never cancelled automatically.** They stay valid and visible; the administrator handles them
  one by one (cancel with a reason, or reschedule to a working day).
- **Removing a weekday that still has future `booked` appointments** is refused with `409 WORKING_DAYS_HAVE_APPOINTMENTS`
  and `details.count`. The dashboard shows how many and asks for confirmation; confirming resends the change with
  `acknowledgeExistingAppointments: true`. Only appointments that have not ended yet are counted.
- **Race safety:** the department update takes `SELECT ... FOR UPDATE` on the department row and every booking or
  reschedule takes `FOR SHARE` on it, so a booking can never slip onto a day that is being switched off, and the count shown
  to the administrator is exact.
- Adding a day takes effect immediately; slots appear on the website at once.
- A new department starts with all seven days; the administrator unticks the days it does not work.
- Every change is audited (`department.updated` with the new days and the number of appointments that fall on removed days; no personal data).

Known limitation (honest note): changing the **center-wide** working days (Settings → Center) is applied immediately without
the acknowledgement step and without the row lock described above. Existing appointments are untouched, but a booking
that is being created at the very same instant the center-wide change is saved could still land on a day that has just
been switched off. The window is milliseconds and only matters if an administrator edits the center days while patients
are booking; closures (which do have the acknowledgement step) are the recommended tool for one-off closed days.

## 3. Booking sequence (one transaction)

`createAppointment` (used by the website, admin and Telegram):

1. `SELECT ... FROM departments ... FOR SHARE`; the department must exist and be active (`DEPARTMENT_INACTIVE`).
2. The department must have an active dentist (`NO_ACTIVE_DENTIST`). The appointment stores that dentist.
3. If a service is given it must belong to the department and be active (`SERVICE_NOT_IN_DEPARTMENT`, `SERVICE_INACTIVE`).
4. The patient must exist and be active (`PATIENT_NOT_FOUND`, `ACCOUNT_DISABLED`).
5. `pg_advisory_xact_lock(hash('appointments:<department>:<date>'))` serialises everyone working on that department-day.
6. Re-read the settings, closures and booked slots **inside the transaction** and apply `slotUnavailableReason`.
7. `INSERT`. The database is the last line of defence: the unique index `appointments_active_slot_uq` and the two overlap
   constraints turn a lost race into `409 SLOT_UNAVAILABLE` / `409 PATIENT_OVERLAP`, never into a duplicate row.
8. An audit event `appointment.created` is written in the same transaction (ids, date, slot, channel; no clinical data).

The response is sent only after COMMIT, so "booked" is never reported for an appointment that was not stored (this matters
for the Telegram assistant: it may only confirm a booking after a `201` from this endpoint).

Proven by tests that run against real PostgreSQL: 24 simultaneous requests for one slot → exactly one succeeds and the other
23 get `SLOT_UNAVAILABLE`; 24 requests spread over the four slots → exactly four succeed; the last free slot of a nearly full
day goes to exactly one of many competitors; parallel cancel + book and parallel reschedules into one slot leave a consistent
state; one patient booking two departments at the same time slot at once gets exactly one booking; eight simultaneous bookings
racing with an unconfirmed switch-off of that weekday (six rounds) always end either with the days unchanged and the
bookings stored, or with the days changed and **no** booking on that day.

## 4. Cancelling and rescheduling

| Actor | Rule |
|---|---|
| Patient (website) | Only own appointments (another patient's id answers 404), only while at least **24 hours** remain before the start. |
| Patient via Telegram/n8n | Exactly the same code path and the same 24-hour rule. |
| Administrator | Same rule, but inside the 24-hour window may proceed with `override: true` **and** a written reason (≥ 3 characters). The override and reason are audited. |

- The 24-hour rule is computed with absolute instants on the server clock: `starts_at − now ≥ 24 h` (the boundary is inclusive:
  exactly 24:00:00 is allowed, 23:59:59 is refused with `422 WITHIN_24H_WINDOW`). Daylight-saving changes cannot distort it.
- For a reschedule the rule is measured against the **original** start time. The new slot must pass every check in §2
  (including the department's working days) and must be in the **same department**. `RESCHEDULE_NO_CHANGE` if it is the same slot.
- Cancelling is always possible for a `booked` appointment outside the 24-hour window, even if its weekday is no longer a
  working day; rescheduling needs a target that is bookable now.
- Only `booked` appointments can be cancelled or rescheduled (`APPOINTMENT_NOT_ACTIVE` otherwise).
- Every appointment DTO carries `selfService { canCancel, canReschedule, deadline, blockedReason }` computed by the backend,
  so the screens and the bot show the same deadline and never decide by themselves.

## 5. Status lifecycle

```
booked ──► cancelled          (terminal; releases the slot)
   │
   ├────► completed           (terminal)
   └────► no_show ──► completed   (admin correction)
```

`completed` and `no_show` can be set by an administrator only after the appointment has started
(`422 APPOINTMENT_NOT_STARTED`). A database trigger rejects every other transition, so a raw SQL update cannot corrupt history.
Completed and no-show appointments keep their slot on their own date and do not affect any other date.

## 6. One patient, one place at a time

A patient cannot hold two overlapping active appointments, even in different departments
(`409 PATIENT_OVERLAP`; database constraint `appointments_no_patient_overlap`). This is a decision of this implementation
(not stated in the specification): a person cannot attend two 2-hour slots at once.

## 7. Patient account rules (booking depends on them)

- Registration needs **phone + password (+ full name) only**. No OTP, SMS or verification: phone ownership is not verified
  (documented limitation in `SECURITY.md`).
- Passwords cannot be recovered by the patient alone. A staff member resets the password in person from the patient's page
  in the dashboard; the old password stops working and all of the patient's sessions are revoked.
- A disabled patient cannot book (`ACCOUNT_DISABLED`).

## 8. Where each rule is tested

| Rule | Test file (all run against a real PostgreSQL) |
|---|---|
| Slots, capacity, midnight, DST nights (29 Oct 2026 and 29 Apr 2027), past, horizon, overlap, cancel releases, 24-hour boundary | `backend/tests/integration/booking.test.ts` |
| Parallel bookings and cancel/book races | `backend/tests/integration/concurrency.test.ts` |
| Department working days: validation, availability, booking from web/admin/Telegram, reschedule, center ∩ department, closures, acknowledgement, race | `backend/tests/integration/department-working-days.test.ts` |
| Same rules through the integration API | `backend/tests/integration/integration-api.test.ts`, `n8n-e2e.test.ts` |
| Pure time math (24 h boundary, slot windows, DST) | `backend/tests/unit/time.test.ts` |
| Booking and working-days journeys in a real browser | `e2e/tests/01-patient-journey.spec.ts`, `03-working-days.spec.ts` |
