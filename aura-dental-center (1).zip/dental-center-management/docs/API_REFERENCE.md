# API reference (generated)

> Generated from the route declarations by `npm run openapi`. Do not edit by hand; edit the code and regenerate.
> The machine-readable version is [`openapi.json`](./openapi.json). Conventions are explained in [API.md](./API.md).

## Admin auth

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| POST | `/api/v1/admin/auth/change-password` | admin session (password change allowed) | Change the admin password (mandatory after first login). Clears the forced-change flag and revokes other sessions. | `INVALID_CREDENTIALS`, `PASSWORD_TOO_SHORT`, `PASSWORD_TOO_WEAK`, `PASSWORD_UNCHANGED` |
| POST | `/api/v1/admin/auth/login` | none | Admin sign in. If `mustChangePassword` is true, only change-password, me and logout are allowed until it is done. | `VALIDATION_ERROR`, `INVALID_CREDENTIALS`, `TOO_MANY_ATTEMPTS`, `RATE_LIMITED` |
| POST | `/api/v1/admin/auth/logout` | admin session (password change allowed) | Sign out of the dashboard. |  |
| GET | `/api/v1/admin/auth/me` | admin session (password change allowed) | Current admin and CSRF token (also usable while a password change is pending). |  |

## Admin: appointments

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/appointments` | admin session | List/filter appointments (date range, department, status, patient, free-text on patient name/phone). |  |
| POST | `/api/v1/admin/appointments` | admin session | Book on behalf of a patient. Slot, capacity, closure and past-time rules still apply (no override exists for them). | `PATIENT_NOT_FOUND`, `SLOT_UNAVAILABLE`, `DAILY_CAPACITY_REACHED`, `SLOT_IN_PAST`, `DATE_CLOSED`, `DEPARTMENT_NOT_WORKING_DAY`, `BEYOND_BOOKING_HORIZON`, `PATIENT_OVERLAP`, `DEPARTMENT_NOT_FOUND`, `NO_ACTIVE_DENTIST` |
| GET | `/api/v1/admin/appointments/:id` | admin session | One appointment with patient details. | `APPOINTMENT_NOT_FOUND` |
| POST | `/api/v1/admin/appointments/:id/cancel` | admin session | Cancel. Inside the 24-hour window an explicit `override: true` and a reason are required; both are audited. | `APPOINTMENT_NOT_FOUND`, `APPOINTMENT_NOT_ACTIVE`, `WITHIN_24H_WINDOW`, `OVERRIDE_REASON_REQUIRED` |
| POST | `/api/v1/admin/appointments/:id/reschedule` | admin session | Move an appointment to another slot of the same department. Override rules as for cancel. | `APPOINTMENT_NOT_FOUND`, `APPOINTMENT_NOT_ACTIVE`, `WITHIN_24H_WINDOW`, `OVERRIDE_REASON_REQUIRED`, `SLOT_UNAVAILABLE`, `DAILY_CAPACITY_REACHED`, `SLOT_IN_PAST`, `DATE_CLOSED`, `DEPARTMENT_NOT_WORKING_DAY`, `RESCHEDULE_NO_CHANGE` |
| POST | `/api/v1/admin/appointments/:id/status` | admin session | Mark an appointment completed or no-show (only after it has started). Cancellation has its own endpoint. | `APPOINTMENT_NOT_FOUND`, `INVALID_STATUS_TRANSITION`, `APPOINTMENT_NOT_STARTED` |

## Admin: audit

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/audit-events` | admin session | Browse the append-only audit log (newest first). Read-only: there is no write or delete endpoint. |  |

## Admin: dashboard

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/dashboard` | admin session | Today's appointments, status counts, per-department load (x of 4) and the next 7 days at a glance. |  |

## Admin: dentists

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/dentists` | admin session | All dentists (active and historical). |  |
| POST | `/api/v1/admin/dentists` | admin session | Assign a dentist to a department. If one is active, pass replaceExisting: true to deactivate them (kept for history). Dentists have no login. | `DEPARTMENT_NOT_FOUND`, `DEPARTMENT_HAS_DENTIST`, `AT_LEAST_ONE_TRANSLATION` |
| GET | `/api/v1/admin/dentists/:id` | admin session | One dentist. | `DENTIST_NOT_FOUND` |
| PATCH | `/api/v1/admin/dentists/:id` | admin session | Edit a dentist's display information, or deactivate them. | `DENTIST_NOT_FOUND`, `DEPARTMENT_HAS_DENTIST`, `AT_LEAST_ONE_TRANSLATION` |

## Admin: departments

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/departments` | admin session | All departments (including inactive) with all translations. |  |
| POST | `/api/v1/admin/departments` | admin session | Add a department. Needs a unique slug and at least one language. Working days default to every day. Assign its dentist afterwards. | `SLUG_TAKEN`, `AT_LEAST_ONE_TRANSLATION`, `AT_LEAST_ONE_WORKING_DAY` |
| GET | `/api/v1/admin/departments/:id` | admin session | One department. | `DEPARTMENT_NOT_FOUND` |
| PATCH | `/api/v1/admin/departments/:id` | admin session | Edit a department. Per language: a non-empty name saves/updates it, an empty name removes that language. Deactivate instead of deleting. Working days control which weekdays patients can book in this department (together with the center's own working days). Removing a weekday on which booked, unfinished appointments exist is refused with WORKING_DAYS_HAVE_APPOINTMENTS (details.count) until repeated with acknowledgeExistingAppointments; those appointments are never cancelled automatically. | `DEPARTMENT_NOT_FOUND`, `SLUG_TAKEN`, `AT_LEAST_ONE_TRANSLATION`, `AT_LEAST_ONE_WORKING_DAY`, `WORKING_DAYS_HAVE_APPOINTMENTS` |

## Admin: gallery

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/gallery` | admin session | All before/after cases including unpublished. |  |
| POST | `/api/v1/admin/gallery` | admin session | Add a case. `real` cases can be published only after consent is confirmed; `sample` placeholders are always labelled as samples on the website. | `DEPARTMENT_NOT_FOUND`, `CONSENT_REQUIRED` |
| DELETE | `/api/v1/admin/gallery/:id` | admin session | Remove a case. | `GALLERY_CASE_NOT_FOUND` |
| PATCH | `/api/v1/admin/gallery/:id` | admin session | Edit/publish/unpublish a case. | `GALLERY_CASE_NOT_FOUND`, `CONSENT_REQUIRED` |

## Admin: medical records

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/medical-records/:id` | admin session | One medical record (audited as a view). | `MEDICAL_RECORD_NOT_FOUND` |
| PATCH | `/api/v1/admin/medical-records/:id` | admin session | Update a medical record. Records are never deleted; corrections are updates (who/when kept in updatedBy/updatedAt and the audit log). | `MEDICAL_RECORD_NOT_FOUND`, `APPOINTMENT_NOT_FOR_PATIENT` |
| GET | `/api/v1/admin/patients/:patientId/medical-records` | admin session | All medical records of a patient, newest first. Admin only; the access is audited. | `PATIENT_NOT_FOUND` |
| POST | `/api/v1/admin/patients/:patientId/medical-records` | admin session | Create a medical record (history, allergies, diagnosis, treatment, notes). At least one field must have content. | `PATIENT_NOT_FOUND`, `APPOINTMENT_NOT_FOR_PATIENT` |

## Admin: patients

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/patients` | admin session | Search patients by name or phone. |  |
| POST | `/api/v1/admin/patients` | admin session | Create a patient account at the front desk (e.g. a walk-in who then books). | `INVALID_PHONE`, `PHONE_ALREADY_REGISTERED`, `PASSWORD_TOO_SHORT` |
| GET | `/api/v1/admin/patients/:id` | admin session | Patient details (never includes the password hash). | `PATIENT_NOT_FOUND` |
| PATCH | `/api/v1/admin/patients/:id` | admin session | Edit name, phone, language, or activate/deactivate an account. Deactivation revokes all sessions. | `PATIENT_NOT_FOUND`, `INVALID_PHONE`, `PHONE_ALREADY_REGISTERED` |
| POST | `/api/v1/admin/patients/:id/reset-password` | admin session | Staff-assisted password recovery. The admin must confirm the patient's identity in person (identityVerified: true). All the patient's sessions are revoked; the action is audited without the password. | `PATIENT_NOT_FOUND`, `IDENTITY_CONFIRMATION_REQUIRED`, `PASSWORD_TOO_SHORT`, `PASSWORD_TOO_WEAK` |
| POST | `/api/v1/admin/patients/:id/telegram/revoke` | admin session | Unlink a patient's Telegram account. |  |

## Admin: services

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/services` | admin session | All services, optionally of one department. |  |
| POST | `/api/v1/admin/services` | admin session | Add a service to a department. Price is optional (null = not shown). | `DEPARTMENT_NOT_FOUND`, `AT_LEAST_ONE_TRANSLATION` |
| GET | `/api/v1/admin/services/:id` | admin session | One service. | `SERVICE_NOT_FOUND` |
| PATCH | `/api/v1/admin/services/:id` | admin session | Edit a service (deactivate instead of deleting; past appointments keep referencing it). | `SERVICE_NOT_FOUND`, `DEPARTMENT_NOT_FOUND`, `AT_LEAST_ONE_TRANSLATION` |

## Admin: settings

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/admin/closures` | admin session | Closed dates (whole center when departmentId is null). |  |
| POST | `/api/v1/admin/closures` | admin session | Close a date range (whole center, or one department). If active appointments already exist in it, the request is refused until acknowledged: those appointments are NOT cancelled automatically. | `INVALID_RANGE`, `CLOSURE_HAS_APPOINTMENTS`, `DEPARTMENT_NOT_FOUND` |
| DELETE | `/api/v1/admin/closures/:id` | admin session | Reopen a closed range. | `CLOSURE_NOT_FOUND` |
| GET | `/api/v1/admin/settings/center` | admin session | Center profile with every translation (single source of truth for address/contact). |  |
| PUT | `/api/v1/admin/settings/center` | admin session | Update the center profile. Only the fields you send change. Per-language text accepts empty strings (e.g. to clear an address). |  |
| GET | `/api/v1/admin/settings/slots` | admin session | The four daily two-hour slots (4 PM - 12 AM, Africa/Cairo). |  |
| PATCH | `/api/v1/admin/settings/slots/:slotNumber` | admin session | Enable/disable a slot. Existing appointments are untouched; start times and the 2-hour length are fixed by design. | `AT_LEAST_ONE_SLOT` |

## Integration (n8n)

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/integrations/availability` | integration key | Bookable slots for a department (same rules and data as the website). | `DEPARTMENT_NOT_FOUND`, `INVALID_RANGE`, `RANGE_TOO_LARGE` |
| GET | `/api/v1/integrations/center` | integration key | Center details (address, contact, hours). The assistant must read these from here, never from its prompt. |  |
| GET | `/api/v1/integrations/departments` | integration key | Active departments with dentist. |  |
| GET | `/api/v1/integrations/departments/:slug` | integration key | Department with services, dentist and prices (when configured). | `DEPARTMENT_NOT_FOUND` |
| GET | `/api/v1/integrations/telegram/:telegramUserId/appointments` | integration key | Appointments of the linked patient. | `TELEGRAM_NOT_LINKED` |
| POST | `/api/v1/integrations/telegram/:telegramUserId/appointments` | integration key | Book for the linked patient. Success is only reported when the backend has persisted the appointment. | `TELEGRAM_NOT_LINKED`, `SLOT_UNAVAILABLE`, `DAILY_CAPACITY_REACHED`, `SLOT_IN_PAST`, `DATE_CLOSED`, `DEPARTMENT_NOT_WORKING_DAY`, `BEYOND_BOOKING_HORIZON`, `PATIENT_OVERLAP`, `DEPARTMENT_NOT_FOUND` |
| POST | `/api/v1/integrations/telegram/:telegramUserId/appointments/:id/cancel` | integration key | Cancel the linked patient's appointment (24-hour rule enforced by the backend). | `TELEGRAM_NOT_LINKED`, `APPOINTMENT_NOT_FOUND`, `APPOINTMENT_NOT_ACTIVE`, `WITHIN_24H_WINDOW` |
| POST | `/api/v1/integrations/telegram/:telegramUserId/appointments/:id/reschedule` | integration key | Reschedule the linked patient's appointment (24-hour rule enforced by the backend). | `TELEGRAM_NOT_LINKED`, `APPOINTMENT_NOT_FOUND`, `APPOINTMENT_NOT_ACTIVE`, `WITHIN_24H_WINDOW`, `SLOT_UNAVAILABLE`, `DAILY_CAPACITY_REACHED`, `SLOT_IN_PAST`, `DATE_CLOSED`, `DEPARTMENT_NOT_WORKING_DAY`, `RESCHEDULE_NO_CHANGE` |
| DELETE | `/api/v1/integrations/telegram/:telegramUserId/link` | integration key | Unlink this Telegram user (e.g. a /unlink bot command). |  |
| GET | `/api/v1/integrations/telegram/:telegramUserId/status` | integration key | Is this Telegram user linked to a patient account? |  |
| POST | `/api/v1/integrations/telegram/link` | integration key | Redeem a one-time linking code created by a logged-in patient and bind it to this Telegram user. | `LINK_CODE_INVALID`, `TOO_MANY_ATTEMPTS` |

## Patient

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/patient/appointments` | patient session | Own appointments. scope=upcoming (booked, not finished), history (everything else) or all. |  |
| POST | `/api/v1/patient/appointments` | patient session | Book a slot. All rules are enforced server-side inside a transaction. | `SLOT_UNAVAILABLE`, `DAILY_CAPACITY_REACHED`, `SLOT_IN_PAST`, `DATE_CLOSED`, `DEPARTMENT_NOT_WORKING_DAY`, `BEYOND_BOOKING_HORIZON`, `PATIENT_OVERLAP`, `DEPARTMENT_NOT_FOUND`, `DEPARTMENT_INACTIVE`, `NO_ACTIVE_DENTIST`, `SERVICE_NOT_IN_DEPARTMENT` |
| GET | `/api/v1/patient/appointments/:id` | patient session | One of the patient's own appointments. Someone else's appointment ID returns 404, never 403. | `APPOINTMENT_NOT_FOUND` |
| POST | `/api/v1/patient/appointments/:id/cancel` | patient session | Cancel an own appointment. Allowed only if at least 24 hours remain before it starts. | `APPOINTMENT_NOT_FOUND`, `APPOINTMENT_NOT_ACTIVE`, `WITHIN_24H_WINDOW` |
| POST | `/api/v1/patient/appointments/:id/reschedule` | patient session | Move an own appointment to another available slot of the same department. The 24-hour rule applies to the ORIGINAL start. | `APPOINTMENT_NOT_FOUND`, `APPOINTMENT_NOT_ACTIVE`, `WITHIN_24H_WINDOW`, `SLOT_UNAVAILABLE`, `DAILY_CAPACITY_REACHED`, `SLOT_IN_PAST`, `DATE_CLOSED`, `DEPARTMENT_NOT_WORKING_DAY`, `RESCHEDULE_NO_CHANGE`, `PATIENT_OVERLAP` |
| GET | `/api/v1/patient/me` | patient session | Current patient profile and CSRF token (call after a page reload to restore the session). |  |
| PATCH | `/api/v1/patient/me` | patient session | Update permitted profile fields (name, language). The phone number is the account identity and is changed only by staff. |  |
| DELETE | `/api/v1/patient/telegram` | patient session | Unlink the Telegram account. The bot loses access to this patient's data immediately. |  |
| GET | `/api/v1/patient/telegram` | patient session | Whether a Telegram account is linked to this patient. |  |
| POST | `/api/v1/patient/telegram/link-token` | patient session | Create a short-lived (10 min), single-use code. The patient sends it to the Telegram bot to link their account. |  |

## Patient auth

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| POST | `/api/v1/patient/auth/login` | none | Sign in with phone + password. Failures are generic and rate limited per IP and per phone. | `VALIDATION_ERROR`, `INVALID_CREDENTIALS`, `TOO_MANY_ATTEMPTS`, `RATE_LIMITED` |
| POST | `/api/v1/patient/auth/logout` | patient session | Sign out: revokes the current session and clears the cookie. |  |
| POST | `/api/v1/patient/auth/password` | patient session | Change own password (requires the current password). Other sessions are revoked. | `INVALID_CREDENTIALS`, `PASSWORD_TOO_SHORT`, `PASSWORD_TOO_WEAK` |
| POST | `/api/v1/patient/auth/register` | none | Create a patient account (phone + password) and sign in. The phone number is normalized but NOT verified. | `VALIDATION_ERROR`, `INVALID_PHONE`, `PHONE_ALREADY_REGISTERED`, `PASSWORD_TOO_SHORT`, `PASSWORD_TOO_WEAK` |

## Public

| Method | Path | Auth | Purpose | Error codes |
|---|---|---|---|---|
| GET | `/api/v1/public/center` | none | Center details (name, address, contact, hours, slots, timezone). Single source of truth, also used by the n8n assistant. |  |
| GET | `/api/v1/public/departments` | none | Active departments with their assigned dentist, localized. |  |
| GET | `/api/v1/public/departments/:slug` | none | One department landing-page payload: services, dentist and published before/after cases. | `DEPARTMENT_NOT_FOUND` |
| GET | `/api/v1/public/departments/:slug/availability` | none | Genuinely bookable slots per day for a department (default: today + 13 days; max 62 days). | `DEPARTMENT_NOT_FOUND`, `INVALID_RANGE`, `RANGE_TOO_LARGE` |
| GET | `/api/v1/public/gallery` | none | Published before/after cases. Sample content is labelled isSample=true; real cases require recorded consent. |  |

