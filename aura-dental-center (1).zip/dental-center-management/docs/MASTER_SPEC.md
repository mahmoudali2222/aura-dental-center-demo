# MASTER PROJECT SPECIFICATION & BUILD PROMPT
# Dental Center Management System

## 1. Your Role and Mission

Act as a senior full-stack software architect, backend engineer, database designer, frontend engineer, security engineer, DevOps engineer, and QA engineer.

Your mission is to design, implement, integrate, test, document, and prepare a complete, maintainable Dental Center Management System from scratch.

This is a real software project, not a UI mockup, a collection of disconnected pages, or a demonstration that merely looks complete.

The final system must have working database operations, secure authentication, correct booking rules, a functional patient website, a separate admin dashboard, an integration API for an existing n8n instance, multilingual support, Docker deployment, automated tests, and comprehensive documentation.

**Do not begin by generating every file at once.** First inspect the workspace, establish the architecture, document the implementation plan, and then execute the project in logical phases.

Do not claim that something works unless you have actually verified it to the extent possible in your environment. Clearly report anything that could not be tested.

---

# 2. Critical Project Constraints

Follow these rules throughout the project:

1. This is a completely NEW project.
2. Do not reuse, modify, import, or depend on the old dental-clinic-dashboard project.
3. Do not reuse the old project's PostgreSQL database, database volume, environment file, or Docker Compose project.
4. Create a new, independent PostgreSQL database and persistent Docker volume.
5. Reuse the user's existing n8n instance. Do not deploy a second n8n instance unless explicitly requested later.
6. The center has one physical location and one address. The address must be configurable and must not be hardcoded throughout the application or permanently embedded in prompts.
7. Each department has exactly one assigned dentist in the initial configuration.
8. There is no separate dentist login or dentist dashboard in the current scope.
9. Medical records are accessible and manageable through the authenticated Admin Dashboard only.
10. The patient-facing website must not contain an AI chatbot. AI patient conversations take place through Telegram using the existing n8n instance.
11. The system must support Arabic, English, and French.
12. The frontend must be developed after the backend, database, booking rules, API, authentication, and integration architecture have been established.
13. The user will provide a visual design reference for the patient website later. Do not invent or finalize the site's visual design before receiving that reference.
14. Prioritize maintainability, security, clear architecture, and practical functionality over unnecessary complexity.
15. Do not silently change any business rule defined in this specification.

If you discover a genuine contradiction or an important decision that cannot safely be inferred, explain it and ask a focused question. For non-blocking implementation details, make a sensible engineering decision and document it.

---

# 3. Product Overview

Build a Dental Center Management System consisting of these major components:

A. Patient Booking Website
B. Admin Dashboard
C. Backend REST API
D. Independent PostgreSQL database
E. Docker-based local deployment
F. Integration with the user's existing n8n instance and Telegram AI assistant
G. Comprehensive project documentation
H. Automated testing and a verified delivery checklist

The Patient Website and Admin Dashboard are separate user interfaces. They must use the same backend API and the same new database.

Use a clear separation of concerns:

- Frontend: presentation, user interaction, localization, and client-side validation.
- Backend: business logic, authentication, authorization, booking rules, validation, and database access.
- PostgreSQL: persistent application data.
- n8n: external automation and Telegram conversation orchestration.
- Docker Compose: repeatable local deployment and service management.

Never allow the frontend or n8n workflow to bypass backend business rules.

---

# 4. Dental Departments and Services

Seed the initial system with the following departments:

1. General Dentistry
2. Endodontics
3. Orthodontics
4. Periodontics
5. Restorative Dentistry
6. Cosmetic Dentistry
7. Pediatric Dentistry
8. Prosthodontics
9. Oral Surgery
10. Implantology
11. Oral Radiology

Treat these as initial configurable data, not hardcoded UI elements.

The Admin must be able to manage department information and associated services without modifying source code.

Each department has exactly one assigned dentist in the initial scope.

Each department should support:

- A stable internal identifier.
- A name in Arabic, English, and French.
- A localized description.
- Its associated dentist's display name.
- A list of services.
- Localized service names and descriptions.
- Optional prices, if configured.
- Active/inactive status.
- Website display order.
- Department images and related content references.

Do not invent real dentist identities, qualifications, prices, or clinical claims. Use clearly identified sample data where required and document how to replace it.

The initial data must be easy to configure, edit, or extend later.

The architecture should not require rewriting the application to add a department, change a service, or update the assigned dentist.

---

# 5. Appointment Scheduling and Booking Rules

These rules are mandatory and must be enforced on the backend and, where appropriate, by database constraints or transaction-safe operations.

## 5.1 Working Hours

The center operates from:

- Opening time: 4:00 PM.
- Closing time: 12:00 AM midnight.
- Timezone: `Africa/Cairo`.

Represent the final daily slot as 10:00 PM–12:00 AM. Correctly handle the fact that its end time is midnight.

Do not incorrectly treat midnight as the beginning of a new working day when calculating the duration of the final slot.

## 5.2 Appointment Duration

Every appointment occupies exactly two hours.

The standard daily slots are:

| Slot | Start | End |
|---|---|---|
| 1 | 4:00 PM | 6:00 PM |
| 2 | 6:00 PM | 8:00 PM |
| 3 | 8:00 PM | 10:00 PM |
| 4 | 10:00 PM | 12:00 AM |

The user must be able to choose a date and an available slot.

Do not allow arbitrary appointment durations or overlapping appointment times in the initial version.

## 5.3 Daily Capacity

Each department has a maximum of **four active appointments per calendar day**.

This is a per-department limit, not a limit shared by the entire center.

Each department can therefore have up to four bookings per day, with its own dentist and available slots.

The system must:

- Prevent duplicate bookings for the same department and slot.
- Prevent more than four active appointments for a department on the same date.
- Prevent overlapping bookings for the same department.
- Prevent booking the same slot twice through concurrent requests.
- Enforce the rules on the server, not merely by hiding unavailable slots in the UI.
- Return an appropriate error if a slot becomes unavailable during booking.
- Display only genuinely available slots to patients.
- Respect department activation status and configured closures.

Use database transactions and appropriate constraints or locking strategies to prevent race conditions.

Test concurrent requests attempting to book the same slot and concurrent requests competing for the department's daily capacity.

## 5.4 Appointment Lifecycle

Implement a clearly defined appointment lifecycle.

At minimum, support:

- Booked/confirmed.
- Cancelled.
- Completed.
- No-show, if needed for operational tracking.

Define which statuses consume daily capacity.

Cancelled appointments must release their slot and capacity. Completed appointments must remain in the historical record but must not block future bookings on other dates.

Document the allowed status transitions and enforce them in the backend.

Avoid allowing arbitrary status changes from untrusted clients.

## 5.5 Cancellation and Rescheduling

Patients may cancel or reschedule an appointment only when at least 24 hours remain before the appointment's start time.

Enforce this policy using server-side time calculations in the center's timezone.

If fewer than 24 hours remain:

- The patient cannot cancel or reschedule through the self-service website.
- The system should display a clear localized explanation.
- The Admin may handle the situation manually through the Admin Dashboard.

The same restriction must apply to relevant patient actions initiated through Telegram/n8n.

Do not trust a date, time, patient ID, or permission supplied by a client without server-side validation.

Test the 24-hour boundary, including just before and just after the threshold.

## 5.6 Date and Time Handling

- Store appointment timestamps consistently, preferably using timezone-aware database types.
- Use `Africa/Cairo` for business scheduling.
- Display times according to the selected language and locale.
- Handle midnight, date transitions, and daylight-saving changes correctly.
- Prevent bookings in the past.
- Keep historical appointments intact if working hours or scheduling settings change.

If the user interface displays a date without a year in some contexts, the backend must still store the complete date, including the year.

---

# 6. Patient Registration and Authentication

## 6.1 Registration

Patients create accounts using:

- Phone number.
- Password.

No email is required.

Do not implement OTP, SMS verification, or phone verification. The user explicitly cannot add this step.

Normalize phone numbers consistently and prevent duplicate accounts for equivalent normalized phone numbers.

The system must clearly document that, because phone ownership is not verified, it cannot guarantee that the person registering owns the supplied number.

## 6.2 Login

Returning patients log in using their phone number and password.

Implement:

- Strong password hashing using a modern password-hashing algorithm such as Argon2id or an appropriate bcrypt configuration.
- Secure session handling.
- Server-side authorization.
- Login rate limiting.
- Generic authentication errors that do not unnecessarily disclose whether an account exists.
- Secure cookie settings appropriate to the deployment environment.
- CSRF protection where applicable.
- Session expiration and logout.
- Protection against common authentication attacks.

Never store plaintext passwords or return password hashes to the frontend.

## 6.3 Password Recovery

There is no self-service OTP reset.

If a patient forgets their password, they must visit the center in person.

Provide a secure, documented, staff-assisted recovery process that:

1. Requires the Admin to authenticate.
2. Requires the Admin to verify the patient's identity in person.
3. Allows a password reset without revealing the previous password.
4. Invalidates relevant existing sessions when appropriate.
5. Records the recovery action in the audit log.
6. Avoids exposing sensitive credentials in application logs.

The system must not provide an unauthenticated password-reset endpoint.

## 6.4 Patient Portal

After logging in, a patient can:

- View their own profile.
- Update permitted profile information.
- View upcoming appointments.
- View appointment history.
- Book an available appointment.
- Cancel eligible appointments.
- Reschedule eligible appointments.
- See localized appointment status and error messages.

Patients must never be able to view another patient's account, appointments, or medical records by changing an identifier in a request.

Medical records remain Admin-only in this project scope.

---

# 7. Admin Authentication and Authorization

There is one initial administrative access path. No dentist login is required.

## 7.1 Initial Admin Account

Create the initial Admin account securely through environment configuration or a dedicated initialization command.

Requirements:

- Never hardcode a real password into source code.
- Provide `.env.example` with placeholder values only.
- Validate required configuration at startup.
- Fail safely when mandatory production configuration is missing.
- Force the initial Admin to change the initial password after the first successful login.
- Do not allow normal administration until the required password change is completed.
- Store only the password hash.
- Never print passwords or secrets in logs.
- Document the exact initial setup procedure.

The Admin account must not be silently recreated or reset on every restart.

## 7.2 Admin Capabilities

The Admin Dashboard should support:

- Overview of today's appointments and operational status.
- Appointment management.
- Patient management.
- Department management.
- Service management.
- Assigned dentist information management.
- Working-hours and closure management.
- Medical-record management.
- Patient website content and image-reference management where appropriate.
- General application settings.
- Audit-log access.
- Backup and restore procedures.

The Admin can add, edit, cancel, and manage appointments while preserving booking rules and historical consistency.

Administrative actions that override normal patient restrictions must be explicit and auditable.

## 7.3 Medical Records

Medical records are accessible through the authenticated Admin Dashboard only.

Implement fields for:

- Patient reference.
- Medical history.
- Allergies.
- Diagnosis.
- Treatment.
- Clinical notes.
- Record creation and update timestamps.
- The authenticated Admin responsible for relevant changes, where applicable.

Use appropriate relationships between records, patients, appointments, and services where clinically and technically justified.

Do not put sensitive medical information into public website responses, general analytics, Telegram messages, or application logs.

Do not expose medical records through unauthenticated endpoints or public frontend bundles.

Apply least-privilege access and validate every medical-record request on the backend.

The project is not intended to replace a specialized electronic health record system. Keep the current medical-record scope practical and documented.

---

# 8. Audit Log and Backup/Restore

These are the only two specifically requested advanced administrative capabilities beyond the core management system.

Do not add a waitlist, financial accounting system, inventory management system, or a large analytics module unless explicitly requested later.

## 8.1 Audit Log

Implement an audit log for important actions, including:

- Admin login events and relevant authentication events.
- Patient account administration.
- Password recovery.
- Appointment creation, changes, cancellation, and status changes.
- Department and service changes.
- Medical-record creation and modification.
- Settings changes.
- Backup and restore operations.

Each event should capture appropriate information such as:

- Actor identifier.
- Action type.
- Entity type and identifier.
- Timestamp.
- Outcome.
- Safe contextual metadata.

Do not record passwords, session tokens, secret keys, or unnecessary medical details in the audit log.

Protect audit records against modification by ordinary application users.

## 8.2 Backup and Restore

Provide documented, practical PostgreSQL backup and restoration procedures.

Requirements:

- Use supported PostgreSQL backup tools.
- Include Docker-compatible commands.
- Explain where backup files are stored.
- Explain how to verify that a backup file is valid.
- Explain how to restore into the intended database safely.
- Explain the risks of overwriting current data.
- Never assume that a Docker volume alone is a sufficient backup.
- Keep backup operations separate from ordinary application startup.
- Document a test restore procedure using a separate test database or environment.

Do not claim that automated scheduled backups exist unless they have actually been implemented and tested.

---

# 9. Patient Booking Website

The patient website is a public-facing, polished, professional dental-center website with patient account functionality.

It must be separate from the Admin Dashboard.

## 9.1 Design Reference

The user will provide a visual design reference later.

Before receiving that reference:

- Establish the architecture and functional requirements.
- Prepare the component structure and localization foundation.
- Define the API contracts.
- Implement and test the backend.
- Prepare a minimal functional frontend shell only where necessary for integration testing.
- Do not finalize the patient website's visual style, layout, animation language, or page composition.
- Do not claim that the final design matches a reference you have not received.

Once the user provides the reference, analyze it and implement a coherent, responsive design inspired by it.

Do not copy inaccessible assets or rely on external images that may disappear.

## 9.2 Required Patient Website Features

Include:

- Homepage.
- Center introduction and configurable location information.
- Department directory.
- Individual department landing pages.
- Service details.
- Assigned dentist information.
- Before-and-after case gallery.
- Patient registration.
- Patient login.
- Patient account and profile.
- Appointment booking.
- Upcoming appointments.
- Appointment history.
- Cancellation and rescheduling controls.
- Clear validation, loading, empty, success, and error states.
- Language selector.
- Responsive mobile and desktop layouts.

## 9.3 Department Landing Pages

Each department should have its own route and localized page.

Each page should be able to display:

- Department name and description.
- Services.
- Assigned dentist.
- Relevant photographs.
- Related before-and-after cases, where available.
- Booking call to action.
- Available booking dates and slots, when appropriate.

Department pages must be generated from backend data rather than hardcoded separately for each department.

## 9.4 Before-and-After Gallery

The website should display real treatment cases when the user supplies approved images.

Do not fabricate real patient treatment results.

Do not label AI-generated or placeholder imagery as real clinical before-and-after cases.

Use clear content metadata and document the need for patient consent and privacy protection before publishing identifiable patient images.

Support appropriate image optimization, responsive image sizes, lazy loading, descriptive alternative text, and sensible fallback behavior.

## 9.5 Image Asset Structure

The user wants to supply images through organized project folders rather than requiring a sophisticated upload system.

Create a clear, documented asset structure, for example:

- `frontend/public/assets/branding/`
- `frontend/public/assets/departments/`
- `frontend/public/assets/services/`
- `frontend/public/assets/gallery/`

You may adjust this structure if your chosen frontend architecture justifies it.

Provide a manifest or documentation file specifying:

- Exact folder paths.
- Expected filenames.
- Recommended formats and dimensions.
- Which page or department uses each image.
- Which images are optional.
- How to replace a placeholder with the user's real image.

Use obvious placeholder names where assets are missing. Never silently represent placeholders as genuine clinical cases.

Make image references easy to maintain without editing business logic.

---

# 10. Three-Language Support

The complete system must support:

1. Arabic (`ar`)
2. English (`en`)
3. French (`fr`)

This applies to the Patient Website and the Admin Dashboard.

## 10.1 Localization Requirements

Translate all user-facing interface text, including:

- Navigation.
- Buttons.
- Forms.
- Validation errors.
- Authentication.
- Booking workflows.
- Appointment statuses.
- Admin tables and filters.
- Empty states.
- Success and failure notifications.
- Dialogs.
- Help text.
- Accessibility labels.
- Date and time displays.

Do not leave important interface text permanently hardcoded in one language.

Use a structured internationalization system with separate, maintainable translation resources.

## 10.2 Arabic RTL

Arabic must use proper right-to-left layout.

Use the appropriate document direction and language attributes, and use logical CSS properties where possible.

Avoid fragile implementations that merely reverse text alignment without supporting actual RTL layout.

Check:

- Navigation.
- Forms.
- Tables.
- Icons.
- Dropdowns.
- Modals.
- Calendars.
- Animations.
- Responsive layouts.

English and French must use left-to-right layout.

Switching languages must not break the page structure.

## 10.3 Localized Content

Department names, service names, descriptions, and website content must support all three languages.

Use an explicit data model for localized content rather than relying only on translating the UI.

For any missing translation, define a predictable fallback policy and document it.

Never display untranslated internal keys to patients.

The Admin interface must make it clear which language's content is being edited.

## 10.4 Language Preference

Provide a visible language selector.

Persist the user's selected language appropriately, such as in their account preferences for authenticated users and local browser preferences for anonymous users.

Do not require users to create an account just to change the website language.

Use locale-aware date and time formatting while preserving the center's actual scheduling timezone.

## 10.5 Localization Testing

Test all three languages, especially:

- Arabic RTL.
- Long French labels.
- Mobile screen layouts.
- Date and time formatting.
- Form validation.
- Booking and cancellation messages.
- Admin workflows.
- Mixed-language content.

Do not treat a language selector alone as complete multilingual support.

---

# 11. Backend API

Create a clean, documented REST API.

Choose a maintainable technology stack appropriate for the project. A JavaScript/TypeScript stack with Node.js is acceptable and may be preferable for consistency across frontend and backend.

A reasonable starting architecture is:

- React and Vite for frontend applications.
- TypeScript where practical.
- Node.js backend using a suitable framework.
- PostgreSQL for persistent data.
- Docker Compose for local deployment.

You may choose a different stack only if you can explain why it is more appropriate and keep the project understandable and maintainable.

Avoid unnecessary microservices. A well-structured modular backend is preferred for this project.

Organize the backend into clear modules such as:

- Authentication.
- Patients.
- Departments.
- Services.
- Dentist information.
- Availability and scheduling.
- Appointments.
- Medical records.
- Administration.
- Audit logging.
- Configuration.
- n8n integration.

## 11.1 API Design

Use consistent response formats and appropriate HTTP status codes.

Implement:

- Request validation.
- Authentication middleware.
- Authorization checks.
- Consistent error handling.
- Pagination where needed.
- Safe filtering and sorting.
- Request logging without sensitive data.
- API versioning if justified.
- Rate limiting on sensitive endpoints.
- Clear API documentation.

Separate public endpoints from authenticated patient and Admin endpoints.

Do not rely on frontend restrictions for security.

## 11.2 API Documentation

Document each major endpoint, including:

- HTTP method and route.
- Purpose.
- Authentication requirements.
- Required permissions.
- Request parameters and body.
- Validation rules.
- Successful response.
- Possible error responses.

Provide an OpenAPI specification if appropriate for the chosen stack.

---

# 12. Database Design

Use a new PostgreSQL database dedicated to this project.

Design a normalized, maintainable schema with explicit relationships and constraints.

At minimum, consider entities for:

- Patients.
- Admin users.
- Departments.
- Dentist information or department assignments.
- Services.
- Appointments.
- Medical records.
- Audit events.
- Application settings.
- Closures or scheduling exceptions, if required.
- Localized content, using a practical schema appropriate to the chosen approach.

Do not create a separate dentist authentication system.

Do not store all application data in one oversized table or in unstructured JSON when relational fields and constraints are more appropriate.

## 12.1 Database Requirements

- Use migrations.
- Use foreign keys.
- Add suitable indexes.
- Enforce unique patient phone numbers after normalization.
- Enforce referential integrity.
- Design deletion behavior carefully for historical appointments and medical records.
- Use transactions for multi-step operations.
- Prevent booking races.
- Use consistent timestamps.
- Keep secrets out of database seed files.
- Make initial seed data repeatable and safe.

Explain the schema and important relationships in `docs/DATABASE.md`.

Provide a clear way to initialize a fresh database and apply migrations.

Database migrations must be safe to run in the documented order.

Do not automatically erase existing production data during startup or routine migration.

---

# 13. n8n and Telegram Integration

The user already has an n8n instance.

Do not create a new n8n deployment by default.

The new Dental Center backend must expose a secure integration API so that n8n can request supported operations.

The Telegram AI assistant should be able to help patients with supported tasks such as:

- Providing department and service information.
- Providing configured center details.
- Checking available appointment slots.
- Creating bookings.
- Cancelling eligible bookings.
- Rescheduling eligible bookings.
- Giving booking status information to properly authenticated patients.

The website itself must not have an AI chatbot.

## 13.1 Backend Is the Source of Truth

n8n must not independently implement a second booking database or duplicate the authoritative scheduling rules.

All appointment creation, cancellation, rescheduling, availability checks, and relevant patient operations must be performed through the new backend API.

The backend remains responsible for:

- Validating requests.
- Checking availability.
- Enforcing daily capacity.
- Enforcing the 24-hour cancellation policy.
- Enforcing identity and authorization.
- Writing database changes.
- Returning the authoritative result.

The AI assistant must never claim that a booking succeeded unless the backend confirms success.

## 13.2 Secure Integration

Implement a secure machine-to-machine authentication method, such as a dedicated service credential with adequate entropy and server-side verification.

Requirements:

- Store the secret in environment configuration.
- Never commit real credentials.
- Never expose service credentials to the browser.
- Restrict which endpoints the integration credential can access.
- Rate-limit or otherwise protect integration endpoints.
- Avoid returning unnecessary patient information.
- Log integration actions safely.
- Document credential creation, configuration, rotation, and revocation.

Do not give n8n unrestricted Admin access merely to make integration easier.

## 13.3 Telegram Identity and Patient Authorization

A Telegram username or chat ID alone is not sufficient proof that someone owns a patient account.

Design a secure patient-linking flow that allows the user to associate their Telegram account with their patient account before accessing personal appointments or requesting cancellations.

The linking mechanism must:

- Require authenticated proof through the patient account.
- Use short-lived, single-use linking tokens or another appropriately secure method.
- Avoid putting passwords or long-lived secrets into Telegram messages.
- Store the resulting association securely.
- Allow revocation or replacement.
- Prevent one Telegram account from accessing another patient's data.

Do not invent a weak identity-verification shortcut.

If the full linking flow cannot be implemented in the initial phase, clearly mark personal Telegram operations as unavailable until it is implemented. Do not permit unauthenticated personal booking access as a temporary workaround.

## 13.4 Center Address and Configuration

The center has one physical address.

The address may change, so it must not be scattered throughout the code or permanently hardcoded in the AI prompt.

Create a single source of truth for the center's configurable public details, including its address and relevant contact information.

Ensure the AI agent receives current values through an appropriate configuration or knowledge-retrieval mechanism.

The AI assistant must not guess the address, opening hours, prices, available services, or dentist information.

If these details are missing or cannot be retrieved, it must explain that it cannot confirm the information.

The website and the AI assistant must not drift into using different addresses or conflicting operating hours.

## 13.5 n8n Documentation

Provide:

- `docs/N8N_INTEGRATION.md`
- An explanation of the backend endpoints used by n8n.
- Credential setup instructions.
- Required environment variables.
- Telegram identity-linking documentation.
- Example request and response payloads.
- Workflow import/setup instructions if a workflow export is included.
- Troubleshooting steps.

If you provide n8n workflow JSON, validate its structure and document which credentials and node configuration must be supplied manually.

Do not include real Telegram bot tokens, API keys, or user credentials in exported workflow files.

---

# 14. Docker and Deployment Architecture

The project must run locally on Windows using Docker Desktop and be suitable for later deployment to a VPS.

Create a new independent Docker Compose configuration.

The main services should normally include:

1. Patient frontend.
2. Admin frontend, if implemented as a separate application.
3. Backend API.
4. PostgreSQL.

You may serve both frontend applications through a single web server container if this keeps the architecture simpler and the applications remain logically separate.

Do not start a new n8n container by default.

Use a dedicated Compose project name and a unique database volume. Do not collide with existing containers, ports, or Docker volumes from the old project.

Inspect existing port usage before selecting ports. If a conflict exists, document a configurable alternative rather than changing another project.

## 14.1 Docker Requirements

- Multi-stage builds where appropriate.
- Small, sensible images.
- Health checks.
- Service dependencies that account for database readiness.
- Persistent PostgreSQL storage.
- Restart policies suitable for the environment.
- Non-root containers where practical.
- Internal networking for services that do not need public exposure.
- Environment-based configuration.
- No secrets baked into images.
- No database port exposed publicly by default.
- Clear logs.
- Graceful startup and shutdown.
- Reproducible builds.

Do not assume that starting a container means the application is healthy.

## 14.2 Required Commands in Documentation

Provide exact Windows PowerShell commands for:

- Checking prerequisites.
- Configuring the environment file.
- Building and starting the project.
- Checking container status.
- Viewing logs.
- Running database migrations.
- Running automated tests.
- Stopping the project.
- Restarting the project.
- Updating the project.
- Backing up the database.
- Restoring a backup.
- Troubleshooting common startup failures.

Clearly distinguish PowerShell commands from Linux/VPS commands.

Never use destructive cleanup commands that might remove the user's existing database volumes or unrelated containers.

## 14.3 VPS Readiness

Document the future deployment path:

- Provisioning a VPS.
- Installing Docker and Docker Compose.
- Configuring environment variables.
- Domain and DNS setup.
- HTTPS and reverse proxy.
- Database persistence.
- Backups and restore verification.
- Updating the application safely.
- Log inspection.
- Production security considerations.

Do not claim that the application is deployed to a VPS unless deployment has actually been performed.

---

# 15. Security and Privacy

Security is a required part of implementation, not a future enhancement.

At minimum:

- Validate all user inputs on the backend.
- Use parameterized database queries or a safe ORM.
- Protect against SQL injection.
- Apply context-appropriate output encoding.
- Configure CORS explicitly.
- Protect authentication sessions.
- Apply rate limiting to authentication and sensitive endpoints.
- Enforce server-side authorization.
- Prevent insecure direct-object-reference attacks.
- Protect patient and medical information.
- Avoid logging secrets and sensitive clinical data.
- Use safe error messages.
- Protect administrative functions.
- Secure the n8n integration.
- Avoid exposing internal infrastructure details in public API errors.
- Store secrets in environment configuration.
- Include `.env.example`, not a real `.env` containing secrets.
- Document secure production cookie settings and HTTPS requirements.

Do not claim complete security or legal compliance merely because common protections exist.

Document important assumptions and limitations, including the lack of phone verification.

---

# 16. Frontend Engineering Standards

Once the functional foundation is ready and the design reference is provided, build the frontend carefully.

Use a consistent component system and shared design tokens.

Keep components small and understandable.

Avoid giant files containing unrelated UI, API calls, business rules, and data transformations.

Use clear separation between:

- UI components.
- Page-level components.
- API clients.
- Authentication state.
- Localization resources.
- Validation schemas.
- Shared types.
- Reusable hooks or utilities.
- Styling and design tokens.

## 16.1 User Experience

The website should feel polished, professional, and appropriate for a dental center.

Use tasteful animation and transitions only when they improve the experience.

Prioritize:

- Clear navigation.
- Fast loading.
- Responsive layouts.
- Readable typography.
- Accessible controls.
- Appropriate contrast.
- Consistent spacing.
- Good mobile interactions.
- Loading indicators.
- Empty states.
- Useful validation messages.
- Error recovery.

Respect reduced-motion preferences.

Do not sacrifice performance, accessibility, or usability for animation.

The Admin Dashboard should prioritize clarity, efficiency, organized data presentation, and predictable interactions.

Do not make the Admin Dashboard a copy of the public marketing website.

## 16.2 Functional UI Only

Do not leave buttons that look functional but do nothing.

Do not use hardcoded sample appointment data as if it were live database data.

Do not fake login success, booking success, cancellation, or database connectivity.

Where sample data is necessary, label it clearly.

Every important interface action must call the appropriate API and handle both success and failure.

---

# 17. Testing and Quality Assurance

You must test the integrated application, not just individual functions.

Create a written test plan before implementation and update it as the project develops.

Use suitable testing tools for the selected stack.

A reasonable testing strategy includes unit tests, integration tests, API tests, database tests, and browser-based end-to-end tests.

## 17.1 Authentication Tests

Test:

- Patient registration.
- Duplicate normalized phone numbers.
- Valid and invalid login.
- Password hashing.
- Logout.
- Session expiration.
- Rate limiting.
- First-login Admin password change.
- Patient access restrictions.
- Admin-only endpoint protection.
- Patient account isolation.
- Password recovery authorization.

## 17.2 Booking Tests

Test:

- Booking each of the four daily slots.
- Four bookings in one department on one day.
- Rejection of a fifth active booking.
- Capacity for different departments on the same day.
- Prevention of duplicate slot booking.
- Prevention of overlapping appointments.
- Booking in the past.
- Midnight handling.
- Cancelled booking capacity release.
- Rescheduling to an unavailable slot.
- Rescheduling and cancellation inside the 24-hour window.
- Rescheduling and cancellation outside the 24-hour window.
- Concurrent booking attempts for the same slot.
- Concurrent booking attempts that compete for the final available capacity.
- Correct behavior after database or backend errors.

## 17.3 Medical Record Tests

Test:

- Admin can access authorized medical records.
- Unauthenticated users cannot access them.
- Patients cannot access them through the API.
- Unknown record identifiers do not reveal other patients' information.
- Sensitive fields do not leak through unrelated endpoints or logs.
- Important record modifications generate audit events.

## 17.4 Localization Tests

Test the complete core workflow in Arabic, English, and French.

Check:

- Language switching.
- RTL and LTR.
- Responsive layouts.
- Translated validation errors.
- Appointment dates and times.
- Localized department and service content.
- Missing translations.
- Long text.
- Admin workflows.

## 17.5 n8n Integration Tests

Test:

- Valid integration credentials.
- Invalid integration credentials.
- Availability checks.
- Successful booking through the API.
- Rejected booking requests.
- Cancellation policy enforcement.
- Telegram patient-linking security.
- Access restrictions on personal appointment data.
- Consistency between website bookings and Telegram bookings.

## 17.6 Docker Integration Tests

From a clean project environment:

1. Build the Docker images.
2. Start the Compose stack.
3. Verify service health.
4. Verify database initialization and migrations.
5. Verify backend readiness.
6. Verify frontend access.
7. Execute a real test booking.
8. Verify that the booking is persisted in PostgreSQL.
9. Verify that the same booking is visible through the relevant Admin and patient interfaces.
10. Restart the stack and confirm persistence.
11. Test backup and restoration in an isolated test database.
12. Stop the stack without deleting persistent data.

Never test destructive restoration against the only copy of real data.

## 17.7 Browser Tests

Use browser-based tests where available to verify real user journeys, including:

- Patient registration and login.
- Appointment booking.
- Viewing appointments.
- Cancellation and rescheduling.
- Admin login.
- Appointment management.
- Medical record management.
- Language switching.
- Mobile layout basics.

If browser testing is unavailable, state this clearly and use the strongest alternative available.

## 17.8 Quality Gates

Before declaring the project ready:

- All critical tests must pass.
- No known critical or high-severity security issue may be left unreported.
- No unresolved critical booking or authorization defect may be hidden.
- Database migrations must run successfully.
- The Docker stack must start and become healthy.
- The main patient booking journey must work end to end.
- Admin actions must persist correctly.
- n8n integration endpoints must enforce their intended authorization.
- The documentation must match the actual files, commands, and configuration.

Do not fabricate test results, screenshots, logs, coverage percentages, or successful deployment claims.

If any gate cannot be completed, report the blocker and exact remaining work instead of declaring unconditional success.

---

# 18. Required Documentation

Create a comprehensive Markdown documentation set.

At minimum:

## `README.md`

Include:

- Project overview.
- Feature summary.
- Architecture summary.
- Prerequisites.
- Initial setup.
- Environment configuration.
- Exact local startup instructions.
- Application URLs and ports.
- Testing commands.
- Troubleshooting.
- Links to detailed documentation.

## `PROJECT_DOCUMENTATION.md`

This is the main project specification and maintenance guide.

It must explain:

- What the project does.
- The agreed business rules.
- Every major subsystem.
- The architecture.
- How the components communicate.
- The database structure.
- Authentication and authorization.
- Appointment scheduling.
- Localization.
- n8n integration.
- Docker operation.
- Testing.
- Deployment.
- Backup and restore.
- How to extend the project safely.

## Additional documentation

Create these files, or equivalent clearly named documents:

- `docs/ARCHITECTURE.md`
- `docs/DATABASE.md`
- `docs/API.md`
- `docs/BOOKING_RULES.md`
- `docs/SECURITY.md`
- `docs/N8N_INTEGRATION.md`
- `docs/TESTING.md`
- `docs/DEPLOYMENT.md`
- `docs/BACKUP_RESTORE.md`
- `docs/IMAGE_ASSETS.md`
- `docs/TROUBLESHOOTING.md`
- `docs/PROJECT_STATUS.md`

Do not generate empty documentation files merely to satisfy the list.

Documentation must reflect the actual implementation, including any limitations or deferred features.

## File-by-File Explanation

The documentation must explain the folder structure and the purpose of every important source file, configuration file, migration, test directory, and deployment file.

For complex files, explain their responsibilities and how they connect to other modules.

Include a clear map of:

- Where to change booking rules.
- Where to add a department or service.
- Where to update translations.
- Where to replace website images.
- Where to update center address and contact details.
- Where to change environment configuration.
- Where to modify n8n API integration.
- Where to add a new API endpoint.
- Where to add a database migration.
- Where to add and run tests.

The project should be understandable to another developer or AI assistant without requiring them to reverse-engineer the entire codebase.

---

# 19. Environment Configuration

Create `.env.example` with documented placeholder values.

Include all required configuration, such as:

- Database name.
- Database user.
- Database password placeholder.
- Backend port.
- Frontend port or ports.
- Allowed frontend origins.
- Session configuration.
- Initial Admin bootstrap configuration.
- n8n service credential placeholder.
- Cookie security settings.
- Public application URL.
- Center timezone.
- Other necessary settings justified by the architecture.

Do not invent unnecessary environment variables.

Validate required values during startup.

Provide clear instructions for generating strong secrets and configuring them locally.

Do not commit real credentials or automatically overwrite an existing `.env` file.

The address and public center information must have a documented, centralized configuration source and must be available to the website and AI assistant without being duplicated across source files.

---

# 20. Recommended Project Structure

Use a clean structure similar to the following, adapting it to your actual stack:

```text
dental-center-management/
├── README.md
├── PROJECT_DOCUMENTATION.md
├── docker-compose.yml
├── .env.example
├── .gitignore
├── backend/
│   ├── Dockerfile
│   ├── package.json
│   ├── src/
│   │   ├── config/
│   │   ├── middleware/
│   │   ├── modules/
│   │   │   ├── auth/
│   │   │   ├── patients/
│   │   │   ├── departments/
│   │   │   ├── services/
│   │   │   ├── appointments/
│   │   │   ├── medical-records/
│   │   │   ├── admin/
│   │   │   ├── audit/
│   │   │   └── integrations/
│   │   ├── database/
│   │   ├── app.ts
│   │   └── server.ts
│   └── tests/
├── patient-frontend/
│   ├── Dockerfile
│   ├── package.json
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── api/
│   │   ├── i18n/
│   │   ├── hooks/
│   │   ├── styles/
│   │   └── assets/
│   └── tests/
├── admin-frontend/
│   ├── Dockerfile
│   ├── package.json
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── api/
│   │   ├── i18n/
│   │   └── styles/
│   └── tests/
├── database/
│   ├── migrations/
│   └── seeds/
├── n8n/
│   ├── README.md
│   └── workflows/
├── scripts/
├── docs/
└── .github/
    └── workflows/
```

This is a reference, not a requirement to create unnecessary files. Use a separate frontend application for the Admin Dashboard if it improves separation and maintainability; otherwise explain the routing and separation strategy if a shared frontend application is used.

Do not create empty folders or modules that serve no purpose.

---

# 21. Implementation Workflow

Follow this sequence.

## Phase 1 — Requirements and Architecture

1. Inspect the new workspace.
2. Confirm that you are not modifying the old project.
3. Produce a requirements checklist.
4. Identify business rules and security boundaries.
5. Propose the architecture and explain important choices.
6. Design the database schema and API contracts.
7. Write the initial implementation plan.
8. Identify any genuine blockers.

Do not start by creating the entire frontend.

## Phase 2 — Database and Backend

1. Initialize the backend.
2. Configure PostgreSQL.
3. Implement migrations and safe seed data.
4. Implement authentication and authorization.
5. Implement departments and services.
6. Implement availability and booking rules.
7. Implement patient appointment management.
8. Implement Admin operations.
9. Implement Admin-only medical records.
10. Implement audit logging.
11. Implement the n8n integration API.
12. Add automated tests and run them.

## Phase 3 — Docker and Integration

1. Build the Docker configuration.
2. Verify database initialization.
3. Start the backend and database.
4. Verify health checks and persistent storage.
5. Test API operations against PostgreSQL.
6. Test concurrent booking protection.
7. Test authentication and authorization.
8. Test the n8n integration boundary.
9. Document exact startup and troubleshooting procedures.

## Phase 4 — Frontend Foundation

Before the visual reference is provided:

1. Establish frontend architecture.
2. Establish API client and authentication integration.
3. Configure Arabic, English, and French localization.
4. Establish correct RTL/LTR behavior.
5. Build the minimal functional shell needed for integration tests.
6. Avoid finalizing the visual design.

**When the backend, database, API contracts, and integration tests are ready, request the user's patient-website design reference before implementing the final patient-facing UI.**

Do not pretend the reference has been supplied.

## Phase 5 — Patient Website and Admin Dashboard

After the design reference is supplied:

1. Implement the patient website based on the reference.
2. Build department and service pages from backend data.
3. Implement patient authentication.
4. Implement booking and appointment management.
5. Implement the gallery and documented asset structure.
6. Build the Admin Dashboard as a separate, organized interface.
7. Implement Admin management features.
8. Connect all real workflows to the backend.
9. Test all three languages.
10. Verify responsive layouts and accessible interactions.

Do not leave critical controls as mock functionality.

## Phase 6 — Full-System QA

1. Run all unit and integration tests.
2. Run browser-based tests where available.
3. Test booking concurrency and all capacity rules.
4. Test authorization boundaries.
5. Test multilingual workflows.
6. Test the Docker stack from a clean environment.
7. Test persistence across restarts.
8. Test backup and restoration safely.
9. Fix discovered defects and rerun relevant tests.
10. Update documentation to match the final code.

## Phase 7 — Delivery Preparation

Prepare a clean, complete project directory.

Include:

- All source files.
- Docker configuration.
- Database migrations.
- Safe seed data.
- Tests.
- Documentation.
- Environment example.
- Image asset instructions.
- n8n integration documentation.
- A final verified test report.
- A list of remaining limitations, if any.

Do not include real secrets, unnecessary generated files, node_modules directories, or database dumps containing sensitive data.

---

# 22. Definition of Done

The project is ready for delivery only when the following can be verified:

- [ ] The new project is independent of the old project.
- [ ] It uses a dedicated PostgreSQL database and volume.
- [ ] Docker builds and starts the intended services.
- [ ] Database migrations run successfully.
- [ ] Patient registration and login work.
- [ ] Admin login and mandatory initial password change work.
- [ ] Patient account isolation is enforced.
- [ ] All listed departments can be configured.
- [ ] Each department has one assigned dentist.
- [ ] Each department supports four two-hour slots per day.
- [ ] Booking capacity is enforced under concurrent requests.
- [ ] Midnight is handled correctly.
- [ ] The 24-hour patient cancellation/rescheduling policy works.
- [ ] Medical records are restricted to the Admin Dashboard.
- [ ] Important administrative actions are audited.
- [ ] Backup and restore procedures are documented and tested in isolation.
- [ ] The backend API is documented.
- [ ] The existing n8n instance can integrate through the protected API.
- [ ] Telegram personal-data access requires secure patient linking.
- [ ] Arabic, English, and French are implemented.
- [ ] Arabic RTL and English/French LTR work correctly.
- [ ] The patient website and Admin Dashboard are distinct interfaces.
- [ ] The patient website is connected to real backend data.
- [ ] Image asset folders and filenames are documented.
- [ ] The final patient website visual design uses the reference supplied by the user.
- [ ] Critical end-to-end user journeys pass.
- [ ] Documentation matches the actual implementation.
- [ ] Untested or deferred features are clearly disclosed.

If a checkbox cannot be verified, do not mark it complete.

---

# 23. Final Report Required From You

At the end, provide a concise but detailed implementation report containing:

1. What was built.
2. The final architecture and technology choices.
3. The actual project folder structure.
4. Database schema and migration status.
5. Docker services and application URLs.
6. Exact PowerShell commands for initial setup and startup.
7. How to configure the existing n8n instance.
8. Where to configure the center address and other public details.
9. How to supply department and gallery images.
10. How to run the test suite.
11. Which tests actually passed.
12. Which tests failed or could not be run, and why.
13. Known limitations and unfinished items.
14. How to back up and restore the database.
15. How to deploy the project to a VPS later.

Provide the final report only after performing the work that the environment allows you to perform.

Do not substitute a report for actual implementation.

Do not declare the project complete merely because all source files have been generated.

---

# 24. Start Here

Begin with Phase 1.

Inspect the workspace and confirm that it is a clean location for the new project. Present the architecture, the requirements checklist, the database plan, and the staged implementation plan.

Then begin implementation in the order specified above.

Keep the project coherent, secure, testable, and easy to maintain. Make sensible engineering decisions without overengineering. Preserve every explicit business rule in this document.

**The objective is a real, integrated, tested, documented Dental Center Management System—not just a visually impressive prototype.**