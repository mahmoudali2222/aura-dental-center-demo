# Implementation Plan

Follows §21 of the master spec. Exit criteria are what must be *demonstrated*, not just written.

> **Status (2 November 2026).** This plan was written first and is kept as the record of the order of work and of the decisions
> taken. Phases 1–3 and phase 5 (the dashboard and the **patient website with its white and color-wheel design**, built on the pictures the
> center supplied) are built and tested; the official logo and the hero video were not supplied and have empty, ready places
> (`FRONTEND.md`); phase 6 ran everywhere the development environment allows. What
> is verified and what is not (Docker builds, PowerShell scripts, real Telegram) is in `PROJECT_STATUS.md`, the as-built design is in
> `ARCHITECTURE.md`. Wherever this plan says "I would", read "was done" unless `PROJECT_STATUS.md` says otherwise.

## Phases

| Phase | Scope | Exit criteria |
|---|---|---|
| **1. Requirements & architecture** | Workspace check, requirements register, architecture, DB plan, plan, test plan | These documents exist; open decisions listed |
| **2. Database & backend** | Migrations + seeds; config validation; auth (patient/admin, sessions, CSRF, rate limits); departments/services/dentists; scheduling + booking; patient appointments; admin ops; medical records; audit; n8n integration + Telegram linking; OpenAPI | Migrations run on a fresh DB; automated tests pass against a real PostgreSQL, including concurrency, 24 h boundary, midnight, authorization isolation |
| **3. Docker & integration** | Dockerfiles, Compose, nginx, health checks, backup/restore scripts, PowerShell docs, `scripts/verify-docker.ps1` | `docker compose config` validates here; backup/restore verified with `pg_dump`/`pg_restore` into an isolated DB here; image build + container health **only claimed if actually run** |
| **4. Frontend foundation** | Vite apps, API client, auth state, i18n (ar/en/fr), RTL/LTR, asset folders + manifest, minimal functional shell | Shell can register, log in, list slots, book, cancel against the real backend |
| **→ Checkpoint** | **Ask the user for the patient-website design reference** | Reference received |
| **5. Patient site & admin UI** | Final patient UI from the reference; admin dashboard; all real workflows | No mock controls |
| **6. Full-system QA** | All suites, browser tests where possible, localization checks, docker journey on the user's machine | Quality gates in spec §17.8 |
| **7. Delivery** | Clean tree, final report | Spec §22 checklist, unverifiable boxes left unchecked |

### Where I propose to deviate from the order (needs your OK, not done silently)

The admin dashboard does not depend on the patient design reference. Because the reference arrives "later", I would
like to build the **admin dashboard during the wait** (after Phase 4) rather than after the reference. The patient
website visual layer stays blocked on the reference exactly as the spec requires. If you prefer strict spec order,
say so and I will wait.

## Design decisions and defaults (document, non-blocking)

The spec is explicit on all hard rules. These are the gaps I filled with defaults; each is a setting or isolated code
path, so changing one later is cheap. **Please confirm or correct them.**

| ID | Decision | Default chosen | Why it matters |
|---|---|---|---|
| D1 | Same-origin deployment (nginx serves both SPAs, proxies `/api/`) | yes | simpler cookies/CSRF |
| D2 | Statuses that consume capacity | `booked`, `completed`, `no_show` | a slot whose patient didn't show is still gone for that day; only `cancelled` frees it |
| D3 | Reschedule semantics | in-place move of the same appointment, re-validated like a new booking; the 24 h rule is measured against the **original** start; the new slot only has to be a future, available slot | keeps history in one row + audit event |
| D4 | 24 h boundary | inclusive: exactly 24:00:00 before start is still allowed | spec says "at least 24 hours" |
| D5 | Admin override | admin may cancel/reschedule inside 24 h only with `override=true` and a reason; both audited. Admin still cannot break slot/capacity rules or book in the past | spec §7.2 |
| D6 | DST nights | appointment length is exactly two *real* hours; on the two clock-change nights of each year (Thu 29 Oct 2026, Thu 29 Apr 2027, …) the 10 PM slot's wall-clock end label is not "12:00 AM"; UI shows `ends_at` in Cairo time | spec says both "exactly two hours" and "handle DST"; this satisfies both |
| D7 | Patient double-booking | a patient cannot hold two overlapping active appointments across departments (DB exclusion constraint) | spec only forbids per-department overlap; physically impossible otherwise. Remove if you disagree |
| D8 | Booking horizon | 60 days ahead (setting) | spec doesn't say; avoids unbounded availability queries |
| D9 | Working weekdays | **all 7 days open until you set them.** Configurable in the dashboard at two levels: the center (`center_profile.working_days`) and each department (`departments.working_days`); the effective days are the intersection and they control availability and booking on the website, the dashboard and Telegram (`BOOKING_RULES.md` §2) | spec gives hours but not days; many Egyptian clinics close Fridays. Changed by your request of 30 Oct 2026. **Question 1 below** |
| D10 | Default site language | `ar` (setting) | Egyptian center. **Question 2 below** |
| D11 | Registration fields | full name + phone + password | a clinic can't manage patients without a name; spec lists only phone/password. **Question 3 below** |
| D12 | Session lifetimes | patient: 7 days absolute, 24 h idle; admin: 8 h absolute, 30 min idle (env-configurable) | |
| D13 | Argon2id parameters | m = 19 MiB, t = 2, p = 1 (OWASP minimum recommended profile) | tune on target hardware |
| D14 | Sample content | trilingual placeholder dentists and a few generic services per department, flagged `is_sample`, no prices, no clinical claims; gallery starts empty | spec §4, §9.4 |
| D15 | Integration key rotation | two accepted key slots | zero-downtime rotation |
| D16 | Departments | exactly seven: Restorative Dentistry, Endodontics, Orthodontics, Periodontics, Pediatric Dentistry, Prosthodontics, Oral Surgery; migration 0003 deletes any other completely and refuses (changing nothing) if a doomed department still has appointments | your request of 30 Oct 2026 |
| D17 | Removing a department working day that has future appointments | refused with `409 WORKING_DAYS_HAVE_APPOINTMENTS` and the count, unless the dashboard resends it acknowledged; existing appointments are never cancelled automatically | protects patients; staff decide what to do with each booking |
| D18 | Lock-out recovery for the only administrator | `docker compose run --rm reset-admin-password` (forces a password change, closes the sessions, audited) | admin accounts can only be created by the bootstrap command, so a forgotten password would otherwise need manual SQL |

## Questions for you (still open; none blocks the system from running)

1. **Which weekdays is the center open?** (Default: every day. Is Friday closed?)
2. **Default website language?** (Default: Arabic.)
3. **OK to require full name at registration** in addition to phone + password?
4. **Where does your n8n run?** On the same Windows machine in Docker Desktop, on a VPS, or n8n Cloud?
   This decides how it reaches the backend. n8n Cloud cannot reach `localhost`; it needs the backend on a public
   HTTPS URL, which is available only after VPS deployment (or a tunnel for testing).
5. ~~Admin dashboard during the reference wait~~ — done that way (the dashboard was built while waiting).
6. **The patient-website design reference** (still not supplied).

## Genuine blockers

- **None for Phases 2–3 code.**
- **Environment limitation:** no Docker daemon in this sandbox. Docker build/run/health/persistence checks (spec
  §17.6) cannot be executed here. `scripts/verify-docker.ps1` runs that checklist on your machine and prints pass/fail (it uses a
  separate throw-away project, so your data is untouched); those items stay *not verified* until you run it and share the report.
- **Needed later:** patient-website design reference (Phase 4 checkpoint); real center address, phone, dentist names,
  services, prices and approved gallery images (all optional for development, required before go-live).

## Working agreements

- Real code, real tests, real output only. No fabricated results.
- Every business rule above has a test ID in `docs/TESTING.md` before its code is written.
- Docs are updated in the same change as the code they describe.
- No destructive commands; no touching anything outside `dental-center-management/`.
