# Test plan and how to run the tests

Nothing in this file claims a result that was not produced by a real run. The latest verified results are in
[`PROJECT_STATUS.md`](PROJECT_STATUS.md) §2; what could **not** be run here is in §3 of the same file.

## What exists

| Layer | Tool | Where | What it needs | Count (2 Nov 2026) |
|---|---|---|---|---|
| Backend unit + integration | Vitest, Fastify `inject`, **real PostgreSQL 16** (no database mocking; every run applies the migrations to a fresh database) | `backend/tests/` | Node 22 and a PostgreSQL server (`TEST_DATABASE_ADMIN_URL`, default `postgres://postgres@127.0.0.1:54329/postgres`) | 203 tests in 15 files |
| Concurrency | same, parallel requests on separate connections | `backend/tests/integration/concurrency.test.ts` | same | included above |
| Backup/restore | real `pg_dump` / `pg_restore` | `backend/tests/integration/backup-restore.test.ts`, `scripts/tests/test-backup-scripts.sh` | PostgreSQL client tools | 5 tests + 25 checks |
| Frontend | Vitest + jsdom + Testing Library, fake backends | `frontend/tests/` | Node 22 | 216 tests in 10 files |
| n8n | `node --test`, request/response simulator, exported workflows executed by a simulator | `integrations/n8n/test/` | Node 22 | 35 tests |
| n8n in a real n8n | `integrations/n8n/test/real-n8n-check.cjs` (manual) | | an installed n8n + a running backend | 34 checks (run once, see `N8N_INTEGRATION.md` §11) |
| Browser | Playwright (Chromium) against a **real backend + the real web-container nginx configuration + a fresh database** | `e2e/` | `scripts/e2e-local.sh` (nginx, PostgreSQL, built apps) | 61 tests (desktop + phone) |
| HTTP smoke | `scripts/smoke-api.mjs` | | a running stack | 27 checks |
| Docker journey | `scripts/verify-docker.ps1` (spec 17.6, DOCK-01..12) on **your** machine | | Docker Desktop | **not run in the build environment** |

An injectable `Clock` makes the 24-hour boundary, midnight and the daylight-saving nights testable (the backend test clock is
fixed at Monday 2 November 2026, 10:00 Cairo time).

## How to run everything

```sh
# backend (needs PostgreSQL; if you have none: scripts/e2e-local.sh shows the variables it expects)
npm --prefix backend ci
TEST_DATABASE_ADMIN_URL=postgres://postgres@127.0.0.1:5432/postgres npm --prefix backend test
npm --prefix backend run typecheck

# frontend
npm --prefix frontend ci
npm --prefix frontend test
npm --prefix frontend run build          # type-check + production build

# n8n
npm --prefix integrations/n8n ci && npm --prefix integrations/n8n test
node integrations/n8n/build.cjs --check  # exported workflows are what the sources generate

# backup scripts (real PostgreSQL, no Docker needed)
bash scripts/tests/test-backup-scripts.sh

# browser tests (needs nginx, PostgreSQL, Playwright's Chromium; builds must exist)
npm --prefix backend run build && npm --prefix frontend run build
scripts/e2e-local.sh                                            # everything
scripts/e2e-local.sh --project=desktop-chromium -g "working days"   # a subset

# API smoke test against a running stack (27 checks; creates two "ZZ Smoke ..." patients: use a throw-away stack).
# Passed against the local backend + nginx stack; against the Docker stack it is run by verify-docker.ps1
node scripts/smoke-api.mjs http://localhost:8480

# Docker journey on Windows (isolated copy; never touches your data)
powershell -ExecutionPolicy Bypass -File .\scripts\verify-docker.ps1
```

The browser tests register at most five patients per run because the production registration limit (10 per hour per address) applies to
them: wait an hour or restart the throw-away stack before running them many times. They create patients called "E2E ..."; never point
them at the real clinic.

Where a test needs a time-dependent rule it injects its own clock; tests that touch the database use their own database
(`dc_test_<random>`, dropped afterwards) and never the clinic's.

## Mutation checks

For the most important rules a test is only trusted after it has been seen to fail: the code is temporarily broken, the test must go red, and
the code is restored. Done for: working-days enforcement and its race, the duplicate-error fix on the forms, blank environment values,
the administrator password reset, the 24-hour boundary and the booking constraints.

## Test catalogue

IDs are referenced from `REQUIREMENTS.md` and appear in the titles of the tests that implement them (`grep -rn BOOK-11 backend/tests`). Cases whose title does not carry the literal ID: AUD-02 → `db.test.ts` ("AUD: the audit log is append-only …"); I18N-01 → `frontend/tests/i18n.test.ts` (key parity, no empty text, same placeholders) and the TypeScript compiler (`defineMessages`); I18N-03/04/05 → `e2e/tests/04-languages.spec.ts` and `e2e/tests/mobile.layout.spec.ts`.

### Authentication (spec 17.1)

| ID | Case |
|---|---|
| AUTH-01 | Register with valid phone/password/name creates a patient, returns no hash |
| AUTH-02 | `01012345678`, `+201012345678`, `0020 101 234 5678` and Arabic-Indic digits normalize to one E.164 value; second registration rejected |
| AUTH-03 | Weak/short password rejected with localized-key error code |
| AUTH-04 | Valid login sets HttpOnly cookie; wrong password and unknown phone return the same generic error |
| AUTH-05 | Stored hash is Argon2id and not the plaintext |
| AUTH-06 | Logout revokes the session; cookie no longer works |
| AUTH-07 | Expired session (absolute and idle) rejected |
| AUTH-08 | Login rate limit triggers after N failures per IP and per phone |
| AUTH-09 | State-changing request without CSRF token or with foreign `Origin` rejected |
| AUTH-10 | Admin bootstrap creates exactly one admin, is idempotent, never logs the password |
| AUTH-11 | Fresh admin can only call change-password/me/logout until password changed |
| AUTH-12 | Patient cookie cannot call admin routes; admin cookie cannot call patient routes |
| AUTH-13 | Patient A cannot read/cancel patient B's appointment by ID (404, not 403) |
| AUTH-14 | Staff-assisted reset: admin only; new password works, old fails, patient sessions revoked, audit event without password |
| AUTH-15 | No unauthenticated password-reset route exists (route table assertion) |

### Booking (spec 17.2)

| ID | Case |
|---|---|
| BOOK-01 | Each of the 4 slots can be booked |
| BOOK-02 | 4 bookings in one department/day succeed; 5th rejected |
| BOOK-03 | Same day, different departments: independent capacity |
| BOOK-04 | Duplicate slot in same department rejected (`SLOT_UNAVAILABLE`) |
| BOOK-05 | Overlap impossible: slot numbers are the only bookable units |
| BOOK-06 | Booking in the past rejected; booking a slot that already started today rejected |
| BOOK-07 | Slot 4: `starts_at` 22:00 Cairo, `ends_at` 00:00 next day, `appointment_date` = start date, duration 2 h |
| BOOK-08 | Cancelling releases slot and capacity; slot can be re-booked |
| BOOK-09 | Completed appointment keeps its slot on its date and does not affect other dates |
| BOOK-10 | Reschedule to a free slot succeeds; to a taken slot rejected, original untouched |
| BOOK-11 | Cancel/reschedule at 24:00:01, 24:00:00 before start allowed; at 23:59:59 rejected (patient) |
| BOOK-12 | Admin override inside 24 h requires reason, succeeds, audited |
| BOOK-13 | Inactive department / closed date: no slots offered, booking rejected |
| BOOK-14 | Illegal status transitions rejected (e.g. cancelled → booked) |
| BOOK-15 | Patient overlap across departments rejected (D7) |
| BOOK-16 | Fall-back night (29 Oct 2026) and spring-forward night (23 Apr 2026): slot 4 is exactly 2 real hours, still one appointment-date, capacity unaffected |
| BOOK-17 | Beyond booking horizon rejected |
| CONC-01 | 20 parallel requests for the same slot → exactly 1 success, 19 `SLOT_UNAVAILABLE`, 1 row |
| CONC-02 | Parallel requests competing for the last remaining capacity → never more than 4 active rows |
| CONC-03 | Parallel cancel + book on the same slot leaves a consistent state |
| ERR-01 | Backend error mid-transaction leaves no partial row (forced failure) |

### Medical records (17.3)

| ID | Case |
|---|---|
| MED-01 | Admin can create/read/update records; authorship + timestamps set |
| MED-02 | Unauthenticated → 401; patient session → 403/404; integration key → 403/404 |
| MED-03 | Unknown record ID gives the same response as a record the caller cannot see |
| MED-04 | Clinical fields never appear in public, patient or integration responses nor in captured logs |
| MED-05 | Create/update emits audit events with no clinical text in metadata |

### Audit and database

| ID | Case |
|---|---|
| AUD-01 | Listed actions each emit an event with actor, entity, outcome |
| AUD-02 | `UPDATE`, `DELETE`, `TRUNCATE` on `audit_events` fail |
| AUD-03 | Secrets and passwords never appear in audit metadata (redaction test) |
| DB-01 | Migrations apply to an empty DB; re-run is a no-op; altered applied migration aborts |
| DB-02 | Seeds are idempotent (run twice, same row counts) |
| DB-03 | Constraints: slot range, duration, gallery publish needs consent + real case |

### Localization (17.4)

| ID | Case |
|---|---|
| I18N-01 | Every UI key exists in ar/en/fr for both apps (automated key diff) |
| I18N-02 | Public API returns content in the requested locale with the documented fallback; never a raw key |
| I18N-03 | `dir`/`lang` switch on language change; Arabic layout renders RTL (browser test) |
| I18N-04 | Date/time rendering per locale keeps Cairo zone |
| I18N-05 | Long French labels do not break layouts on a 360 px viewport (browser test) |

### n8n / Telegram (17.5)

| ID | Case |
|---|---|
| INT-01 | Missing/wrong key → 401; correct key → 200; either rotation slot accepted |
| INT-02 | Availability via integration equals availability via website |
| INT-03 | Booking via integration needs a linked Telegram user; unlinked → `TELEGRAM_NOT_LINKED` |
| INT-04 | Link token is single-use, expires after 10 minutes, stored hashed |
| INT-05 | Telegram user cannot read or cancel another patient's appointment |
| INT-06 | Cancel/reschedule via integration obeys the 24 h rule |
| INT-07 | Website booking and Telegram booking compete for the same capacity |
| INT-08 | Revoking a link blocks further personal operations immediately |
| INT-09 | Integration key cannot reach admin or medical-record routes |
| INT-10 | Center profile from integration endpoint equals the public endpoint |


### Department working days and the seven departments (user change request, 30 Oct 2026)

| ID | Case | Test |
|---|---|---|
| WD-01 | Every seeded department works every day until edited; days are saved sorted, deduplicated and shown on admin and public views | `department-working-days.test.ts` |
| WD-02 | Empty list, unknown weekday, non-integers refused; nothing changes; only an administrator can change them; audited | same |
| WD-03 | Days off are `closed` with no slots; booking on one → `DEPARTMENT_NOT_WORKING_DAY`; working days stay open | same |
| WD-04 | Same rule for admin booking, Telegram booking and reschedule (reschedule onto a day off leaves the appointment untouched) | same |
| WD-05 | Effective days = center ∩ department; closures still apply; switching a day back on works at once | same |
| WD-06 | Removing a day with booked appointments → `409 WORKING_DAYS_HAVE_APPOINTMENTS` with the count until acknowledged; nothing is auto-cancelled; cancelled/finished/other-weekday/other-department appointments are not counted | same |
| WD-07 | 8 racing bookings against an unconfirmed switch-off, 6 rounds: never a booking on a switched-off day | same |
| WD-08 | Migration 0003: adds the column, keeps the seven, deletes others completely (translations, dentist, services, gallery, closures), refuses and rolls back if a doomed department has appointments | `db.test.ts` (DB-01b) |
| WD-09 | Dashboard: weekday picker, the two-step acknowledge flow, card summary, center days | `frontend/tests/admin-catalog.test.tsx`, `admin-settings.test.tsx` |
| WD-10 | Patient site: working days shown, only open days offered, stale-slot handling | `frontend/tests/patient-app.test.tsx` |
| WD-11 | Telegram: `/departments` shows `(works: …)`, the new refusal is explained in all three languages | `integrations/n8n/test/telegram-commands.test.cjs` |
| WD-12 | A real browser: set days in the dashboard, see them on the website and in the booking calendar, refused on a day off | `e2e/tests/03-working-days.spec.ts` |

### Operations added during QA

| ID | Case | Test |
|---|---|---|
| OPS-03 | Blank `.env` entries (what Docker Compose passes) mean "not set"; blank required values still fail | `backend/tests/unit/config.test.ts` |
| OPS-04 | Lock-out recovery: reset replaces the password, forces a change, closes sessions, is audited, unknown user changes nothing | `backend/tests/integration/auth.test.ts` |
| OPS-05 | Backup scripts keep the whole migration history through backup → restore → rollback | `scripts/tests/test-backup-scripts.sh` |
| UI-01 | A form failure shows one message (field or banner), not two | `frontend/tests/patient-app.test.tsx`, `e2e/tests/01-patient-journey.spec.ts` |

### Patient website redesign (2 November 2026)

| ID | Case | Test |
|---|---|---|
| PX-01 | The seed sets each department's picture path (to a file that exists in `frontend/public`) only when the department is created, and never overwrites an administrator's change or an emptied field | `backend/tests/integration/db.test.ts` (2 tests) |
| PX-02 | Home: the evening timeline is drawn from the center's real slots and working days; department index with working days and a booking link that carries the department; the next appointment only for a signed-in patient | `frontend/tests/patient-redesign.test.tsx`, `e2e/tests/06-patient-experience.spec.ts` |
| PX-03 | Pictures come from the API path, a missing file is dropped (no broken icon), no section when none is left; the department example is shown uncropped; the real pictures load at their own size | `frontend/tests/patient-redesign.test.tsx`, `e2e/tests/06-patient-experience.spec.ts` |
| PX-04 | The booking calendar asks for the whole booking period counted from today in the **center's** zone, offers only days the API calls `open`, says so when nothing is bookable, starts the week on Saturday (Arabic) or Monday; date helpers (month grid, leap years, zones, digits) | `frontend/tests/patient-redesign.test.tsx`, `frontend/tests/patient-dates.test.ts`, `e2e/tests/06-patient-experience.spec.ts` (days equal the API's open days) |
| PX-05 | Optional service is sent with the booking; the chosen department is in the address; rescheduling uses the same real calendar and sends only the new day and slot | `frontend/tests/patient-redesign.test.tsx` |
| PX-06 | Patient-precautions picture with its text (also in French), in the booking flow, after booking, and from My appointments; the note field still says not to write medical details | `frontend/tests/patient-redesign.test.tsx`, `e2e/tests/06-patient-experience.spec.ts` |
| PX-07 | Section 10: the 30 names exactly as given and in order, compact wrapping chips (each only as wide as its name, no list markers), both "منه الله" present with different tones, last on every public page | `frontend/tests/patient-redesign.test.tsx`, `e2e/tests/06-patient-experience.spec.ts` |
| PX-08 | Telegram is a link to the bot only (new tab, `noopener`), no chat on the site; no logo and no video by default (empty places, no stand-ins); a configured logo/video is used without other changes; muted/looped video and poster for reduced motion | `frontend/tests/patient-redesign.test.tsx`, `e2e/tests/06-patient-experience.spec.ts` |
| PX-09 | Arabic home is right-to-left with no English fallback strings; brand and hero text sit on the correct side; tablet width (820 px) has no horizontal scroll in ar/en/fr; keyboard selection of day and time; reduced motion stops the one self-running animation | `frontend/tests/patient-redesign.test.tsx`, `e2e/tests/06-patient-experience.spec.ts`, `e2e/tests/mobile.layout.spec.ts` |
| SEC-HDR | Through the real nginx configuration every page and every proxied API answer (200, 401, 404, the integration location) carries each security header exactly once, no HSTS, no `X-Powered-By`, `X-Frame-Options: DENY`; API answers are `no-store` | `e2e/tests/05-http-headers.spec.ts` (11 tests) |

### Operations

| ID | Case |
|---|---|
| OPS-01 | `pg_dump` custom-format backup verifies with `pg_restore --list`; restores into an isolated DB with identical row counts |
| OPS-02 | Startup fails with clear errors when required env vars are missing/invalid (production mode) |
| DOCK-01..12 | Spec 17.6 checklist, executed by `scripts/verify-docker.ps1` on the user's machine (build, start, healthy, migrations, ready, site served, real booking, persisted in PostgreSQL, visible to patient and admin, stop/start persistence, backup + safe restore + live restore on the throw-away copy, stop without deleting the volume). **Not run in the build environment.** |

### Browser journeys (17.7)

Implemented in `e2e/` and run for real (61 tests, 2 November 2026): HTTP security headers through the real nginx (SEC-HDR); patient register/login/book/view/cancel/reschedule; admin login with forced password change, appointment management, patients and medical records, department working days; language switching and right-to-left in all three languages; phone-size layouts (393 px) of the patient site and the dashboard in ar/en/fr; the patient redesign (`06-patient-experience.spec.ts`: the supplied pictures load at their own size, Section 10 chips, the Telegram link, the empty logo/video places, right-to-left placement, reduced motion, the evening timeline from the real slots, tablet width in three languages, the calendar offering exactly the days the API calls open, keyboard selection). Only Chromium was used; Firefox, Safari and real devices were not.
