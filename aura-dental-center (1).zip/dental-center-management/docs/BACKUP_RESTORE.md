# Backup and restore

The only thing that needs backing up is the **PostgreSQL database** (patients, appointments, medical records, settings,
audit log). Images you added live in `frontend/public/assets/` (copy that folder too); your `.env` holds the secrets and
should be kept safely **separately** from backups (a backup file contains patient data; `.env` contains keys).

> A backup that stays on the same computer is lost with that computer. After every backup copy the file to another disk,
> a USB drive or private cloud storage. Backup files contain personal and medical data: protect them like the database.

## Make a backup

| System | Command | Result |
|---|---|---|
| Windows PowerShell | `.\scripts\backup.ps1` | `backups\dental-center-YYYYMMDD-HHMMSS.dump` + `.sha256` |
| Linux / VPS | `sh scripts/backup.sh` | same |

Options: `-Keep 30` / `KEEP=30` (how many to keep; default 14, `0` = keep all), `-BackupDir D:\clinic-backups` /
`BACKUP_DIR=/mnt/usb`. The database container must be running (`docker compose up -d`).

The script only says "Backup OK (verified)" after it (1) wrote the dump with `pg_dump --format=custom`, (2) read it back with
`pg_restore --list`, (3) copied it out of the container with an identical byte size and (4) wrote a SHA-256 checksum. A failure
at any step deletes the incomplete file and exits with an error, so a half-written file is never mistaken for a backup.
Making a backup does not stop the site or lock bookings.

Suggested routine: a backup at the end of every working day and **always before an update** (`DEPLOYMENT.md` A5). Scheduling
(Windows Task Scheduler / cron) is described in `DEPLOYMENT.md`; nothing is scheduled automatically.

## Check a backup without touching real data (do this regularly)

```powershell
.\scripts\restore.ps1 .\backups\dental-center-20261101-020000.dump
```
```sh
sh scripts/restore.sh backups/dental-center-20261101-020000.dump
```

This is the **default and safe** mode: the file's checksum is verified, the backup is restored into a temporary scratch
database (`<name>_restore_check`), a table-by-table row-count comparison "in backup / live now" is printed, and the scratch
database is deleted. The live database is never modified and the application keeps running. It ends with `RESTORE CHECK PASSED`
or an explicit failure.

## Restore for real (replaces the live data)

Use only when the live database is damaged or you need to go back in time.

```powershell
.\scripts\restore.ps1 .\backups\dental-center-20261101-020000.dump -Live
```
```sh
sh scripts/restore.sh backups/dental-center-20261101-020000.dump --live
```

What happens, in order, and why it is safe to try:

1. You must **type the database name** to confirm (or set `DC_CONFIRM=<name>` / `-ConfirmDatabase <name>` in automation). Anything
   else aborts with no change.
2. A **pre-restore backup of the current data** is taken (`backups/pre-restore-*.dump`). If that fails, nothing is changed.
   Retention never deletes pre-restore backups.
3. The backend and web containers are stopped.
4. The database is dropped and recreated, and the backup is loaded (`pg_restore --exit-on-error`).
5. Pending migrations are applied (a backup from an older version is brought up to date; see the note below), and the backend
   and web are started again. Row counts are printed.

If any step fails the application is left **stopped** and the script prints the pre-restore backup and the exact command to roll
back (`restore ... --live` with that file). Everything entered after the backup was made is gone from the live database; that is the
purpose of a restore, so check the date of the file first.

Note for backups made before the seven-department change (migration 0003): restoring such a backup applies migration 0003, which
deletes departments outside the seven and refuses (with a message, changing nothing) if one of them has appointments.

## If the whole server/PC is lost

1. Install Docker, copy the project folder and your saved `.env` (the **same** `POSTGRES_PASSWORD`/keys are not required for the
   data, but `PUBLIC_APP_URL` and the integration key are).
2. `docker compose up -d --build` creates a new empty database.
3. `scripts/restore.* <backup file> -Live` (confirm with the database name) loads the data.
4. Copy back `frontend/public/assets/`.
5. Sign in with your existing administrator account (it is part of the backup; `bootstrap-admin` does nothing if one exists).

## What has been tested, and what has not

Run for real in the development environment (real PostgreSQL 16 `pg_dump`/`pg_restore`):

- `backend/tests/integration/backup-restore.test.ts` (5 tests): a custom-format dump is readable and contains the data; a truncated or
  corrupted dump is detected by the verification step; restoring into a separate database gives an identical fingerprint of
  every table (all columns); the restored database keeps its constraints, triggers and audit immutability; the application
  (patients' original passwords, appointments, booking rules) works on the restored database.
- `scripts/tests/test-backup-scripts.sh` (25 checks) runs the real `backup.sh` / `restore.sh` shell scripts against a real
  PostgreSQL with a test double instead of `docker compose`: backup verification, checksum, retention, safe-check mode, rejection
  of truncated/text/mismatching/missing files, confirmation prompt, live restore, pre-restore backup, order "stop → migrate →
  start" and rollback with the pre-restore backup.

**Not tested:** the PowerShell versions (`backup.ps1`, `restore.ps1`) have never been executed (no PowerShell here); they mirror the
shell scripts line by line. `docker compose cp`/`exec` with the real containers has not been run. On Windows, `docker compose cp`
needs a normal path such as `backups\file.dump`; if a backup fails at the copy step, see `TROUBLESHOOTING.md`. `scripts/verify-docker.ps1`
exercises backup and restore against a throw-away copy of the stack on your machine; run it once after installing.
