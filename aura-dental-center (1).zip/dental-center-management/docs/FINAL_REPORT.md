# Final report

Written 1 November 2026, after the last full test run. It answers the fifteen points of §23 of the master specification. Every number
below comes from a run in the development environment; anything that could not be run says so (section 12). Details live in the
documents linked in each section.

## 1. What was built

- **Patient website** (Arabic RTL / English / French): browse the seven departments, register with phone + password only, book,
  cancel, reschedule, account, Telegram linking code. Premium white and color-wheel design (2 November 2026) with a calendar over the real availability, the supplied department pictures and precautions picture, a quiet Telegram link and Section 10 contributors. Functional and responsive; **the official logo and the hero video were not supplied, so their places are empty.**
- **Admin Dashboard** (separate app at `/admin/`): appointments, patients (staff-assisted password reset), medical records (admin only),
  departments with **configurable working days**, dentists, services, gallery, center settings (address, contact, center working days,
  slots, closed dates), audit log.
- **REST API** (Fastify, Node 22, TypeScript) with OpenAPI, **PostgreSQL 16** with three forward-only migrations, **Docker Compose**
  stack with a one-shot migration job, backup/restore scripts, and **n8n workflows** (API tool workflow + Telegram commands) for your existing n8n.
- Your last request is implemented: exactly seven departments (others deleted completely by migration 0003), working days editable
  per department and for the whole center, and they control availability and booking on the website, the dashboard and Telegram.

## 2. Architecture and technology

nginx (serves both apps, proxies `/api/`) → Fastify backend → PostgreSQL; n8n calls `/api/v1/integrations/*` with a bearer key.
Node 22, TypeScript, Fastify 5, zod, `pg` (hand-written SQL), argon2id, luxon; React 19, React Router 7, Vite; Vitest, Playwright.
Reasons for each choice and the booking transaction: [`ARCHITECTURE.md`](ARCHITECTURE.md), [`BOOKING_RULES.md`](BOOKING_RULES.md).

## 3. Folder structure

```
dental-center-management/
├── README.md  docker-compose.yml  .env.example  .gitignore  .dockerignore
├── backend/        Dockerfile, src/ (config, database, lib, middleware, modules/*, cli), tests/ (unit + integration)
├── frontend/       Dockerfile, nginx/ (default.conf + snippets), src/ (patient, admin, shared), tests/, public/assets/ (empty picture folders)
├── database/       migrations/ (0001, 0002, 0003), seeds/catalog.sample.json
├── integrations/n8n/  workflows/ (2 exported workflows), src/, test/, build.cjs
├── e2e/            Playwright browser tests
├── scripts/        backup/restore (.sh/.ps1), new-secret, verify-docker.ps1, smoke-api.mjs, e2e-local.sh, run-local-web.sh, tests/
└── docs/           all documentation (index in PROJECT_DOCUMENTATION.md)
```

## 4. Database and migrations

20 application tables (plus the migration bookkeeping table), three migrations, all applied to an empty database on every test run. Booking safety is enforced by the database as well as the
code (unique index for an active slot, exclusion constraints against overlaps, a status-guard trigger); audit events are append-only.
Migration 0003 adds `departments.working_days`, keeps exactly the seven departments and deletes the rest completely, and **stops without
changing anything** if a department it would delete still has appointments. [`DATABASE.md`](DATABASE.md).

## 5. Docker services and URLs

`db`, `migrate` (job), `backend`, `web`; on demand `bootstrap-admin` and `reset-admin-password`. Compose project `dental-center`,
volume `dental_center_pgdata`. Only the website is published: `http://localhost:8480/` (patients), `http://localhost:8480/admin/` (staff),
bound to this computer unless you change `WEB_BIND`. The database and the backend are not published.

## 6. PowerShell commands (initial setup and start)

```powershell
Copy-Item .env.example .env
powershell -ExecutionPolicy Bypass -File .\scripts\new-secret.ps1      # run twice: database password, n8n key
notepad .env                                                           # fill in the CHANGE_ME values
docker compose up -d --build
docker compose ps                                                      # wait for "healthy"
docker compose run --rm bootstrap-admin                                # first administrator (forced password change at first sign-in)
```

Optional, recommended first: `powershell -ExecutionPolicy Bypass -File .\scripts\verify-docker.ps1` (isolated copy; your data is untouched).

## 7. Configuring your existing n8n

Create the key (`INTEGRATION_API_KEY`), import the two workflow files from `integrations/n8n/workflows/`, create the two credentials,
set the `baseUrl` in the `Config` node (it depends on where your n8n runs), then link a Telegram chat to a patient from the website's
account page. Step by step, including key rotation: [`N8N_INTEGRATION.md`](N8N_INTEGRATION.md).

## 8. Center address and public details

Admin Dashboard → **Settings → Center**: name, address (three languages), phone, WhatsApp, email, map link, working days, default
language. One database row feeds the website, the dashboard and the Telegram assistant; nothing is hard-coded.

## 9. Department and gallery images

Copy files into `frontend/public/assets/departments/` (and `gallery/`, `services/`, `branding/`), then enter the path (for example
`/assets/departments/endodontics.jpg`) in the dashboard. No image is shipped; a missing file shows nothing. File names, sizes and the
consent rules for real patient photos: [`IMAGE_ASSETS.md`](IMAGE_ASSETS.md).

## 10. Running the tests

```sh
TEST_DATABASE_ADMIN_URL=postgres://postgres@127.0.0.1:5432/postgres npm --prefix backend test
npm --prefix frontend test
npm --prefix integrations/n8n test
bash scripts/tests/test-backup-scripts.sh
scripts/e2e-local.sh                       # browser tests; build backend and frontend first
powershell -ExecutionPolicy Bypass -File .\scripts\verify-docker.ps1     # on Windows, with Docker Desktop
```

## 11. Tests that actually passed (2 November 2026)

| Suite | Result |
|---|---|
| Backend (real PostgreSQL 16; concurrency, 24 h boundary, midnight and DST nights, authorization isolation, working days, migrations, backup/restore) | **203 / 203**, typecheck clean |
| Frontend (components, all three languages, working-days screens) | **216 / 216**, typecheck clean, production build OK |
| n8n workflows and Telegram commands | **35 / 35**; exported workflows identical to the sources |
| Backup/restore scripts against a real database | **25 / 25** |
| Browser (Chromium; real backend + real nginx configuration + fresh database; desktop and 393 px phone) | **61 / 61** |
| API smoke script against a local stack | **passed** (26 pass, 1 skipped by design) |
| `docker compose config` | valid (4 default services, 2 tool services) |

Mutation checks (break the code, see the test fail, restore) were done for working-days enforcement, the duplicate-error fix, blank
environment values, admin password reset, and the header fix (the header test failed before the fix and passes after).

Problems the testing found and that are fixed: duplicated and conflicting security headers on every API answer (nginx + backend),
the bootstrap-admin command not receiving its password from `.env`, blank `.env` entries stopping the backend, no recovery for a locked-out
sole administrator, a duplicated error message on forms, a hard-coded migration count in a test.

## 12. Not run or not verified, and why

| Item | Why |
|---|---|
| Docker image builds, container start-up, health checks, volume persistence, the nginx-unprivileged runtime | No Docker daemon in the development environment; Docker Hub and the Docker download site are blocked. The nginx configuration itself *was* run. |
| `verify-docker.ps1`, `backup.ps1`, `restore.ps1`, `new-secret.ps1` | No PowerShell available. The shell equivalents of backup/restore were tested. |
| Real Telegram; persistence inside an active n8n; working days inside the real n8n | No bot token or Telegram access. The real-n8n check (34 checks) pre-dates the working-days change. |
| VPS installation and the HTTPS proxy examples | No server. |
| Accessibility audit (axe/Lighthouse, screen reader), Firefox/Safari/real phones | Only Chromium was available; no audit tool was run. |
| Dependency and image vulnerability scan, external security review | Not performed. |
| Load testing beyond the concurrency tests | Not performed. |

## 13. Known limitations and unfinished items

- **Patient website:** the official logo and the hero video were not supplied (empty places, nothing invented). The supplied before/after pictures are low resolution (about 400 px wide) and are shown at their own size, never enlarged. The contributors' names are used as given (the two "منه الله" are separate entries).
- No OTP/SMS and no two-factor for administrators (by specification); one database role; rate limits are in memory and reset on restart.
- Center-wide working-day changes apply immediately without the confirmation step that departments have.
- Administrator accounts are created only by the bootstrap command (no screen); no image upload screen; no backup screen in the dashboard.
- Medical records can be created and edited, not deleted. Departments can be deactivated in the dashboard, not deleted.
- A patient cannot hold two overlapping appointments in different departments (decision D7; easy to remove).

Full list: [`PROJECT_STATUS.md`](PROJECT_STATUS.md) §3–4, [`SECURITY.md`](SECURITY.md).

## 14. Backup and restore

Backup: `.\scripts\backup.ps1` (or `sh scripts/backup.sh`): writes a verified custom-format dump plus a checksum, without stopping the
site. Check a backup safely (restores into an isolated throw-away database, never the live one): `.\scripts\restore.ps1 <file>`.
Restoring over the live database is a separate, explicit, confirmed step that first takes a safety backup and can be rolled back.
[`BACKUP_RESTORE.md`](BACKUP_RESTORE.md). Never run `docker compose down -v`.

## 15. Deploying to a VPS later

Install Docker, copy the project, create `.env` with `PUBLIC_APP_URL=https://your-domain`, `COOKIE_SECURE=true` and strong secrets, run
`docker compose up -d --build`, then `bootstrap-admin`. Put a reverse proxy with HTTPS (Caddy or nginx examples provided) in front of port
8480, set HSTS there, pass the real visitor address on (`real-ip.conf`), and schedule backups. For n8n Cloud the API needs a public HTTPS
address. [`DEPLOYMENT.md`](DEPLOYMENT.md) §B (the VPS part was not run).

## Questions that still need your answer

1. The **official logo** and the **hero background video** (and whether the supplied before/after pictures show real patients, which needs their consent to stay public).
2. Which weekdays is the center open? (All seven until you set them in the dashboard.)
3. Default language (assumed Arabic) and full name at registration (assumed required).
4. Where does your n8n run (same PC in Docker Desktop, another machine, VPS, n8n Cloud)?
5. Real center details, dentist names, services, prices and pictures (all optional to start).
