# n8n + Telegram integration

This connects the **existing** n8n instance (the one that already runs your Telegram assistant) to the Dental Center backend. Nothing new is deployed for n8n: you import two workflows, add two credentials and set one URL.

The principle: **the backend owns every rule** (opening hours, 4 slots, 4 appointments per department per day, no double booking, 24-hour cancel/reschedule limit, linking). n8n is only a messenger. It cannot book a slot the website would refuse, and it never says "done" unless the backend answered with success.

Status of what is described here: see [§11 What has and has not been verified](#11-what-has-and-has-not-been-verified).

---

## 1. What is provided

| File | Purpose |
|---|---|
| `integrations/n8n/workflows/dental-center-telegram-commands.workflow.json` | Telegram bot with fixed commands (`/info`, `/book`, `/my`, …) in Arabic, English and French. Works on its own, no AI needed. |
| `integrations/n8n/workflows/dental-center-api.workflow.json` | Sub-workflow "Dental Center - API". One call = one validated, authenticated request to the backend. Use it as a tool from your AI agent. |
| `integrations/n8n/src/*.js` | The logic that is embedded in the Code nodes, as plain tested JavaScript. |
| `integrations/n8n/build.cjs` | Regenerates the two JSON files from `src/`. `node build.cjs --check` fails if they have drifted. |
| `integrations/n8n/test/*.test.cjs` | 35 automated tests (see §11). |
| `integrations/n8n/test/real-n8n-check.cjs` | Manual check that runs the exported workflows inside a **real n8n** against a **real backend** (see §11). |
| `docs/openapi.json`, `docs/API_REFERENCE.md` | The backend side of every call (tag **Integration (n8n)**). |

The workflow files contain **no keys, no bot tokens, no addresses**. Credential ids are empty on purpose: you pick your own after importing.

## 2. How it fits together

```
Patient (Telegram, private chat)
        │  message
        ▼
  n8n  ── Telegram Trigger ── Parse command (Code) ──┐
                                                      │ needs data?
                                                      ▼
                              HTTP Request  ──►  Dental Center backend  ──►  PostgreSQL
                              Authorization: Bearer <integration key>       (rules enforced here)
                                                      │
        Format reply (Code) ◄──────── JSON {data} or {error:{code}}
        │
        ▼
  Send reply (Telegram)
```

* The integration key only opens `/api/v1/integrations/*`. It cannot reach admin routes, medical records or password data.
* A Telegram account can act on appointments **only after it is linked** to a patient account (§5). Without a link every personal operation is refused with `TELEGRAM_NOT_LINKED`.
* The center address, phone and hours are read from `GET /center` every time. They are not written in any workflow or prompt, so changing the address in the admin dashboard changes what the bot says.

## 3. Set up (once)

### 3.1 Create the integration key

PowerShell (Windows):

```powershell
.\scripts\new-secret.ps1 32
```

Linux / macOS / Git Bash:

```sh
sh scripts/new-secret.sh 32
```

Put the result in `.env`:

```
INTEGRATION_API_KEY=<the value>
```

then restart the backend so it reads it: `docker compose up -d backend`.
Empty `INTEGRATION_API_KEY` = integration switched off (every call answers `503 INTEGRATION_DISABLED`).

### 3.2 Create two credentials in n8n

1. **Header Auth**, name it exactly `Dental Center API key`
   * Name: `Authorization`
   * Value: `Bearer <the same key>` (the word `Bearer`, one space, the key)
2. **Telegram API**, name it `Telegram bot`, with the token of the bot you will use (from @BotFather). Skip this if you reuse your existing Telegram credential.

### 3.3 Import the workflows

n8n → **Workflows → Import from file**, once per file. Then in each imported workflow:

1. Open every node that shows a credential warning (both HTTP Request nodes, Telegram Trigger, Send reply) and select your credential. The two HTTP Request nodes ("…API" and "…API (JSON body)") are intentional: n8n cannot switch a request body on and off with an expression, so requests with and without a body use separate nodes, chosen by the **Has body?** node. Give both the same credential.
2. Open the **Config** node and set `baseUrl` (see §4).
3. Save, then switch **Active** on.

(CLI alternative: `n8n import:workflow --input=<file>`.)

### 3.4 Check the connection

Before testing from Telegram, confirm n8n can reach the backend. In n8n open the API sub-workflow, execute it manually with the input `{"operation":"center"}`. The result must be `ok: true` with your center data.

## 4. The base URL (`Config` node)

`baseUrl` must end with `/api/v1/integrations` (no trailing slash). The backend is published only through the website container (port `WEB_PORT`, default 8480), so pick the line that matches where n8n runs:

| n8n runs… | `baseUrl` |
|---|---|
| In Docker Desktop on the same Windows PC as the Dental Center (default shipped in the files) | `http://host.docker.internal:8480/api/v1/integrations` |
| Directly on the same machine (not in Docker) | `http://127.0.0.1:8480/api/v1/integrations` |
| On another machine in the same network | `http://<LAN IP of the Dental Center PC>:8480/api/v1/integrations` and set `WEB_BIND=0.0.0.0` (see the security note) |
| Both on a VPS | `https://<your domain>/api/v1/integrations` |

**Optional second lock.** `frontend/nginx/integrations-access.conf` can limit `/api/v1/integrations/` to your n8n host's address (default: allow all, key still required). Edit it, then `docker compose restart web`.

**Security note.** The key protects the integration routes, but anything reachable from the internet will be probed. When the website is public, keep the integration routes limited to your n8n host (firewall, reverse-proxy allow-list, or n8n and the site on the same private network), and use HTTPS between them. Never expose a plain-HTTP port 8480 to the internet.

## 5. Linking a Telegram chat to a patient (required for personal operations)

A Telegram user id proves nothing about who the person is, so linking uses a one-time code created inside the patient's **logged-in website session**:

1. The patient signs in on the website → profile → **Telegram** → *Create linking code*. The code looks like `K7QF-3MZP-9WHD`, is valid for **10 minutes** and works **once**. Only its hash is stored.
2. The patient opens the bot in a private chat and sends `/link K7QF-3MZP-9WHD` (or just the code).
3. The backend redeems the code and binds the Telegram account to that patient. The Telegram id comes from Telegram itself (`message.from.id`), never from the text.

Rules that follow from this: a new link replaces the old one; `/unlink` removes it; an inactive patient's link stops working; 8 wrong codes from one Telegram id trigger a temporary block (`TOO_MANY_ATTEMPTS`). No password or secret is ever sent through Telegram.

## 6. Bot commands

| Command | What it does |
|---|---|
| `/start`, `/help` | Lists the commands. |
| `/info` | Center name, address, phone, map link, working days, slot times and time zone, all read from the API. If no address is configured the bot says so plainly. |
| `/departments` | Departments that can take bookings and their dentist. Numbered; the numbers can be used in `/slots` and `/book` for 30 minutes. A department that does not work every day shows its days, for example `(works: Mon, Wed, Fri)`; the days come from the Admin Dashboard. |
| `/slots <department> [YYYY-MM-DD]` | Free times (only genuinely bookable ones). |
| `/book <department> <YYYY-MM-DD> <slot 1-4>` | Books for the linked patient. |
| `/my` | Upcoming appointments, numbered. Entries that are inside the 24-hour window are marked. |
| `/cancel <number>` | Cancels the appointment with that number from the last `/my`. |
| `/reschedule <number> <YYYY-MM-DD> <slot>` | Moves it. |
| `/link <code>`, `/unlink` | Link / unlink this chat. |
| `/lang ar\|en\|fr` | Language. Default comes from the Telegram app language; the choice is remembered per user. |

Behaviours worth knowing:

* Only **private chats** are served. Groups, channels and bots are ignored without any reply or API call, because appointment data is personal.
* `/cancel` and `/reschedule` accept the **number from `/my`**, not a pasted id, so a message cannot point at someone else's appointment. (The backend additionally scopes every id to the linked patient.)
* A day the department does not work (its working days are set in the Admin Dashboard) is refused by the backend with `DEPARTMENT_NOT_WORKING_DAY`, and `/slots` simply shows no times for it. The bot says so in plain words (`BOOKING_RULES.md` §2).
* The 24-hour rule, capacity and overlap rules are enforced by the backend. The bot shows the backend's refusal in plain words (24 hours, slot taken, day closed, …), never the raw error code.
* A failure (backend down, wrong key, unexpected answer) produces a "nothing was changed, please try again" message. The bot never confirms an action unless the backend returned success.
* The numbered lists and language choices are kept in the workflow's static data (see §10, limitation 1).

## 7. Using the AI assistant you already have

Telegram allows **one webhook per bot**. Two active workflows with a *Telegram Trigger* on the same bot will fight each other, so choose one of:

* **A. Separate bot for commands (zero changes to your assistant).** Create a second bot in @BotFather for the command workflow. Simple and safe; patients just use two bots.
* **B. One bot, two paths (recommended if you want a single bot).** Keep your existing *Telegram Trigger*. After it, add an **IF**: if the message text starts with `/` or looks like a linking code → continue into the nodes of the command workflow (from **Parse command** onward, including the **Has body?** node and both HTTP Request nodes; copy them across); otherwise → your existing AI agent. Deactivate the command workflow's own trigger afterwards.

### 7.1 Give the AI agent the real tools

Add the sub-workflow **Dental Center - API** to your AI agent as a *Call n8n Workflow* tool. Define its inputs:

| Input | Value |
|---|---|
| `operation` | chosen by the model, one of the operations below |
| `params` | chosen by the model (object) |
| `locale` | `ar`, `en` or `fr`, chosen by the model from the patient's language |
| `telegramUserId` | **fixed expression, not model-chosen:** `{{ $('Telegram Trigger').item.json.message.from.id }}` |

Never let the model fill in `telegramUserId`: it comes from Telegram only.

| `operation` | `params` | Needs link |
|---|---|---|
| `center` | – | no |
| `departments` | – | no |
| `department` | `slug` | no |
| `availability` | `department` (slug), optional `from`, `to` (`YYYY-MM-DD`) | no |
| `status` | – | no |
| `link` | `code` | no |
| `unlink` | – | yes |
| `myAppointments` | optional `scope`: `upcoming` (default), `history`, `all` | yes |
| `book` | `departmentSlug`, `date`, `slotNumber` (1–4) | yes |
| `cancel` | `appointmentId` | yes |
| `reschedule` | `appointmentId`, `date`, `slotNumber` | yes |

The tool always returns `{ ok, status, data }` on success or `{ ok:false, error:{code,message}, retryable }` on failure. Invalid input (bad date, slot outside 1–4, malformed id) is rejected inside the workflow before any request is sent.

### 7.2 Rules for the assistant's system prompt

Paste this into the agent's instructions (adapt the wording, keep the rules):

```
You assist patients of a dental center. All facts come from tools, never from memory.

- Address, phone, opening hours, slot times, departments, dentists and prices: always call the tools (center, departments, department). If a value is missing or the address is not configured, say that it is not available yet. Never guess or invent one.
- Booking, viewing, cancelling or rescheduling appointments is only possible for a linked patient. If a tool answers TELEGRAM_NOT_LINKED, tell the patient to create a linking code on the website (profile > Telegram) and send /link CODE here. Do not ask for the phone number or password in chat.
- Before booking, cancelling or rescheduling, repeat the department, date and time and ask the patient to confirm. Do the action only after a clear "yes".
- Say an action was done ONLY if the tool result has ok = true. If ok = false, explain the reason in plain words and say that nothing was changed. Never retry a booking silently.
- Rules are enforced by the system: opening hours 4 PM to 12 AM Africa/Cairo, four 2-hour slots, at most four appointments per department per day, cancel or reschedule at least 24 hours before the appointment. If the system refuses, relay that; do not offer workarounds.
- Slots: use availability and offer only the slots it returns.
- Never give medical advice or diagnoses. For clinical questions, suggest booking a consultation.
- Reply in the patient's language (Arabic, English or French).
```

## 8. Rotating the integration key (no downtime)

1. Generate a new key and put it in `.env` as `INTEGRATION_API_KEY_NEXT`; `docker compose up -d backend`. The backend now accepts both.
2. Update the **Dental Center API key** credential in n8n to `Bearer <new key>`. Test (§3.4).
3. Move the new value to `INTEGRATION_API_KEY`, empty `INTEGRATION_API_KEY_NEXT`, `docker compose up -d backend`. The old key stops working.

## 9. Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| Bot answers "temporary problem, nothing was changed" | n8n cannot reach the backend or the key is wrong. Run §3.4 and read the HTTP node's output. |
| Backend log / node output shows `401 INVALID_INTEGRATION_KEY` | The credential value is not exactly `Bearer <key>`, or it is not the key in `.env`. |
| `503 INTEGRATION_DISABLED` | `INTEGRATION_API_KEY` is empty in `.env`, or the backend was not restarted after changing it. |
| `ECONNREFUSED` / `ENOTFOUND host.docker.internal` | Wrong `baseUrl` for where n8n runs (§4); the website container is not running (`docker compose ps`); on Linux add `extra_hosts: host.docker.internal:host-gateway` to the n8n container. |
| Telegram Trigger does not fire | n8n needs a public HTTPS `WEBHOOK_URL`, and the workflow must be **Active**. Only one active trigger per bot (§7). |
| `/link` says the code is invalid | Expired (10 min), already used, or a newer code was created. Create a new one. |
| The bot ignores messages in a group | By design (private chats only). |
| Numbers in `/cancel 2` are "not found" | The list is remembered for 30 minutes and per user. Send `/my` first. |
| Language/list memory is lost when testing with "Execute workflow" | n8n keeps static data only for **active** (production) executions. |

## 10. Known limitations

1. **State in static data.** The language choice and numbered lists use n8n workflow static data. It is per n8n instance, not shared across several n8n workers, and is not kept for manual test runs. If you run n8n in queue mode with several workers, move this state into a data table or Redis.
2. **Text commands, not buttons.** The command bot is deliberately deterministic. Inline keyboards can be added later; they would call the same API.
3. **Services/prices through the bot** are available to the AI agent (`department` operation) but have no dedicated command.
4. **Integration key is one shared secret** for all n8n calls. The audit log records these actions with actor type `integration`; the individual Telegram user is not an authenticated principal, which is why linking exists.

## 11. What has and has not been verified

Verified by running it:

* **Inside a real n8n.** `integrations/n8n/test/real-n8n-check.cjs` was run against **n8n 2.45.4** (CLI, on Node 24, as that version requires) and a real backend built from this repository with a real PostgreSQL 16 database. 34 checks passed. Both exported files import unchanged; the API sub-workflow answered real requests (center, departments, availability, an unknown department, unlinked status, a refused path-injection id); the Telegram workflow, with only the Telegram trigger and the Telegram sender replaced by a test input and a capture node, ran link → book → duplicate booking refused → list → reschedule → cancel → unlink, and every reply was cross-checked against what the website API reports for the same patient. A wrong integration key never produced a success message. Group and bot messages were ignored.
  * This run found a **real defect that the simulator could not**: n8n ignores an expression in the HTTP Request node's "Send Body" switch, so every POST was sent with an empty body. The workflows now use two HTTP Request nodes (with and without a JSON body); a regression test guards it.
  * `/cancel` and `/reschedule` need the list remembered from `/my`. n8n keeps workflow static data only for production (active) executions, so in this check the list was seeded into the test workflow; the real Code nodes then read it back. A production run of that persistence was **not** performed (see "Not verified").
* `integrations/n8n/test` - **35 tests pass** (`cd integrations/n8n && npm test`): request building and validation, response normalisation, every command in three languages, message-key parity between ar/en/fr, "a failure is never reported as success" for every error shape, group/bot ignoring, workflow structure, the body/no-body node split, no secrets or hostnames in the exports, exports identical to what `build.cjs` generates.
* `backend/tests/integration/n8n-e2e.test.ts` - **11 tests pass** against the real backend and PostgreSQL: the exported Telegram workflow (its real Code nodes, expressions and connections, executed by a small simulator) runs the full journey, rejects a taken slot, enforces the 24-hour rule, isolates two patients, handles unlink, wrong/missing key, a broken backend, and group chats. Database rows are checked, not only replies.
* The backend integration API itself: `backend/tests/integration/integration-api.test.ts` (25 tests).

Not verified (needs your environment):

* The **real-n8n check was run before the department-working-days change**. That change only adds one error message and the `(works: …)` text in the command workflow (the unit tests, the simulator-based end-to-end test and the exports check were all re-run afterwards and pass); the real-n8n check has not been repeated since.

* Real Telegram delivery, a real bot token, and the Telegram Trigger webhook (the test replaced them).
* Persistence of static data (language choice, numbered lists) across messages in an **active** workflow.
* Other n8n versions than 2.45.4.
* `host.docker.internal` reachability from your n8n container on your Windows machine.

How to repeat the real-n8n check yourself (needs an installed n8n and a running backend with `INTEGRATION_API_KEY` set; it uses a throwaway n8n user folder and registers one test patient and one test booking in that backend, so point it at a test database, never at real patient data):

```sh
cd integrations/n8n
N8N_BIN=<path to node_modules/n8n/bin/n8n> \
N8N_REAL_NODE=<node executable that satisfies your n8n version> \
N8N_REAL_BASE_URL=http://127.0.0.1:3480/api/v1/integrations \
N8N_REAL_KEY=<the backend's INTEGRATION_API_KEY> \
node test/real-n8n-check.cjs
```
