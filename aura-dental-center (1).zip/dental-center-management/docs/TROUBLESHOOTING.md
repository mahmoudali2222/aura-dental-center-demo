# Troubleshooting

Start with two commands, run in the project folder: `docker compose ps` (is everything `healthy`?) and
`docker compose logs --tail 80 backend` (the API's own explanation). Secrets are never written to the logs.

## Starting the system

| Symptom | Cause and fix |
|---|---|
| `error during connect` / `Cannot connect to the Docker daemon` | Docker Desktop is not running. Start it and wait until it says "running". |
| `Set POSTGRES_PASSWORD in .env (copy .env.example)` | `.env` is missing or `POSTGRES_PASSWORD` is empty. `Copy-Item .env.example .env`, then set the value. |
| `port is already allocated` / `bind: Only one usage of each socket address` | Something else uses port 8480. Set another `WEB_PORT` in `.env` (and `PUBLIC_APP_URL` to match), then `docker compose up -d`. Check: `Get-NetTCPConnection -State Listen \| Where-Object LocalPort -eq 8480`. |
| The first `up --build` is very slow or fails while downloading | It downloads Node, PostgreSQL and nginx images (a few hundred MB). Check the internet connection and retry; nothing is half-installed. |
| `backend` keeps restarting; the log starts with `Invalid configuration:` | `.env` has a wrong value. The log names the variable and the rule (never the value). Typical ones: `PUBLIC_APP_URL must use https:// in production (except localhost)`, `COOKIE_SECURE must be true in production unless PUBLIC_APP_URL points at localhost`, `INTEGRATION_API_KEY: must be at least 32 characters` (use `scripts/new-secret.ps1`, or leave it empty), `DATABASE_URL: ...`. |
| `password authentication failed for user` in `backend`/`migrate` | You changed `POSTGRES_PASSWORD` after the database was first created. PostgreSQL keeps the original password inside the volume. Either put the **old** value back in `.env`, or change it inside the database: `docker compose exec db psql -U dental_center -d postgres -c "ALTER USER dental_center PASSWORD 'new-value'"` and use the same value in `.env` (letters and digits only). Do **not** delete the volume: that erases the data. |
| A password in `.env` containing `$` is cut off or changes | Docker Compose treats `$` in `.env` as a variable. Use letters and digits (and `- _ . !`), no `$`. |
| `migrate` fails with `Migration ... was modified after being applied (checksum mismatch)` | Someone edited an old migration file. Restore the original file from the project copy you received; never edit applied migrations, add a new one. |
| `migrate` fails with `Cannot delete departments that still have appointments` | Migration 0003 found an old department (not one of the seven) with appointments and, by design, changed nothing. See `DATABASE.md`; decide what to do with those appointments, then run `docker compose up -d` again. |
| `web` is `unhealthy` or the site says 502 / "Bad Gateway" | The backend is not up. `docker compose ps`, then `docker compose logs backend`. After the backend is `healthy` the site works again without restarting `web`. |
| After a reboot nothing runs | Start Docker Desktop, then `docker compose up -d`. The containers are set to restart unless stopped. |

## Using the website and the dashboard

| Symptom | Cause and fix |
|---|---|
| Sign-in / register / any form fails with "This request was blocked for security reasons. Please reload the page." (`ORIGIN_NOT_ALLOWED`; reloading does not help) | You opened the site from an address that is not `PUBLIC_APP_URL`, for example `http://127.0.0.1:8480` while `.env` says `http://localhost:8480`. Use the exact address, or add the other one to `ALLOWED_ORIGINS` and run `docker compose up -d`. |
| Signing in seems to work but you are signed out at once | `COOKIE_SECURE=true` while using plain `http://`. The browser refuses to keep a secure cookie on http. Use `COOKIE_SECURE=false` for local http, `true` only with HTTPS. |
| "Too many failed attempts. Please wait a few minutes before trying again." / "Too many requests" (429) | The sign-in limit protects against password guessing: 8 failures per phone/user name and 20 sign-ins per address within 15 minutes; 10 registrations per hour per address. Wait, or `docker compose restart backend` (the counters are in memory). |
| An administrator forgot the password | Nobody can read a password back. Staff with access to the server can set a new one: put the user name and a new password (at least 12 characters) into `ADMIN_BOOTSTRAP_USERNAME` / `ADMIN_BOOTSTRAP_PASSWORD` in `.env`, run `docker compose run --rm reset-admin-password`, sign in with it (a new password is demanded immediately), then remove `ADMIN_BOOTSTRAP_PASSWORD` from `.env`. This closes that administrator's sessions and is written to the audit log. |
| A patient forgot the password | By design there is no online recovery. At the desk, after checking who the person is: dashboard → Patients → the patient → reset password. |
| A patient cannot register: "phone already registered" | An account with that number exists (possibly created by someone else; numbers are not verified). Staff can look it up under Patients and, if needed, reset its password after identifying the owner. |
| A day shows as closed / has no times | A day has times only if it is a working day of the center **and** of the department and not a closed date, in the future and within the booking horizon. Check Center settings (working days, closed dates, horizon) and Departments & dentists → the department → working days. `BOOKING_RULES.md` §2. |
| A department cannot be booked: "no dentist" | Every department needs one **active** dentist. Departments & dentists → add or reactivate the dentist. |
| Removing a working day asks for confirmation and shows a number | That many future booked appointments fall on the day. Nothing is cancelled automatically: confirm to proceed, then cancel or move those appointments yourself from Appointments. |
| A patient cannot cancel or reschedule | Less than 24 hours remain before the appointment. Only an administrator can still do it, with an explicit override and a reason. |
| Times look one hour off after 29 October | Egypt left daylight-saving time on Thursday 29 October 2026 (clocks back at midnight). The center uses `Africa/Cairo`; the system follows the tz database automatically. If your computer's clock or time zone is wrong, fix that first. Keep Docker Desktop and the images updated for future rule changes. |
| My picture does not appear | The file must be inside `frontend/public/assets/<folder>/`, and the path typed in the dashboard must be exactly `/assets/<folder>/<file>` (letters, digits, `.`, `_`, `-`, `/` only). Pictures are cached for up to an hour: press Ctrl+F5. See `IMAGE_ASSETS.md`. |
| The Arabic page shows Western digits (0-9) | Intentional: Arabic text uses Latin digits for phone numbers, dates and times so they are always unambiguous and copyable. |

## Telegram / n8n

See `N8N_INTEGRATION.md` §9. The most common ones: `401 INVALID_INTEGRATION_KEY` (credential value must be `Bearer <key>`),
`503 INTEGRATION_DISABLED` (key empty or the backend not restarted), `ENOTFOUND host.docker.internal` (wrong `baseUrl` for where
n8n runs), and `/link` says the code is invalid (10 minutes, single use).

## Backups

| Symptom | Cause and fix |
|---|---|
| `the database container is not running` | `docker compose up -d db` first. |
| `could not copy the backup out of the container` on Windows | Use a plain destination such as the default `backups\` folder; do not use a path containing spaces or network drives with `-BackupDir`, then copy the file afterwards. |
| `checksum mismatch: the backup file is damaged` | The file changed after it was written (interrupted copy, disk problem). Use another backup; keep several. |

## Dangerous things not to do

- `docker compose down -v`, `docker volume rm dental_center_pgdata`, `docker system prune --volumes`: erase the database.
- Editing files in `database/migrations/` that were already applied.
- Putting `.env`, backup files or the integration key in chats, tickets, screenshots or version control.
- Running `scripts/smoke-api.mjs` or the browser tests against the real clinic: they create test patients ("ZZ Smoke ...").
  `scripts/verify-docker.ps1` runs them against an isolated copy for that reason.

## When you ask for help

Send: `docker compose ps`, the last 80 lines of `docker compose logs backend`, the exact error text, and what you did just before.
Do **not** send `.env`, backups, screenshots with patient data, or passwords.
