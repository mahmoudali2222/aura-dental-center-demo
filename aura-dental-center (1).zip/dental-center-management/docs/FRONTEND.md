# Frontend

One Vite package (`frontend/`) builds **two separate single-page apps** that share one code base:

| App | Address | Entry | Purpose |
|---|---|---|---|
| Patient website | `/` | `frontend/index.html` → `src/patient/main.tsx` | Public pages, register/login, booking, "my appointments", account and Telegram link |
| Admin Dashboard | `/admin/` | `frontend/admin/index.html` → `src/admin/main.tsx` | Staff only; its own bundle, router, session cookie and language choice. Nothing from it is shipped to patients. |

Both are served by the web container (nginx) on one origin, so the browser needs no CORS and the API calls are plain `fetch` to `/api/v1/...`
with the session cookie. Stack: React 19, React Router 7, TypeScript (strict), Vite; no UI framework, no CSS framework, no analytics, no CDN
(the Content-Security-Policy would block them).

## Patient website

| Route | Page | Needs sign-in |
|---|---|---|
| `/` | Home: hero (with the place for the background video) and the **evening timeline** drawn from the center's real slots; for a signed-in patient their next appointment; the departments as an index (each with its **working-days strip**); the **treatment-results** strip (the supplied before/after pictures); how booking works; a quiet **Telegram assistant** band | no |
| `/departments`, `/departments/:slug` | Index; department page with the **treatment example** picture (uncropped), services, dentist, a sticky "book" card with the **working days**, published gallery | no |
| `/login`, `/register` | Phone + password (+ full name). No code, no SMS. | no |
| `/book` | One page, numbered steps: department → service (optional) → **month calendar over real availability** and the day's free times → note + the **patient-precautions** picture → confirm (summary beside it, a slim bar on a phone) | yes |
| `/appointments` | Upcoming and history as cards with a date leaf; change time (the same calendar), cancel, **"Before your visit"** (the precautions); the buttons are replaced by an explanation inside 24 hours | yes |
| `/account` | Name, language, password, **Telegram linking code** and the bot link | yes |

Every page ends with the footer (center details from the API) and, below it, **Section 10: Project contributors**.

Behaviours that matter:

- The booking calendar asks the API for availability for the **center's whole booking period** (today in the center's time zone up to
  `bookingHorizonDays`, both from the center's settings) and draws one cell per day the API returns. Only days the API calls `open` can be
  chosen; full, closed (a weekday the department or the center does not work, or a closure), past and out-of-period days are shown but
  cannot be picked, and a dot marks each free time. The server decides everything, the page never "knows" the rules (`BOOKING_RULES.md`).
  The same calendar is used to change the time of an existing appointment.
- After a conflict (someone took the slot a second earlier) the page reloads the day's times and says so.
- All errors are shown from the **error code**, translated; raw codes and English developer messages are never shown to patients.
- Field problems appear at the field; a top banner appears only when no field message explains the failure (found by a browser test and
  fixed: the same message used to be shown twice).

## Admin Dashboard

| Route | Content |
|---|---|
| `/admin/login`, `/admin/change-password` | Sign-in; the forced first password change |
| `/admin/` | Today's appointments, status counts, per-department load (x of 4), next seven days |
| `/admin/appointments` | Filter (applies when you press Search), book for a patient, manage (cancel with inline confirmation, reschedule, mark completed / no-show; inside 24 hours an explicit override with reason) |
| `/admin/patients`, `/admin/patients/:id` | Search, add a patient, edit, disable, **reset password** (identity-checked), revoke Telegram link, **medical records** (history, allergies, diagnosis, treatment, notes) |
| `/admin/departments` | Departments with **working days** (weekday picker), dentist, active flag, images, trilingual texts |
| `/admin/services`, `/admin/gallery` | Services (optional price), gallery cases (consent gate for real cases) |
| `/admin/settings` | Center profile (trilingual name/address/intro/hours note, phone, WhatsApp, email, map, default language, currency, horizon, **center working days**), the four slots (enable/disable), closed dates |
| `/admin/audit` | Read-only audit log with filters |

Patterns used everywhere (reuse them when adding screens): `useAction` (one in-flight action with error mapping), `formErrors`
(API field issues → field messages), `TranslationFields` (name/description in three languages in one block), `Dialog` / `ConfirmDialog`,
and the **two-step acknowledge flow**: when a change would affect existing appointments (a closed date, or removing a department working
day) the API answers `409` with the count; the screen shows "N appointments fall on these days; they will not be cancelled" and resends the
change with `acknowledgeExistingAppointments: true` only after confirmation.

## Languages and direction

- Arabic (default for the center, RTL), English, French. The language switcher is always visible and needs no account.
- **Choice policy:** explicit choice stored in this browser (`dc.patient.locale` / `dc.admin.locale`) › signed-in account preference ›
  browser language › center default language › Arabic. Implemented in `src/shared/i18n/detect.ts`.
- `<html lang dir>` is set per language; the CSS uses **logical properties** (`margin-inline-start` …) so one stylesheet serves both directions.
- **Compile-time completeness:** messages are written with `defineMessages({ en, ar, fr })`; the types of `ar` and `fr` derive from the keys
  of `en`, so a missing key in any language is a compile error (`tsc` runs in `npm run build`). A test additionally checks that no value is empty.
- Arabic uses **Latin digits** (locale `ar-EG-u-nu-latn`) so phone numbers, dates and times are unambiguous and copyable. Time is 12-hour in
  Arabic/English and 24-hour in French. Plurals use the CLDR categories (`key_one`, `key_few`, `key_other` …).
- Dates and times are displayed in the **center's** zone (`Africa/Cairo`), whatever the visitor's computer says. The last slot's end time is the
  one the API sends (11 PM / 12 AM / 1 AM on the two daylight-saving nights), never a hard-coded "12:00 AM".
- Where to edit texts: `src/patient/i18n/messages.ts`, `src/admin/i18n/messages*.ts`, `src/shared/i18n/messages/common.ts`.

## Patient website design

Direction: calm, premium, clean. A **white** page with pale-blue bands. The colors follow the **color wheel**: one deep blue-teal
(hue ~200, `--primary`) as the main color, its analogous neighbour **mint** (~165) and its complement **peach/coral** (~15) as quiet accents,
and a touch of lilac for variety (the contributor chips and the timeline). To change the mood edit only the palette block at the top of
`src/patient/styles/theme.css`; generous spacing; Readex Pro for all three languages (self-hosted from `@fontsource-variable/readex-pro`, so the
Content-Security-Policy `font-src 'self'` is respected); light weights for headings. Motion is small and purposeful: pages arrive with a short
fade, the **evening timeline** fills in once, dialogs and menus ease in. Everything stops for visitors who prefer reduced motion.

How it is built (reuse this when adding screens):

- **Scoped to the patient site.** The shared `tokens.css` / `base.css` also serve the Admin Dashboard, which keeps its own look. The patient
  site sets `<html data-app="patient">` and everything in `src/patient/styles/` is written under that attribute (`theme.css` re-points the
  shared tokens and re-skins buttons/fields/alerts/dialogs; `shell.css` is the header, footer and Section 10; `home.css` and `pages.css` are the
  pages). The styles are imported by `src/patient/main.tsx` only, so the Admin bundle never contains them (checked in the build output).
- **Logical CSS properties** and a few `html[dir="rtl"]` rules; arrows and chevrons flip with `.icon-dir`; the Arabic calendar week starts on
  Saturday (English/French on Monday); Arabic is never letter-spaced and gets taller line heights.
- **No inline styles or inline `<style>`** (the CSP forbids them). Pictures are plain `<img>` elements shown at their own size.
- The patient pages hold no clinic data: departments, working days, slots, prices, address and phone all come from the API.

### Places kept ready (nothing was invented)

`src/patient/config.ts` is the one file for things that belong to the website and are not data:

| Slot | Status | How to fill it |
|---|---|---|
| **Official logo** | **Not supplied.** The header and footer show the center's name as plain text; no stand-in symbol exists. | Copy the file to `frontend/public/assets/branding/` and set `logo: { src: '/assets/branding/logo.svg', includesName: true }`. Nothing else changes (`BrandMark.tsx` reserves the space; if the picture already contains the name, the text stays for screen readers only). |
| **Hero background video** | **Not supplied.** The hero shows its soft background; `HeroMedia.tsx` is an empty, decorative layer behind the hero text. | Copy the files to `frontend/public/assets/branding/` and set `heroVideo: { src: '/assets/branding/hero.mp4', poster: '/assets/branding/hero-poster.jpg' }`. It plays muted and looped under a light veil that keeps the text readable; visitors who prefer reduced motion get the poster only. No layout change is needed. |
| **Telegram assistant** | Set: `https://t.me/drAliclinic2_bot`. | Link only (home band, footer, account page); the website has no chat window of its own. |
| **Patient-precautions picture** | Supplied: `/assets/info/patient-precautions.jpg`. | Shown in the booking flow, after booking and under "Before your visit" in My appointments, together with its text (also for French readers). |

### Section 10: Project contributors

`src/patient/contributors.ts` holds the 30 names exactly as the center gave them (in that order; both "منه الله" are kept as separate
entries). `Contributors.tsx` shows them at the bottom of every public page as compact chips that wrap, each only as wide as its name, with no
numbers or bullets. Chips cycle through four soft tones, so the two "منه الله" differ. To change a name edit that file.

## Accessibility and responsive behaviour

Built in: semantic landmarks and headings, labelled form controls with `aria-describedby` for hints and errors, focus-managed dialogs (focus is
trapped inside and returned on close, Esc closes), visible focus rings, status badges that carry text and not only colour, tables that scroll
inside their own box on phones, buttons and form fields with a 44 px minimum height (`--tap-target`), `prefers-reduced-motion` respected. Browser tests
check that public pages, the booking flow and the dashboard fit a 393 px phone screen in all three languages without horizontal page scrolling.
**Not done:** an automated accessibility audit (axe/Lighthouse) and a screen-reader pass: treat WCAG conformance as unverified.

## Develop and test

```sh
cd frontend
npm ci
npm run dev            # http://localhost:5173 (patient), http://localhost:5173/admin/ ; /api is proxied to http://127.0.0.1:3480
npm run typecheck
npm test               # Vitest + Testing Library, fake backends (216 tests)
npm run build          # type-check, then dist/ with both apps (bundles in /static/, so /assets/ stays yours)
```

`DC_BACKEND_URL` changes the proxy target for `npm run dev` / `npm run preview`. For a real backend you need PostgreSQL and the backend running
(`DEPLOYMENT.md`, or `scripts/e2e-local.sh` for a throw-away stack without Docker). With the dev server use `ALLOWED_ORIGINS=http://localhost:5173`
in the backend environment and `COOKIE_SECURE=false`.
