'use strict';
/*
 * Text-command Telegram assistant logic for the Dental Center (no AI involved, no invented facts).
 * Pure functions, unit-tested in test/, pasted into the n8n Code nodes by build.cjs (which also supplies buildRequest()).
 *
 *   parseUpdate(update, state, nowMs)  -> decision  (what to answer, or which API call to make)
 *   formatReply(decision, result, state, nowMs) -> { chatId, text }   (result = normalizeResponse(...) of the API call)
 *
 * `state` is persisted by the workflow (n8n workflow static data): { lang: {userId: 'ar'}, lists: {userId: {...}} }.
 * Rules this file guarantees:
 *   - only PRIVATE chats are served (a group must never receive personal appointment data);
 *   - the Telegram user id comes from Telegram itself (message.from.id), never from message text;
 *   - "booked/cancelled/rescheduled" is said ONLY when the API answered 2xx; every other outcome is reported as not done;
 *   - the address, hours, phone and departments are read from the API, never written here.
 */
const DEFAULT_LANG = 'ar';
const LIST_TTL_MS = 30 * 60 * 1000;
const LANGS = ['ar', 'en', 'fr'];
const LOCALE_TAG = { ar: 'ar-EG', en: 'en-GB', fr: 'fr-FR' };

const STRINGS = {
  en: {
    help: 'I can help with:\n/info - address, phone and opening hours\n/departments - departments and dentists\n/slots <department> [YYYY-MM-DD] - free times\n/book <department> <YYYY-MM-DD> <slot 1-4> - book\n/my - your upcoming appointments\n/cancel <number> - cancel one (24 hours notice)\n/reschedule <number> <YYYY-MM-DD> <slot> - move one\n/link <code> - link this chat to your patient account\n/unlink - remove the link\n/lang ar|en|fr - language',
    notLinked: 'This Telegram account is not linked to a patient account yet.\nSign in on the website, open the Telegram section of your profile, create a linking code and send it here:\n/link YOUR-CODE',
    linkUsage: 'Send /link followed by the code from the website, for example:\n/link K7QF-3MZP-9WHD',
    linked: 'Done. This chat is now linked to your patient account. Send /my to see your appointments.',
    linkInvalid: 'That code is invalid or has expired. Create a new code on the website and try again.',
    tooMany: 'Too many attempts. Please wait a few minutes and try again.',
    unlinked: 'This chat is no longer linked. I cannot see your appointments any more.',
    addressMissing: 'Address: not available yet - please contact the center.',
    address: 'Address: {v}',
    phone: 'Phone: {v}',
    map: 'Map: {v}',
    hours: 'Opening hours ({days}): {slots} ({tz} time). Each visit is a 2-hour slot.',
    everyDay: 'every day',
    deptHeader: 'Departments (use the name or the number with /slots and /book):',
    deptLine: '{n}. {name} [{slug}] - {dentist}',
    deptDays: 'works: {days}',
    slotsUsage: 'Usage: /slots <department> [YYYY-MM-DD]\nExample: /slots orthodontics',
    slotsHeader: 'Free times - {dept}:',
    slotsNone: 'No free times in this period.',
    slotsHow: 'To book: /book {slug} <date> <slot number>',
    bookUsage: 'Usage: /book <department> <YYYY-MM-DD> <slot 1-4>\nExample: /book orthodontics 2026-11-10 2\nSee free times with /slots.',
    needDepartments: 'Send /departments first to use numbers, or write the department name such as orthodontics.',
    booked: 'Booked: {dept} - {date} {start}-{end}{dentist}.\nYou can cancel or move it up to 24 hours before it starts (/my).',
    myHeader: 'Your upcoming appointments:',
    myEmpty: 'You have no upcoming appointments.',
    myLine: '{n}. {dept} - {date} {start}-{end}{dentist}{note}',
    myLocked: ' (can no longer be changed here)',
    myFooter: 'Change one: /cancel <number> or /reschedule <number> <YYYY-MM-DD> <slot>',
    cancelUsage: 'Usage: /cancel <number>\nSend /my first to see the numbers.',
    rescheduleUsage: 'Usage: /reschedule <number> <YYYY-MM-DD> <slot 1-4>\nSend /my first to see the numbers.',
    needList: 'Send /my first so I know which appointment you mean.',
    cancelled: 'Cancelled: {dept} - {date} {start}-{end}. That time is free again.',
    rescheduled: 'Moved: {dept} is now {date} {start}-{end}{dentist}.',
    langSet: 'Language set to English.',
    langUsage: 'Usage: /lang ar | en | fr',
    unknown: 'I only understand commands for now. Send /help to see them.',
    generic: 'Sorry, something went wrong on our side. Nothing was changed. Please try again in a moment.',
    e_SLOT_UNAVAILABLE: 'That time is no longer available. Use /slots to see free times.',
    e_SLOT_IN_PAST: 'That time has already started or passed.',
    e_DATE_CLOSED: 'The center is closed on that date.',
    e_DEPARTMENT_NOT_WORKING_DAY: 'That department does not work on that day. Use /departments to see its working days, or /slots to see free times.',
    e_BEYOND_BOOKING_HORIZON: 'That date is too far ahead to book yet.',
    e_PATIENT_OVERLAP: 'You already have an appointment at that time.',
    e_DAILY_CAPACITY_REACHED: 'That department is fully booked on that day.',
    e_WITHIN_24H_WINDOW: 'Appointments can only be cancelled or moved at least 24 hours before they start. Please contact the center.',
    e_APPOINTMENT_NOT_FOUND: 'I could not find that appointment. Send /my to refresh the list.',
    e_APPOINTMENT_NOT_ACTIVE: 'That appointment is no longer active.',
    e_RESCHEDULE_NO_CHANGE: 'That is the same time as your current appointment.',
    e_DEPARTMENT_NOT_FOUND: 'I could not find that department. Send /departments to see them.',
    e_VALIDATION_ERROR: 'Something in the request was not valid. Please check the format (see /help).',
  },
  ar: {
    help: 'يمكنني مساعدتك في:\n/info - العنوان والهاتف ومواعيد العمل\n/departments - الأقسام والأطباء\n/slots <القسم> [YYYY-MM-DD] - المواعيد المتاحة\n/book <القسم> <YYYY-MM-DD> <رقم الفترة 1-4> - حجز موعد\n/my - مواعيدك القادمة\n/cancel <الرقم> - إلغاء موعد (قبل 24 ساعة)\n/reschedule <الرقم> <YYYY-MM-DD> <الفترة> - تغيير موعد\n/link <الكود> - ربط هذه المحادثة بحسابك\n/unlink - إلغاء الربط\n/lang ar|en|fr - اللغة',
    notLinked: 'حساب تيليجرام هذا غير مربوط بحساب مريض بعد.\nادخل إلى الموقع، افتح قسم تيليجرام في ملفك الشخصي، أنشئ كود ربط وأرسله هنا:\n/link الكود-الخاص-بك',
    linkUsage: 'أرسل /link ثم الكود من الموقع، مثال:\n/link K7QF-3MZP-9WHD',
    linked: 'تم. أصبحت هذه المحادثة مربوطة بحسابك. أرسل /my لعرض مواعيدك.',
    linkInvalid: 'الكود غير صحيح أو انتهت صلاحيته. أنشئ كودًا جديدًا من الموقع وحاول مرة أخرى.',
    tooMany: 'محاولات كثيرة. من فضلك انتظر بضع دقائق ثم حاول مرة أخرى.',
    unlinked: 'تم إلغاء ربط هذه المحادثة. لم أعد أستطيع رؤية مواعيدك.',
    addressMissing: 'العنوان: غير متاح حاليًا - برجاء التواصل مع المركز.',
    address: 'العنوان: {v}',
    phone: 'الهاتف: {v}',
    map: 'الخريطة: {v}',
    hours: 'مواعيد العمل ({days}): {slots} (بتوقيت {tz}). كل زيارة فترة مدتها ساعتان.',
    everyDay: 'كل يوم',
    deptHeader: 'الأقسام (استخدم الاسم أو الرقم مع /slots و /book):',
    deptLine: '{n}. {name} [{slug}] - {dentist}',
    deptDays: 'أيام العمل: {days}',
    slotsUsage: 'الاستخدام: /slots <القسم> [YYYY-MM-DD]\nمثال: /slots orthodontics',
    slotsHeader: 'المواعيد المتاحة - {dept}:',
    slotsNone: 'لا توجد مواعيد متاحة في هذه الفترة.',
    slotsHow: 'للحجز: /book {slug} <التاريخ> <رقم الفترة>',
    bookUsage: 'الاستخدام: /book <القسم> <YYYY-MM-DD> <رقم الفترة 1-4>\nمثال: /book orthodontics 2026-11-10 2\nاعرض المواعيد المتاحة بـ /slots.',
    needDepartments: 'أرسل /departments أولًا لاستخدام الأرقام، أو اكتب اسم القسم مثل orthodontics.',
    booked: 'تم الحجز: {dept} - {date} {start}-{end}{dentist}.\nيمكنك الإلغاء أو التغيير حتى 24 ساعة قبل الموعد (/my).',
    myHeader: 'مواعيدك القادمة:',
    myEmpty: 'ليس لديك مواعيد قادمة.',
    myLine: '{n}. {dept} - {date} {start}-{end}{dentist}{note}',
    myLocked: ' (لا يمكن تغييره من هنا الآن)',
    myFooter: 'للتغيير: /cancel <الرقم> أو /reschedule <الرقم> <YYYY-MM-DD> <الفترة>',
    cancelUsage: 'الاستخدام: /cancel <الرقم>\nأرسل /my أولًا لمعرفة الأرقام.',
    rescheduleUsage: 'الاستخدام: /reschedule <الرقم> <YYYY-MM-DD> <الفترة 1-4>\nأرسل /my أولًا لمعرفة الأرقام.',
    needList: 'أرسل /my أولًا حتى أعرف أي موعد تقصد.',
    cancelled: 'تم الإلغاء: {dept} - {date} {start}-{end}. أصبح هذا الموعد متاحًا من جديد.',
    rescheduled: 'تم التغيير: موعد {dept} أصبح {date} {start}-{end}{dentist}.',
    langSet: 'تم ضبط اللغة على العربية.',
    langUsage: 'الاستخدام: /lang ar | en | fr',
    unknown: 'أفهم الأوامر فقط حاليًا. أرسل /help لعرضها.',
    generic: 'عذرًا، حدث خطأ من جانبنا. لم يتم تغيير أي شيء. حاول مرة أخرى بعد قليل.',
    e_SLOT_UNAVAILABLE: 'هذا الموعد لم يعد متاحًا. اعرض المواعيد المتاحة بـ /slots.',
    e_SLOT_IN_PAST: 'هذا الموعد بدأ بالفعل أو انتهى.',
    e_DATE_CLOSED: 'المركز مغلق في هذا التاريخ.',
    e_DEPARTMENT_NOT_WORKING_DAY: 'هذا القسم لا يعمل في ذلك اليوم. أرسل /departments لمعرفة أيام عمله، أو /slots لعرض المواعيد المتاحة.',
    e_BEYOND_BOOKING_HORIZON: 'هذا التاريخ بعيد جدًا ولا يمكن الحجز فيه الآن.',
    e_PATIENT_OVERLAP: 'لديك بالفعل موعد في نفس الوقت.',
    e_DAILY_CAPACITY_REACHED: 'هذا القسم مكتمل الحجز في ذلك اليوم.',
    e_WITHIN_24H_WINDOW: 'يمكن إلغاء أو تغيير الموعد قبل 24 ساعة على الأقل من بدايته. من فضلك تواصل مع المركز.',
    e_APPOINTMENT_NOT_FOUND: 'لم أجد هذا الموعد. أرسل /my لتحديث القائمة.',
    e_APPOINTMENT_NOT_ACTIVE: 'هذا الموعد لم يعد نشطًا.',
    e_RESCHEDULE_NO_CHANGE: 'هذا هو نفس وقت موعدك الحالي.',
    e_DEPARTMENT_NOT_FOUND: 'لم أجد هذا القسم. أرسل /departments لعرض الأقسام.',
    e_VALIDATION_ERROR: 'هناك خطأ في البيانات المرسلة. راجع الصيغة (انظر /help).',
  },
  fr: {
    help: 'Je peux vous aider avec :\n/info - adresse, téléphone et horaires\n/departments - services et dentistes\n/slots <service> [AAAA-MM-JJ] - créneaux libres\n/book <service> <AAAA-MM-JJ> <créneau 1-4> - réserver\n/my - vos prochains rendez-vous\n/cancel <numéro> - annuler (préavis de 24 h)\n/reschedule <numéro> <AAAA-MM-JJ> <créneau> - déplacer\n/link <code> - lier ce chat à votre compte patient\n/unlink - supprimer le lien\n/lang ar|en|fr - langue',
    notLinked: "Ce compte Telegram n'est pas encore lié à un compte patient.\nConnectez-vous sur le site, ouvrez la section Telegram de votre profil, créez un code de liaison et envoyez-le ici :\n/link VOTRE-CODE",
    linkUsage: 'Envoyez /link suivi du code affiché sur le site, par exemple :\n/link K7QF-3MZP-9WHD',
    linked: 'Terminé. Ce chat est maintenant lié à votre compte patient. Envoyez /my pour voir vos rendez-vous.',
    linkInvalid: 'Ce code est invalide ou a expiré. Créez un nouveau code sur le site et réessayez.',
    tooMany: 'Trop de tentatives. Veuillez patienter quelques minutes puis réessayer.',
    unlinked: "Ce chat n'est plus lié. Je ne peux plus voir vos rendez-vous.",
    addressMissing: "Adresse : pas encore disponible - veuillez contacter le centre.",
    address: 'Adresse : {v}',
    phone: 'Téléphone : {v}',
    map: 'Plan : {v}',
    hours: 'Horaires ({days}) : {slots} (heure de {tz}). Chaque visite est un créneau de 2 heures.',
    everyDay: 'tous les jours',
    deptHeader: 'Services (utilisez le nom ou le numéro avec /slots et /book) :',
    deptLine: '{n}. {name} [{slug}] - {dentist}',
    deptDays: 'jours : {days}',
    slotsUsage: 'Utilisation : /slots <service> [AAAA-MM-JJ]\nExemple : /slots orthodontics',
    slotsHeader: 'Créneaux libres - {dept} :',
    slotsNone: 'Aucun créneau libre sur cette période.',
    slotsHow: 'Pour réserver : /book {slug} <date> <numéro du créneau>',
    bookUsage: 'Utilisation : /book <service> <AAAA-MM-JJ> <créneau 1-4>\nExemple : /book orthodontics 2026-11-10 2\nVoir les créneaux libres avec /slots.',
    needDepartments: "Envoyez d'abord /departments pour utiliser les numéros, ou écrivez le nom du service, par exemple orthodontics.",
    booked: "Réservé : {dept} - {date} {start}-{end}{dentist}.\nVous pouvez annuler ou déplacer jusqu'à 24 h avant le début (/my).",
    myHeader: 'Vos prochains rendez-vous :',
    myEmpty: "Vous n'avez aucun rendez-vous à venir.",
    myLine: '{n}. {dept} - {date} {start}-{end}{dentist}{note}',
    myLocked: ' (ne peut plus être modifié ici)',
    myFooter: 'Modifier : /cancel <numéro> ou /reschedule <numéro> <AAAA-MM-JJ> <créneau>',
    cancelUsage: "Utilisation : /cancel <numéro>\nEnvoyez d'abord /my pour voir les numéros.",
    rescheduleUsage: "Utilisation : /reschedule <numéro> <AAAA-MM-JJ> <créneau 1-4>\nEnvoyez d'abord /my pour voir les numéros.",
    needList: "Envoyez d'abord /my pour que je sache de quel rendez-vous il s'agit.",
    cancelled: 'Annulé : {dept} - {date} {start}-{end}. Ce créneau est de nouveau libre.',
    rescheduled: 'Déplacé : {dept} est maintenant le {date} {start}-{end}{dentist}.',
    langSet: 'Langue : français.',
    langUsage: 'Utilisation : /lang ar | en | fr',
    unknown: 'Je ne comprends que les commandes pour le moment. Envoyez /help pour les voir.',
    generic: "Désolé, une erreur est survenue de notre côté. Rien n'a été modifié. Veuillez réessayer dans un instant.",
    e_SLOT_UNAVAILABLE: "Ce créneau n'est plus disponible. Utilisez /slots pour voir les créneaux libres.",
    e_SLOT_IN_PAST: 'Ce créneau a déjà commencé ou est passé.',
    e_DATE_CLOSED: 'Le centre est fermé à cette date.',
    e_DEPARTMENT_NOT_WORKING_DAY: "Ce service ne travaille pas ce jour-là. Envoyez /departments pour voir ses jours de travail, ou /slots pour voir les créneaux libres.",
    e_BEYOND_BOOKING_HORIZON: 'Cette date est trop lointaine pour réserver pour le moment.',
    e_PATIENT_OVERLAP: 'Vous avez déjà un rendez-vous à ce moment-là.',
    e_DAILY_CAPACITY_REACHED: 'Ce service est complet ce jour-là.',
    e_WITHIN_24H_WINDOW: "Un rendez-vous ne peut être annulé ou déplacé que 24 heures au moins avant son début. Veuillez contacter le centre.",
    e_APPOINTMENT_NOT_FOUND: 'Je ne trouve pas ce rendez-vous. Envoyez /my pour actualiser la liste.',
    e_APPOINTMENT_NOT_ACTIVE: "Ce rendez-vous n'est plus actif.",
    e_RESCHEDULE_NO_CHANGE: "C'est le même horaire que votre rendez-vous actuel.",
    e_DEPARTMENT_NOT_FOUND: 'Je ne trouve pas ce service. Envoyez /departments pour les voir.',
    e_VALIDATION_ERROR: 'Quelque chose dans la demande est invalide. Vérifiez le format (voir /help).',
  },
};

function t(lang, key, vars) {
  const table = STRINGS[lang] || STRINGS[DEFAULT_LANG];
  let s = table[key] !== undefined ? table[key] : STRINGS.en[key] !== undefined ? STRINGS.en[key] : key;
  if (vars) for (const k of Object.keys(vars)) s = s.split('{' + k + '}').join(vars[k] === undefined || vars[k] === null ? '' : String(vars[k]));
  return s;
}
function mapLang(code) {
  const base = String(code || '').toLowerCase().split('-')[0];
  return LANGS.indexOf(base) >= 0 ? base : DEFAULT_LANG;
}
function weekday(date, lang) {
  try { return new Date(date + 'T12:00:00Z').toLocaleDateString(LOCALE_TAG[lang] || 'en-GB', { weekday: 'short', timeZone: 'UTC' }); } catch (e) { return ''; }
}
function isoDay(n, lang) {
  // 2026-11-02 is a Monday
  return weekday('2026-11-0' + (1 + Number(n)), lang);
}
function addDays(date, n) {
  const d = new Date(date + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function listFresh(state, userId, key, nowMs) {
  const l = state.lists && state.lists[userId];
  return l && l[key] && nowMs - l.at <= LIST_TTL_MS ? l[key] : null;
}
function saveList(state, userId, key, value, nowMs) {
  if (!state.lists) state.lists = {};
  state.lists[userId] = Object.assign({}, state.lists[userId] || {}, { at: nowMs });
  state.lists[userId][key] = value;
}
function isDate(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && new Date(s + 'T00:00:00Z').toISOString().slice(0, 10) === s; }
function dentistText(a) { return a && a.dentist && a.dentist.name ? ' - ' + a.dentist.name : ''; }

/** Resolves "orthodontics" or "3" (number from the last /departments) to a slug, or returns {reply} explaining what to do. */
function resolveDepartment(arg, state, userId, nowMs, lang) {
  if (!arg) return { reply: null };
  if (/^\d{1,2}$/.test(arg)) {
    const list = listFresh(state, userId, 'departments', nowMs);
    if (!list) return { reply: t(lang, 'needDepartments') };
    const slug = list[Number(arg) - 1];
    return slug ? { slug: slug } : { reply: t(lang, 'needDepartments') };
  }
  const s = arg.toLowerCase();
  return /^[a-z0-9]+(-[a-z0-9]+)*$/.test(s) ? { slug: s } : { reply: t(lang, 'e_DEPARTMENT_NOT_FOUND') };
}
function resolveAppointment(arg, state, userId, nowMs) {
  const list = listFresh(state, userId, 'appointments', nowMs);
  if (/^\d{1,2}$/.test(arg || '')) return list && list[Number(arg) - 1] ? list[Number(arg) - 1] : null;
  return null;
}

function parseUpdate(update, state, nowMs) {
  const msg = update && (update.message || update.edited_message);
  if (!msg || !msg.from || !msg.chat || msg.from.is_bot) return { ignore: true };
  if (msg.chat.type !== 'private') return { ignore: true }; // never answer in groups: appointment data is personal
  const userId = String(msg.from.id);
  if (!state.lang) state.lang = {};
  const lang = state.lang[userId] || mapLang(msg.from.language_code);
  const base = { chatId: msg.chat.id, userId: userId, lang: lang, needsApi: false };
  const text = typeof msg.text === 'string' ? msg.text.trim() : '';
  const reply = (command, key, vars) => Object.assign({}, base, { command: command, replyText: t(lang, key, vars) });
  const call = (command, input, ctx) => Object.assign({}, base, { command: command, needsApi: true, input: input, ctx: ctx || {} });
  if (!text) return reply('unknown', 'unknown');

  // a bare linking code (K7QF-3MZP-9WHD) is accepted without the /link prefix
  if (text.charAt(0) !== '/' && /^[A-Za-z0-9]{4}-?[A-Za-z0-9]{4}-?[A-Za-z0-9]{4}$/.test(text)) {
    return call('link', { operation: 'link', telegramUserId: userId, params: { code: text } });
  }
  if (text.charAt(0) !== '/') return reply('unknown', 'unknown');

  const parts = text.split(/\s+/);
  const cmd = parts[0].toLowerCase().replace(/@.*$/, '');
  const args = parts.slice(1);
  const locale = lang;

  switch (cmd) {
    case '/start':
    case '/help': return reply('help', 'help');
    case '/lang': {
      const want = (args[0] || '').toLowerCase();
      if (LANGS.indexOf(want) < 0) return reply('lang', 'langUsage');
      state.lang[userId] = want;
      return Object.assign({}, base, { lang: want, command: 'lang', replyText: t(want, 'langSet') });
    }
    case '/info': return call('info', { operation: 'center', locale: locale });
    case '/departments': return call('departments', { operation: 'departments', locale: locale });
    case '/slots': {
      if (!args[0]) return reply('slots', 'slotsUsage');
      const d = resolveDepartment(args[0], state, userId, nowMs, lang);
      if (!d.slug) return Object.assign({}, base, { command: 'slots', replyText: d.reply });
      let from = args[1];
      if (from !== undefined && !isDate(from)) return reply('slots', 'slotsUsage');
      from = from || undefined;
      const to = from ? from : undefined; // one given day, otherwise the API default window (today + 13 days)
      return call('slots', { operation: 'availability', locale: locale, params: { department: d.slug, from: from, to: to } }, { slug: d.slug, oneDay: !!from });
    }
    case '/book': {
      if (args.length !== 3 || !isDate(args[1]) || !/^[1-4]$/.test(args[2])) return reply('book', 'bookUsage');
      const d = resolveDepartment(args[0], state, userId, nowMs, lang);
      if (!d.slug) return Object.assign({}, base, { command: 'book', replyText: d.reply });
      return call('book', { operation: 'book', telegramUserId: userId, locale: locale, params: { departmentSlug: d.slug, date: args[1], slotNumber: Number(args[2]) } });
    }
    case '/my': return call('my', { operation: 'myAppointments', telegramUserId: userId, locale: locale, params: { scope: 'upcoming' } });
    case '/cancel': {
      if (args.length !== 1) return reply('cancel', 'cancelUsage');
      const a = resolveAppointment(args[0], state, userId, nowMs);
      if (!a) return reply('cancel', 'needList');
      return call('cancel', { operation: 'cancel', telegramUserId: userId, locale: locale, params: { appointmentId: a.id } }, { appt: a });
    }
    case '/reschedule': {
      if (args.length !== 3 || !isDate(args[1]) || !/^[1-4]$/.test(args[2])) return reply('reschedule', 'rescheduleUsage');
      const a = resolveAppointment(args[0], state, userId, nowMs);
      if (!a) return reply('reschedule', 'needList');
      return call('reschedule', { operation: 'reschedule', telegramUserId: userId, locale: locale, params: { appointmentId: a.id, date: args[1], slotNumber: Number(args[2]) } }, { appt: a });
    }
    case '/link': {
      if (!args[0]) return reply('link', 'linkUsage');
      return call('link', { operation: 'link', telegramUserId: userId, params: { code: args.join('') } });
    }
    case '/unlink': return call('unlink', { operation: 'unlink', telegramUserId: userId });
    default: return reply('unknown', 'unknown');
  }
}

function errorText(lang, error) {
  const code = error && error.code;
  if (code === 'TELEGRAM_NOT_LINKED') return t(lang, 'notLinked');
  if (code === 'LINK_CODE_INVALID') return t(lang, 'linkInvalid');
  if (code === 'TOO_MANY_ATTEMPTS' || code === 'RATE_LIMITED') return t(lang, 'tooMany');
  const key = 'e_' + code;
  const table = STRINGS[lang] || STRINGS[DEFAULT_LANG];
  return table[key] !== undefined ? table[key] : t(lang, 'generic'); // never show raw codes or internals to patients
}
function trim(text) { return text.length > 3900 ? text.slice(0, 3890) + '\n...' : text; }

function formatReply(decision, result, state, nowMs) {
  const lang = decision.lang;
  const out = (text) => ({ chatId: decision.chatId, text: trim(text) });
  if (!decision.needsApi) return out(decision.replyText);
  if (!result || !result.ok) return out(errorText(lang, result && result.error));
  const data = result.data;
  switch (decision.command) {
    case 'link': return out(t(lang, 'linked'));
    case 'unlink': return out(t(lang, 'unlinked'));
    case 'info': {
      const lines = [data.name || ''];
      lines.push(data.addressConfigured ? t(lang, 'address', { v: data.address }) : t(lang, 'addressMissing'));
      if (data.phone) lines.push(t(lang, 'phone', { v: data.phone }));
      if (data.mapUrl) lines.push(t(lang, 'map', { v: data.mapUrl }));
      const days = Array.isArray(data.workingDays) ? data.workingDays : [];
      const dayText = days.length === 7 ? t(lang, 'everyDay') : days.map((d) => isoDay(d, lang)).join(', ');
      const slots = (data.slots || []).map((s) => s.startTime + '-' + s.endTime).join(', ');
      if (slots) lines.push(t(lang, 'hours', { days: dayText, slots: slots, tz: data.timezone || '' }));
      if (data.hoursNote) lines.push(data.hoursNote);
      return out(lines.filter(Boolean).join('\n'));
    }
    case 'departments': {
      const list = (data || []).filter((d) => d.bookable !== false);
      saveList(state, decision.userId, 'departments', list.map((d) => d.slug), nowMs);
      const lines = [t(lang, 'deptHeader')];
      list.forEach((d, i) => {
        let line = t(lang, 'deptLine', { n: i + 1, name: d.name, slug: d.slug, dentist: d.dentist && d.dentist.name ? d.dentist.name : '' }).replace(/ - $/, '');
        // a department that does not work every day says which days it works, so nobody has to guess why a date has no times
        if (Array.isArray(d.workingDays) && d.workingDays.length > 0 && d.workingDays.length < 7) line += ' (' + t(lang, 'deptDays', { days: d.workingDays.map((n) => isoDay(n, lang)).join(', ') }) + ')';
        lines.push(line);
      });
      return out(lines.join('\n'));
    }
    case 'slots': {
      const days = (data && data.days ? data.days : []).filter((d) => d.slots && d.slots.length);
      const lines = [t(lang, 'slotsHeader', { dept: decision.ctx.slug })];
      if (!days.length) { lines.push(t(lang, 'slotsNone')); return out(lines.join('\n')); }
      for (const d of days.slice(0, 14)) {
        lines.push(d.date + ' (' + weekday(d.date, lang) + '): ' + d.slots.map((s) => s.slotNumber + ') ' + s.startTime + '-' + s.endTime).join(', '));
      }
      lines.push(t(lang, 'slotsHow', { slug: decision.ctx.slug }));
      return out(lines.join('\n'));
    }
    case 'book': return out(t(lang, 'booked', apptVars(data)));
    case 'my': {
      const list = Array.isArray(data) ? data : [];
      saveList(state, decision.userId, 'appointments', list.map((a) => ({ id: a.id })), nowMs);
      if (!list.length) return out(t(lang, 'myEmpty'));
      const lines = [t(lang, 'myHeader')];
      list.forEach((a, i) => lines.push(t(lang, 'myLine', Object.assign(apptVars(a), { n: i + 1, note: a.selfService && a.selfService.canCancel ? '' : t(lang, 'myLocked') }))));
      lines.push(t(lang, 'myFooter'));
      return out(lines.join('\n'));
    }
    case 'cancel': return out(t(lang, 'cancelled', apptVars(data)));
    case 'reschedule': return out(t(lang, 'rescheduled', apptVars(data)));
    default: return out(t(lang, 'generic'));
  }
}
function apptVars(a) {
  return { dept: a && a.department ? a.department.name : '', date: a ? a.date : '', start: a ? a.startTime : '', end: a ? a.endTime : '', dentist: dentistText(a) };
}

// <exports>
if (typeof module !== 'undefined' && module.exports) module.exports = { parseUpdate, formatReply, t, mapLang, STRINGS, LANGS, errorText };
// </exports>
