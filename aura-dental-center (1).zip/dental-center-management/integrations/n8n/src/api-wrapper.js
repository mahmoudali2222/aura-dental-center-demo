'use strict';
/*
 * Dental Center API helper for n8n.
 * Pure functions: build an HTTP request for an operation, and turn the HTTP response into a uniform result.
 * This file is unit-tested (test/) and is pasted verbatim into the n8n Code nodes by build.cjs.
 * The backend enforces every booking rule; nothing here decides whether a booking is allowed.
 */
const LOCALES = ['ar', 'en', 'fr'];
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function fail(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}
function isRealDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}
function query(params) {
  const parts = [];
  for (const k of Object.keys(params)) {
    const v = params[k];
    if (v !== undefined && v !== null && v !== '') parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(v)));
  }
  return parts.length ? '?' + parts.join('&') : '';
}
function tgId(input) {
  const id = String(input.telegramUserId === undefined || input.telegramUserId === null ? '' : input.telegramUserId);
  if (!/^[1-9]\d{0,14}$/.test(id)) throw fail('BAD_INPUT', 'telegramUserId must be the numeric Telegram user id');
  return id;
}
function slug(p) {
  if (typeof p.slug !== 'string' || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(p.slug)) throw fail('BAD_INPUT', 'a department slug such as "orthodontics" is required');
  return p.slug;
}
function apptId(p) {
  if (typeof p.appointmentId !== 'string' || !UUID_RE.test(p.appointmentId)) throw fail('BAD_INPUT', 'appointmentId must be an appointment UUID');
  return p.appointmentId;
}
function slotNo(p) {
  const n = Number(p.slotNumber);
  if (!Number.isInteger(n) || n < 1 || n > 4) throw fail('BAD_INPUT', 'slotNumber must be 1, 2, 3 or 4');
  return n;
}
function dateOf(p, name) {
  if (!isRealDate(p[name])) throw fail('BAD_INPUT', name + ' must be a real date in the form YYYY-MM-DD');
  return p[name];
}

/**
 * input: { operation, telegramUserId?, locale?, params? }
 * returns { method, path, body }  (path is relative to .../api/v1/integrations)
 */
function buildRequest(input) {
  if (!input || typeof input !== 'object') throw fail('BAD_INPUT', 'input must be an object');
  const p = input.params || {};
  const locale = LOCALES.indexOf(input.locale) >= 0 ? input.locale : undefined;
  switch (input.operation) {
    case 'center': return { method: 'GET', path: '/center' + query({ locale }), body: null };
    case 'departments': return { method: 'GET', path: '/departments' + query({ locale }), body: null };
    case 'department': return { method: 'GET', path: '/departments/' + slug(p) + query({ locale }), body: null };
    case 'availability': {
      const q = { department: slug({ slug: p.department }) && p.department, from: p.from, to: p.to };
      if (q.from !== undefined) dateOf(q, 'from');
      if (q.to !== undefined) dateOf(q, 'to');
      return { method: 'GET', path: '/availability' + query(q), body: null };
    }
    case 'link': {
      const code = typeof p.code === 'string' ? p.code.trim() : '';
      if (code.length < 8 || code.length > 32) throw fail('BAD_INPUT', 'code looks wrong');
      return { method: 'POST', path: '/telegram/link', body: { code: code, telegramUserId: tgId(input) } };
    }
    case 'status': return { method: 'GET', path: '/telegram/' + tgId(input) + '/status', body: null };
    case 'unlink': return { method: 'DELETE', path: '/telegram/' + tgId(input) + '/link', body: null };
    case 'myAppointments': {
      const scope = p.scope === 'history' || p.scope === 'all' ? p.scope : 'upcoming';
      return { method: 'GET', path: '/telegram/' + tgId(input) + '/appointments' + query({ scope, locale }), body: null };
    }
    case 'book': {
      const body = { departmentSlug: slug({ slug: p.departmentSlug }) && p.departmentSlug, date: dateOf(p, 'date'), slotNumber: slotNo(p) };
      if (p.serviceId) {
        if (!UUID_RE.test(String(p.serviceId))) throw fail('BAD_INPUT', 'serviceId must be a UUID');
        body.serviceId = p.serviceId;
      }
      return { method: 'POST', path: '/telegram/' + tgId(input) + '/appointments' + query({ locale }), body: body };
    }
    case 'cancel':
      return { method: 'POST', path: '/telegram/' + tgId(input) + '/appointments/' + apptId(p) + '/cancel' + query({ locale }), body: {} };
    case 'reschedule':
      return { method: 'POST', path: '/telegram/' + tgId(input) + '/appointments/' + apptId(p) + '/reschedule' + query({ locale }), body: { date: dateOf(p, 'date'), slotNumber: slotNo(p) } };
    default:
      throw fail('BAD_INPUT', 'unknown operation "' + input.operation + '"');
  }
}

/**
 * Turns an HTTP response (n8n "full response": statusCode + body) into one shape.
 * ok === true ONLY for a 2xx answer from the backend: that is the single condition under which a booking, cancellation
 * or change may be reported as done to the patient.
 */
function normalizeResponse(res) {
  if (!res || typeof res.statusCode !== 'number') {
    return { ok: false, status: 0, error: { code: 'UPSTREAM_UNREACHABLE', message: 'No answer from the Dental Center API' }, retryable: true };
  }
  let body = res.body;
  if (typeof body === 'string') {
    try { body = body === '' ? undefined : JSON.parse(body); } catch (e) { body = undefined; }
  }
  const status = res.statusCode;
  if (status >= 200 && status < 300) {
    if (status !== 204 && !(body && body.data !== undefined)) {
      return { ok: false, status: status, error: { code: 'UPSTREAM_BAD_RESPONSE', message: 'Unexpected answer from the Dental Center API' }, retryable: false };
    }
    return { ok: true, status: status, data: body && body.data !== undefined ? body.data : null, meta: body && body.meta ? body.meta : undefined };
  }
  const err = body && body.error && typeof body.error === 'object' ? body.error : {};
  return {
    ok: false,
    status: status,
    error: { code: typeof err.code === 'string' ? err.code : 'UPSTREAM_ERROR', message: typeof err.message === 'string' ? err.message : 'Request failed', details: err.details },
    retryable: status >= 500,
  };
}

// <exports>
if (typeof module !== 'undefined' && module.exports) module.exports = { buildRequest, normalizeResponse, isRealDate, LOCALES };
// </exports>
