'use strict';
/*
 * Builds workflows/*.workflow.json from the tested sources in src/.  Usage:  node build.cjs   |   node build.cjs --check
 * The JSON contains NO credentials, tokens or keys: credentials are chosen in the n8n UI after import.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const read = (f) => fs.readFileSync(path.join(__dirname, 'src', f), 'utf8').replace(/\/\/ <exports>[\s\S]*?\/\/ <\/exports>\n?/, '').replace(/^'use strict';\n/, '');
const API = read('api-wrapper.js');
const TG = read('telegram-commands.js');

const uuid = (seed) => {
  const h = crypto.createHash('sha1').update('dental-center-n8n:' + seed).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-8${h.slice(17, 20)}-${h.slice(20, 32)}`;
};
const node = (name, type, typeVersion, position, parameters, extra) => Object.assign({ parameters, id: uuid(name), name, type, typeVersion, position }, extra || {});
const code = (name, position, body) => node(name, 'n8n-nodes-base.code', 2, position, { mode: 'runOnceForEachItem', jsCode: body });
const ifBool = (name, position, expr) => node(name, 'n8n-nodes-base.if', 2.2, position, {
  conditions: {
    options: { caseSensitive: true, leftValue: '', typeValidation: 'strict', version: 2 },
    conditions: [{ id: uuid(name + ':cond'), leftValue: `={{ ${expr} }}`, rightValue: '', operator: { type: 'boolean', operation: 'true', singleValue: true } }],
    combinator: 'and',
  },
  options: {},
});
const setBase = (name, position) => node(name, 'n8n-nodes-base.set', 3.4, position, {
  assignments: { assignments: [{ id: uuid(name + ':baseUrl'), name: 'baseUrl', value: 'http://host.docker.internal:8480/api/v1/integrations', type: 'string' }] },
  includeOtherFields: true,
  options: {},
}, { notes: 'EDIT ME: the address of the Dental Center API as seen from n8n, ending in /api/v1/integrations. Not a secret.', notesInFlow: true });
// n8n's "Send Body" switch cannot be an expression (the node marks it noDataExpression), so a request with a body and a request
// without one are two separate HTTP nodes, chosen by an IF. This was found by running the first version inside a real n8n:
// POST bodies were silently sent empty.
const http = (name, position, withBody) => node(name, 'n8n-nodes-base.httpRequest', 4.2, position, Object.assign({
  method: '={{ $json.request.method }}',
  url: '={{ $json.baseUrl + $json.request.path }}',
  authentication: 'genericCredentialType',
  genericAuthType: 'httpHeaderAuth',
}, withBody ? { sendBody: true, contentType: 'json', specifyBody: 'json', jsonBody: '={{ JSON.stringify($json.request.body) }}' } : {}, {
  options: { timeout: 15000, response: { response: { fullResponse: true, neverError: true, responseFormat: 'json' } } },
}), { credentials: { httpHeaderAuth: { id: '', name: 'Dental Center API key' } }, notes: 'Credential type "Header Auth": Name = Authorization, Value = Bearer <INTEGRATION_API_KEY>. Create it in n8n; never paste the key here.', notesInFlow: true });

// ------------------------------------------------------------------ workflow A: API wrapper (sub-workflow)
const wfApi = {
  name: 'Dental Center - API (sub-workflow)',
  nodes: [
    node('When called by another workflow', 'n8n-nodes-base.executeWorkflowTrigger', 1.1, [0, 0], { inputSource: 'passthrough' }),
    setBase('Config', [220, 0]),
    code('Build request', [440, 0], `${API}
const item = $input.item.json;
try {
  return { json: { baseUrl: item.baseUrl, request: buildRequest(item), badInput: false } };
} catch (e) {
  return { json: { badInput: true, error: { code: e.code || 'BAD_INPUT', message: String(e.message || e) } } };
}`),
    ifBool('Bad input?', [660, 0], '$json.badInput'),
    code('Return bad input', [880, -120], `const e = $input.item.json.error;
return { json: { ok: false, status: 0, error: { code: e.code, message: e.message }, retryable: false } };`),
    ifBool('Has body?', [880, 120], '$json.request.body !== null'),
    http('Call Dental Center API (JSON body)', [1100, 40], true),
    http('Call Dental Center API', [1100, 200], false),
    code('Normalize result', [1320, 120], `${API}
return { json: normalizeResponse($input.item.json) };`),
  ],
  connections: {
    'When called by another workflow': { main: [[{ node: 'Config', type: 'main', index: 0 }]] },
    Config: { main: [[{ node: 'Build request', type: 'main', index: 0 }]] },
    'Build request': { main: [[{ node: 'Bad input?', type: 'main', index: 0 }]] },
    'Bad input?': { main: [[{ node: 'Return bad input', type: 'main', index: 0 }], [{ node: 'Has body?', type: 'main', index: 0 }]] },
    'Has body?': { main: [[{ node: 'Call Dental Center API (JSON body)', type: 'main', index: 0 }], [{ node: 'Call Dental Center API', type: 'main', index: 0 }]] },
    'Call Dental Center API (JSON body)': { main: [[{ node: 'Normalize result', type: 'main', index: 0 }]] },
    'Call Dental Center API': { main: [[{ node: 'Normalize result', type: 'main', index: 0 }]] },
  },
  active: false,
  settings: { executionOrder: 'v1' },
  pinData: {},
};

// ------------------------------------------------------------------ workflow B: Telegram commands
const wfTg = {
  name: 'Dental Center - Telegram commands',
  nodes: [
    node('Telegram Trigger', 'n8n-nodes-base.telegramTrigger', 1.1, [0, 0], { updates: ['message'], additionalFields: {} },
      { webhookId: uuid('webhook'), credentials: { telegramApi: { id: '', name: 'Telegram bot' } }, notes: 'Select your existing Telegram bot credential. The bot token lives only in that credential.', notesInFlow: true }),
    code('Parse command', [220, 0], `${API}
${TG}
const state = $getWorkflowStaticData('global');
const decision = parseUpdate($input.item.json, state, Date.now());
if (decision.needsApi) {
  try { decision.request = buildRequest(decision.input); }
  catch (e) { decision.needsApi = false; decision.replyText = t(decision.lang, 'generic'); }
}
return { json: decision };`),
    ifBool('Ignore? (groups, bots)', [440, 0], '$json.ignore === true'),
    ifBool('Needs API?', [660, 120], '$json.needsApi'),
    setBase('Config', [880, 40]),
    ifBool('Has body?', [1100, 40], '$json.request.body !== null'),
    http('Call Dental Center API (JSON body)', [1320, -40], true),
    http('Call Dental Center API', [1320, 120], false),
    code('Format reply', [1540, 120], `${API}
${TG}
const state = $getWorkflowStaticData('global');
const decision = $('Parse command').item.json;
const result = decision.needsApi ? normalizeResponse($input.item.json) : null;
return { json: formatReply(decision, result, state, Date.now()) };`),
    node('Send reply', 'n8n-nodes-base.telegram', 1.2, [1760, 120], {
      resource: 'message', operation: 'sendMessage', chatId: '={{ $json.chatId }}', text: '={{ $json.text }}', additionalFields: { appendAttribution: false },
    }, { webhookId: uuid('send-webhook'), credentials: { telegramApi: { id: '', name: 'Telegram bot' } } }),
  ],
  connections: {
    'Telegram Trigger': { main: [[{ node: 'Parse command', type: 'main', index: 0 }]] },
    'Parse command': { main: [[{ node: 'Ignore? (groups, bots)', type: 'main', index: 0 }]] },
    'Ignore? (groups, bots)': { main: [[], [{ node: 'Needs API?', type: 'main', index: 0 }]] },
    'Needs API?': { main: [[{ node: 'Config', type: 'main', index: 0 }], [{ node: 'Format reply', type: 'main', index: 0 }]] },
    Config: { main: [[{ node: 'Has body?', type: 'main', index: 0 }]] },
    'Has body?': { main: [[{ node: 'Call Dental Center API (JSON body)', type: 'main', index: 0 }], [{ node: 'Call Dental Center API', type: 'main', index: 0 }]] },
    'Call Dental Center API (JSON body)': { main: [[{ node: 'Format reply', type: 'main', index: 0 }]] },
    'Call Dental Center API': { main: [[{ node: 'Format reply', type: 'main', index: 0 }]] },
    'Format reply': { main: [[{ node: 'Send reply', type: 'main', index: 0 }]] },
  },
  active: false,
  settings: { executionOrder: 'v1' },
  pinData: {},
};

const outputs = {
  'workflows/dental-center-api.workflow.json': wfApi,
  'workflows/dental-center-telegram-commands.workflow.json': wfTg,
};
const check = process.argv.includes('--check');
let stale = false;
for (const [rel, wf] of Object.entries(outputs)) {
  const file = path.join(__dirname, rel);
  const text = JSON.stringify(wf, null, 2) + '\n';
  if (check) {
    if (!fs.existsSync(file) || fs.readFileSync(file, 'utf8') !== text) { console.error('out of date: ' + rel); stale = true; }
  } else {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, text);
    console.log('wrote ' + rel + ' (' + text.length + ' bytes)');
  }
}
if (stale) process.exit(1);
module.exports = { outputs };
