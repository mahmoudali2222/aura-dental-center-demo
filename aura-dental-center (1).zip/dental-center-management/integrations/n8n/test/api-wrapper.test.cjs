'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildRequest, normalizeResponse, isRealDate } = require('../src/api-wrapper.js');

const UUID = '3f2b8c1e-9d4a-4c6b-8e7f-0a1b2c3d4e5f';
const err = (fn) => { try { fn(); } catch (e) { return e; } return null; };

test('read-only operations build the documented GET requests', () => {
  assert.deepEqual(buildRequest({ operation: 'center', locale: 'ar' }), { method: 'GET', path: '/center?locale=ar', body: null });
  assert.deepEqual(buildRequest({ operation: 'center' }), { method: 'GET', path: '/center', body: null });
  assert.equal(buildRequest({ operation: 'center', locale: 'de' }).path, '/center', 'unsupported locale is dropped, not forwarded');
  assert.equal(buildRequest({ operation: 'departments', locale: 'fr' }).path, '/departments?locale=fr');
  assert.equal(buildRequest({ operation: 'department', params: { slug: 'oral-surgery' }, locale: 'en' }).path, '/departments/oral-surgery?locale=en');
  assert.equal(buildRequest({ operation: 'availability', params: { department: 'endodontics', from: '2026-11-10', to: '2026-11-12' } }).path, '/availability?department=endodontics&from=2026-11-10&to=2026-11-12');
  assert.equal(buildRequest({ operation: 'availability', params: { department: 'endodontics' } }).path, '/availability?department=endodontics');
});

test('personal operations need the numeric Telegram user id and build the documented requests', () => {
  const base = { telegramUserId: '123456789', locale: 'en' };
  assert.deepEqual(buildRequest({ ...base, operation: 'link', params: { code: ' K7QF-3MZP-9WHD ' } }), { method: 'POST', path: '/telegram/link', body: { code: 'K7QF-3MZP-9WHD', telegramUserId: '123456789' } });
  assert.deepEqual(buildRequest({ ...base, operation: 'status' }), { method: 'GET', path: '/telegram/123456789/status', body: null });
  assert.deepEqual(buildRequest({ ...base, operation: 'unlink' }), { method: 'DELETE', path: '/telegram/123456789/link', body: null });
  assert.equal(buildRequest({ ...base, operation: 'myAppointments' }).path, '/telegram/123456789/appointments?scope=upcoming&locale=en');
  assert.equal(buildRequest({ ...base, operation: 'myAppointments', params: { scope: 'all' } }).path, '/telegram/123456789/appointments?scope=all&locale=en');
  assert.equal(buildRequest({ ...base, operation: 'myAppointments', params: { scope: 'everything' } }).path.includes('scope=upcoming'), true);
  assert.deepEqual(buildRequest({ ...base, operation: 'book', params: { departmentSlug: 'orthodontics', date: '2026-11-10', slotNumber: '2' } }),
    { method: 'POST', path: '/telegram/123456789/appointments?locale=en', body: { departmentSlug: 'orthodontics', date: '2026-11-10', slotNumber: 2 } });
  assert.deepEqual(buildRequest({ ...base, operation: 'cancel', params: { appointmentId: UUID } }), { method: 'POST', path: `/telegram/123456789/appointments/${UUID}/cancel?locale=en`, body: {} });
  assert.deepEqual(buildRequest({ ...base, operation: 'reschedule', params: { appointmentId: UUID, date: '2026-11-11', slotNumber: 3 } }),
    { method: 'POST', path: `/telegram/123456789/appointments/${UUID}/reschedule?locale=en`, body: { date: '2026-11-11', slotNumber: 3 } });
});

test('invalid input is rejected before any request is made (no path injection, no bad dates or slots)', () => {
  const bad = (input, fragment) => { const e = err(() => buildRequest(input)); assert.ok(e, JSON.stringify(input)); assert.equal(e.code, 'BAD_INPUT'); if (fragment) assert.match(e.message, fragment); };
  bad({ operation: 'nope' }, /unknown operation/);
  bad(null);
  bad({ operation: 'status' }, /telegramUserId/);
  for (const id of ['abc', '0123', '12/../../admin', '', '1234567890123456', '-5', '12 34']) bad({ operation: 'status', telegramUserId: id });
  bad({ operation: 'department', params: { slug: '../admin' } });
  bad({ operation: 'department', params: { slug: 'Ortho' } });
  bad({ operation: 'availability', params: { department: 'a/b' } });
  bad({ operation: 'availability', params: { department: 'ok', from: '2026-13-01' } });
  bad({ operation: 'cancel', telegramUserId: '1', params: { appointmentId: '../../admin/patients' } });
  bad({ operation: 'cancel', telegramUserId: '1', params: { appointmentId: `${UUID}/x` } });
  for (const slot of [0, 5, 1.5, 'x', undefined]) bad({ operation: 'book', telegramUserId: '1', params: { departmentSlug: 'ok', date: '2026-11-10', slotNumber: slot } });
  for (const date of ['2026-02-30', '10-11-2026', '2026-11-10T10:00', '', undefined]) bad({ operation: 'book', telegramUserId: '1', params: { departmentSlug: 'ok', date, slotNumber: 1 } });
  bad({ operation: 'book', telegramUserId: '1', params: { departmentSlug: 'ok', date: '2026-11-10', slotNumber: 1, serviceId: 'nope' } });
  bad({ operation: 'link', telegramUserId: '1', params: { code: 'x' } });
  bad({ operation: 'link', telegramUserId: '1', params: {} });
});

test('isRealDate accepts real calendar dates only', () => {
  assert.ok(isRealDate('2026-02-28')); assert.ok(isRealDate('2028-02-29'));
  assert.ok(!isRealDate('2026-02-29')); assert.ok(!isRealDate('2026-00-10')); assert.ok(!isRealDate(20261110));
});

test('normalizeResponse: ok only for a 2xx answer that carries data', () => {
  assert.deepEqual(normalizeResponse({ statusCode: 201, body: { data: { id: 'x' } } }), { ok: true, status: 201, data: { id: 'x' }, meta: undefined });
  assert.deepEqual(normalizeResponse({ statusCode: 200, body: { data: [1], meta: { total: 1 } } }).meta, { total: 1 });
  assert.deepEqual(normalizeResponse({ statusCode: 204, body: '' }), { ok: true, status: 204, data: null, meta: undefined });
  assert.deepEqual(normalizeResponse({ statusCode: 200, body: '{"data":{"linked":true}}' }).data, { linked: true }, 'string bodies are parsed');
  const noData = normalizeResponse({ statusCode: 200, body: { hello: 'world' } });
  assert.equal(noData.ok, false, '2xx without { data } must not count as success');
  assert.equal(noData.error.code, 'UPSTREAM_BAD_RESPONSE');
  assert.equal(normalizeResponse({ statusCode: 200, body: '<html>proxy error</html>' }).ok, false);
});

test('normalizeResponse: failures keep the backend error code and are never reported as ok', () => {
  const r = normalizeResponse({ statusCode: 409, body: { error: { code: 'SLOT_UNAVAILABLE', message: 'taken', details: { a: 1 } } } });
  assert.deepEqual(r, { ok: false, status: 409, error: { code: 'SLOT_UNAVAILABLE', message: 'taken', details: { a: 1 } }, retryable: false });
  assert.equal(normalizeResponse({ statusCode: 401, body: { error: { code: 'INVALID_INTEGRATION_KEY', message: 'x' } } }).error.code, 'INVALID_INTEGRATION_KEY');
  const s = normalizeResponse({ statusCode: 502, body: '<html>Bad gateway</html>' });
  assert.equal(s.ok, false); assert.equal(s.retryable, true); assert.equal(s.error.code, 'UPSTREAM_ERROR');
  for (const res of [undefined, null, {}, { body: { data: 1 } }, { statusCode: 'x' }]) {
    const u = normalizeResponse(res);
    assert.equal(u.ok, false); assert.equal(u.error.code, 'UPSTREAM_UNREACHABLE'); assert.equal(u.retryable, true);
  }
});
