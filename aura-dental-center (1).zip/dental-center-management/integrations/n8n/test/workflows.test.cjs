'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { runWorkflow } = require('./helpers/simulate.cjs');

const dir = path.join(__dirname, '..', 'workflows');
const load = (f) => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
const API = load('dental-center-api.workflow.json');
const TG = load('dental-center-telegram-commands.workflow.json');
const ALL = { 'dental-center-api.workflow.json': API, 'dental-center-telegram-commands.workflow.json': TG };

test('the exported files are exactly what build.cjs generates from the tested sources', () => {
  execFileSync(process.execPath, [path.join(__dirname, '..', 'build.cjs'), '--check'], { stdio: 'pipe' });
});

test('workflow structure: unique node names, valid connections, inactive, no credentials or secrets embedded', () => {
  for (const [file, wf] of Object.entries(ALL)) {
    const names = wf.nodes.map((n) => n.name);
    assert.equal(new Set(names).size, names.length, `${file}: node names must be unique`);
    assert.equal(wf.active, false, `${file}: must be imported inactive; the user activates it after setting credentials`);
    for (const [from, outs] of Object.entries(wf.connections)) {
      assert.ok(names.includes(from), `${file}: connection from unknown node ${from}`);
      for (const branch of outs.main) for (const c of branch) assert.ok(names.includes(c.node), `${file}: connection to unknown node ${c.node}`);
    }
    for (const n of wf.nodes) {
      assert.ok(Array.isArray(n.position) && n.position.length === 2, `${file}/${n.name}: position`);
      for (const cred of Object.values(n.credentials || {})) assert.equal(cred.id, '', `${file}/${n.name}: credential ids must stay empty, the user selects their own credentials`);
    }
    const raw = JSON.stringify(wf);
    assert.doesNotMatch(raw, /\d{8,10}:[A-Za-z0-9_-]{30,}/, `${file}: looks like a Telegram bot token`);
    assert.doesNotMatch(raw, /Bearer\s+[A-Za-z0-9._~+\/-]{16,}/, `${file}: looks like a bearer token`);
    assert.doesNotMatch(raw, /(api[_-]?key|secret|password)"\s*:\s*"[^"]{8,}/i, `${file}: looks like an embedded secret`);
    assert.doesNotMatch(raw, /https?:\/\/(?!host\.docker\.internal|localhost|127\.0\.0\.1|example\.)[a-z0-9.-]+\.(com|net|org|io|app|dev)/i, `${file}: no real hostnames baked in`);
  }
});

test('the API key is only ever read from the n8n credential (Header Auth), never from a node parameter', () => {
  for (const wf of Object.values(ALL)) {
    for (const n of wf.nodes.filter((x) => x.type.endsWith('.httpRequest'))) {
      assert.equal(n.parameters.authentication, 'genericCredentialType');
      assert.equal(n.parameters.genericAuthType, 'httpHeaderAuth');
      assert.ok(n.credentials.httpHeaderAuth);
      assert.equal(n.parameters.sendHeaders, undefined, 'no hand-written Authorization header');
      assert.equal(n.parameters.options.response.response.neverError, true, 'error answers must reach the formatter, not abort the run');
      assert.equal(n.parameters.options.response.response.fullResponse, true, 'the status code is needed to decide success');
    }
  }
});

test('requests with a body and without one use separate HTTP nodes (n8n ignores expressions in "Send Body")', () => {
  for (const [file, wf] of Object.entries(ALL)) {
    const nodes = wf.nodes.filter((n) => n.type.endsWith('.httpRequest'));
    assert.equal(nodes.length, 2, `${file}: one node with a JSON body, one without`);
    const withBody = nodes.filter((n) => n.parameters.sendBody === true);
    const without = nodes.filter((n) => n.parameters.sendBody === undefined);
    assert.equal(withBody.length, 1, file); assert.equal(without.length, 1, file);
    assert.equal(withBody[0].parameters.contentType, 'json');
    assert.equal(withBody[0].parameters.specifyBody, 'json');
    assert.match(withBody[0].parameters.jsonBody, /JSON\.stringify\(\$json\.request\.body\)/);
    assert.equal(without[0].parameters.jsonBody, undefined);
    for (const n of nodes) assert.notEqual(typeof n.parameters.sendBody, 'string', `${file}/${n.name}: an expression in sendBody is silently treated as "no body" by n8n`);
    // exactly one of them is reached for any request
    const gate = wf.nodes.find((n) => n.name === 'Has body?');
    assert.ok(gate, `${file}: Has body? node`);
    const out = wf.connections['Has body?'].main;
    assert.equal(out[0][0].node, withBody[0].name); assert.equal(out[1][0].node, without[0].name);
  }
});

test('the base URL is a single, clearly named, editable value in each workflow', () => {
  for (const wf of Object.values(ALL)) {
    const cfg = wf.nodes.find((n) => n.name === 'Config');
    assert.deepEqual(cfg.parameters.assignments.assignments.map((a) => a.name), ['baseUrl']);
    assert.match(cfg.parameters.assignments.assignments[0].value, /^http:\/\/host\.docker\.internal:8480\/api\/v1\/integrations$/);
  }
});

// ---------- end-to-end through the real Code nodes with a fake HTTP layer ----------
const NOW = Date.now();
const UUID = '3f2b8c1e-9d4a-4c6b-8e7f-0a1b2c3d4e5f';
const update = (text, id = 4242, extra = {}) => ({ update_id: 1, message: { message_id: 9, from: { id, is_bot: false, first_name: 'P', language_code: 'en' }, chat: { id, type: 'private' }, date: 0, text, ...extra } });
const resp = (statusCode, body) => ({ statusCode, headers: {}, body });
const appt = { id: UUID, status: 'booked', department: { slug: 'orthodontics', name: 'Orthodontics' }, dentist: { name: 'Dr. Sample' }, date: '2026-11-10', startTime: '18:00', endTime: '20:00', selfService: { canCancel: true } };

function fakeApi(handlers) {
  const calls = [];
  const http = async (req) => {
    calls.push(req);
    const h = handlers.find((x) => x.method === req.method && x.match.test(req.url));
    if (!h) return resp(404, { error: { code: 'NOT_FOUND', message: 'no route' } });
    return h.reply(req);
  };
  return { http, calls };
}
const go = (text, api, opts = {}) => runWorkflow(TG, 'Telegram Trigger', update(text, opts.id, opts.extra), { http: api.http, staticData: opts.state || {} });

test('workflow: /book is reported as done only after the backend answered 201', async () => {
  const api = fakeApi([{ method: 'POST', match: /\/telegram\/4242\/appointments\?locale=en$/, reply: () => resp(201, { data: appt }) }]);
  const r = await go('/book orthodontics 2026-11-10 2', api);
  assert.equal(api.calls.length, 1);
  assert.equal(api.calls[0].url, 'http://host.docker.internal:8480/api/v1/integrations/telegram/4242/appointments?locale=en');
  assert.deepEqual(api.calls[0].body, { departmentSlug: 'orthodontics', date: '2026-11-10', slotNumber: 2 });
  assert.equal(r.sent.length, 1);
  assert.equal(r.sent[0].chatId, 4242);
  assert.match(r.sent[0].text, /Booked: Orthodontics - 2026-11-10 18:00-20:00 - Dr\. Sample/);
});

test('workflow: every kind of failure leads to an honest message, never to a success message', async () => {
  const failures = [
    resp(409, { error: { code: 'SLOT_UNAVAILABLE', message: 'x' } }),
    resp(403, { error: { code: 'TELEGRAM_NOT_LINKED', message: 'x' } }),
    resp(401, { error: { code: 'INVALID_INTEGRATION_KEY', message: 'x' } }),
    resp(503, { error: { code: 'INTEGRATION_DISABLED', message: 'x' } }),
    resp(500, { error: { code: 'INTERNAL_ERROR', message: 'x' } }),
    resp(502, '<html>Bad Gateway</html>'),
    resp(200, { surprise: true }),
    resp(0, ''),
    undefined,
  ];
  for (const f of failures) {
    const api = fakeApi([{ method: 'POST', match: /./, reply: () => f }]);
    const r = await go('/book orthodontics 2026-11-10 2', api);
    assert.equal(r.sent.length, 1, JSON.stringify(f));
    assert.doesNotMatch(r.sent[0].text, /Booked:/, JSON.stringify(f));
    assert.doesNotMatch(r.sent[0].text, /INVALID_INTEGRATION_KEY|INTEGRATION_DISABLED|INTERNAL_ERROR|undefined|\[object/, 'internals are not leaked to the patient');
  }
});

test('workflow: unlinked user gets the linking instructions; the code flow works end to end', async () => {
  const state = {};
  let linked = false;
  const api = fakeApi([
    { method: 'GET', match: /\/telegram\/4242\/appointments/, reply: () => (linked ? resp(200, { data: [appt], meta: {} }) : resp(403, { error: { code: 'TELEGRAM_NOT_LINKED', message: 'x' } })) },
    { method: 'POST', match: /\/telegram\/link$/, reply: (req) => { assert.deepEqual(req.body, { code: 'K7QF-3MZP-9WHD', telegramUserId: '4242' }); linked = true; return resp(200, { data: { linked: true } }); } },
  ]);
  const before = await go('/my', api, { state });
  assert.match(before.sent[0].text, /not linked.*\/link YOUR-CODE/s);
  const link = await go('/link K7QF-3MZP-9WHD', api, { state });
  assert.match(link.sent[0].text, /now linked/);
  const after = await go('/my', api, { state });
  assert.match(after.sent[0].text, /1\. Orthodontics - 2026-11-10 18:00-20:00 - Dr\. Sample/);
  const cancelApi = fakeApi([{ method: 'POST', match: new RegExp(`/telegram/4242/appointments/${UUID}/cancel\\?locale=en$`), reply: () => resp(200, { data: { ...appt, status: 'cancelled' } }) }]);
  const cancelled = await go('/cancel 1', cancelApi, { state });
  assert.equal(cancelApi.calls.length, 1);
  assert.match(cancelled.sent[0].text, /Cancelled: Orthodontics/);
});

test('workflow: /unlink answers 204 with an empty body', async () => {
  const api = fakeApi([{ method: 'DELETE', match: /\/telegram\/4242\/link$/, reply: () => resp(204, '') }]);
  const r = await go('/unlink', api);
  assert.match(r.sent[0].text, /no longer linked/);
});

test('workflow: group chats, bots and non-message updates produce no API call and no reply', async () => {
  const api = fakeApi([{ method: 'GET', match: /./, reply: () => resp(200, { data: [] }) }]);
  for (const u of [update('/my', 1, { chat: { id: -1001, type: 'supergroup' } }), { update_id: 3 }]) {
    const r = await runWorkflow(TG, 'Telegram Trigger', u, { http: api.http, staticData: {} });
    assert.equal(r.sent.length, 0);
  }
  const bot = update('/my'); bot.message.from.is_bot = true;
  assert.equal((await runWorkflow(TG, 'Telegram Trigger', bot, { http: api.http, staticData: {} })).sent.length, 0);
  assert.equal(api.calls.length, 0);
});

test('workflow: local-only commands never touch the API', async () => {
  const api = fakeApi([]);
  for (const t of ['/help', '/start', 'hello', '/lang fr', '/book', '/cancel 7']) {
    const r = await go(t, api);
    assert.equal(r.sent.length, 1, t);
  }
  assert.equal(api.calls.length, 0);
});

test('workflow: the language choice and the numbered lists live in workflow static data, per Telegram user', async () => {
  const state = {};
  const api = fakeApi([{ method: 'GET', match: /\/telegram\/4242\/appointments/, reply: () => resp(200, { data: [appt] }) }]);
  await go('/lang fr', api, { state });
  const r = await go('/my', api, { state });
  assert.match(r.sent[0].text, /Orthodontics/);
  assert.equal(state.lang['4242'], 'fr');
  assert.deepEqual(state.lists['4242'].appointments, [{ id: UUID }]);
  const other = await go('/help', api, { state, id: 777 });
  assert.match(other.sent[0].text, /I can help/, 'another user keeps their own language');
  assert.match((await go('/help', api, { state })).sent[0].text, /Je peux vous aider/);
});

test('API sub-workflow: validates before calling, passes the Bearer-protected request through, normalizes the answer', async () => {
  const api = fakeApi([{ method: 'GET', match: /\/availability\?department=endodontics$/, reply: () => resp(200, { data: { days: [] } }) }]);
  const ok = await runWorkflow(API, 'When called by another workflow', { operation: 'availability', params: { department: 'endodontics' } }, { http: api.http });
  assert.deepEqual(ok.last, { ok: true, status: 200, data: { days: [] }, meta: undefined });
  assert.equal(api.calls[0].url, 'http://host.docker.internal:8480/api/v1/integrations/availability?department=endodontics');
  const bad = await runWorkflow(API, 'When called by another workflow', { operation: 'cancel', telegramUserId: '5', params: { appointmentId: '../../admin' } }, { http: api.http });
  assert.equal(bad.last.ok, false);
  assert.equal(bad.last.error.code, 'BAD_INPUT');
  assert.equal(api.calls.length, 1, 'invalid input never reaches the network');
  const down = await runWorkflow(API, 'When called by another workflow', { operation: 'center' }, { http: async () => undefined });
  assert.equal(down.last.ok, false); assert.equal(down.last.error.code, 'UPSTREAM_UNREACHABLE');
});
