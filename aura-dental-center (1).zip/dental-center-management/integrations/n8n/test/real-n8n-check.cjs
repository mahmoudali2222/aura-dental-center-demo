#!/usr/bin/env node
'use strict';
/*
 * Runs the exported workflows inside a REAL n8n (CLI) against a REAL running Dental Center backend.
 * It is a manual check, not part of `npm test`, because it needs two things the plain test suite does not:
 *   1. an installed n8n (the version you intend to use; recent n8n needs Node >= 24), and
 *   2. a running backend with INTEGRATION_API_KEY set, reachable at N8N_REAL_BASE_URL.
 *
 *   N8N_BIN=<path to n8n/bin/n8n> \
 *   N8N_REAL_NODE=<node executable that satisfies n8n's engines, default: node> \
 *   N8N_REAL_BASE_URL=http://127.0.0.1:3490/api/v1/integrations \
 *   N8N_REAL_KEY=<the INTEGRATION_API_KEY of that backend> \
 *   node test/real-n8n-check.cjs
 *
 * What is replaced: the Telegram Trigger (updates are injected by a Code node) and the Telegram "Send reply" node (the text is
 * captured instead of being sent). Everything else - expressions, IF/Set nodes, HTTP Request with Header Auth credential, the
 * embedded Code nodes - is the exported workflow, executed by n8n. The script creates a throwaway n8n user folder and never
 * touches an existing n8n installation. It prints one line per check and exits non-zero on the first failure.
 */
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const N8N_BIN = process.env.N8N_BIN;
const NODE = process.env.N8N_REAL_NODE || process.execPath;
const BASE_URL = (process.env.N8N_REAL_BASE_URL || '').replace(/\/+$/, '');
const KEY = process.env.N8N_REAL_KEY || '';
if (!N8N_BIN || !BASE_URL || !KEY) {
  console.error('Set N8N_BIN, N8N_REAL_BASE_URL and N8N_REAL_KEY (see the header of this file).');
  process.exit(2);
}
const ORIGIN = new URL(BASE_URL).origin;
const WF_DIR = path.join(__dirname, '..', 'workflows');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'dc-n8n-real-'));
const ENV = {
  ...process.env,
  N8N_USER_FOLDER: path.join(TMP, 'home'),
  N8N_DIAGNOSTICS_ENABLED: 'false',
  N8N_VERSION_NOTIFICATIONS_ENABLED: 'false',
  N8N_PERSONALIZATION_ENABLED: 'false',
  N8N_TEMPLATES_ENABLED: 'false',
};
fs.mkdirSync(ENV.N8N_USER_FOLDER, { recursive: true });

let failures = 0;
const check = (name, ok, detail) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : `\n      ${detail ?? ''}`}`);
  if (!ok) failures++;
};

function n8n(args) {
  const r = spawnSync(NODE, [N8N_BIN, ...args], { env: ENV, encoding: 'utf8', timeout: 240_000, maxBuffer: 64 * 1024 * 1024 });
  return { code: r.status, out: r.stdout || '', err: r.stderr || '' };
}

function writeJson(name, value) {
  const file = path.join(TMP, name);
  fs.writeFileSync(file, JSON.stringify(value));
  return file;
}

const load = (f) => JSON.parse(fs.readFileSync(path.join(WF_DIR, f), 'utf8'));
const CRED = (key) => ({ id: 'dcreal1', name: 'Dental Center API key', type: 'httpHeaderAuth', data: { name: 'Authorization', value: `Bearer ${key}` } });

function useTestCredential(wf) {
  for (const n of wf.nodes) {
    if (n.type.endsWith('.httpRequest')) n.credentials = { httpHeaderAuth: { id: 'dcreal1', name: 'Dental Center API key' } };
    if (n.name === 'Config') n.parameters.assignments.assignments[0].value = BASE_URL;
  }
}

/** Replaces the trigger by a Code node that emits `items`, and (for the bot) the Telegram sender by a capture node. */
function asTestWorkflow(source, id, items, staticData) {
  const wf = JSON.parse(JSON.stringify(source));
  if (staticData) wf.staticData = staticData;
  wf.id = id;
  wf.name = `${source.name} (real-n8n check)`;
  const triggerName = wf.nodes.find((n) => /Trigger$/.test(n.type) || n.type.endsWith('executeWorkflowTrigger') || n.type.endsWith('telegramTrigger')).name;
  const trigger = wf.nodes.find((n) => n.name === triggerName);
  const firstTargets = wf.connections[triggerName].main[0];
  wf.nodes = wf.nodes.filter((n) => n.name !== triggerName);
  delete wf.connections[triggerName];
  wf.nodes.push(
    { id: 'chk-manual', name: 'Manual', type: 'n8n-nodes-base.manualTrigger', typeVersion: 1, position: [trigger.position[0] - 400, trigger.position[1]], parameters: {} },
    { id: 'chk-inputs', name: 'Inputs', type: 'n8n-nodes-base.code', typeVersion: 2, position: [trigger.position[0] - 200, trigger.position[1]], parameters: { mode: 'runOnceForAllItems', jsCode: `return ${JSON.stringify(items.map((json) => ({ json })))};` } },
  );
  wf.connections.Manual = { main: [[{ node: 'Inputs', type: 'main', index: 0 }]] };
  wf.connections.Inputs = { main: [firstTargets] };
  const send = wf.nodes.find((n) => n.type.endsWith('.telegram'));
  if (send) {
    send.type = 'n8n-nodes-base.code';
    send.typeVersion = 2;
    delete send.credentials;
    send.parameters = { mode: 'runOnceForEachItem', jsCode: 'return { json: { chatId: $json.chatId, text: $json.text } };' };
    send.name = 'Send reply';
  }
  useTestCredential(wf);
  return wf;
}

function execute(workflow, id) {
  const imp = n8n(['import:workflow', `--input=${writeJson(`${id}.json`, workflow)}`]);
  if (imp.code !== 0) throw new Error(`import failed for ${id}:\n${imp.out}\n${imp.err}`);
  const run = n8n(['execute', `--id=${id}`]);
  const start = run.out.search(/^\{/m);
  if (start < 0) throw new Error(`no JSON result for ${id}:\n${run.out}\n${run.err}`);
  const result = JSON.parse(run.out.slice(start, run.out.lastIndexOf('}') + 1));
  return { status: result.status, runData: result.data.resultData.runData, error: result.data.resultData.error };
}

const outputs = (run, node) => (run.runData[node] || []).flatMap((r) => (r.data.main[0] || []).map((i) => i.json));

async function api(method, p, body, cookie, csrf) {
  const headers = { 'content-type': 'application/json' };
  if (cookie) headers.cookie = cookie;
  if (csrf) headers['x-csrf-token'] = csrf;
  const res = await fetch(`${ORIGIN}${p}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : undefined, cookie: (res.headers.getSetCookie?.() || []).map((c) => c.split(';')[0]).join('; ') };
}

/** Picks bookable slots far enough ahead (24-hour rule) and different from anything an earlier run left behind. */
async function freeSlots(department, count) {
  const from = cairoDatePlus(5);
  const res = await api('GET', `/api/v1/public/departments/${department}/availability?from=${from}&to=${cairoDatePlus(40)}`);
  const picks = [];
  for (const day of [...res.body.data.days].reverse()) {
    if (day.status !== 'open' || day.slots.length === 0) continue;
    picks.push({ date: day.date, slotNumber: day.slots[0].slotNumber, startTime: day.slots[0].startTime, endTime: day.slots[0].endTime });
    if (picks.length === count) break;
  }
  if (picks.length < count) throw new Error(`not enough free ${department} slots to run the check`);
  return picks;
}

function cairoDatePlus(days) {
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit', day: '2-digit' });
  const [y, m, d] = f.format(new Date()).split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10);
}

(async () => {
  console.log(`n8n: ${n8n(['--version']).out.trim() || 'unknown'}   backend: ${ORIGIN}`);
  const imp = n8n(['import:credentials', `--input=${writeJson('cred.json', [CRED(KEY)])}`]);
  check('credential import', imp.code === 0, imp.out + imp.err);

  // 1. both exported workflows import untouched (this is the file the user will import)
  for (const f of ['dental-center-api.workflow.json', 'dental-center-telegram-commands.workflow.json']) {
    const r = n8n(['import:workflow', `--input=${path.join(WF_DIR, f)}`]);
    check(`import ${f}`, r.code === 0 && /Successfully imported 1 workflow/.test(r.out), r.out + r.err);
  }

  // 2. API sub-workflow, real HTTP against the real backend
  const apiRun = execute(asTestWorkflow(load('dental-center-api.workflow.json'), 'chkapi01', [
    { operation: 'center', locale: 'en' },
    { operation: 'departments', locale: 'en' },
    { operation: 'availability', params: { department: 'endodontics' } },
    { operation: 'availability', params: { department: 'no-such-department' } },
    { operation: 'status', telegramUserId: '123456789' },
    { operation: 'myAppointments', telegramUserId: '123456789' },
    { operation: 'cancel', telegramUserId: '5', params: { appointmentId: '../../admin' } },
  ]), 'chkapi01');
  check('API sub-workflow finished', apiRun.status === 'success', JSON.stringify(apiRun.error));
  const normalized = outputs(apiRun, 'Normalize result');
  const bad = outputs(apiRun, 'Return bad input');
  check('center -> ok with timezone and four slots', normalized[0]?.ok === true && normalized[0].data.timezone && normalized[0].data.slots.length === 4, JSON.stringify(normalized[0]));
  check('departments -> ok, non-empty list', normalized[1]?.ok === true && normalized[1].data.length > 0, JSON.stringify(normalized[1]));
  check('availability -> ok with days', normalized[2]?.ok === true && Array.isArray(normalized[2].data.days), JSON.stringify(normalized[2]));
  check('unknown department -> ok:false DEPARTMENT_NOT_FOUND', normalized[3]?.ok === false && normalized[3].error.code === 'DEPARTMENT_NOT_FOUND', JSON.stringify(normalized[3]));
  check('unlinked status -> linked:false', normalized[4]?.ok === true && normalized[4].data.linked === false, JSON.stringify(normalized[4]));
  check('unlinked appointments -> TELEGRAM_NOT_LINKED', normalized[5]?.ok === false && normalized[5].error.code === 'TELEGRAM_NOT_LINKED', JSON.stringify(normalized[5]));
  check('path-injection input rejected before any request', bad.length === 1 && bad[0].error.code === 'BAD_INPUT' && normalized.length === 6, JSON.stringify({ bad, n: normalized.length }));

  // 3. Telegram command workflow
  const tg = 880000000 + Math.floor(Math.random() * 1_000_000);
  const upd = (text, o = {}) => ({ update_id: 1, message: { message_id: 1, from: { id: o.id ?? tg, is_bot: !!o.bot, first_name: 'T', language_code: o.lang ?? 'en' }, chat: { id: o.chatId ?? o.id ?? tg, type: o.type ?? 'private' }, date: 0, text } });
  const bot = load('dental-center-telegram-commands.workflow.json');
  const say = (id, updates, staticData) => {
    const run = execute(asTestWorkflow(bot, id, updates, staticData), id);
    return { run, replies: outputs(run, 'Send reply') };
  };

  // each update comes from its own Telegram user so that replies can be matched to updates even though n8n runs the
  // "needs API" and "local reply" branches in its own order
  const pub = say('chktg01', [upd('/info', { id: tg + 11 }), upd('/departments', { id: tg + 12 }), upd('/slots endodontics', { id: tg + 13 }), upd('/help', { id: tg + 14 }), upd('/my', { id: tg + 15 }), upd('/my', { type: 'supergroup', chatId: -100123 }), upd('/my', { bot: true, id: tg + 17 })]);
  const reply = (r, id) => r.replies.find((x) => x.chatId === id)?.text || '';
  check('bot public commands finished', pub.run.status === 'success', JSON.stringify(pub.run.error));
  check('group and bot messages are ignored (5 replies for 7 updates)', pub.replies.length === 5, `${pub.replies.length}`);
  check('/info shows slot times and the time zone from the API', /16:00-18:00.*22:00-00:00/.test(reply(pub, tg + 11)) && /Africa\/Cairo/.test(reply(pub, tg + 11)), reply(pub, tg + 11));
  check('/departments lists departments', /1\. .*\[[a-z-]+\]/.test(reply(pub, tg + 12)), reply(pub, tg + 12));
  check('/slots lists free times', /1\) 16:00-18:00/.test(reply(pub, tg + 13)), reply(pub, tg + 13));
  check('/help lists commands', /\/book/.test(reply(pub, tg + 14)), reply(pub, tg + 14));
  check('unlinked /my explains how to link', /not linked/i.test(reply(pub, tg + 15)), reply(pub, tg + 15));

  const phone = `+2010${String(Math.floor(Math.random() * 1e8)).padStart(8, '0')}`;
  const reg = await api('POST', '/api/v1/patient/auth/register', { fullName: 'Real N8N Check', phone, password: `Check-${Date.now()}-Pw` });
  check('test patient registered through the real API', reg.status === 201, JSON.stringify(reg.body));
  const csrf = reg.body.data.csrfToken;
  const code = (await api('POST', '/api/v1/patient/telegram/link-token', {}, reg.cookie, csrf)).body.data.code;
  const linked = say('chktg02', [upd(`/link ${code}`)]);
  check('/link with the real one-time code links the chat', /now linked/.test(linked.replies[0]?.text || ''), linked.replies[0]?.text);
  check('backend confirms the link', (await api('GET', '/api/v1/patient/telegram', undefined, reg.cookie)).body.data.linked === true, '');
  const replay = say('chktg03', [upd(`/link ${code}`, { id: tg + 1 })]);
  check('the same code cannot be used again', /invalid or has expired/.test(replay.replies[0]?.text || ''), replay.replies[0]?.text);

  const [first, second, third] = await freeSlots('endodontics', 3);
  const date = first.date;
  const booked = say('chktg04', [upd(`/book endodontics ${date} ${first.slotNumber}`)]);
  check('/book answers "Booked" only after the backend created it', new RegExp(`^Booked: Endodontics - ${date} ${first.startTime}-${first.endTime}`).test(booked.replies[0]?.text || ''), booked.replies[0]?.text);
  const mine = (await api('GET', '/api/v1/patient/appointments?scope=upcoming', undefined, reg.cookie)).body.data;
  check('the booking is visible to the patient on the website API', mine.length === 1 && mine[0].createdVia === 'telegram' && mine[0].date === date && mine[0].slotNumber === first.slotNumber, JSON.stringify(mine));
  const again = say('chktg05', [upd(`/book endodontics ${date} ${first.slotNumber}`)]);
  check('booking the same slot again is refused honestly', !/^Booked/.test(again.replies[0]?.text || '') && /overlap|already|time/i.test(again.replies[0]?.text || ''), again.replies[0]?.text);
  const list = say('chktg06', [upd('/my')]);
  check('/my lists the appointment', new RegExp(`1\\. Endodontics - ${date} ${first.startTime}-${first.endTime}`).test(list.replies[0]?.text || ''), list.replies[0]?.text);

  // /cancel and /reschedule use the numbers of the last /my. n8n keeps workflow static data only for production executions,
  // so the list a previous /my would have stored is seeded into the test workflow (the real Code nodes then read it back).
  const apptId = mine[0].id;
  const seeded = () => ({ global: { lang: {}, lists: { [tg]: { at: Date.now(), appointments: [{ id: apptId }] } } } });
  const noList = say('chktg07', [upd('/cancel 1')]);
  check('/cancel without a remembered list asks for /my first and changes nothing', /\/my first/.test(noList.replies[0]?.text || '') && (await api('GET', '/api/v1/patient/appointments?scope=upcoming', undefined, reg.cookie)).body.data.length === 1, noList.replies[0]?.text);
  const newDate = second.date;
  const moved = say('chktg08', [upd(`/reschedule 1 ${newDate} ${second.slotNumber}`)], seeded());
  check('/reschedule moves the appointment', new RegExp(`^Moved: Endodontics is now ${newDate} ${second.startTime}-${second.endTime}`).test(moved.replies[0]?.text || ''), moved.replies[0]?.text);
  const after = (await api('GET', '/api/v1/patient/appointments?scope=upcoming', undefined, reg.cookie)).body.data[0];
  check('the website API shows the new date and slot', after.date === newDate && after.slotNumber === second.slotNumber && after.rescheduledCount === 1, JSON.stringify(after));
  const cancelled = say('chktg09', [upd('/cancel 1')], seeded());
  check('/cancel cancels it', new RegExp(`^Cancelled: Endodontics - ${newDate} ${second.startTime}-${second.endTime}`).test(cancelled.replies[0]?.text || ''), cancelled.replies[0]?.text);
  const gone = (await api('GET', '/api/v1/patient/appointments?scope=all', undefined, reg.cookie)).body.data[0];
  check('the backend row is cancelled by telegram', gone.status === 'cancelled' && gone.cancelledBy === 'telegram', JSON.stringify(gone));
  const unlinked = say('chktg10', [upd('/unlink')]);
  check('/unlink answers and the backend link is gone (204 handled)', /no longer linked/.test(unlinked.replies[0]?.text || '') && (await api('GET', '/api/v1/patient/telegram', undefined, reg.cookie)).body.data.linked === false, unlinked.replies[0]?.text);

  const wrongKey = (() => {
    n8n(['import:credentials', `--input=${writeJson('cred-bad.json', [CRED('wrong-key-wrong-key-wrong-key-123456')])}`]);
    return say('chktg11', [upd(`/book endodontics ${third.date} ${third.slotNumber}`)]);
  })();
  check('a wrong integration key never produces a success message', !/^Booked/.test(wrongKey.replies[0]?.text || '') && wrongKey.replies.length === 1, wrongKey.replies[0]?.text);
  n8n(['import:credentials', `--input=${writeJson('cred.json', [CRED(KEY)])}`]);

  fs.rmSync(TMP, { recursive: true, force: true });
  console.log(failures === 0 ? '\nAll real-n8n checks passed.' : `\n${failures} check(s) FAILED.`);
  process.exit(failures === 0 ? 0 : 1);
})().catch((e) => {
  console.error(e);
  console.error(`(work files kept in ${TMP})`);
  process.exit(1);
});
