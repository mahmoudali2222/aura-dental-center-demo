'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseUpdate, formatReply, STRINGS, LANGS, mapLang, errorText } = require('../src/telegram-commands.js');
const { buildRequest, normalizeResponse } = require('../src/api-wrapper.js');

const NOW = Date.parse('2026-11-02T08:00:00Z');
const UUID_A = '3f2b8c1e-9d4a-4c6b-8e7f-0a1b2c3d4e5f';
const UUID_B = '4a2b8c1e-9d4a-4c6b-8e7f-0a1b2c3d4e60';
const upd = (text, o = {}) => ({ update_id: 1, message: { message_id: 1, from: { id: o.id || 111222333, is_bot: !!o.bot, first_name: 'T', language_code: o.lang }, chat: { id: o.chatId || o.id || 111222333, type: o.type || 'private' }, date: 0, text } });
const ok = (data, meta) => ({ ok: true, status: 200, data, meta });
const bad = (code, status = 409) => ({ ok: false, status, error: { code, message: 'x' }, retryable: false });
const appt = (o = {}) => ({ id: UUID_A, status: 'booked', department: { slug: 'orthodontics', name: 'Orthodontics' }, dentist: { name: 'Dr. Sample' }, date: '2026-11-10', startTime: '18:00', endTime: '20:00', selfService: { canCancel: true }, ...o });
const run = (text, state = {}, o = {}) => parseUpdate(upd(text, o), state, NOW);

test('only private chats from real users are served', () => {
  assert.deepEqual(parseUpdate(upd('/my', { type: 'group', chatId: -100123 }), {}, NOW), { ignore: true });
  assert.deepEqual(parseUpdate(upd('/my', { type: 'supergroup' }), {}, NOW), { ignore: true });
  assert.deepEqual(parseUpdate(upd('/my', { type: 'channel' }), {}, NOW), { ignore: true });
  assert.deepEqual(parseUpdate(upd('/my', { bot: true }), {}, NOW), { ignore: true });
  assert.deepEqual(parseUpdate({ update_id: 5, callback_query: {} }, {}, NOW), { ignore: true });
  assert.deepEqual(parseUpdate({}, {}, NOW), { ignore: true });
  assert.deepEqual(parseUpdate(null, {}, NOW), { ignore: true });
  assert.equal(run('/my', {}, { type: 'private' }).needsApi, true);
});

test('the Telegram user id comes from Telegram (message.from), never from the text', () => {
  const d = run('/my 999 /link 555', {}, { id: 424242 });
  assert.equal(d.input.telegramUserId, '424242');
  const spoof = run('/book orthodontics 2026-11-10 2 telegramUserId=999', {}, { id: 424242 });
  assert.match(spoof.replyText, /Usage|الاستخدام|Utilisation/, 'extra arguments make it a usage error, nothing is sent');
  const link = run('/link K7QF-3MZP-9WHD', {}, { id: 424242 });
  assert.deepEqual(buildRequest(link.input).body, { code: 'K7QF-3MZP-9WHD', telegramUserId: '424242' });
});

test('language: Telegram language code, overridable with /lang and remembered', () => {
  assert.equal(mapLang('ar-EG'), 'ar'); assert.equal(mapLang('fr'), 'fr'); assert.equal(mapLang('en-GB'), 'en'); assert.equal(mapLang('de'), 'ar'); assert.equal(mapLang(undefined), 'ar');
  const state = {};
  assert.equal(run('/help', state, { lang: 'fr' }).lang, 'fr');
  const set = run('/lang en', state, { lang: 'fr' });
  assert.equal(set.lang, 'en'); assert.match(set.replyText, /English/);
  assert.equal(run('/help', state, { lang: 'fr' }).lang, 'en', 'the choice sticks for this user');
  assert.equal(run('/help', state, { lang: 'fr', id: 7 }).lang, 'fr', 'and only for this user');
  assert.match(run('/lang xx', state).replyText, /\/lang ar/);
});

test('commands that need no API answer locally; commands are case-insensitive and accept @botname', () => {
  for (const c of ['/start', '/help', '/HELP', '/help@DentalBot']) { const d = run(c); assert.equal(d.needsApi, false); assert.match(d.replyText, /\/book/); }
  assert.equal(run('hello there').needsApi, false);
  assert.match(run('hello there', {}, { lang: 'en' }).replyText, /\/help/);
  assert.equal(run('').needsApi, false);
  assert.equal(run('/unknowncmd').needsApi, false);
});

test('read commands become the right API operations', () => {
  assert.deepEqual(run('/info', {}, { lang: 'en' }).input, { operation: 'center', locale: 'en' });
  assert.deepEqual(run('/departments', {}, { lang: 'fr' }).input, { operation: 'departments', locale: 'fr' });
  const s = run('/slots Orthodontics', {}, { lang: 'en' });
  assert.deepEqual(s.input, { operation: 'availability', locale: 'en', params: { department: 'orthodontics', from: undefined, to: undefined } });
  assert.equal(buildRequest(s.input).path, '/availability?department=orthodontics');
  const day = run('/slots orthodontics 2026-11-10');
  assert.equal(buildRequest(day.input).path, '/availability?department=orthodontics&from=2026-11-10&to=2026-11-10');
  assert.match(run('/slots').replyText, /slots/);
  assert.match(run('/slots orthodontics 10-11-2026').replyText, /slots/);
  assert.match(run('/slots ../admin', {}, { lang: 'en' }).replyText, /department/i);
});

test('/book validates locally and numbers refer to the last /departments list only while it is fresh', () => {
  assert.match(run('/book', {}, { lang: 'en' }).replyText, /Usage: \/book/);
  assert.match(run('/book orthodontics 2026-11-10', {}, { lang: 'en' }).replyText, /Usage: \/book/);
  assert.match(run('/book orthodontics 2026-11-10 5', {}, { lang: 'en' }).replyText, /Usage: \/book/);
  assert.match(run('/book orthodontics 2026-02-30 2', {}, { lang: 'en' }).replyText, /Usage: \/book/);
  const d = run('/book Orthodontics 2026-11-10 2', {}, { id: 55, lang: 'en' });
  assert.equal(d.needsApi, true);
  assert.deepEqual(buildRequest(d.input), { method: 'POST', path: '/telegram/55/appointments?locale=en', body: { departmentSlug: 'orthodontics', date: '2026-11-10', slotNumber: 2 } });
  const noList = run('/book 3 2026-11-10 2', {}, { lang: 'en' });
  assert.equal(noList.needsApi, false); assert.match(noList.replyText, /\/departments first/);
  const state = { lists: { 111222333: { at: NOW - 60_000, departments: ['restorative-dentistry', 'endodontics', 'orthodontics'] } } };
  assert.equal(run('/book 3 2026-11-10 2', state).input.params.departmentSlug, 'orthodontics');
  assert.equal(run('/book 4 2026-11-10 2', state, { lang: 'en' }).needsApi, false, 'number beyond the list');
  state.lists[111222333].at = NOW - 31 * 60_000;
  assert.equal(run('/book 3 2026-11-10 2', state, { lang: 'en' }).needsApi, false, 'stale list is not trusted');
});

test('/cancel and /reschedule use the numbers from the last /my and never accept raw ids from chat text', () => {
  const state = { lists: { 111222333: { at: NOW - 1000, appointments: [{ id: UUID_A }, { id: UUID_B }] } } };
  const c = run('/cancel 2', state);
  assert.equal(c.input.params.appointmentId, UUID_B);
  assert.equal(buildRequest(c.input).path, `/telegram/111222333/appointments/${UUID_B}/cancel?locale=ar`);
  const r = run('/reschedule 1 2026-11-12 3', state);
  assert.deepEqual(buildRequest(r.input).body, { date: '2026-11-12', slotNumber: 3 });
  assert.equal(run('/cancel 3', state, { lang: 'en' }).needsApi, false);
  assert.match(run('/cancel 3', state, { lang: 'en' }).replyText, /\/my first/);
  assert.match(run(`/cancel ${UUID_A}`, state, { lang: 'en' }).replyText, /\/my first/, 'a pasted id is not accepted');
  assert.match(run('/cancel', state, { lang: 'en' }).replyText, /Usage: \/cancel/);
  assert.match(run('/reschedule 1 2026-11-12', state, { lang: 'en' }).replyText, /Usage: \/reschedule/);
  assert.match(run('/cancel 1', {}, { lang: 'en' }).replyText, /\/my first/);
});

test('linking: /link CODE, a bare code, and /unlink', () => {
  assert.equal(run('/link K7QF-3MZP-9WHD').input.params.code, 'K7QF-3MZP-9WHD');
  assert.equal(run('/link K7QF 3MZP 9WHD').input.params.code, 'K7QF3MZP9WHD', 'spaces typed by the user are tolerated');
  assert.equal(run('K7QF-3MZP-9WHD').input.operation, 'link', 'a bare code is treated as a linking attempt');
  assert.equal(run('k7qf3mzp9whd').input.operation, 'link');
  assert.equal(run('Abcd-Efgh-Ijkl').needsApi, true, 'anything shaped like a code goes to the API, which simply answers invalid');
  assert.equal(run('Hello-World-Test1').needsApi, false, 'ordinary words are not sent to the API');
  assert.equal(run('thanks').needsApi, false);
  assert.match(run('/link', {}, { lang: 'en' }).replyText, /\/link K7QF/);
  assert.equal(run('/unlink').input.operation, 'unlink');
});

test('formatReply: success messages come only from successful results and use real data', () => {
  const state = {};
  const d = (text, o) => parseUpdate(upd(text, o), state, NOW);
  assert.match(formatReply(d('/link K7QF-3MZP-9WHD', { lang: 'en' }), ok({ linked: true }), state, NOW).text, /now linked/);
  assert.match(formatReply(d('/unlink', { lang: 'en' }), ok(null), state, NOW).text, /no longer linked/);
  const booked = formatReply(d('/book orthodontics 2026-11-10 2', { lang: 'en' }), ok(appt()), state, NOW).text;
  assert.match(booked, /Booked: Orthodontics - 2026-11-10 18:00-20:00 - Dr\. Sample/);
  const cancelled = formatReply(d('/cancel 1', { lang: 'en' }) /* needs list */, null, state, NOW);
  assert.match(cancelled.text, /\/my first/);
  state.lists = { 111222333: { at: NOW, appointments: [{ id: UUID_A }] } };
  assert.match(formatReply(d('/cancel 1', { lang: 'en' }), ok(appt({ status: 'cancelled' })), state, NOW).text, /Cancelled: Orthodontics - 2026-11-10 18:00-20:00/);
  assert.match(formatReply(d('/reschedule 1 2026-11-12 3', { lang: 'en' }), ok(appt({ date: '2026-11-12', startTime: '20:00', endTime: '22:00' })), state, NOW).text, /Moved: Orthodontics is now 2026-11-12 20:00-22:00/);
});

test('formatReply: a failed API call is NEVER reported as done, in every language', () => {
  for (const lang of LANGS) {
    const state = { lists: { 111222333: { at: NOW, appointments: [{ id: UUID_A }] } } };
    const doneWords = { en: /Booked:|Cancelled:|Moved:|now linked/, ar: /تم الحجز|تم الإلغاء|تم التغيير|أصبحت هذه المحادثة مربوطة/, fr: /Réservé :|Annulé :|Déplacé :|maintenant lié/ }[lang];
    for (const text of ['/book orthodontics 2026-11-10 2', '/cancel 1', '/reschedule 1 2026-11-12 3', '/link K7QF-3MZP-9WHD']) {
      for (const failure of [bad('SLOT_UNAVAILABLE'), bad('WITHIN_24H_WINDOW', 422), bad('SOMETHING_NEW', 500), { ok: false, status: 0, error: { code: 'UPSTREAM_UNREACHABLE' }, retryable: true }, null, undefined]) {
        const d = parseUpdate(upd(text, { lang }), state, NOW);
        const out = formatReply(d, failure, state, NOW);
        assert.doesNotMatch(out.text, doneWords, `${lang} ${text} ${JSON.stringify(failure)}`);
        assert.ok(out.text.length > 10);
        assert.doesNotMatch(out.text, /SLOT_UNAVAILABLE|WITHIN_24H|UPSTREAM|undefined|\[object/, 'no raw codes or internals');
      }
    }
  }
});

test('error codes map to a human message in all three languages; unknown ones become a neutral "nothing changed" message', () => {
  const codes = ['SLOT_UNAVAILABLE', 'SLOT_IN_PAST', 'DATE_CLOSED', 'DEPARTMENT_NOT_WORKING_DAY', 'BEYOND_BOOKING_HORIZON', 'PATIENT_OVERLAP', 'DAILY_CAPACITY_REACHED', 'WITHIN_24H_WINDOW', 'APPOINTMENT_NOT_FOUND', 'APPOINTMENT_NOT_ACTIVE', 'RESCHEDULE_NO_CHANGE', 'DEPARTMENT_NOT_FOUND', 'VALIDATION_ERROR', 'TELEGRAM_NOT_LINKED', 'LINK_CODE_INVALID', 'TOO_MANY_ATTEMPTS'];
  for (const lang of LANGS) {
    const seen = new Set();
    for (const code of codes) { const m = errorText(lang, { code }); assert.notEqual(m, STRINGS[lang].generic, `${lang} ${code}`); seen.add(m); }
    assert.equal(seen.size, codes.length, `${lang}: each code has its own message`);
    for (const code of ['INVALID_INTEGRATION_KEY', 'INTEGRATION_DISABLED', 'INTERNAL_ERROR', 'WHATEVER', undefined]) assert.equal(errorText(lang, { code }), STRINGS[lang].generic);
  }
  assert.match(errorText('en', { code: 'TELEGRAM_NOT_LINKED' }), /\/link/);
  assert.match(errorText('en', { code: 'WITHIN_24H_WINDOW' }), /24 hours/);
});

test('/info shows the configured address, or says plainly that it is not available; hours come from the API', () => {
  const center = { name: 'Dental Center', address: '12 Example St, Cairo', addressConfigured: true, phone: '+20 2 1234 5678', mapUrl: 'https://maps.example.com/x', timezone: 'Africa/Cairo', workingDays: [1, 2, 3, 4, 5, 6, 7], hoursNote: '', slots: [{ startTime: '16:00', endTime: '18:00' }, { startTime: '22:00', endTime: '00:00' }] };
  const state = {};
  const info = (data, lang) => formatReply(parseUpdate(upd('/info', { lang }), state, NOW), ok(data), state, NOW).text;
  const en = info(center, 'en');
  for (const part of ['Dental Center', 'Address: 12 Example St, Cairo', 'Phone: +20 2 1234 5678', 'https://maps.example.com/x', 'every day', '16:00-18:00, 22:00-00:00', 'Africa/Cairo']) assert.ok(en.includes(part), part);
  const none = info({ ...center, address: '', addressConfigured: false, phone: null, mapUrl: null }, 'en');
  assert.match(none, /Address: not available yet/);
  assert.doesNotMatch(none, /Phone:|Map:/);
  assert.match(info({ ...center, addressConfigured: false, address: '' }, 'ar'), /غير متاح/);
  assert.match(info({ ...center, workingDays: [1, 2, 3] }, 'en'), /Mon.*Tue.*Wed/);
  // the address the bot shows is never a constant of this code
  for (const lang of LANGS) for (const v of Object.values(STRINGS[lang])) assert.doesNotMatch(v, /\d{1,3}\s+\w+\s+(St|Street|شارع|rue)\b/i);
});

test('/departments and /slots format real API shapes and remember the numbering', () => {
  const state = {};
  const dd = parseUpdate(upd('/departments', { lang: 'en' }), state, NOW);
  const out = formatReply(dd, ok([
    { slug: 'restorative-dentistry', name: 'Restorative Dentistry', bookable: true, dentist: { name: 'Dr. A' } },
    { slug: 'no-dentist', name: 'Hidden', bookable: false, dentist: null },
    { slug: 'endodontics', name: 'Endodontics', bookable: true, dentist: { name: 'Dr. B' }, workingDays: [1, 3, 5] },
  ]), state, NOW).text;
  assert.match(out, /1\. Restorative Dentistry \[restorative-dentistry\] - Dr\. A/);
  assert.match(out, /2\. Endodontics \[endodontics\] - Dr\. B \(works: Mon, Wed, Fri\)/);
  assert.doesNotMatch(out.split('\n')[1], /works:/, 'a department that works every day (or sends no days) gets no extra text');
  assert.doesNotMatch(out, /Hidden/, 'departments that cannot take bookings are not offered');
  assert.deepEqual(state.lists['111222333'].departments, ['restorative-dentistry', 'endodontics']);
  assert.equal(parseUpdate(upd('/slots 2'), state, NOW).input.params.department, 'endodontics');

  const sd = parseUpdate(upd('/slots endodontics', { lang: 'en' }), state, NOW);
  const slots = formatReply(sd, ok({ days: [
    { date: '2026-11-10', status: 'open', availableCount: 2, slots: [{ slotNumber: 1, startTime: '16:00', endTime: '18:00' }, { slotNumber: 4, startTime: '22:00', endTime: '00:00' }] },
    { date: '2026-11-11', status: 'closed', availableCount: 0, slots: [] },
  ] }), state, NOW).text;
  assert.match(slots, /2026-11-10 \(Tue\): 1\) 16:00-18:00, 4\) 22:00-00:00/);
  assert.doesNotMatch(slots, /2026-11-11/);
  assert.match(slots, /\/book endodontics <date> <slot number>/);
  assert.match(formatReply(sd, ok({ days: [{ date: '2026-11-10', status: 'full', availableCount: 0, slots: [] }] }), state, NOW).text, /No free times/);
});

test('/my lists appointments with numbers, stores them for /cancel, and flags the ones that are locked', () => {
  const state = {};
  const d = parseUpdate(upd('/my', { lang: 'en' }), state, NOW);
  const text = formatReply(d, ok([appt(), appt({ id: UUID_B, date: '2026-11-03', selfService: { canCancel: false, blockedReason: 'WITHIN_24H_WINDOW' } })]), state, NOW).text;
  assert.match(text, /1\. Orthodontics - 2026-11-10 18:00-20:00 - Dr\. Sample\n/);
  assert.match(text, /2\. Orthodontics - 2026-11-03.*\(can no longer be changed here\)/);
  assert.deepEqual(state.lists['111222333'].appointments, [{ id: UUID_A }, { id: UUID_B }]);
  assert.match(formatReply(d, ok([]), state, NOW).text, /no upcoming appointments/);
});

test('every language has exactly the same message keys, no placeholder is left unfilled, and replies fit Telegram limits', () => {
  const keys = (l) => Object.keys(STRINGS[l]).sort().join();
  assert.equal(keys('ar'), keys('en')); assert.equal(keys('fr'), keys('en'));
  for (const lang of LANGS) {
    for (const [k, v] of Object.entries(STRINGS[lang])) {
      assert.ok(v.trim().length > 3, `${lang}.${k}`);
      assert.ok(v.length < 900, `${lang}.${k} too long`);
    }
    const state = { lists: { 111222333: { at: NOW, appointments: [{ id: UUID_A }], departments: ['orthodontics'] } } };
    for (const text of ['/help', '/book orthodontics 2026-11-10 2', '/my', '/cancel 1', '/reschedule 1 2026-11-12 3', '/slots orthodontics', '/info', '/departments']) {
      const dec = parseUpdate(upd(text, { lang }), state, NOW);
      const out = formatReply(dec, dec.needsApi ? bad('SLOT_UNAVAILABLE') : null, state, NOW);
      assert.doesNotMatch(out.text, /\{[a-z]+\}/, `${lang} ${text}`);
      assert.ok(out.text.length <= 4000);
    }
  }
  const many = Array.from({ length: 400 }, (_, i) => appt({ id: UUID_A, date: '2026-12-01', department: { name: 'X'.repeat(30) }, n: i }));
  const state = {}; const dec = parseUpdate(upd('/my', { lang: 'en' }), state, NOW);
  assert.ok(formatReply(dec, ok(many), state, NOW).text.length <= 4000, 'long lists are truncated below the Telegram limit');
});

test('the Arabic and French texts use proper characters (no transliteration placeholders)', () => {
  assert.match(STRINGS.ar.booked, /تم الحجز/);
  assert.match(STRINGS.fr.booked, /Réservé/);
  assert.match(STRINGS.fr.e_SLOT_UNAVAILABLE, /créneau/);
  assert.doesNotMatch(JSON.stringify(STRINGS.fr), /creneau|ete |telephone/);
});
