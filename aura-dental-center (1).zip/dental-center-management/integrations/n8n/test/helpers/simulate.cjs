'use strict';
/*
 * A minimal executor for the exported workflows: follows `connections`, runs the REAL embedded Code nodes, evaluates the
 * simple `={{ ... }}` expressions we use, and lets the test supply the HTTP layer. It is not n8n (it cannot prove n8n accepts
 * the file; the import test does that); it proves our wiring and our Code nodes do what the design says.
 */
const evalExpr = (value, scope) => {
  if (typeof value !== 'string' || !value.startsWith('={{')) return value;
  const expr = value.slice(3, value.lastIndexOf('}}')).trim();
  return new Function('$json', '$', `return (${expr});`)(scope.$json, scope.$);
};

async function runWorkflow(wf, startName, startJson, env) {
  const byName = new Map(wf.nodes.map((n) => [n.name, n]));
  const outputs = {};
  const sent = [];
  const path = [];
  const staticData = env.staticData || {};
  const $ = (name) => ({ first: () => ({ json: outputs[name] }), item: { json: outputs[name] } }); // single item per run, like a Telegram update

  async function step(name, json) {
    const n = byName.get(name);
    path.push(name);
    const type = n.type.split('.').pop();
    let out = json;
    let branch = 0;
    switch (type) {
      case 'telegramTrigger':
      case 'executeWorkflowTrigger': break;
      case 'code': {
        const fn = new Function('$input', '$getWorkflowStaticData', '$', n.parameters.jsCode);
        const res = fn({ item: { json }, first: () => ({ json }), all: () => [{ json }] }, () => staticData, $);
        out = (await res).json;
        break;
      }
      case 'if': {
        const c = n.parameters.conditions.conditions[0];
        const v = evalExpr(c.leftValue, { $json: json, $ });
        branch = v === true ? 0 : 1;
        break;
      }
      case 'set': {
        out = Object.assign({}, json);
        for (const a of n.parameters.assignments.assignments) out[a.name] = a.value;
        if (env.baseUrl) out.baseUrl = env.baseUrl; // tests point the "edit me" URL at their server
        break;
      }
      case 'httpRequest': {
        if (n.parameters.sendBody !== undefined && n.parameters.sendBody !== true) throw new Error('simulator: sendBody must be a literal true (n8n ignores expressions there)');
        const req = {
          method: evalExpr(n.parameters.method, { $json: json, $ }),
          url: evalExpr(n.parameters.url, { $json: json, $ }),
          body: n.parameters.sendBody === true ? JSON.parse(evalExpr(n.parameters.jsonBody, { $json: json, $ })) : undefined,
        };
        out = await env.http(req);
        break;
      }
      case 'telegram': {
        sent.push({ chatId: evalExpr(n.parameters.chatId, { $json: json, $ }), text: evalExpr(n.parameters.text, { $json: json, $ }) });
        break;
      }
      default: throw new Error('simulator: unsupported node type ' + n.type);
    }
    outputs[name] = out;
    const next = ((wf.connections[name] || {}).main || [])[branch] || [];
    if (next.length === 0) last = out; // the workflow's result is what its last node produced
    for (const c of next) await step(c.node, out);
    return out;
  }
  let last;
  await step(startName, startJson);
  return { sent, path, outputs, staticData, last };
}
module.exports = { runWorkflow };
