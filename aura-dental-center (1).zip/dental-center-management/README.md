# Dental Center Management System

A booking website for patients, a separate dashboard for the administrator, a REST API, an independent PostgreSQL database, Docker
deployment, and an integration with your existing **n8n + Telegram** assistant, for one dental center in Egypt.

> **Read this first: what is and is not verified.** The backend, database, dashboard, patient website, n8n workflows and backup scripts
> were run and tested for real (see [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md)). The development environment had **no
> working Docker**, so the Docker images, container start-up, health checks and volume persistence were **never run**; run
> `scripts/verify-docker.ps1` on your PC (it uses a separate throw-away project and never touches your data). The PowerShell scripts
> and real Telegram were not run either. The patient website is fully functional with its white and color-wheel design; the **official logo and the hero video have not
> been supplied yet** (their places are ready and empty).

## What it does

- **Patients** browse the seven departments, register with a **phone number and a password only** (no SMS/OTP), book, cancel and
  reschedule appointments, and link their Telegram account. Arabic (right-to-left), English and French.
- **The administrator** manages appointments, patients (including staff-assisted password recovery), **medical records** (admin only),
  departments and their **working days**, the assigned dentist of each department, services, the before/after gallery, the center
  profile and address (one place, used everywhere), closed dates, and reads the **audit log**.
- **n8n / Telegram** use the same booking rules through a key-protected API.

Fixed rules (the whole system enforces them; details in [`docs/BOOKING_RULES.md`](docs/BOOKING_RULES.md)):

- Open **4 PM – 12 AM, Africa/Cairo**, in four two-hour slots a day; at most **4 active appointments per department per day**; two
  people can never get the same slot (concurrency-tested, backed by database constraints); a cancelled appointment releases its slot.
- Exactly **seven departments**: Restorative Dentistry, Endodontics, Orthodontics, Periodontics, Pediatric Dentistry,
  Prosthodontics, Oral Surgery, each with one assigned dentist. Each department's **working days** (and the center's) are set in the
  dashboard and control what patients can see and book, on the website and in Telegram.
- A patient can cancel or reschedule only **at least 24 hours before** the start (the same on the website and in Telegram).

## Architecture in one picture

```
Browser ──► web (nginx: patient site /, dashboard /admin/, proxies /api/) ──► backend (Fastify, Node 22) ──► db (PostgreSQL 16)
n8n ──(HTTPS + bearer key)──► /api/v1/integrations/*  (same backend, same rules)
```

One public address, one origin; the backend and the database are not published. Details: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Prerequisites

| For | You need |
|---|---|
| Running it | Windows 10/11 with **Docker Desktop** (WSL 2 backend, Compose v2), or a Linux VPS with Docker |
| Developing / testing | Node.js 22, PostgreSQL 16, and for the browser tests nginx and Playwright's Chromium |

## Quick start (Windows, Docker Desktop, PowerShell)

```powershell
Copy-Item .env.example .env                                           # 1. private settings (never commit .env)
powershell -ExecutionPolicy Bypass -File .\scripts\new-secret.ps1     # 2. run twice: database password, n8n key
notepad .env                                                          # 3. fill in the CHANGE_ME values (see below)
docker compose up -d --build                                          # 4. build and start (first time: several minutes)
docker compose ps                                                     # 5. wait until db, backend and web are "healthy"
docker compose run --rm bootstrap-admin                               # 6. create the first administrator (once)
```

Then open **http://localhost:8480/admin/**, sign in with the bootstrap user, and choose a new password (it is forced at the first
sign-in). Set the center details, working days and dentists in the dashboard; the patient website is at **http://localhost:8480/**.
Remove `ADMIN_BOOTSTRAP_PASSWORD` from `.env` afterwards. Full guide, including a VPS with HTTPS: [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md).

**Settings you must fill in `.env`** (all described in `.env.example`): `POSTGRES_PASSWORD` (letters and digits only; fixed when the
database is first created), `ADMIN_BOOTSTRAP_USERNAME` / `ADMIN_BOOTSTRAP_PASSWORD` (at least 12 characters, no `$`),
`INTEGRATION_API_KEY` (only if you use n8n; leave empty to switch the integration off). Keep `PUBLIC_APP_URL` equal to the address you
type in the browser.

## Addresses and ports

| What | Address | Notes |
|---|---|---|
| Patient website | `http://localhost:8480/` | the only published port (`WEB_PORT`), bound to this computer only (`WEB_BIND=127.0.0.1`) |
| Admin dashboard | `http://localhost:8480/admin/` | staff only |
| API | `http://localhost:8480/api/v1/…` | through the same address; OpenAPI in [`docs/openapi.json`](docs/openapi.json) |
| Backend | container port 3480 | not published |
| PostgreSQL | none | internal Docker network only; volume `dental_center_pgdata`, project `dental-center` |

## Everyday commands

| Task | Command |
|---|---|
| Start / status / logs | `docker compose up -d` / `docker compose ps` / `docker compose logs -f backend` |
| Stop, **keeping all data** | `docker compose down` |
| Back up the database | `powershell -ExecutionPolicy Bypass -File .\scripts\backup.ps1` (Linux: `sh scripts/backup.sh`); see [`docs/BACKUP_RESTORE.md`](docs/BACKUP_RESTORE.md) |
| Forgot the administrator password | `docker compose run --rm reset-admin-password` |

**Never run `docker compose down -v`** (it deletes the database volume).

## Tests

```sh
npm --prefix backend ci && TEST_DATABASE_ADMIN_URL=postgres://postgres@127.0.0.1:5432/postgres npm --prefix backend test   # real PostgreSQL
npm --prefix frontend ci && npm --prefix frontend test && npm --prefix frontend run build
npm --prefix integrations/n8n ci && npm --prefix integrations/n8n test
bash scripts/tests/test-backup-scripts.sh
scripts/e2e-local.sh                                                          # real browser (Chromium) against a throw-away stack
powershell -ExecutionPolicy Bypass -File .\scripts\verify-docker.ps1          # Docker journey on your PC (isolated copy)
```

What each suite covers, the latest results and how to read them: [`docs/TESTING.md`](docs/TESTING.md).

## Troubleshooting

The common ones: *the form says "blocked for security reasons"* (open the exact `PUBLIC_APP_URL` address), *the database password
"does not work"* (it is fixed at first start), *a port is in use* (change `WEB_PORT`), *a picture does not appear*. All with fixes in
[`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md).

## Documentation

| Document | Content |
|---|---|
| [`docs/PROJECT_DOCUMENTATION.md`](docs/PROJECT_DOCUMENTATION.md) | The main guide: what the system does, every subsystem, repository map, index of all documents |
| [`docs/FINAL_REPORT.md`](docs/FINAL_REPORT.md) | The final report: what was built, how to run it, which tests passed, what could not be run |
| [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md) | What is done, what was verified and how, **what is not verified**, open questions |
| [`docs/BOOKING_RULES.md`](docs/BOOKING_RULES.md), [`docs/REQUIREMENTS.md`](docs/REQUIREMENTS.md) | Every business rule and its tests |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md), [`docs/DATABASE.md`](docs/DATABASE.md), [`docs/API.md`](docs/API.md), [`docs/FRONTEND.md`](docs/FRONTEND.md) | How it is built |
| [`docs/SECURITY.md`](docs/SECURITY.md) | Controls and honest limitations |
| [`docs/N8N_INTEGRATION.md`](docs/N8N_INTEGRATION.md) | Connecting your existing n8n and Telegram bot |
| [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md), [`docs/BACKUP_RESTORE.md`](docs/BACKUP_RESTORE.md), [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md) | Operating it |
| [`docs/IMAGE_ASSETS.md`](docs/IMAGE_ASSETS.md) | Where pictures go, names and sizes |
| [`docs/MASTER_SPEC.md`](docs/MASTER_SPEC.md), [`docs/IMPLEMENTATION_PLAN.md`](docs/IMPLEMENTATION_PLAN.md) | The original specification and the plan |

## Open questions for the owner

The patient-website **official logo and hero video**; which weekdays the center is open (defaults to all seven until set); the default language
(assumed Arabic) and whether the full name is required at registration (assumed yes); where your n8n runs (it decides the address n8n
uses to reach the API). See [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md) §5.
