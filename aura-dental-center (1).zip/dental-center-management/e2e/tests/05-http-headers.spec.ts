import { expect, test } from '@playwright/test';

/**
 * SEC-HDR: the security headers of every response of the web container, including the ones proxied from the backend.
 *
 * The backend (helmet) and nginx both used to add their own set to API answers, so a browser received two values for the same
 * header, some of them in conflict (X-Frame-Options SAMEORIGIN + DENY, two Referrer-Policy values, two Content-Security-Policy
 * headers, a Strict-Transport-Security over plain HTTP). nginx is now the only owner of these headers for the whole origin
 * (`frontend/nginx/proxy-api.conf` strips the backend's copies). `headersArray()` keeps repeated headers apart, which is what makes
 * the duplicates visible: `fetch` would merge them into one "a, a" string.
 */
const SINGLE = ['x-content-type-options', 'x-frame-options', 'referrer-policy', 'permissions-policy', 'content-security-policy', 'cache-control'] as const;

const PAGES = ['/', '/admin/', '/departments', '/healthz'];
const API = [
  '/api/health',
  '/api/v1/public/center?locale=en',
  '/api/v1/public/departments?locale=ar',
  '/api/v1/admin/auth/me', // 401 produced by the backend
  '/api/v1/does-not-exist', // 404 produced by the backend
  '/api/v1/integrations/health', // the machine API location (answered by the backend or refused by nginx, either way once)
];

for (const url of [...PAGES, ...API]) {
  test(`SEC-HDR: ${url} carries each security header exactly once, and no HSTS or X-Powered-By`, async ({ request }) => {
    const res = await request.get(url, { maxRedirects: 0 });
    const names = res.headersArray().map((h) => h.name.toLowerCase());
    const count = (name: string) => names.filter((n) => n === name).length;
    for (const name of SINGLE) {
      if (name === 'cache-control' && url === '/healthz') continue; // the liveness answer has no cache rule of its own
      expect(count(name), `${name} on ${url} (status ${res.status()})`).toBe(1);
    }
    expect(count('strict-transport-security'), 'HSTS belongs where HTTPS is terminated, not in this plain-HTTP container').toBe(0);
    expect(count('x-powered-by')).toBe(0);
    expect(res.headers()['x-frame-options']).toBe('DENY');
  });
}

test('SEC-HDR: API answers are never cacheable', async ({ request }) => {
  for (const url of ['/api/v1/public/center?locale=en', '/api/v1/admin/auth/me', '/api/v1/does-not-exist']) {
    const res = await request.get(url);
    expect(res.headers()['cache-control'], url).toBe('no-store');
  }
});
