import { expect, request as pwRequest, test, type Page } from '@playwright/test';
import { A, AUTH_ADMIN, AUTH_PATIENT, PATIENT_PASSWORD, cairoDate, chooseDay, newPhone } from './support.js';

test.use({ storageState: AUTH_ADMIN });
test.describe.configure({ mode: 'serial' });

const DEPARTMENTS = ['Restorative Dentistry', 'Endodontics', 'Orthodontics', 'Periodontics', 'Pediatric Dentistry', 'Prosthodontics', 'Oral Surgery'];
const nav = (page: Page, key: string) => page.getByRole('navigation', { name: A('admin.nav.main') }).getByRole('link', { name: A(key), exact: true });

test('every dashboard page opens without an error', async ({ page }) => {
  await page.goto('/admin/');
  await expect(page.getByRole('heading', { level: 1 }).first()).toBeVisible();
  for (const key of ['admin.nav.appointments', 'admin.nav.patients', 'admin.nav.departments', 'admin.nav.services', 'admin.nav.gallery', 'admin.nav.settings', 'admin.nav.audit']) {
    await nav(page, key).click();
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    await expect(page.getByText(A('admin.loadFailed'))).toHaveCount(0);
  }
});

test('the departments page lists exactly the seven departments, each with its dentist and working days', async ({ page }) => {
  await page.goto('/admin/departments');
  await expect(page.getByRole('heading', { level: 1, name: A('dep.title') })).toBeVisible();
  const cards = page.getByRole('main').getByRole('listitem').filter({ has: page.getByRole('heading', { level: 2 }) });
  await expect(cards).toHaveCount(7);
  for (const name of DEPARTMENTS) {
    const card = page.getByRole('listitem', { name, exact: true });
    await expect(card).toBeVisible();
    await expect(card.getByText(A('dep.workingDays.everyDay'))).toBeVisible();
    await expect(card.getByText(A('dep.badge.bookable'))).toBeVisible();
  }
});

test.describe('staff working in person with a patient at the front desk', () => {
  const phone = newPhone();
  const name = 'E2E Front Desk Patient';
  const temporaryPassword = 'Front-Desk-Temp-1';
  let bookingDay = '';

  test('add the patient (phone and password only)', async ({ page }) => {
    await page.goto('/admin/patients');
    await page.getByRole('button', { name: A('pat.add') }).click();
    const dialog = page.getByRole('dialog', { name: A('pat.create.title') });
    await dialog.getByLabel(A('pat.field.fullName'), { exact: true }).fill(name);
    await dialog.getByLabel(A('pat.field.phone'), { exact: true }).fill(phone);
    await dialog.getByLabel(A('pat.field.password'), { exact: true }).fill(temporaryPassword);
    await dialog.getByRole('button', { name: A('pat.create.submit') }).click();
    // the new account opens straight away; the phone number is stored in international form
    await expect(page.getByRole('heading', { level: 1, name })).toBeVisible();
    await expect(page.getByLabel(A('pat.field.phone'), { exact: true })).toHaveValue(`+20${phone.slice(1)}`);
    await expect(page.getByText(A('pat.appts.empty'))).toBeVisible();
    await page.goto('/admin/patients');
    await page.getByLabel(A('pat.search.label')).fill(name);
    await expect(page.getByRole('link', { name })).toBeVisible();
  });

  test('book an appointment for that patient, see it in the list, and cancel it', async ({ page }) => {
    await page.goto('/admin/appointments');
    await page.getByRole('button', { name: A('appts.book') }).click();
    const dialog = page.getByRole('dialog', { name: A('appts.book.title') });
    await dialog.getByLabel(A('appts.book.patient.search'), { exact: true }).fill(name);
    await dialog.getByRole('list', { name: A('appts.book.patient.choose') }).getByRole('button').first().click();
    await dialog.getByLabel(A('appts.book.department'), { exact: true }).selectOption({ label: 'Endodontics' });
    await expect(dialog.getByRole('radiogroup', { name: A('appts.slot.dayGroup') })).toBeVisible();
    const days = await dialog.locator('input[type="radio"][name^="day-"]').evaluateAll((els) => els.map((e) => (e as HTMLInputElement).value));
    bookingDay = days.find((d) => d >= cairoDate(4))!;
    expect(bookingDay).toBeTruthy();
    await chooseDay(page, bookingDay);
    await dialog.locator('label:has(input[name^="slot-"])').nth(2).click(); // the third time of that day
    await dialog.getByRole('button', { name: A('appts.book.submit') }).click();
    await expect(dialog.getByText(A('appts.book.done'))).toBeVisible();
    await dialog.getByRole('button', { name: A('common.close') }).click();

    await page.getByLabel(A('appts.filter.search'), { exact: true }).fill(name);
    await page.getByRole('button', { name: A('common.search'), exact: true }).click();
    await expect(page.getByRole('row')).toHaveCount(2); // the header and the one appointment of this patient
    const row = page.getByRole('row').filter({ hasText: name });
    await expect(row).toHaveCount(1);
    await expect(row).toContainText('Endodontics');
    await expect(row).toContainText(A('appts.via.admin'));

    await row.getByRole('button', { name: A('appts.manage.for', 'en', { patient: name, date: '' }).split(' on ')[0]!, exact: false }).click();
    const manage = page.getByRole('dialog', { name: A('appts.detail.title') });
    await manage.getByRole('button', { name: A('appts.action.cancel') }).click();
    await expect(manage.getByText(A('appts.cancel.text'))).toBeVisible();
    await manage.getByRole('button', { name: A('appts.cancel.confirm') }).click();
    await expect(page.getByText(A('appts.cancel.done'))).toBeVisible();
    await expect(row.getByText(A('status.cancelled'))).toBeVisible();
  });

  test('write a medical record, read it back; the record text never reaches the audit log', async ({ page }) => {
    await page.goto('/admin/patients');
    await page.getByLabel(A('pat.search.label')).fill(name);
    await page.getByRole('link', { name }).click();
    await expect(page.getByRole('heading', { name: A('mr.title') })).toBeVisible();
    await page.getByRole('button', { name: A('mr.add') }).click();
    const dialog = page.getByRole('dialog', { name: A('mr.create.title') });
    const secret = 'E2E-SECRET-CLINICAL-NOTE-4471';
    await dialog.getByLabel(A('mr.diagnosis'), { exact: false }).first().fill(secret);
    await dialog.getByRole('button', { name: A('mr.save') }).click();
    await expect(page.getByText(A('mr.saved'))).toBeVisible();
    await expect(page.getByTestId('medical-record').getByText(secret)).toBeVisible();

    await page.goto('/admin/audit');
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    await expect(page.getByText(/medical_record/).first()).toBeVisible();
    await expect(page.getByText(secret)).toHaveCount(0);
  });

  test('medical records and the whole admin API stay closed to a signed-in patient', async ({ baseURL, request }) => {
    const found = await request.get(`/api/v1/admin/patients?q=${encodeURIComponent(name)}`);
    const patientId = (await found.json()).data[0].id as string;
    const records = await request.get(`/api/v1/admin/patients/${patientId}/medical-records`);
    expect(records.status()).toBe(200); // the administrator can read them

    const patientApi = await pwRequest.newContext({ baseURL, storageState: AUTH_PATIENT });
    for (const url of ['/api/v1/admin/patients', '/api/v1/admin/appointments', '/api/v1/admin/audit-events', `/api/v1/admin/patients/${patientId}/medical-records`]) {
      expect([401, 403], url).toContain((await patientApi.get(url)).status());
    }
    // no cookie at all (a plain request, not a Playwright context that might inherit the administrator's cookies)
    expect((await fetch(`${baseURL}/api/v1/admin/patients/${patientId}/medical-records`)).status).toBe(401);
    await patientApi.dispose();
  });

  test('staff reset the password in person; the patient can sign in with the new one only', async ({ page, browser }) => {
    await page.goto('/admin/patients');
    await page.getByLabel(A('pat.search.label')).fill(name);
    await page.getByRole('link', { name }).click();
    await page.getByRole('button', { name: A('pat.reset.button') }).click();
    const dialog = page.getByRole('dialog', { name: A('pat.reset.title') });
    const newPassword = 'Reset-By-Staff-2026';
    await dialog.getByLabel(A('pat.reset.new'), { exact: true }).fill(newPassword);
    const submit = dialog.getByRole('button', { name: A('pat.reset.submit') });
    await expect(submit).toBeDisabled(); // the identity check must be confirmed first
    await dialog.getByLabel(A('pat.reset.identity')).check();
    await submit.click();
    await expect(page.getByText(A('pat.reset.done'))).toBeVisible();

    const visitor = await browser.newContext({ storageState: { cookies: [], origins: [] } });
    const login = (password: string) => visitor.request.post('/api/v1/patient/auth/login', { data: { phone, password } });
    expect((await login(temporaryPassword)).status()).toBe(401);
    expect((await login(newPassword)).status()).toBe(200);
    await visitor.close();
  });
});

test('the staff password can be changed again later, and is not shown anywhere', async ({ page }) => {
  await page.goto('/admin/change-password');
  await expect(page.getByRole('heading', { name: A('pw.title') })).toBeVisible();
  await expect(page.getByText(A('pw.forced'))).toHaveCount(0); // no longer forced
  const html = await page.content();
  expect(html).not.toContain(process.env.E2E_ADMIN_NEW_PASSWORD!);
  expect(PATIENT_PASSWORD).toBeTruthy();
});
