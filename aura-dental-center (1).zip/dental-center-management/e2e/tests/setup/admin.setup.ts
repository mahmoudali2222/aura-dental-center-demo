import { test as setup, expect } from '@playwright/test';
import { A, AUTH_ADMIN, admin } from '../support.js';

/**
 * The very first administrator sign-in (spec: the bootstrap password is temporary). This also prepares the signed-in state the
 * dashboard tests reuse. On a stack where the password was already changed (a second run) it simply signs in.
 */
setup('the first administrator sign-in forces a new password, then the dashboard opens', async ({ page, request }) => {
  const a = admin();
  // Is the account still on its temporary password? (A probe with no browser; the probe session is closed straight away.)
  const probe = await request.post('/api/v1/admin/auth/login', { data: { username: a.username, password: a.initial } });
  const firstRun = probe.ok();
  if (firstRun) {
    const csrf = (await probe.json()).data.csrfToken as string;
    await request.post('/api/v1/admin/auth/logout', { headers: { 'x-csrf-token': csrf } });
  }

  await page.goto('/admin/');
  await expect(page.getByRole('heading', { name: A('login.title') })).toBeVisible();
  await page.getByLabel(A('login.username'), { exact: true }).fill(a.username);

  if (firstRun) {
    await page.getByLabel(A('login.password'), { exact: true }).fill(a.initial);
    await page.getByRole('button', { name: A('login.submit') }).click();
    await expect(page.getByText(A('pw.forced'))).toBeVisible();
    // nothing but the password change is reachable meanwhile
    await expect(page.getByRole('navigation', { name: A('admin.nav.main') })).toHaveCount(0);
    await page.goto('/admin/appointments');
    await expect(page.getByText(A('pw.forced'))).toBeVisible();

    await page.getByLabel(A('pw.current'), { exact: true }).fill(a.initial);
    await page.getByLabel(A('pw.new'), { exact: true }).fill(a.password);
    await page.getByLabel(A('pw.confirm'), { exact: true }).fill(a.password);
    await page.getByRole('button', { name: A('pw.submit') }).click();
  } else {
    await page.getByLabel(A('login.password'), { exact: true }).fill(a.password);
    await page.getByRole('button', { name: A('login.submit') }).click();
  }
  await expect(page.getByRole('navigation', { name: A('admin.nav.main') })).toBeVisible();
  await expect(page.getByText(A('pw.forced'))).toHaveCount(0);
  await page.context().storageState({ path: AUTH_ADMIN });
});
