import { expect, test, type Page } from '@playwright/test';
import { P, PATIENT_PASSWORD, cairoDate, chooseDay, newPhone, offeredDays } from './support.js';

const DEPARTMENTS = ['Restorative Dentistry', 'Endodontics', 'Orthodontics', 'Periodontics', 'Pediatric Dentistry', 'Prosthodontics', 'Oral Surgery'];

/** Picks the first offered day at least `minAhead` days from today (so it can still be cancelled online) and its first time. */
async function pickDayAndTime(page: Page, minAhead: number, skip: string[] = []): Promise<string> {
  const earliest = cairoDate(minAhead);
  const date = (await offeredDays(page)).find((d) => d >= earliest && !skip.includes(d));
  expect(date, 'the booking page offers a day far enough ahead').toBeTruthy();
  await chooseDay(page, date!);
  await page.locator('label:has(input[name^="slot-"])').first().click();
  return date!;
}

test.describe.configure({ mode: 'serial' });

test.describe('a visitor', () => {
  test('sees the seven departments and nothing else, with the center details coming from the API', async ({ page }) => {
    await page.goto('/departments');
    await expect(page.getByRole('heading', { level: 1, name: P('departments.title') })).toBeVisible();
    for (const name of DEPARTMENTS) await expect(page.getByRole('heading', { name, exact: true })).toBeVisible();
    await expect(page.getByRole('main').getByRole('heading', { level: 2 })).toHaveCount(DEPARTMENTS.length);
    // the old clinic's departments are gone
    for (const gone of ['General Dentistry', 'Oral Radiology', 'Cosmetic Dentistry', 'Implantology']) await expect(page.getByText(gone)).toHaveCount(0);
    // the footer shows what the API returned (the address is not set until the center sets it: it says so, it never invents one)
    await expect(page.getByText(P('footer.addressMissing'))).toBeVisible();
  });

  test('a department page shows its dentist, services and a booking link', async ({ page }) => {
    await page.goto('/departments/orthodontics');
    await expect(page.getByRole('heading', { level: 1, name: 'Orthodontics' })).toBeVisible();
    await expect(page.getByRole('heading', { name: P('departments.dentist') })).toBeVisible();
    await expect(page.getByRole('link', { name: P('departments.book') })).toHaveAttribute('href', /\/book\?department=orthodontics$/);
    await expect(page.getByText(/^Working days:/)).toHaveCount(0); // works every day until the administrator changes it
  });

  test('is sent from /book to sign-in with an explanation', async ({ page }) => {
    await page.goto('/book?department=orthodontics');
    await expect(page.getByRole('heading', { name: P('auth.login.title') })).toBeVisible();
    await expect(page.getByText(P('auth.signInToContinue'))).toBeVisible();
  });

  test('cannot reach the admin API or the dashboard data without signing in', async ({ page, request }) => {
    expect((await request.get('/api/v1/admin/patients')).status()).toBe(401);
    expect((await request.get('/api/v1/patient/appointments')).status()).toBe(401);
    await page.goto('/admin/appointments');
    await expect(page.getByRole('heading', { name: 'Staff sign in' })).toBeVisible();
  });
});

test.describe('a patient', () => {
  const phone = newPhone();
  const name = 'E2E Patient Journey';

  test('registers with only a name, phone number and password (no code is sent or asked for)', async ({ page }) => {
    await page.goto('/register');
    await page.getByLabel(P('auth.fullName'), { exact: true }).fill(name);
    await page.getByLabel(P('auth.phone'), { exact: true }).fill(phone);
    await page.getByLabel(P('auth.password'), { exact: true }).fill(PATIENT_PASSWORD);
    await page.getByRole('button', { name: P('auth.register.submit') }).click();
    await expect(page.getByRole('link', { name: P('nav.appointments') })).toBeVisible();
    await expect(page.getByRole('button', { name: P('nav.logout') })).toBeVisible();
    expect(await page.getByLabel(/code|otp/i).count()).toBe(0);
  });

  test('a wrong password is refused with a readable message, the right one signs in', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel(P('auth.phone'), { exact: true }).fill(phone);
    await page.getByLabel(P('auth.password'), { exact: true }).fill('Wrong-Password-123');
    await page.getByRole('button', { name: P('auth.login.submit') }).click();
    await expect(page.getByText(P('err.INVALID_CREDENTIALS'))).toBeVisible();
    await expect(page.getByRole('button', { name: P('nav.logout') })).toHaveCount(0);
    await page.getByLabel(P('auth.password'), { exact: true }).fill(PATIENT_PASSWORD);
    await page.getByRole('button', { name: P('auth.login.submit') }).click();
    await expect(page.getByRole('button', { name: P('nav.logout') })).toBeVisible();
    await page.context().storageState({ path: '.auth/patient.json' });
  });

  test.describe('with a session', () => {
    test.use({ storageState: '.auth/patient.json' });
    let firstDay = '';

    test('books an appointment: choose a department, a day and a time, and sees it confirmed', async ({ page }) => {
      await page.goto('/book');
      await page.getByRole('radiogroup', { name: P('book.department') }).locator('label', { hasText: 'Orthodontics' }).click();
      firstDay = await pickDayAndTime(page, 4);
      await page.getByRole('button', { name: P('book.submit') }).click();
      await expect(page.getByText(P('book.success'))).toBeVisible();
      await page.getByRole('link', { name: P('book.viewAppointments') }).click();
      const card = page.getByRole('article', { name: /^Orthodontics/ });
      await expect(card).toBeVisible();
      await expect(card.getByText(P('appts.via.web'))).toBeVisible();
      await expect(card.getByText(/4:00\s?pm\s?[–-]\s?6:00\s?pm/i)).toBeVisible();
    });

    test('the same time can no longer be booked by someone else, and the day shows one time fewer', async ({ page, browser }) => {
      // a second person (separate browser context, no shared cookies) sees one time less on that day
      const other = await browser.newContext({ storageState: { cookies: [], origins: [] } }); // nobody signed in
      const p2 = await other.newPage();
      await p2.goto('/book?department=orthodontics');
      await expect(p2.getByRole('heading', { name: P('auth.login.title') })).toBeVisible(); // booking needs an account
      const res = await other.request.get(`/api/v1/public/departments/orthodontics/availability?from=${firstDay}&to=${firstDay}`);
      const day = (await res.json()).data.days[0];
      expect(day.availableCount).toBe(3);
      expect(day.slots.map((s: { slotNumber: number }) => s.slotNumber)).not.toContain(1);
      await other.close();
      await page.goto('/appointments');
      await expect(page.getByRole('article', { name: /^Orthodontics/ })).toHaveCount(1);
    });

    test('changes the time of the appointment, then cancels it, and the time is released', async ({ page, request }) => {
      await page.goto('/appointments');
      const card = page.getByRole('article', { name: /^Orthodontics/ });
      await card.getByRole('button', { name: P('appts.reschedule') }).click();
      const picker = page.getByRole('region', { name: P('appts.reschedule.title') });
      const days = await offeredDays(page);
      const newDay = days.find((d) => d >= cairoDate(4) && d !== firstDay)!;
      await chooseDay(page, newDay);
      await picker.locator('label:has(input[name^="slot-"])').nth(1).click(); // the second time of that day
      await picker.getByRole('button', { name: P('appts.reschedule.confirm') }).click();
      await expect(page.getByText(P('appts.rescheduled'))).toBeVisible();
      // the first day has all its times again
      const first = (await (await request.get(`/api/v1/public/departments/orthodontics/availability?from=${firstDay}&to=${firstDay}`)).json()).data.days[0];
      expect(first.availableCount).toBe(4);

      await card.getByRole('button', { name: P('appts.cancel') }).click();
      await expect(page.getByRole('dialog', { name: P('appts.cancel.title') })).toBeVisible();
      await page.getByRole('button', { name: P('appts.cancel.confirm') }).click();
      await expect(page.getByText(P('appts.cancelled'))).toBeVisible();
      await expect(page.getByText(P('appts.empty.upcoming'))).toBeVisible();
      const released = (await (await request.get(`/api/v1/public/departments/orthodontics/availability?from=${newDay}&to=${newDay}`)).json()).data.days[0];
      expect(released.availableCount).toBe(4);
      await page.getByRole('button', { name: P('appts.history') }).click();
      await expect(page.getByRole('article', { name: /^Orthodontics/ })).toBeVisible();
    });

    test('signs out, and the session is really gone', async ({ page, request }) => {
      await page.goto('/appointments');
      await page.getByRole('button', { name: P('nav.logout') }).click();
      await expect(page.getByRole('link', { name: P('nav.login') })).toBeVisible();
      expect((await request.get('/api/v1/patient/appointments')).status()).toBe(401);
    });
  });
});
