import { expect, request as pwRequest, test, type Page } from '@playwright/test';
import { PATIENT_PASSWORD, P, cairoDate, newPhone, offeredDays } from './support.js';

/**
 * The look and structure of the patient website that only a real browser can check: pictures that load at their own size, the
 * right-to-left layout, the Section 10 chips, the Telegram link, the empty logo/video places, the tablet width, and the booking
 * calendar agreeing with the API. (Behaviour such as booking and cancelling is covered in 01 and 04.)
 */
const NO_STORAGE = { cookies: [], origins: [] };
type L = 'en' | 'ar' | 'fr';

async function open(page: Page, path: string, locale: L) {
  await page.addInitScript((l) => localStorage.setItem('dc.patient.locale', l), locale);
  await page.goto(path);
  await expect(page.getByRole('main')).toBeVisible();
}

async function signedInPage(page: Page, baseURL: string | undefined) {
  const api = await pwRequest.newContext({ baseURL, storageState: NO_STORAGE });
  const reg = await api.post('/api/v1/patient/auth/register', { data: { fullName: 'E2E Look Patient', phone: newPhone(), password: PATIENT_PASSWORD } });
  expect(reg.status()).toBe(201);
  await page.context().addCookies((await api.storageState()).cookies);
  await api.dispose();
}

test.describe('patient website: look and structure', () => {
  test.use({ storageState: NO_STORAGE });

  test('the supplied before/after pictures load, one per department, and are shown at most at their own size (never enlarged or cropped)', async ({ page }) => {
    await open(page, '/', 'en');
    const imgs = page.locator('.results__img');
    await expect(imgs).toHaveCount(7);
    await expect.poll(() => imgs.evaluateAll((els) => els.every((e) => (e as HTMLImageElement).complete && (e as HTMLImageElement).naturalWidth > 0))).toBe(true);
    const sizes = await imgs.evaluateAll((els) => els.map((e) => { const i = e as HTMLImageElement; return { natural: i.naturalWidth, shown: i.getBoundingClientRect().width, ratioNatural: i.naturalWidth / i.naturalHeight, ratioShown: i.getBoundingClientRect().width / i.getBoundingClientRect().height }; }));
    for (const s of sizes) {
      expect(s.shown, 'not enlarged (only its 1px frame is added)').toBeLessThanOrEqual(s.natural + 2);
      expect(Math.abs(s.ratioShown - s.ratioNatural), 'same proportions: not stretched or cropped').toBeLessThan(0.03);
    }
    const objectFit = await imgs.first().evaluate((e) => getComputedStyle(e).objectFit);
    expect(objectFit).toBe('fill'); // the default: the whole picture, no cover/crop
  });

  test('every department page shows its own picture from the API, loaded', async ({ page, request }) => {
    const departments = (await (await request.get('/api/v1/public/departments?locale=en')).json()).data as { slug: string; imagePath: string | null }[];
    expect(departments).toHaveLength(7);
    for (const d of departments) {
      expect(d.imagePath, `${d.slug} has a picture`).toMatch(/^\/assets\/departments\/[\w-]+\.jpg$/);
      await page.goto(`/departments/${d.slug}`);
      const img = page.locator('.example__img');
      await expect(img).toBeVisible();
      await expect.poll(() => img.evaluate((e) => (e as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);
      expect(await img.getAttribute('src')).toBe(d.imagePath);
    }
  });

  test('Section 10: 30 compact chips in the given order, each only as wide as its name, wrapping, no list markers, the two "منه الله" in different tones', async ({ page }) => {
    await open(page, '/', 'ar');
    const chips = page.locator('.credits .chip');
    await expect(chips).toHaveCount(30);
    const names = await chips.allTextContents();
    expect(names[0]).toBe('ماريا ابراهيم');
    expect(names[29]).toBe('احمد ابراهيم');
    const same = names.map((n, i) => (n === 'منه الله' ? i : -1)).filter((i) => i >= 0);
    expect(same).toHaveLength(2);
    const measured = await chips.evaluateAll((els) => els.map((el) => {
      const r = document.createRange(); r.selectNodeContents(el);
      const chip = el.getBoundingClientRect();
      return { w: chip.width, text: r.getBoundingClientRect().width, top: Math.round(chip.top), bg: getComputedStyle(el).backgroundColor };
    }));
    for (const m of measured) expect(m.w - m.text, 'padding only: the chip hugs its name').toBeLessThan(40);
    expect(new Set(measured.map((m) => Math.round(m.w))).size, 'widths follow the names').toBeGreaterThan(8);
    expect(new Set(measured.map((m) => m.top)).size, 'chips wrap onto several rows').toBeGreaterThanOrEqual(3);
    expect(measured[same[0]!]!.bg).not.toBe(measured[same[1]!]!.bg);
    expect(await page.locator('.credits ul').evaluate((e) => getComputedStyle(e).listStyleType)).toBe('none');
    // it is the last block of the page
    expect(await page.locator('.credits').evaluate((e) => e.getBoundingClientRect().bottom + window.scrollY)).toBeGreaterThan(await page.locator('.site-footer .footer-grid').evaluate((e) => e.getBoundingClientRect().bottom + window.scrollY - 1));
  });

  test('the Telegram assistant is a link to the bot that opens in a new tab; there is no chat on the site', async ({ page }) => {
    await open(page, '/', 'en');
    const links = page.getByRole('link', { name: /Open in Telegram/ });
    await expect(links.first()).toBeVisible();
    for (const a of await links.all()) {
      await expect(a).toHaveAttribute('href', 'https://t.me/drAliclinic2_bot');
      await expect(a).toHaveAttribute('target', '_blank');
      await expect(a).toHaveAttribute('rel', /noopener/);
    }
    await expect(page.locator('main textarea, main input[type="text"]')).toHaveCount(0);
  });

  test('the place for the logo and the place for the video are there but empty: no logo picture, no video, no stand-in', async ({ page }) => {
    await open(page, '/', 'en');
    await expect(page.locator('.brand__logo')).toHaveCount(0);
    await expect(page.locator('video')).toHaveCount(0);
    await expect(page.locator('.hero__media')).toHaveAttribute('data-media', 'none');
    await expect(page.locator('.hero__media')).toHaveAttribute('aria-hidden', 'true');
    await expect(page.locator('header').getByRole('link', { name: 'Aura Dental Center' })).toBeVisible();
  });

  test('right-to-left: the brand sits at the right edge and the hero text is right-aligned in Arabic, the opposite in English', async ({ page }) => {
    const width = page.viewportSize()!.width;
    await open(page, '/', 'ar');
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    const brand = await page.locator('header .brand').boundingBox();
    expect(brand!.x + brand!.width / 2, 'Arabic: brand on the right').toBeGreaterThan(width / 2);
    const h1 = await page.locator('h1').boundingBox();
    expect(h1!.x + h1!.width / 2, 'Arabic: the heading belongs to the right column').toBeGreaterThan(width / 2);
    await page.getByRole('button', { name: 'English', exact: true }).click();
    await expect(page.locator('html')).toHaveAttribute('dir', 'ltr');
    const brandEn = await page.locator('header .brand').boundingBox();
    expect(brandEn!.x + brandEn!.width / 2, 'English: brand on the left').toBeLessThan(width / 2);
    const h1En = await page.locator('h1').boundingBox();
    expect(h1En!.x + h1En!.width / 2).toBeLessThan(width / 2);
  });

  test('the one self-running animation (the evening timeline) stops for visitors who prefer reduced motion', async ({ page }) => {
    await open(page, '/', 'en');
    expect(await page.locator('.timeline__block').first().evaluate((e) => getComputedStyle(e).animationName)).toBe('block-in');
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.reload();
    await expect(page.locator('.timeline__block').first()).toBeVisible();
    expect(await page.locator('.timeline__block').first().evaluate((e) => getComputedStyle(e).animationName)).toBe('none');
  });

  test('the evening timeline shows the center’s real slots (from the API)', async ({ page, request }) => {
    const center = (await (await request.get('/api/v1/public/center?locale=en')).json()).data as { slots: unknown[] };
    await open(page, '/', 'en');
    await expect(page.locator('.timeline__slot')).toHaveCount(center.slots.length);
  });
});

test.describe('patient website: tablet width', () => {
  test.use({ storageState: NO_STORAGE, viewport: { width: 820, height: 1180 } });
  for (const locale of ['en', 'ar', 'fr'] as const) {
    test(`public pages fit a tablet and keep their layout (${locale})`, async ({ page }) => {
      await page.addInitScript((l) => localStorage.setItem('dc.patient.locale', l), locale);
      for (const path of ['/', '/departments', '/departments/prosthodontics', '/login', '/register']) {
        await page.goto(path);
        await expect(page.getByRole('main')).toBeVisible();
        const { sw, iw } = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth }));
        expect(sw, `${path} (${locale})`).toBeLessThanOrEqual(iw);
      }
      await expect(page.locator('html')).toHaveAttribute('dir', locale === 'ar' ? 'rtl' : 'ltr');
    });
  }
});

test.describe('patient website: booking uses real availability', () => {
  test.use({ storageState: NO_STORAGE });

  test('the calendar offers exactly the days the API calls open, and shows the supplied precautions picture', async ({ page, request, baseURL }) => {
    await signedInPage(page, baseURL);
    const to = cairoDate(59);
    const api = (await (await request.get(`/api/v1/public/departments/orthodontics/availability?from=${cairoDate(0)}&to=${to}`)).json()).data as { days: { date: string; status: string }[] };
    const open = api.days.filter((d) => d.status === 'open').map((d) => d.date);
    expect(open.length).toBeGreaterThan(20);
    await page.addInitScript(() => localStorage.setItem('dc.patient.locale', 'en'));
    await page.goto('/book?department=orthodontics');
    expect(await offeredDays(page)).toEqual(open);
    // the picture supplied by the center is in the flow, loaded, with its text alternative
    const img = page.locator('.precautions__img');
    await expect(img).toBeVisible();
    await expect.poll(() => img.evaluate((e) => (e as HTMLImageElement).naturalWidth)).toBe(1048);
    await expect(page.locator('.precautions__details')).toContainText(P('precautions.heart'));
  });

  test('keyboard: the calendar days and the times can be chosen without a mouse', async ({ page, baseURL }) => {
    await signedInPage(page, baseURL);
    await page.addInitScript(() => localStorage.setItem('dc.patient.locale', 'en'));
    await page.goto('/book?department=endodontics');
    const first = page.locator('.cal__cell.is-open input').first();
    await first.focus();
    await page.keyboard.press('Space');
    await expect(first).toBeChecked();
    await page.locator('.time input').first().focus();
    await page.keyboard.press('Space');
    await expect(page.getByRole('button', { name: P('book.submit') })).toBeEnabled();
  });
});
