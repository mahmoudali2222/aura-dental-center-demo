import { expect, request as pwRequest, test, type APIRequestContext, type Page } from '@playwright/test';
import { A, P, PATIENT_PASSWORD, adminApi, chooseDay, cairoDate, newPhone, offeredDays, weekdayOf, AUTH_ADMIN } from './support.js';

/**
 * The working days configured in the dashboard decide what patients can see and book. Prosthodontics is switched on and off
 * from the real dashboard, and the real patient website, the booking API and an appointment that already exists are checked.
 */
const DAY = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const DEPT = 'Prosthodontics';
const SLUG = 'prosthodontics';

test.use({ storageState: AUTH_ADMIN });
test.describe.configure({ mode: 'serial' });

let patient: APIRequestContext;
let patientCsrf = '';

test.beforeAll(async ({ baseURL }) => {
  patient = await pwRequest.newContext({ baseURL });
  const res = await patient.post('/api/v1/patient/auth/register', { data: { fullName: 'E2E Working Days Patient', phone: newPhone(), password: PATIENT_PASSWORD } });
  expect(res.status()).toBe(201);
  patientCsrf = (await res.json()).data.csrfToken;
});
test.afterAll(async () => { await patient.dispose(); });

/** Opens the department's edit form on the dashboard and ticks / unticks weekdays by name. */
async function editDays(page: Page, toggle: number[]): Promise<void> {
  await page.goto('/admin/departments');
  await page.getByRole('button', { name: A('dep.editAria', 'en', { name: DEPT }) }).click();
  const dialog = page.getByRole('dialog', { name: A('dep.form.editTitle') });
  const group = dialog.getByRole('group', { name: A('dep.workingDays') });
  for (const d of toggle) await group.getByRole('checkbox', { name: DAY[d]!, exact: true }).click();
}
const saveButton = (page: Page) => page.getByRole('dialog', { name: A('dep.form.editTitle') }).getByRole('button', { name: A('common.save') });
const card = (page: Page) => page.getByRole('listitem', { name: DEPT, exact: true });

async function availability(day: string) {
  const res = await patient.get(`/api/v1/public/departments/${SLUG}/availability?from=${day}&to=${day}`);
  return (await res.json()).data.days[0] as { status: string; availableCount: number };
}
async function bookViaApi(date: string, slotNumber: number) {
  const dept = (await (await patient.get(`/api/v1/public/departments/${SLUG}`)).json()).data.id as string;
  return patient.post('/api/v1/patient/appointments', { data: { departmentId: dept, date, slotNumber }, headers: { 'x-csrf-token': patientCsrf } });
}
/** The first day at least `ahead` days from now on the given weekday that the patient site offers (or, when `offered` is false, any date on that weekday). */
function nextWeekday(weekday: number, ahead = 4): string {
  for (let n = ahead; n < ahead + 14; n++) if (weekdayOf(cairoDate(n)) === weekday) return cairoDate(n);
  throw new Error('unreachable');
}

test('the department works every day until someone changes it', async ({ page }) => {
  await page.goto('/admin/departments');
  await expect(card(page).getByText(A('dep.workingDays.everyDay'))).toBeVisible();
  await page.goto(`/departments/${SLUG}`);
  await expect(page.getByRole('heading', { level: 1, name: DEPT })).toBeVisible();
  await expect(page.getByText(/^Working days:/)).toHaveCount(0);
});

test('a patient books a Wednesday while the department still works on Wednesdays', async () => {
  const res = await bookViaApi(nextWeekday(3), 1);
  expect(res.status()).toBe(201);
});

test('the administrator switches Friday and Saturday off; the card and the patient site say so', async ({ page, browser }) => {
  await editDays(page, [5, 6]);
  await saveButton(page).click(); // nothing is booked on a Friday or Saturday, so no question is asked
  await expect(page.getByText(A('dep.saved.updated', 'en', { name: DEPT }))).toBeVisible();
  await expect(card(page).getByText(/^Works: /)).toBeVisible();
  await expect(card(page).getByText(/^Works: /)).not.toContainText('Friday');
  await expect(card(page).getByText(/^Works: /)).not.toContainText('Saturday');
  await expect(card(page).getByText(/^Works: /)).toContainText('Sunday');

  const visitor = await browser.newContext({ storageState: { cookies: [], origins: [] } });
  const site = await visitor.newPage();
  await site.goto(`/departments/${SLUG}`);
  await expect(site.getByText(/^Working days: /)).toBeVisible();
  await expect(site.getByText(/^Working days: /)).not.toContainText('Friday');
  await expect(site.getByText(/^Working days: /)).toContainText('Monday');
  await visitor.close();
});

test('the booking page offers no Friday and no Saturday, and the API refuses one', async ({ browser }) => {
  const signedIn = await browser.newContext({ storageState: await patient.storageState() });
  const site = await signedIn.newPage();
  await site.goto(`/book?department=${SLUG}`);
  const days = await offeredDays(site);
  expect(days.length).toBeGreaterThan(5);
  expect(days.map(weekdayOf)).not.toContain(5);
  expect(days.map(weekdayOf)).not.toContain(6);
  expect(days.map(weekdayOf)).toEqual(expect.arrayContaining([1, 2, 3, 4, 7]));
  await signedIn.close();

  const friday = nextWeekday(5);
  expect((await availability(friday)).status).toBe('closed');
  const refused = await bookViaApi(friday, 1);
  expect(refused.status()).toBe(422);
  expect((await refused.json()).error.code).toBe('DEPARTMENT_NOT_WORKING_DAY');
  // other departments are not affected
  const ortho = await patient.get(`/api/v1/public/departments/orthodontics/availability?from=${friday}&to=${friday}`);
  expect((await ortho.json()).data.days[0].status).toBe('open');
});

test('switching off a day that has a booking asks first, says how many, and cancels nothing', async ({ page, browser, request }) => {
  const wednesday = nextWeekday(3);
  await editDays(page, [3]); // Wednesday off
  await saveButton(page).click();
  const dialog = page.getByRole('dialog', { name: A('dep.form.editTitle') });
  await expect(dialog.getByText(A('dep.workingDays.ack_one'))).toBeVisible();
  await expect(dialog.getByText(A('dep.workingDays.ack.note'))).toBeVisible();
  const confirm = dialog.getByRole('button', { name: A('dep.workingDays.ack.submit') });
  await expect(confirm).toBeDisabled();
  // nothing changed yet: Wednesday is still bookable
  expect((await availability(wednesday)).status).toBe('open');

  await dialog.getByLabel(A('dep.workingDays.ack.confirm')).check();
  await confirm.click();
  await expect(page.getByText(A('dep.saved.updated', 'en', { name: DEPT }))).toBeVisible();

  // new bookings are refused on Wednesday, but the patient's appointment is still there
  expect((await availability(wednesday)).status).toBe('closed');
  expect((await bookViaApi(wednesday, 2)).status()).toBe(422);
  const mine = await patient.get('/api/v1/patient/appointments?scope=upcoming');
  const kept = (await mine.json()).data.filter((a: { date: string; status: string; department: { slug: string } }) => a.department.slug === SLUG);
  expect(kept).toHaveLength(1);
  expect(kept[0]).toMatchObject({ date: wednesday, status: 'booked' });
  // and the administrator still sees it
  const list = await adminApi(request, 'GET', `/api/v1/admin/appointments?from=${wednesday}&to=${wednesday}&status=booked`);
  expect(list.body.data.some((a: { department: { slug: string } }) => a.department.slug === SLUG)).toBe(true);

  const site = await browser.newContext({ storageState: await patient.storageState() });
  const p = await site.newPage();
  await p.goto('/appointments');
  await expect(p.getByRole('article', { name: new RegExp(`^${DEPT}`) })).toBeVisible();
  await site.close();
});

test('the administrator cannot switch every day off', async ({ page }) => {
  await editDays(page, [1, 2, 4, 7]); // the days that are still on: Monday, Tuesday, Thursday, Sunday
  const dialog = page.getByRole('dialog', { name: A('dep.form.editTitle') });
  await expect(dialog.getByText(A('err.AT_LEAST_ONE_WORKING_DAY'))).toBeVisible();
  await expect(saveButton(page)).toBeDisabled();
  await page.keyboard.press('Escape');
});

test('switching the days back on makes them bookable again at once', async ({ page }) => {
  await editDays(page, [3, 5, 6]); // Wednesday, Friday, Saturday on again
  await saveButton(page).click();
  await expect(page.getByText(A('dep.saved.updated', 'en', { name: DEPT }))).toBeVisible();
  await expect(card(page).getByText(A('dep.workingDays.everyDay'))).toBeVisible();
  const friday = nextWeekday(5);
  expect((await availability(friday)).status).toBe('open');
  expect((await bookViaApi(friday, 1)).status()).toBe(201);
});

test('the center working days apply to every department on top of the department days', async ({ page, request }) => {
  const saturday = nextWeekday(6);
  await page.goto('/admin/settings');
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  const group = page.getByRole('group', { name: A('set.workingDays') });
  await group.getByRole('checkbox', { name: 'Saturday', exact: true }).click();
  await page.getByRole('button', { name: A('set.save') }).click();
  await expect(page.getByText(A('set.saved'))).toBeVisible();
  try {
    for (const slug of ['orthodontics', 'endodontics', SLUG]) {
      const res = await patient.get(`/api/v1/public/departments/${slug}/availability?from=${saturday}&to=${saturday}`);
      expect((await res.json()).data.days[0].status, slug).toBe('closed');
    }
    const refused = await bookViaApi(saturday, 3);
    expect(refused.status()).toBe(422);
    expect((await refused.json()).error.code).toBe('DATE_CLOSED'); // the center is closed that day, whatever the department says
  } finally {
    await adminApi(request, 'PUT', '/api/v1/admin/settings/center', { workingDays: [1, 2, 3, 4, 5, 6, 7] });
  }
  expect((await availability(saturday)).status).toBe('open');
  void P;
});
