import { expect, request as pwRequest, test, type Page } from '@playwright/test';
import { AUTH_ADMIN, PATIENT_PASSWORD, newPhone, P, A, chooseDay, offeredDays } from './support.js';

/** A phone-sized screen (Pixel 5, 393 px wide): nothing may force the page to scroll sideways, and the key actions stay reachable. */
const NO_STORAGE = { cookies: [], origins: [] };

async function noSidewaysScroll(page: Page, what: string) {
  const { scrollWidth, innerWidth } = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, innerWidth: window.innerWidth }));
  expect(scrollWidth, `${what}: the page is ${scrollWidth}px wide on a ${innerWidth}px screen`).toBeLessThanOrEqual(innerWidth);
}

test.describe('patient website on a phone', () => {
  test.use({ storageState: NO_STORAGE });

  for (const locale of ['en', 'ar', 'fr'] as const) {
    test(`public pages fit the screen (${locale})`, async ({ page }) => {
      await page.addInitScript((l) => localStorage.setItem('dc.patient.locale', l), locale);
      for (const path of ['/', '/departments', '/departments/orthodontics', '/login', '/register']) {
        await page.goto(path);
        await expect(page.getByRole('main')).toBeVisible();
        await noSidewaysScroll(page, `${path} (${locale})`);
      }
      await expect(page.locator('html')).toHaveAttribute('dir', locale === 'ar' ? 'rtl' : 'ltr');
    });
  }

  test('a patient can sign in, pick a day and a time and see the confirm button on a phone', async ({ page, baseURL }) => {
    const api = await pwRequest.newContext({ baseURL, storageState: NO_STORAGE });
    const reg = await api.post('/api/v1/patient/auth/register', { data: { fullName: 'E2E Mobile Patient', phone: newPhone(), password: PATIENT_PASSWORD } });
    expect(reg.status()).toBe(201);
    await page.context().addCookies((await api.storageState()).cookies);
    await api.dispose();

    await page.goto('/book?department=endodontics');
    const days = await offeredDays(page);
    await noSidewaysScroll(page, 'booking page');
    await chooseDay(page, days[5]!);
    await page.locator('label:has(input[name^="slot-"])').first().click();
    const confirm = page.getByRole('button', { name: P('book.submit') });
    await confirm.scrollIntoViewIfNeeded();
    await expect(confirm).toBeEnabled();
    const box = await confirm.boundingBox();
    expect(box!.height, 'a finger-sized button').toBeGreaterThanOrEqual(40);
    await noSidewaysScroll(page, 'booking page after choosing a time');
    await page.screenshot({ path: 'test-results/mobile-booking.png', fullPage: true });
  });
});

test.describe('admin dashboard on a phone', () => {
  test.use({ storageState: AUTH_ADMIN });

  test('the dashboard pages and their tables fit the screen (tables scroll inside their own box)', async ({ page }) => {
    for (const path of ['/admin/', '/admin/appointments', '/admin/patients', '/admin/departments', '/admin/services', '/admin/gallery', '/admin/settings', '/admin/audit']) {
      await page.goto(path);
      await expect(page.getByRole('heading', { level: 1 }).first()).toBeVisible();
      await expect(page.getByText(A('admin.loadFailed'))).toHaveCount(0);
      await noSidewaysScroll(page, path);
    }
  });

  test('the department form with its working days fits the screen and every weekday can be tapped', async ({ page }) => {
    await page.goto('/admin/departments');
    await page.getByRole('button', { name: A('dep.editAria', 'en', { name: 'Oral Surgery' }) }).click();
    const dialog = page.getByRole('dialog', { name: A('dep.form.editTitle') });
    const group = dialog.getByRole('group', { name: A('dep.workingDays') });
    await expect(group.getByRole('checkbox')).toHaveCount(7);
    for (const box of await group.getByRole('checkbox').all()) {
      await box.scrollIntoViewIfNeeded();
      await expect(box).toBeVisible();
    }
    await noSidewaysScroll(page, 'department form');
    await page.keyboard.press('Escape');
  });
});
