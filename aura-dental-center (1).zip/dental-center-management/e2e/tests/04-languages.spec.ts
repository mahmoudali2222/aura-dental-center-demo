import { expect, request as pwRequest, test } from '@playwright/test';
import { A, AUTH_ADMIN, P, PATIENT_PASSWORD, chooseDay, newPhone, offeredDays } from './support.js';

const ARABIC_INDIC_DIGITS = /[٠-٩۰-۹]/;
const NO_STORAGE = { cookies: [], origins: [] };
/** The language selector in the page header (its label changes with the language, so it is found by its place, not its name). */
const switcher = (page: import('@playwright/test').Page) => page.locator('header select').first();
/** The patient website's language switcher: three buttons, each named in its own language. */
const NATIVE = { en: 'English', ar: 'العربية', fr: 'Français' } as const;
const patientLanguage = (page: import('@playwright/test').Page, l: keyof typeof NATIVE) => page.locator('header').getByRole('button', { name: NATIVE[l], exact: true }).click();

test.describe.configure({ mode: 'serial' });

test.describe('patient website', () => {
  test.use({ storageState: NO_STORAGE });

  test('Arabic is right-to-left with Arabic words and Latin digits, French is left-to-right, and the choice is remembered', async ({ page }) => {
    await page.goto('/departments');
    await patientLanguage(page, 'ar');
    await expect(page.locator('html')).toHaveAttribute('lang', 'ar');
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    await expect(page.getByRole('heading', { level: 1, name: P('departments.title', 'ar') })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'طب الأسنان الترميمي', exact: true })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Restorative Dentistry' })).toHaveCount(0);
    await expect(page.getByRole('contentinfo')).toContainText('4:00'); // opening hours: Latin digits
    await expect(page.locator('body')).not.toContainText(ARABIC_INDIC_DIGITS);

    await page.reload(); // remembered in this browser
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    await expect(page.getByRole('heading', { level: 1, name: P('departments.title', 'ar') })).toBeVisible();

    await patientLanguage(page, 'fr');
    await expect(page.locator('html')).toHaveAttribute('lang', 'fr');
    await expect(page.locator('html')).toHaveAttribute('dir', 'ltr');
    await expect(page.getByRole('heading', { level: 1, name: P('departments.title', 'fr') })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Dentisterie restauratrice', exact: true })).toBeVisible();
    await expect(page.getByRole('contentinfo')).toContainText('16:00'); // French uses the 24-hour clock
  });

  test('the sign-in and registration forms are translated and right-to-left in Arabic', async ({ page }) => {
    await page.goto('/register');
    await patientLanguage(page, 'ar');
    await expect(page.getByRole('heading', { name: P('auth.register.title', 'ar') })).toBeVisible();
    await expect(page.getByLabel(P('auth.fullName', 'ar'), { exact: true })).toBeVisible();
    await expect(page.getByLabel(P('auth.phone', 'ar'), { exact: true })).toBeVisible();
    await expect(page.getByLabel(P('auth.password', 'ar'), { exact: true })).toBeVisible();
    // a phone number that is not a phone number: the reason is shown at the field, in Arabic, never as a raw code or backend text
    await page.getByLabel(P('auth.fullName', 'ar'), { exact: true }).fill('E2E Bad Phone');
    await page.getByLabel(P('auth.phone', 'ar'), { exact: true }).fill('123');
    await page.getByLabel(P('auth.password', 'ar'), { exact: true }).fill(PATIENT_PASSWORD);
    await page.getByRole('button', { name: P('auth.register.submit', 'ar') }).click();
    await expect(page.getByText(P('err.INVALID_PHONE', 'ar'))).toHaveCount(1); // once, at the field (not repeated in an alert above the form)
    await expect(page.getByText(P('err.INVALID_PHONE', 'ar'))).toBeVisible();
    await expect(page.locator('body')).not.toContainText(/VALIDATION_ERROR|INVALID_PHONE|Invalid/);
    await expect(page.getByRole('button', { name: P('nav.logout', 'ar') })).toHaveCount(0);
  });
});

test.describe('a signed-in patient', () => {
  test.use({ storageState: NO_STORAGE });
  let phone = '';

  test('books in Arabic: 12-hour times with Latin digits; the language choice is saved on the account and follows them to another browser', async ({ page, browser, baseURL }) => {
    phone = newPhone();
    const api = await pwRequest.newContext({ baseURL, storageState: NO_STORAGE });
    const reg = await api.post('/api/v1/patient/auth/register', { data: { fullName: 'E2E Language Patient', phone, password: PATIENT_PASSWORD } });
    expect(reg.status()).toBe(201);
    await page.context().addCookies((await api.storageState()).cookies);
    await api.dispose();

    await page.goto('/book?department=orthodontics');
    await patientLanguage(page, 'ar');
    await expect(page.getByRole('heading', { level: 1, name: P('book.title', 'ar') })).toBeVisible();
    const days = await offeredDays(page, 'ar');
    await chooseDay(page, days[5]!, 'ar');
    const times = page.locator('label:has(input[name^="slot-"])');
    await expect(times.first()).toContainText(/4:00/);
    await expect(page.locator('main')).not.toContainText(ARABIC_INDIC_DIGITS);

    // the choice was saved on the account: a browser that has never seen the site opens in Arabic after signing in
    await expect.poll(async () => {
      const fresh = await browser.newContext({ storageState: NO_STORAGE, locale: 'en-US' });
      const login = await fresh.request.post('/api/v1/patient/auth/login', { data: { phone, password: PATIENT_PASSWORD } });
      const me = await fresh.request.get('/api/v1/patient/me');
      const locale = login.ok() ? (await me.json()).data.patient.preferredLocale : 'login failed';
      await fresh.close();
      return locale;
    }).toBe('ar');

    const other = await browser.newContext({ storageState: NO_STORAGE, locale: 'en-US' });
    const p2 = await other.newPage();
    await p2.goto('/login');
    await p2.getByLabel(P('auth.phone', 'en'), { exact: true }).fill(phone);
    await p2.getByLabel(P('auth.password', 'en'), { exact: true }).fill(PATIENT_PASSWORD);
    await p2.getByRole('button', { name: P('auth.login.submit', 'en') }).click();
    await expect(p2.getByRole('button', { name: P('nav.logout', 'ar') })).toBeVisible();
    await expect(p2.locator('html')).toHaveAttribute('dir', 'rtl');
    await other.close();
  });
});

test.describe('admin dashboard', () => {
  test.use({ storageState: AUTH_ADMIN });

  test('the dashboard switches to Arabic (right-to-left) and French and keeps working', async ({ page }) => {
    await page.goto('/admin/departments');
    await expect(page.getByRole('heading', { level: 1, name: A('dep.title') })).toBeVisible();
    await switcher(page).selectOption('ar');
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    await expect(page.getByRole('heading', { level: 1, name: A('dep.title', 'ar') })).toBeVisible();
    await expect(page.getByRole('navigation', { name: A('admin.nav.main', 'ar') })).toBeVisible();
    await expect(page.getByRole('listitem', { name: 'طب الأسنان الترميمي' })).toContainText(A('dep.workingDays.everyDay', 'ar'));
    // the edit form is translated too, weekday names included
    await page.getByRole('button', { name: A('dep.editAria', 'ar', { name: 'طب الأسنان الترميمي' }) }).click();
    const group = page.getByRole('dialog', { name: A('dep.form.editTitle', 'ar') }).getByRole('group', { name: A('dep.workingDays', 'ar') });
    await expect(group.getByRole('checkbox')).toHaveCount(7);
    await expect(group.getByRole('checkbox', { name: 'الاثنين' })).toBeChecked();
    await page.keyboard.press('Escape');
    await expect(page.locator('body')).not.toContainText(ARABIC_INDIC_DIGITS);

    await switcher(page).selectOption('fr');
    await expect(page.locator('html')).toHaveAttribute('dir', 'ltr');
    await expect(page.getByRole('heading', { level: 1, name: A('dep.title', 'fr') })).toBeVisible();
    await switcher(page).selectOption('en');
    await expect(page.getByRole('heading', { level: 1, name: A('dep.title', 'en') })).toBeVisible();
  });
});
