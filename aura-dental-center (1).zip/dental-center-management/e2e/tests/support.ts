import { expect, type Page, type APIRequestContext } from '@playwright/test';
import { adminMessages } from '../../frontend/src/admin/i18n/messages.js';
import { patientMessages } from '../../frontend/src/patient/i18n/messages.js';

export type L = 'en' | 'ar' | 'fr';
type Vars = Record<string, string | number>;

const fill = (text: string, vars: Vars) => text.replace(/\{(\w+)\}/g, (_m, k: string) => String(vars[k] ?? ''));
/** A text of the patient website, looked up in the same bundle the website uses (so tests do not break when wording is improved). */
export function P(key: string, locale: L = 'en', vars: Vars = {}): string {
  const v = (patientMessages[locale] as Record<string, string>)[key];
  if (v === undefined) throw new Error(`unknown patient message key: ${key}`);
  return fill(v, vars);
}
/** A text of the admin dashboard. */
export function A(key: string, locale: L = 'en', vars: Vars = {}): string {
  const v = (adminMessages[locale] as Record<string, string>)[key];
  if (v === undefined) throw new Error(`unknown admin message key: ${key}`);
  return fill(v, vars);
}

export function env(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`${name} is not set. Run the tests through scripts/e2e-local.sh (or set the E2E_* variables, see playwright.config.ts).`);
  return v;
}
export const admin = () => ({ username: env('E2E_ADMIN_USER'), initial: env('E2E_ADMIN_INITIAL_PASSWORD'), password: env('E2E_ADMIN_NEW_PASSWORD') });

export const AUTH_ADMIN = '.auth/admin.json';
export const AUTH_PATIENT = '.auth/patient.json';

let counter = 0;
/** An Egyptian mobile number nobody else in this run uses. */
export function newPhone(): string {
  counter += 1;
  const tail = String(Date.now() % 1_000_000).padStart(6, '0') + String(counter).padStart(2, '0');
  return `010${tail}`;
}
export const PATIENT_PASSWORD = 'E2e-Patient-Pass-2026';

/** ISO weekday (1 = Monday ... 7 = Sunday) of a plain calendar date. */
export function weekdayOf(isoDate: string): number {
  return ((new Date(`${isoDate}T00:00:00Z`).getUTCDay() + 6) % 7) + 1;
}
/** Today's date in Cairo as YYYY-MM-DD, plus `n` days. */
export function cairoDate(n = 0): string {
  const d = new Date(Date.now() + n * 86_400_000);
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}

/** The month buttons of the booking calendar. */
const monthButtons = (page: Page, locale: L) => ({
  prev: page.getByRole('button', { name: P('book.month.prev', locale) }),
  next: page.getByRole('button', { name: P('book.month.next', locale) }),
});

/**
 * The days the booking page offers, as YYYY-MM-DD, across the whole booking period (read from the radio buttons the patient clicks).
 * The calendar shows one month at a time, so this walks through the months and leaves the calendar on its first month.
 */
export async function offeredDays(page: Page, locale: L = 'en'): Promise<string[]> {
  await expect(page.getByRole('radiogroup', { name: P('book.date', locale) }).first()).toBeVisible();
  const { prev, next } = monthButtons(page, locale);
  while (await prev.first().isEnabled()) await prev.first().click();
  const days: string[] = [];
  for (let month = 0; month < 6; month += 1) {
    days.push(...(await page.locator('input[type="radio"][name^="day-"]').evaluateAll((els) => els.map((e) => (e as HTMLInputElement).value))));
    if (!(await next.first().isEnabled())) break;
    await next.first().click();
  }
  while (await prev.first().isEnabled()) await prev.first().click();
  return days;
}

/** Clicks the day for a date on the booking page, moving to its month first when needed. */
export async function chooseDay(page: Page, date: string, locale: L = 'en'): Promise<void> {
  const label = page.locator(`label:has(input[name^="day-"][value="${date}"])`);
  const { prev, next } = monthButtons(page, locale);
  // the patient website's calendar has month buttons; the dashboard's own booking form lists its days without them
  if ((await prev.count()) > 0) {
    while (await prev.first().isEnabled()) await prev.first().click();
  }
  for (let month = 0; month < 6 && (await label.count()) === 0; month += 1) {
    expect(await next.first().isEnabled(), `${date} is in the booking calendar`).toBe(true);
    await next.first().click();
  }
  await label.click();
}

/**
 * Calls the admin API as the signed-in dashboard session of `request` (a Playwright request context that carries the admin
 * cookie). The session's CSRF token is read from the session itself, exactly as the dashboard does.
 */
export async function adminApi(request: APIRequestContext, method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE', path: string, data?: unknown): Promise<{ status: number; body: any }> {
  const me = await request.get('/api/v1/admin/auth/me');
  expect(me.ok(), 'the administrator session is still valid').toBe(true);
  const csrf = (await me.json()).data.csrfToken as string;
  const res = await request.fetch(path, { method, data, headers: { 'x-csrf-token': csrf } });
  return { status: res.status(), body: await res.json().catch(() => null) };
}
