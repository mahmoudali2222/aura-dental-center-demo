import { defineConfig, devices } from '@playwright/test';

/**
 * Browser tests for the patient website and the admin dashboard. They run against a RUNNING, THROW-AWAY copy of the system
 * (see ../scripts/e2e-local.sh, or point E2E_BASE_URL at a stack you started for testing). They create patients named "E2E ..."
 * and bookings, so never point them at the real clinic database.
 *
 * Environment (set by scripts/e2e-local.sh):
 *   E2E_BASE_URL                     the site, e.g. http://127.0.0.1:8480
 *   E2E_ADMIN_USER / E2E_ADMIN_INITIAL_PASSWORD   the bootstrap admin (still on its first, temporary password)
 *   E2E_ADMIN_NEW_PASSWORD           the password the tests choose when the first sign-in forces a change
 */
export default defineConfig({
  testDir: './tests',
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1, // the tests share one database and one admin account on purpose: they run in a fixed order
  retries: 0,
  reporter: [['list'], ['html', { open: 'never', outputFolder: 'report' }]],
  outputDir: 'test-results',
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://127.0.0.1:8480',
    locale: 'en-US',
    timezoneId: 'Africa/Cairo',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
  projects: [
    { name: 'setup', testMatch: /setup\/.*\.setup\.ts/, use: { ...devices['Desktop Chrome'] } },
    { name: 'desktop-chromium', testIgnore: [/setup\//, /mobile\./], dependencies: ['setup'], use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile-chromium', testMatch: /mobile\..*\.spec\.ts/, dependencies: ['setup'], use: { ...devices['Pixel 5'] } },
  ],
});
