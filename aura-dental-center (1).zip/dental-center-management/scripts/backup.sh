#!/usr/bin/env sh
# Creates a verified backup of the clinic database (PostgreSQL custom format) in ./backups.
#
#   scripts/backup.sh                 one backup, keeps the newest 14 "dental-center-*.dump" files
#   KEEP=30 scripts/backup.sh         keep the newest 30      (KEEP=0 keeps everything)
#   BACKUP_DIR=/mnt/usb scripts/backup.sh
#
# A backup is only reported as good after it was (1) written, (2) read back with pg_restore --list,
# (3) copied out of the container with an identical size, and (4) given a SHA-256 checksum file.
# Run from anywhere; the script moves to the project folder itself. Needs the "db" container to be running.
set -eu
cd "$(dirname "$0")/.."

BACKUP_DIR="${BACKUP_DIR:-backups}"
KEEP="${KEEP:-14}"
PREFIX="${BACKUP_PREFIX:-dental-center}"
COMPOSE="${DC_COMPOSE:-docker compose}"

say() { printf '%s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

$COMPOSE ps --status running --services 2>/dev/null | grep -qx db || die "the database container is not running (start it with: docker compose up -d db)"

ts="$(date +%Y%m%d-%H%M%S)"
file="$BACKUP_DIR/$PREFIX-$ts.dump"
inside="/tmp/dc-backup-$ts.dump"
mkdir -p "$BACKUP_DIR"
cleanup() { $COMPOSE exec -T db rm -f "$inside" >/dev/null 2>&1 || true; }
trap cleanup EXIT

say "Creating backup ..."
$COMPOSE exec -T db sh -c "pg_dump --format=custom --no-owner --no-privileges -U \$POSTGRES_USER -d \$POSTGRES_DB -f $inside" || die "pg_dump failed; no backup was made"
$COMPOSE exec -T db pg_restore --list "$inside" >/dev/null || die "the new dump failed verification (pg_restore --list); do not rely on it"
size_in="$($COMPOSE exec -T db sh -c "wc -c < $inside" | tr -d ' \r\n')"
$COMPOSE cp "db:$inside" "$file" >/dev/null || die "could not copy the backup out of the container"
size_out="$(wc -c < "$file" | tr -d ' \r\n')"
if [ "$size_in" != "$size_out" ] || [ "$size_out" -lt 1000 ]; then rm -f "$file"; die "the copied backup is incomplete ($size_out of $size_in bytes); it was deleted"; fi

name="$(basename "$file")"
if command -v sha256sum >/dev/null 2>&1; then (cd "$BACKUP_DIR" && sha256sum "$name" > "$name.sha256")
elif command -v shasum >/dev/null 2>&1; then (cd "$BACKUP_DIR" && shasum -a 256 "$name" > "$name.sha256")
else say "note: no sha256 tool found; skipping the checksum file"; fi

if [ "$KEEP" -gt 0 ] 2>/dev/null; then
  ls -1t "$BACKUP_DIR/$PREFIX"-*.dump 2>/dev/null | tail -n +"$((KEEP + 1))" | while IFS= read -r old; do
    rm -f "$old" "$old.sha256"; say "Removed old backup: $old"
  done
fi

say "Backup OK (verified): $file ($size_out bytes)"
say "IMPORTANT: copy this file to another disk or cloud storage. A backup stored only on this computer is lost with it."
