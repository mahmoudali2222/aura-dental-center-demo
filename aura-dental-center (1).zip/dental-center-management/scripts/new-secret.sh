#!/usr/bin/env sh
# Prints a random URL-safe secret (default 48 hex characters). Usage: scripts/new-secret.sh [bytes]
bytes="${1:-24}"
if command -v openssl >/dev/null 2>&1; then openssl rand -hex "$bytes"; else head -c "$bytes" /dev/urandom | od -An -tx1 | tr -d ' \n'; echo; fi
