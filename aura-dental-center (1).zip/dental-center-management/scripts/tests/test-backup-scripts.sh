#!/usr/bin/env bash
# Tests scripts/backup.sh and scripts/restore.sh against a throw-away database on a local PostgreSQL, using the
# fake-compose.sh test double (no Docker involved). Run:  bash scripts/tests/test-backup-scripts.sh
# Needs: psql, pg_dump, pg_restore, and a PostgreSQL server (defaults to 127.0.0.1:54329 as user postgres).
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$HERE/../.." && pwd)"
export FAKE_PG_HOST="${FAKE_PG_HOST:-127.0.0.1}" FAKE_PG_PORT="${FAKE_PG_PORT:-54329}" FAKE_PG_USER="${FAKE_PG_USER:-postgres}"
export PGHOST="$FAKE_PG_HOST" PGPORT="$FAKE_PG_PORT" PGUSER="$FAKE_PG_USER"
DB="dc_bk_$$"; export FAKE_PG_DB="$DB"
WORK="$(mktemp -d)"; export BACKUP_DIR="$WORK/backups" FAKE_LOG="$WORK/calls.log" DC_COMPOSE="bash $HERE/fake-compose.sh"
: > "$FAKE_LOG"
pass=0; failn=0
check() { if eval "$2"; then pass=$((pass+1)); echo "PASS  $1"; else failn=$((failn+1)); echo "FAIL  $1   [$2]"; fi; }
q() { psql -At -q -d "${2:-$DB}" -c "$1"; }
cleanup() { psql -q -d postgres -c "DROP DATABASE IF EXISTS $DB WITH (FORCE)" -c "DROP DATABASE IF EXISTS ${DB}_restore_check WITH (FORCE)" >/dev/null 2>&1; rm -rf "$WORK"; }
trap cleanup EXIT
pg_isready -q || { echo "PostgreSQL is not reachable at $PGHOST:$PGPORT"; exit 2; }

psql -q -d postgres -c "CREATE DATABASE $DB" || exit 2
# Use the project's real migration runner so schema_migrations and checksums are exactly what production has.
( cd "$ROOT/backend" && DATABASE_URL="postgres://$PGUSER@$PGHOST:$PGPORT/$DB" npx --no-install tsx src/cli/migrate.ts >/dev/null ) || { echo "migration runner failed"; exit 2; }
psql -q -d "$DB" >/dev/null <<'SQL'
INSERT INTO departments (slug) VALUES ('alpha'),('beta');
INSERT INTO patients (phone_e164, full_name, password_hash) VALUES ('+201010000001','Alice Original','h1'),('+201010000002','Bob Original','h2'),('+201010000003','Carol Original','h3');
INSERT INTO audit_events (actor_type, action, outcome) VALUES ('system','fixture','success');
SQL
MIGRATION_FILES="$(ls -1 "$ROOT"/database/migrations/*.sql | wc -l | tr -d ' ')"   # every shipped migration must be in the restored history
orig_names="$(q "SELECT string_agg(full_name, ',' ORDER BY full_name) FROM patients")"

echo "--- backup.sh"
out="$(sh "$ROOT/scripts/backup.sh" 2>&1)"; rc=$?
check "backup exits 0 and says verified" '[ $rc -eq 0 ] && echo "$out" | grep -q "Backup OK (verified)"'
first="$(ls -1 "$BACKUP_DIR"/dental-center-*.dump | head -n 1)"
check "backup file and checksum exist" '[ -s "$first" ] && [ -s "$first.sha256" ]'
check "checksum verifies" '(cd "$BACKUP_DIR" && sha256sum -c "$(basename "$first").sha256" >/dev/null)'
check "dump is a readable archive containing patients" 'pg_restore --list "$first" | grep -q "TABLE public patients"'
check "temporary file in the container was removed" '! ls /tmp/dc-backup-*.dump >/dev/null 2>&1'
check "backup does not modify the database" '[ "$(q "SELECT count(*) FROM patients")" = 3 ]'

echo "--- retention"
for i in 1 2 3 4; do sleep 1.1; KEEP=3 sh "$ROOT/scripts/backup.sh" >/dev/null 2>&1; done
check "only the newest 3 backups are kept (older removed with their checksum files)" '[ "$(ls -1 "$BACKUP_DIR"/dental-center-*.dump | wc -l)" -eq 3 ] && [ "$(ls -1 "$BACKUP_DIR"/dental-center-*.sha256 | wc -l)" -eq 3 ]'
latest="$(ls -1t "$BACKUP_DIR"/dental-center-*.dump | head -n 1)"

echo "--- restore.sh (safe check, default)"
out="$(sh "$ROOT/scripts/restore.sh" "$latest" 2>&1)"; rc=$?
check "safe check passes" '[ $rc -eq 0 ] && echo "$out" | grep -q "RESTORE CHECK PASSED"'
check "it lists table counts for backup and live" 'echo "$out" | grep -Eq "^patients +3 +3"'
check "scratch database is dropped afterwards" '[ "$(q "SELECT count(*) FROM pg_database WHERE datname = '"'"'${DB}_restore_check'"'"'" postgres)" = 0 ]'
check "live data untouched, application never stopped" '[ "$(q "SELECT string_agg(full_name, '"','"' ORDER BY full_name) FROM patients")" = "$orig_names" ] && ! grep -q "^stop" "$FAKE_LOG"'
KEEP=0 out="$(sh "$ROOT/scripts/restore.sh" "$latest" --keep 2>&1)"
check "--keep leaves the scratch database for inspection" '[ "$(q "SELECT count(*) FROM pg_database WHERE datname = '"'"'${DB}_restore_check'"'"'" postgres)" = 1 ]'
psql -q -d postgres -c "DROP DATABASE ${DB}_restore_check WITH (FORCE)"

echo "--- restore.sh refuses bad input"
head -c "$(( $(wc -c < "$latest") / 2 ))" "$latest" > "$WORK/truncated.dump"
out="$(sh "$ROOT/scripts/restore.sh" "$WORK/truncated.dump" --live 2>&1 </dev/null)"; rc=$?
check "truncated backup is rejected before anything changes" '[ $rc -ne 0 ] && echo "$out" | grep -q "not a readable backup" && ! grep -q "^stop" "$FAKE_LOG"'
echo "not a backup" > "$WORK/text.dump"
out="$(sh "$ROOT/scripts/restore.sh" "$WORK/text.dump" 2>&1)"; rc=$?
check "a text file is rejected" '[ $rc -ne 0 ] && echo "$out" | grep -q "not a readable backup"'
cp "$latest" "$WORK/tampered.dump"; cp "$latest.sha256" "$WORK/tampered.dump.sha256"; sed -i "s/dental-center-.*\.dump/tampered.dump/" "$WORK/tampered.dump.sha256"
printf 'X' | dd of="$WORK/tampered.dump" bs=1 seek=200 conv=notrunc 2>/dev/null
out="$(sh "$ROOT/scripts/restore.sh" "$WORK/tampered.dump" 2>&1)"; rc=$?
check "a file that no longer matches its checksum is rejected" '[ $rc -ne 0 ] && echo "$out" | grep -qi "checksum mismatch"'
out="$(sh "$ROOT/scripts/restore.sh" "$WORK/missing.dump" 2>&1)"; rc=$?
check "a missing file gives a clear error" '[ $rc -ne 0 ] && echo "$out" | grep -q "file not found"'

echo "--- restore.sh --live: confirmation"
q "UPDATE patients SET full_name = 'CHANGED ' || full_name" >/dev/null; q "INSERT INTO patients (phone_e164, full_name, password_hash) VALUES ('+201010000009','Dave AfterBackup','h9')" >/dev/null
changed_names="$(q "SELECT string_agg(full_name, ',' ORDER BY full_name) FROM patients")"
: > "$FAKE_LOG"
out="$(DC_CONFIRM=wrong-name sh "$ROOT/scripts/restore.sh" "$latest" --live 2>&1)"; rc=$?
check "wrong confirmation aborts with no change and no stop" '[ $rc -ne 0 ] && echo "$out" | grep -q "confirmation did not match" && ! grep -q "^stop" "$FAKE_LOG" && [ "$(q "SELECT string_agg(full_name, '"','"' ORDER BY full_name) FROM patients")" = "$changed_names" ]'
out="$(sh "$ROOT/scripts/restore.sh" "$latest" --live 2>&1 </dev/null)"; rc=$?
check "no confirmation at all (no terminal input) aborts" '[ $rc -ne 0 ] && ! grep -q "^stop" "$FAKE_LOG"'

echo "--- restore.sh --live: replaces data"
out="$(DC_CONFIRM="$DB" sh "$ROOT/scripts/restore.sh" "$latest" --live 2>&1)"; rc=$?
[ $rc -ne 0 ] && echo "$out" | tail -15
check "live restore exits 0 and reports completion" '[ $rc -eq 0 ] && echo "$out" | grep -q "LIVE RESTORE COMPLETE"'
check "data is back to the backup state (change undone, post-backup row gone)" '[ "$(q "SELECT string_agg(full_name, '"','"' ORDER BY full_name) FROM patients")" = "$orig_names" ]'
check "audit log and migration history came back too" '[ "$(q "SELECT count(*) FROM audit_events WHERE action = '"'fixture'"'")" = 1 ] && [ "$(q "SELECT count(*) FROM schema_migrations")" = "$MIGRATION_FILES" ]'
pre="$(ls -1t "$BACKUP_DIR"/pre-restore-*.dump | head -n 1)"
check "a pre-restore backup of the replaced data exists and holds the changed state" '[ -s "$pre" ] && pg_restore -f - "$pre" | grep -q "CHANGED Alice"'
check "order: stop backend -> migrate -> start backend" 'a=$(grep -n "^stop.*backend" "$FAKE_LOG" | head -1 | cut -d: -f1); b=$(grep -n "^run.*migrate" "$FAKE_LOG" | head -1 | cut -d: -f1); c=$(grep -n "^up.*backend" "$FAKE_LOG" | head -1 | cut -d: -f1); [ -n "$a" ] && [ -n "$b" ] && [ -n "$c" ] && [ "$a" -lt "$b" ] && [ "$b" -lt "$c" ]'
check "pre-restore backups are never auto-deleted by retention" '[ "$(ls -1 "$BACKUP_DIR"/pre-restore-*.dump | wc -l)" -ge 1 ]'

echo "--- rollback using the pre-restore backup"
out="$(DC_CONFIRM="$DB" sh "$ROOT/scripts/restore.sh" "$pre" --live 2>&1)"; rc=$?
check "rolling back restores the state from before the first restore" '[ $rc -eq 0 ] && [ "$(q "SELECT string_agg(full_name, '"','"' ORDER BY full_name) FROM patients")" = "$changed_names" ]'

echo
echo "RESULT: $pass passed, $failn failed"
[ "$failn" -eq 0 ]
