#!/usr/bin/env bash
# TEST DOUBLE for "docker compose": runs the commands that the backup/restore scripts would run inside the "db" container
# directly against a local PostgreSQL (FAKE_PG_*), and records every call in $FAKE_LOG. It exists only so the scripts' own
# logic can be tested where no Docker daemon is available. It proves nothing about Docker itself.
set -u
while [ $# -gt 0 ]; do case "$1" in -p|-f|--env-file|--project-name) shift 2 ;; --*) shift ;; *) break ;; esac; done
sub="${1:-}"; shift || true
export PGHOST="${FAKE_PG_HOST:-127.0.0.1}" PGPORT="${FAKE_PG_PORT:-54329}" PGUSER="${FAKE_PG_USER:-postgres}"
export POSTGRES_USER="$PGUSER" POSTGRES_DB="${FAKE_PG_DB:?FAKE_PG_DB must be set}"
echo "$sub $*" >> "${FAKE_LOG:-/dev/null}"
case "$sub" in
  ps) echo db ;;
  exec) [ "${1:-}" = "-T" ] && shift; shift; exec "$@" ;;          # drop the service name ("db"), run the command
  cp) src="${1#db:}"; dst="${2#db:}"; cp "$src" "$dst" ;;
  stop|start|up|run) : ;;                                          # recorded only
  *) echo "fake-compose: unsupported subcommand '$sub'" >&2; exit 2 ;;
esac
