#!/usr/bin/env bash
# Runs the browser tests (e2e/) against a REAL, throw-away copy of the system started on this machine WITHOUT Docker:
#   PostgreSQL (a new empty database)  ->  the built backend (node backend/dist)  ->  the web container's real nginx
#   configuration (scripts/run-local-web.sh)  ->  Playwright / Chromium.
# It exists for machines where Docker is unavailable (CI sandboxes). On a machine with Docker Desktop use
# scripts/verify-docker.ps1, which runs the same smoke checks against the real containers.
#
#   scripts/e2e-local.sh [playwright arguments...]        e.g.  scripts/e2e-local.sh --project=desktop-chromium -g "working days"
#
# Needs: Node 22, nginx, a PostgreSQL server reachable with the superuser URL in TEST_DATABASE_ADMIN_URL
# (default postgres://postgres@127.0.0.1:54329/postgres), and the frontend built (npm --prefix frontend run build) and the
# backend built (npm --prefix backend run build). It creates one database "dc_e2e_<random>" and drops it at the end.
# Nothing here touches a real clinic database: the database name is random and created by this script.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
admin_url="${TEST_DATABASE_ADMIN_URL:-postgres://postgres@127.0.0.1:54329/postgres}"
web_port="${E2E_WEB_PORT:-8481}"
api_port="${E2E_API_PORT:-3481}"
name="dc_e2e_$(head -c 6 /dev/urandom | od -An -tx1 | tr -d ' \n')"
db_url="${admin_url%/*}/$name"
tmp="$(mktemp -d /tmp/dental-e2e.XXXXXX)"
pids=()

cleanup() {
  status=$?
  for p in "${pids[@]:-}"; do [ -n "$p" ] && kill "$p" 2>/dev/null || true; done
  for p in "${pids[@]:-}"; do [ -n "$p" ] && wait "$p" 2>/dev/null || true; done
  psql "$admin_url" -qc "DROP DATABASE IF EXISTS $name WITH (FORCE)" >/dev/null 2>&1 || true
  rm -rf "$tmp"
  exit $status
}
trap cleanup EXIT INT TERM

[ -f "$here/frontend/dist/index.html" ] || { echo "frontend is not built: npm --prefix frontend run build" >&2; exit 1; }
[ -f "$here/backend/dist/server.js" ] || { echo "backend is not built: npm --prefix backend run build" >&2; exit 1; }

# Throw-away secrets for this run only (never written anywhere permanent).
rand() { head -c "$1" /dev/urandom | od -An -tx1 | tr -d ' \n'; }
export E2E_ADMIN_USER="e2e_owner"
export E2E_ADMIN_INITIAL_PASSWORD="Init-$(rand 8)-Aa1!"
export E2E_ADMIN_NEW_PASSWORD="Strong-$(rand 8)-Bb2#"
export E2E_INTEGRATION_KEY="$(rand 24)"
export E2E_BASE_URL="http://127.0.0.1:$web_port"

psql "$admin_url" -qc "CREATE DATABASE $name" >/dev/null
export DATABASE_URL="$db_url" NODE_ENV=production HOST=127.0.0.1 PORT="$api_port" LOG_LEVEL=warn
export PUBLIC_APP_URL="$E2E_BASE_URL" COOKIE_SECURE=false TRUST_PROXY=true INTEGRATION_API_KEY="$E2E_INTEGRATION_KEY"
# generous rate limits are NOT set: the tests run against the shipped defaults

cd "$here/backend"
node dist/cli/migrate.js
node dist/cli/seed.js
ADMIN_BOOTSTRAP_USERNAME="$E2E_ADMIN_USER" ADMIN_BOOTSTRAP_PASSWORD="$E2E_ADMIN_INITIAL_PASSWORD" node dist/cli/bootstrap-admin.js >/dev/null

node dist/server.js >"$tmp/backend.log" 2>&1 &
pids+=($!)
for _ in $(seq 1 60); do curl -fsS "http://127.0.0.1:$api_port/api/ready" >/dev/null 2>&1 && break; sleep 0.5; done
curl -fsS "http://127.0.0.1:$api_port/api/ready" >/dev/null || { echo "backend did not become ready:" >&2; tail -20 "$tmp/backend.log" >&2; exit 1; }

"$here/scripts/run-local-web.sh" "$web_port" "$api_port" >"$tmp/web.log" 2>&1 &
pids+=($!)
for _ in $(seq 1 60); do curl -fsS "$E2E_BASE_URL/healthz" >/dev/null 2>&1 && break; sleep 0.5; done
curl -fsS "$E2E_BASE_URL/api/ready" >/dev/null || { echo "web container configuration did not come up:" >&2; tail -20 "$tmp/web.log" >&2; exit 1; }

echo "stack is up: $E2E_BASE_URL  (database $name)" >&2
cd "$here/e2e"
[ -d node_modules/@playwright/test ] || npm ci --no-audit --no-fund >&2
set +e
npx playwright test "$@"
code=$?
set -e
if [ $code -ne 0 ]; then echo "--- backend log (last lines) ---" >&2; tail -15 "$tmp/backend.log" >&2; fi
exit $code
