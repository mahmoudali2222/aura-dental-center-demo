<#
.SYNOPSIS
  Verifies the Docker deployment on THIS machine with a separate, throw-away copy of the stack (spec 17.6, checks DOCK-01 .. DOCK-12).

.DESCRIPTION
  It never touches your real installation. Everything it creates has its own name:
      Compose project   dental-center-verify
      Database volume   dental_center_verify_pgdata
      Network           dental_center_verify_net
      Images            dental-center-verify-backend:local, dental-center-verify-web:local
      Web port          18480 (change with -Port), published on 127.0.0.1 only
      Settings file     .env.verify (random secrets, deleted at the end)
  It refuses to start if that volume already exists, if the port is busy, or if Docker is not running. At the end it removes
  only the things listed above. It uses no "down -v" against any other project and never reads your .env.

  What it does (the numbers are the checks of the specification):
   01 build the images             02 start the stack             03 wait until db/backend/web are healthy
   04 migrations applied and the seven departments exist          05 backend ready through the web container
   06 website and dashboard are served        07 real booking through the API (plus scripts\smoke-api.mjs)
   08 the booking is in PostgreSQL            09 the same booking is visible to the patient and to the administrator
   10 stop and start again (no volume deletion): data and the administrator's password are still there
   11 backup, safe restore check, live restore on the throw-away copy (an earlier state comes back)
   12 stop without deleting the data volume (it must still exist), then remove the throw-away copy

  Needs: Docker Desktop running (Compose v2). The first run downloads/builds images and takes several minutes.
  Writes verify-docker-report-<date>.txt (results and docker versions; only throw-away test data, no secrets).

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\scripts\verify-docker.ps1
.EXAMPLE
  .\scripts\verify-docker.ps1 -Port 18999 -KeepStack     # keep the volume, images and .env.verify for inspection
#>
[CmdletBinding()]
param(
  [int]$Port = 18480,
  [switch]$KeepStack,
  [int]$HealthTimeoutSeconds = 420
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

# ---- the ONLY names this script may create or delete ------------------------------------------------------------------
$Project      = 'dental-center-verify'
$Volume       = 'dental_center_verify_pgdata'
$Network      = 'dental_center_verify_net'
$BackendImage = 'dental-center-verify-backend:local'
$WebImage     = 'dental-center-verify-web:local'
$EnvFile      = '.env.verify'
$BackupFolder = 'verify-backups'
$DbName       = 'dental_center'
$DbUser       = 'dental_center'
$Base         = "http://localhost:$Port"
$Stamp        = Get-Date -Format 'yyyyMMdd-HHmmss'
$ReportFile   = Join-Path $Root "verify-docker-report-$Stamp.txt"

# Safety net: refuse to run if somebody edited the names above to the real installation's names.
foreach ($pair in @(@($Project, 'dental-center'), @($Volume, 'dental_center_pgdata'), @($Network, 'dental_center_net'), @($BackendImage, 'dental-center-backend:local'), @($WebImage, 'dental-center-web:local'))) {
  if ($pair[0] -eq $pair[1]) { throw "Refusing to run: '$($pair[0])' is the name used by the real installation." }
}

$script:Results = New-Object System.Collections.ArrayList
$script:Failed  = $false
$script:Notes   = New-Object System.Collections.ArrayList

function Say([string]$text) { Write-Host $text }
function Add-Result([string]$id, [string]$title, [bool]$ok, [string]$detail) {
  $status = 'FAIL'; if ($ok) { $status = 'PASS' }
  [void]$script:Results.Add([pscustomobject]@{ Id = $id; Title = $title; Status = $status; Detail = $detail })
  if (-not $ok) { $script:Failed = $true }
  $line = "{0}  {1}  {2}" -f $status, $id, $title
  if (-not $ok -and $detail) { $line += "   -> $detail" }
  if ($ok) { Write-Host $line -ForegroundColor Green } else { Write-Host $line -ForegroundColor Red }
}

# Runs a native command without PowerShell turning its stderr output into an error; returns Code and Out (lines).
function Run-Native([string[]]$cmd) {
  $old = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try {
    $exe = $cmd[0]
    $rest = @()
    if ($cmd.Length -gt 1) { $rest = $cmd[1..($cmd.Length - 1)] }
    $out = & $exe @rest 2>&1
    $code = $LASTEXITCODE
  } finally { $ErrorActionPreference = $old }
  $lines = @($out | ForEach-Object { "$_" })
  return [pscustomobject]@{ Code = $code; Out = $lines; Text = ($lines -join "`n") }
}
# Same, but shows the output while it runs (builds and starts take minutes).
function Stream-Native([string[]]$cmd) {
  $old = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try {
    $exe = $cmd[0]
    $rest = @()
    if ($cmd.Length -gt 1) { $rest = $cmd[1..($cmd.Length - 1)] }
    & $exe @rest 2>&1 | ForEach-Object { Write-Host "$_" }
    $code = $LASTEXITCODE
  } finally { $ErrorActionPreference = $old }
  return $code
}
function DcArgs([string[]]$more) { return @('docker', 'compose', '-p', $Project, '--env-file', $EnvFile) + $more }
function Dc([string[]]$more) { return Run-Native (DcArgs $more) }
function Psql([string]$sql) {
  $r = Dc @('exec', '-T', 'db', 'psql', '-At', '-U', $DbUser, '-d', $DbName, '-c', $sql)
  if ($r.Code -ne 0) { throw "psql failed: $($r.Text)" }
  return ($r.Text).Trim()
}

function New-Secret([int]$bytes) {
  $buf = New-Object byte[] $bytes
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  $rng.GetBytes($buf)
  $rng.Dispose()
  return (($buf | ForEach-Object { $_.ToString('x2') }) -join '')
}

# ---- HTTP helpers ------------------------------------------------------------------------------------------------------
function New-Session { return New-Object Microsoft.PowerShell.Commands.WebRequestSession }
function Api([string]$method, [string]$path, $session, $body, [string]$csrf, [hashtable]$headers) {
  $h = @{ 'Accept' = 'application/json' }
  if ($csrf) { $h['X-CSRF-Token'] = $csrf }
  if ($headers) { foreach ($k in $headers.Keys) { $h[$k] = $headers[$k] } }
  $params = @{ Uri = "$Base$path"; Method = $method; Headers = $h; UseBasicParsing = $true }
  if ($session) { $params['WebSession'] = $session }
  if ($null -ne $body) { $params['Body'] = (ConvertTo-Json $body -Depth 6 -Compress); $params['ContentType'] = 'application/json' }
  $status = 0; $text = ''; $respHeaders = $null
  try {
    $resp = Invoke-WebRequest @params
    $status = [int]$resp.StatusCode
    $text = [string]$resp.Content
    $respHeaders = $resp.Headers
  } catch {
    $ex = $_.Exception
    if ($ex.Response) {
      $status = [int]$ex.Response.StatusCode
      if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $text = [string]$_.ErrorDetails.Message }
      else {
        try { $reader = New-Object System.IO.StreamReader($ex.Response.GetResponseStream()); $text = $reader.ReadToEnd(); $reader.Dispose() } catch { $text = '' }
      }
      $respHeaders = $ex.Response.Headers
    } else { throw }
  }
  $json = $null
  if ($text) { try { $json = ConvertFrom-Json $text } catch { $json = $null } }
  return [pscustomobject]@{ Status = $status; Text = $text; Json = $json; Headers = $respHeaders }
}

function Get-ServiceStates {
  $r = Dc @('ps', '-a', '--format', 'json')
  if ($r.Code -ne 0) { return @() }
  $items = @()
  foreach ($line in $r.Out) {
    $t = $line.Trim()
    if (-not $t) { continue }
    try {
      $parsed = ConvertFrom-Json $t
      if ($parsed -is [System.Array]) { $items += $parsed } else { $items += ,$parsed }
    } catch { }
  }
  return $items
}
function Wait-Healthy([int]$seconds) {
  $deadline = (Get-Date).AddSeconds($seconds)
  $last = ''
  while ((Get-Date) -lt $deadline) {
    $states = Get-ServiceStates
    $by = @{}
    foreach ($s in $states) { $by[[string]$s.Service] = $s }
    $ok = $true
    foreach ($name in @('db', 'backend', 'web')) {
      if (-not $by.ContainsKey($name) -or [string]$by[$name].Health -ne 'healthy') { $ok = $false }
    }
    if ($by.ContainsKey('migrate')) {
      $m = $by['migrate']
      if ([string]$m.State -ne 'exited' -or [int]$m.ExitCode -ne 0) { $ok = $false }
    } else { $ok = $false }
    $last = ($states | ForEach-Object { "$($_.Service)=$($_.State)/$($_.Health)" }) -join ' '
    if ($ok) { return [pscustomobject]@{ Ok = $true; Detail = $last } }
    Start-Sleep -Seconds 4
  }
  return [pscustomobject]@{ Ok = $false; Detail = "timed out after $seconds s: $last" }
}

function Check([string]$id, [string]$title, [scriptblock]$body) {
  if ($script:Failed -and $script:StopOnFailure) { return }
  try {
    $detail = & $body
    if ($detail -is [array]) { $detail = ($detail -join ' ') }
    Add-Result $id $title $true ([string]$detail)
  } catch {
    Add-Result $id $title $false $_.Exception.Message
  }
}
function Assert([bool]$cond, [string]$message) { if (-not $cond) { throw $message } }

function Write-Report {
  $lines = New-Object System.Collections.ArrayList
  [void]$lines.Add("Dental Center - Docker verification report")
  [void]$lines.Add("Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')   Project: $Project   Port: $Port")
  $dv = Run-Native @('docker', 'version', '--format', 'client {{.Client.Version}} / server {{.Server.Version}}')
  [void]$lines.Add("Docker: $($dv.Text.Trim())")
  $cv = Run-Native @('docker', 'compose', 'version', '--short')
  [void]$lines.Add("Compose: $($cv.Text.Trim())")
  [void]$lines.Add('')
  foreach ($r in $script:Results) {
    $l = "{0}  {1}  {2}" -f $r.Status, $r.Id, $r.Title
    if ($r.Detail) { $l += "  [$($r.Detail)]" }
    [void]$lines.Add($l)
  }
  if ($script:Failed) { [void]$lines.Add('NOTE  Checks after the first failure are not run, because they depend on it.') }
  foreach ($n in $script:Notes) { [void]$lines.Add("NOTE  $n") }
  $failed = @($script:Results | Where-Object { $_.Status -eq 'FAIL' }).Count
  [void]$lines.Add('')
  if ($failed -eq 0 -and $script:Results.Count -gt 0) { [void]$lines.Add('RESULT: ALL CHECKS PASSED') } else { [void]$lines.Add("RESULT: $failed CHECK(S) FAILED") }
  [System.IO.File]::WriteAllText($ReportFile, (($lines -join "`r`n") + "`r`n"), (New-Object System.Text.UTF8Encoding($false)))
  Say "Report written: $ReportFile"
}

$script:StopOnFailure = $true
$stackCreated = $false
$exitCode = 1
try {
  Say "== Dental Center Docker verification (isolated copy: project '$Project', port $Port) =="

  # ---- preflight -----------------------------------------------------------------------------------------------------
  Check 'PRE-01' 'Docker is installed and its engine is running' {
    Assert ($null -ne (Get-Command docker -ErrorAction SilentlyContinue)) 'The docker command was not found. Install Docker Desktop.'
    $i = Run-Native @('docker', 'info', '--format', '{{.ServerVersion}}')
    Assert ($i.Code -eq 0) 'Docker is installed but not running. Start Docker Desktop, wait until it says it is running, then run this script again.'
    $c = Run-Native @('docker', 'compose', 'version', '--short')
    Assert ($c.Code -eq 0) 'Docker Compose v2 is required (docker compose version failed).'
    "engine $($i.Text.Trim()), compose $($c.Text.Trim())"
  }
  Check 'PRE-02' "Nothing from an earlier verification is left over (volume, containers) and port $Port is free" {
    $v = Run-Native @('docker', 'volume', 'inspect', $Volume)
    Assert ($v.Code -ne 0) "The volume '$Volume' already exists (an earlier verification was interrupted or used -KeepStack). Check that it is yours, remove it with: docker volume rm $Volume   then run again."
    $c = Run-Native @('docker', 'ps', '-a', '--filter', "label=com.docker.compose.project=$Project", '--format', '{{.Names}}')
    Assert ([string]::IsNullOrWhiteSpace($c.Text)) "Containers of project '$Project' exist: $($c.Text.Trim()). Remove them with: docker compose -p $Project down"
    $listener = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue
    Assert ($null -eq $listener) "Port $Port is already in use. Choose another with -Port."
    'ok'
  }
  if ($script:Failed) { throw 'Preflight failed' }

  # ---- throw-away settings (random secrets, never printed, deleted at the end) --------------------------------------------
  $dbPassword   = New-Secret 24
  $integKey     = New-Secret 24
  $adminUser    = 'verify_admin'
  $adminInitial = 'Verify-' + (New-Secret 6) + '-Initial1'
  $adminNew     = 'Verify-' + (New-Secret 6) + '-Changed2'
  $envLines = @(
    "POSTGRES_DB=$DbName", "POSTGRES_USER=$DbUser", "POSTGRES_PASSWORD=$dbPassword",
    "PUBLIC_APP_URL=$Base", 'ALLOWED_ORIGINS=', 'COOKIE_SECURE=false', "WEB_PORT=$Port", 'WEB_BIND=127.0.0.1',
    'CENTER_TIMEZONE=Africa/Cairo', 'LOG_LEVEL=info', "INTEGRATION_API_KEY=$integKey", 'INTEGRATION_API_KEY_NEXT=',
    "ADMIN_BOOTSTRAP_USERNAME=$adminUser", "ADMIN_BOOTSTRAP_PASSWORD=$adminInitial", 'SEED_SAMPLE_CATALOG=true',
    "DB_VOLUME_NAME=$Volume", "NETWORK_NAME=$Network", "BACKEND_IMAGE=$BackendImage", "WEB_IMAGE=$WebImage"
  )
  [System.IO.File]::WriteAllText((Join-Path $Root $EnvFile), (($envLines -join "`n") + "`n"), (New-Object System.Text.UTF8Encoding($false)))
  $stackCreated = $true
  $env:DC_COMPOSE_ARGS = "-p $Project --env-file $EnvFile"   # makes scripts\backup.ps1 and restore.ps1 act on THIS copy only

  # ---- DOCK-01 / 02 / 03 --------------------------------------------------------------------------------------------------
  Check 'DOCK-01' 'Build the Docker images (backend and web)' {
    $code = Stream-Native (DcArgs @('build'))
    Assert ($code -eq 0) "docker compose build failed (exit code $code). Read the messages above."
    'built'
  }
  Check 'DOCK-02' 'Start the stack' {
    $code = Stream-Native (DcArgs @('up', '-d'))
    Assert ($code -eq 0) "docker compose up failed (exit code $code)."
    'started'
  }
  Check 'DOCK-03' 'Services become healthy (db, backend, web) and the migration job finishes successfully' {
    $w = Wait-Healthy $HealthTimeoutSeconds
    if (-not $w.Ok) {
      $logs = Dc @('logs', '--tail', '40', 'backend', 'migrate', 'web')
      [void]$script:Notes.Add("Last log lines (no secrets are logged):`n$($logs.Text)")
    }
    Assert $w.Ok $w.Detail
    $w.Detail
  }

  # ---- DOCK-04 / 05 / 06 --------------------------------------------------------------------------------------------------
  $migrationFiles = @(Get-ChildItem (Join-Path $Root 'database\migrations') -Filter '*.sql').Count
  Check 'DOCK-04' 'Database initialised: all migrations applied, exactly the seven departments, each with working days' {
    $m = [int](Psql 'select count(*) from schema_migrations')
    Assert ($m -eq $migrationFiles) "schema_migrations has $m rows, expected $migrationFiles"
    $found = (@((Psql 'select slug from departments') -split "`n") | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object) -join ','
    $expected = (@('restorative-dentistry', 'endodontics', 'orthodontics', 'periodontics', 'pediatric-dentistry', 'prosthodontics', 'oral-surgery') | Sort-Object) -join ','
    Assert ($found -eq $expected) "departments are: $found"
    $wd = [int](Psql 'select count(*) from departments where cardinality(working_days) between 1 and 7')
    Assert ($wd -eq 7) "working_days missing on some departments ($wd of 7)"
    $slots = [int](Psql 'select count(*) from slot_templates')
    Assert ($slots -eq 4) "slot_templates has $slots rows"
    "$m migrations, 7 departments, 4 slots"
  }
  Check 'DOCK-05' 'Backend is ready (checked through the web container)' {
    $h = Api 'GET' '/api/health' $null $null '' $null
    Assert ($h.Status -eq 200) "/api/health answered $($h.Status)"
    $r = Api 'GET' '/api/ready' $null $null '' $null
    Assert ($r.Status -eq 200) "/api/ready answered $($r.Status) $($r.Text)"
    'health and ready are 200'
  }
  Check 'DOCK-06' 'Website, dashboard and API are served on the one public address' {
    $page = Api 'GET' '/' $null $null '' $null
    Assert ($page.Status -eq 200 -and $page.Text -match 'id="root"') "/ answered $($page.Status)"
    $adm = Api 'GET' '/admin/' $null $null '' $null
    Assert ($adm.Status -eq 200 -and $adm.Text -match 'id="root"') "/admin/ answered $($adm.Status)"
    $deep = Api 'GET' '/admin/appointments' $null $null '' $null
    Assert ($deep.Status -eq 200) "a deep link in the dashboard answered $($deep.Status)"
    $hz = Api 'GET' '/healthz' $null $null '' $null
    Assert ($hz.Status -eq 200) "/healthz answered $($hz.Status)"
    Assert ($page.Headers.ContainsKey('Content-Security-Policy')) 'no Content-Security-Policy header'
    foreach ($loc in @('ar', 'en', 'fr')) {
      $d = Api 'GET' "/api/v1/public/departments?locale=$loc" $null $null '' $null
      Assert ($d.Status -eq 200 -and @($d.Json.data).Count -eq 7) "departments ($loc) answered $($d.Status)"
    }
    $missing = Api 'GET' '/static/does-not-exist.js' $null $null '' $null
    Assert ($missing.Status -eq 404) "a missing file answered $($missing.Status), expected 404"
    'site, dashboard, deep link, healthz, CSP, 7 departments in ar/en/fr'
  }

  # ---- administrator bootstrap + the API smoke test ------------------------------------------------------------------------
  Check 'DOCK-07a' 'Create the first administrator (bootstrap-admin tool)' {
    $b = Dc @('run', '--rm', 'bootstrap-admin')
    Assert ($b.Code -eq 0) "bootstrap-admin failed: $($b.Text)"
    Assert ($b.Text -match 'created') "unexpected output: $($b.Text)"
    $again = Dc @('run', '--rm', 'bootstrap-admin')
    Assert ($again.Code -eq 0 -and $again.Text -match 'already exists') 'running it a second time must change nothing'
    'created once; a second run changes nothing'
  }
  Check 'DOCK-07b' 'API smoke test (scripts\smoke-api.mjs) inside the stack network' {
    $env:SMOKE_INTEGRATION_KEY = $integKey
    try {
      $scripts = Join-Path $Root 'scripts'
      $r = Run-Native @('docker', 'run', '--rm', '--network', $Network, '-e', 'SMOKE_INTEGRATION_KEY', '-v', "${scripts}:/scripts:ro", '--entrypoint', 'node', $BackendImage, '/scripts/smoke-api.mjs', 'http://web:8080')
    } finally { Remove-Item Env:\SMOKE_INTEGRATION_KEY -ErrorAction SilentlyContinue }
    if ($r.Code -ne 0) { [void]$script:Notes.Add("smoke-api output:`n$($r.Text)") }
    Assert ($r.Code -eq 0) 'smoke-api.mjs reported failures (see the note in the report)'
    $passed = @($r.Out | Where-Object { $_ -like 'PASS*' }).Count
    "$passed smoke checks passed"
  }

  # ---- DOCK-07 / 08 / 09: a real booking that stays -------------------------------------------------------------------------
  $patientPhone = '010' + (Get-Random -Minimum 10000000 -Maximum 99999999)
  $patientPass  = 'Verify-Patient-' + (New-Secret 4)
  $patientName  = 'ZZ Verify Patient'
  $apptId = ''; $apptDate = ''; $apptSlot = 0
  $patient = New-Session
  $patientCsrf = ''
  Check 'DOCK-07' 'A real booking through the API (register, choose an open day, book)' {
    $reg = Api 'POST' '/api/v1/patient/auth/register' $patient @{ fullName = $patientName; phone = $patientPhone; password = $patientPass } '' $null
    Assert ($reg.Status -eq 201) "register answered $($reg.Status) $($reg.Text)"
    $script:patientCsrf = [string]$reg.Json.data.csrfToken
    $deps = Api 'GET' '/api/v1/public/departments?locale=en' $null $null '' $null
    $dept = @($deps.Json.data) | Where-Object { $_.slug -eq 'endodontics' } | Select-Object -First 1
    Assert ($null -ne $dept) 'department endodontics not found'
    $from = (Get-Date).AddDays(3).ToString('yyyy-MM-dd'); $to = (Get-Date).AddDays(30).ToString('yyyy-MM-dd')
    $av = Api 'GET' "/api/v1/public/departments/endodontics/availability?from=$from&to=$to" $null $null '' $null
    Assert ($av.Status -eq 200) "availability answered $($av.Status)"
    $open = @($av.Json.data.days) | Where-Object { $_.status -eq 'open' -and @($_.slots).Count -gt 0 } | Select-Object -First 1
    Assert ($null -ne $open) 'no open day in the next month (check the working days)'
    $slot = [int]@($open.slots)[0].slotNumber
    $book = Api 'POST' '/api/v1/patient/appointments' $patient @{ departmentId = $dept.id; date = $open.date; slotNumber = $slot } $script:patientCsrf $null
    Assert ($book.Status -eq 201) "booking answered $($book.Status) $($book.Text)"
    Assert ($book.Json.data.status -eq 'booked') "status is $($book.Json.data.status)"
    $script:apptId = [string]$book.Json.data.id; $script:apptDate = [string]$open.date; $script:apptSlot = $slot
    "booked $($open.date) slot $slot"
  }
  Check 'DOCK-08' 'The booking is stored in PostgreSQL' {
    Assert ([bool]$script:apptId) 'no booking was made'
    $row = Psql "select status || '|' || appointment_date || '|' || slot_number || '|' || (extract(epoch from (ends_at - starts_at)) / 3600)::int from appointments where id = '$($script:apptId)'"
    Assert ($row -eq "booked|$($script:apptDate)|$($script:apptSlot)|2") "row is: $row"
    $row
  }
  $adminSession = New-Session
  $adminCsrf = ''
  Check 'DOCK-09' 'The same booking is visible to the patient and to the administrator' {
    $mine = Api 'GET' '/api/v1/patient/appointments?scope=upcoming' $patient $null '' $null
    Assert ($mine.Status -eq 200 -and (@($mine.Json.data) | Where-Object { $_.id -eq $script:apptId })) 'the patient does not see the booking'
    $login = Api 'POST' '/api/v1/admin/auth/login' $adminSession @{ username = $adminUser; password = $adminInitial } '' $null
    Assert ($login.Status -eq 200 -and $login.Json.data.admin.mustChangePassword -eq $true) "admin login answered $($login.Status)"
    $blocked = Api 'GET' '/api/v1/admin/appointments' $adminSession $null '' $null
    Assert ($blocked.Status -eq 403) "before the password change the dashboard API answered $($blocked.Status), expected 403"
    $ch = Api 'POST' '/api/v1/admin/auth/change-password' $adminSession @{ currentPassword = $adminInitial; newPassword = $adminNew } ([string]$login.Json.data.csrfToken) $null
    Assert ($ch.Status -eq 204) "change-password answered $($ch.Status) $($ch.Text)"
    $login2 = Api 'POST' '/api/v1/admin/auth/login' $adminSession @{ username = $adminUser; password = $adminNew } '' $null
    Assert ($login2.Status -eq 200 -and $login2.Json.data.admin.mustChangePassword -eq $false) "second admin login answered $($login2.Status)"
    $script:adminCsrf = [string]$login2.Json.data.csrfToken
    $one = Api 'GET' "/api/v1/admin/appointments/$($script:apptId)" $adminSession $null '' $null
    Assert ($one.Status -eq 200 -and $one.Json.data.patient.fullName -eq $patientName) "admin read answered $($one.Status)"
    $list = Api 'GET' "/api/v1/admin/appointments?from=$($script:apptDate)&to=$($script:apptDate)&q=ZZ%20Verify" $adminSession $null '' $null
    Assert ($list.Status -eq 200 -and (@($list.Json.data) | Where-Object { $_.id -eq $script:apptId })) 'the booking is not in the administrator list'
    $noPatientAccess = Api 'GET' "/api/v1/admin/appointments/$($script:apptId)" $patient $null '' $null
    Assert ($noPatientAccess.Status -eq 401 -or $noPatientAccess.Status -eq 403) "a patient session reached the admin API ($($noPatientAccess.Status))"
    'visible to the patient and the administrator; forced password change worked; patient cannot use admin routes'
  }

  # ---- DOCK-10: stop and start again, nothing lost -------------------------------------------------------------------------
  Check 'DOCK-10' 'Stop and start the stack again (volume kept): booking, patient and administrator password persist' {
    $code = Stream-Native (DcArgs @('down'))
    Assert ($code -eq 0) "docker compose down failed ($code)"
    $v = Run-Native @('docker', 'volume', 'inspect', $Volume)
    Assert ($v.Code -eq 0) 'the data volume disappeared after "down"'
    $code = Stream-Native (DcArgs @('up', '-d'))
    Assert ($code -eq 0) "docker compose up failed ($code)"
    $w = Wait-Healthy $HealthTimeoutSeconds
    Assert $w.Ok $w.Detail
    $row = Psql "select status from appointments where id = '$($script:apptId)'"
    Assert ($row -eq 'booked') "the booking is '$row' after the restart"
    $again = New-Session
    $pl = Api 'POST' '/api/v1/patient/auth/login' $again @{ phone = $patientPhone; password = $patientPass } '' $null
    Assert ($pl.Status -eq 200) "the patient cannot sign in after the restart ($($pl.Status))"
    $al = Api 'POST' '/api/v1/admin/auth/login' (New-Session) @{ username = $adminUser; password = $adminNew } '' $null
    Assert ($al.Status -eq 200 -and $al.Json.data.admin.mustChangePassword -eq $false) "the administrator cannot sign in after the restart ($($al.Status))"
    $departments = [int](Psql 'select count(*) from departments')
    Assert ($departments -eq 7) "departments: $departments (the seed must not have duplicated or removed any)"
    'booking, patient account and administrator password survived a full stop/start'
  }

  # ---- DOCK-11: backup and restore on the throw-away copy only -------------------------------------------------------------
  Check 'DOCK-11a' 'Backup (scripts\backup.ps1) of the throw-away database' {
    Assert ($env:DC_COMPOSE_ARGS -eq "-p $Project --env-file $EnvFile") 'safety: the backup script is not pointed at the verification copy'
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Root 'scripts\backup.ps1') -BackupDir $BackupFolder -Keep 0 2>&1 | ForEach-Object { Write-Host "$_" }
    Assert ($LASTEXITCODE -eq 0) "backup.ps1 exit code $LASTEXITCODE"
    $files = @(Get-ChildItem (Join-Path $Root $BackupFolder) -Filter '*.dump')
    Assert ($files.Count -eq 1) "expected one backup file, found $($files.Count)"
    Assert (Test-Path "$($files[0].FullName).sha256") 'no checksum file'
    $script:BackupPath = $files[0].FullName
    "$($files[0].Name) ($($files[0].Length) bytes)"
  }
  Check 'DOCK-11b' 'Restore check into an isolated scratch database (live data untouched)' {
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Root 'scripts\restore.ps1') $script:BackupPath 2>&1 | ForEach-Object { "$_" }
    $out | ForEach-Object { Write-Host $_ }
    Assert ($LASTEXITCODE -eq 0) "restore.ps1 exit code $LASTEXITCODE"
    Assert (($out -join "`n") -match 'RESTORE CHECK PASSED') 'the script did not report RESTORE CHECK PASSED'
    $scratch = Psql "select count(*) from pg_database where datname like '%_restore_check'"
    Assert ([int]$scratch -eq 0) 'the scratch database was not removed'
    'restore check passed; scratch database removed'
  }
  Check 'DOCK-11c' 'Live restore on the throw-away copy brings an earlier state back' {
    # Safety: prove that the database container really uses the verification volume before replacing anything.
    $cid = (Dc @('ps', '-q', 'db')).Text.Trim()
    Assert ([bool]$cid) 'db container not found'
    $mounts = Run-Native @('docker', 'inspect', '-f', '{{range .Mounts}}{{.Name}} {{end}}', $cid)
    Assert ($mounts.Text -match [regex]::Escape($Volume)) "safety: the db container does not use '$Volume' ($($mounts.Text.Trim())); live restore refused"
    # change the data: the patient cancels the booking (more than 24 h ahead)
    $can = Api 'POST' "/api/v1/patient/appointments/$($script:apptId)/cancel" $patient @{} $script:patientCsrf $null
    Assert ($can.Status -eq 200) "cancel answered $($can.Status) $($can.Text)"
    Assert ((Psql "select status from appointments where id = '$($script:apptId)'") -eq 'cancelled') 'the change did not happen'
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Root 'scripts\restore.ps1') $script:BackupPath -Live -ConfirmDatabase $DbName 2>&1 | ForEach-Object { Write-Host "$_" }
    Assert ($LASTEXITCODE -eq 0) "restore.ps1 -Live exit code $LASTEXITCODE"
    $w = Wait-Healthy $HealthTimeoutSeconds
    Assert $w.Ok $w.Detail
    Assert ((Psql "select status from appointments where id = '$($script:apptId)'") -eq 'booked') 'after the live restore the booking is not back to its backed-up state'
    $pre = @(Get-ChildItem (Join-Path $Root $BackupFolder) -Filter 'pre-restore-*.dump')
    Assert ($pre.Count -ge 1) 'no pre-restore backup was made'
    $site = Api 'GET' '/api/ready' $null $null '' $null
    Assert ($site.Status -eq 200) "the application is not ready after the restore ($($site.Status))"
    'the cancelled booking is booked again; a pre-restore backup exists; the application is ready'
  }

  # ---- DOCK-12: stop without deleting the data ------------------------------------------------------------------------------
  Check 'DOCK-12' 'Stop the stack without deleting the persistent data volume' {
    $code = Stream-Native (DcArgs @('down'))
    Assert ($code -eq 0) "docker compose down failed ($code)"
    $v = Run-Native @('docker', 'volume', 'inspect', $Volume)
    Assert ($v.Code -eq 0) 'the data volume is gone after "down" (it must be kept)'
    'stopped; the volume still exists'
  }
}
catch {
  if ($script:Results.Count -eq 0 -or -not $script:Failed) { Add-Result 'ERROR' 'The verification could not continue' $false $_.Exception.Message }
  elseif ($_.Exception.Message -ne 'Preflight failed') { [void]$script:Notes.Add("Stopped: $($_.Exception.Message)") }
}
finally {
  # ---- clean-up: ONLY the verification copy's own names ------------------------------------------------------------------
  Remove-Item Env:\DC_COMPOSE_ARGS -ErrorAction SilentlyContinue
  if ($stackCreated) {
    if ($script:Failed) {
      $logs = Dc @('logs', '--tail', '30', 'backend', 'web', 'migrate')
      if ($logs.Text) { [void]$script:Notes.Add("Last log lines before clean-up:`n$($logs.Text)") }
    }
    if (-not $KeepStack) {
      [void](Dc @('down', '--remove-orphans'))
      [void](Run-Native @('docker', 'volume', 'rm', $Volume))
      [void](Run-Native @('docker', 'image', 'rm', $BackendImage, $WebImage))
      Remove-Item (Join-Path $Root $EnvFile) -Force -ErrorAction SilentlyContinue
      Remove-Item (Join-Path $Root $BackupFolder) -Recurse -Force -ErrorAction SilentlyContinue
      [void]$script:Notes.Add("Clean-up done: removed project '$Project', volume '$Volume', its images and the temporary files. Your real installation was never touched.")
    } else {
      [void]$script:Notes.Add("-KeepStack: kept volume '$Volume', images, $EnvFile and $BackupFolder for inspection. Remove them with: docker compose -p $Project --env-file $EnvFile down ; docker volume rm $Volume ; then delete $EnvFile and $BackupFolder.")
    }
  }
  try { Write-Report } catch { Write-Host "Could not write the report: $($_.Exception.Message)" -ForegroundColor Yellow }
  $failedCount = @($script:Results | Where-Object { $_.Status -eq 'FAIL' }).Count
  if ($failedCount -eq 0 -and $script:Results.Count -gt 0) { Write-Host ''; Write-Host 'ALL CHECKS PASSED' -ForegroundColor Green; $exitCode = 0 }
  else { Write-Host ''; Write-Host "$failedCount CHECK(S) FAILED: send the report file (only throw-away test data, no secrets) to get help." -ForegroundColor Red }
}
exit $exitCode
