<#
.SYNOPSIS
  Restores a backup made by scripts\backup.ps1.

.DESCRIPTION
  Default = SAFE CHECK: restores into a temporary scratch database, prints table row counts (backup vs. live) and drops the
  scratch database. The live database is NOT touched.

  -Live = REPLACES the live database with the backup. You must type the database name to confirm. Before replacing anything it
  takes a "pre-restore" backup of the current data, stops the application, restores, applies newer migrations and starts the
  application again. If anything fails the application stays stopped and the pre-restore backup path is printed for rollback.

.EXAMPLE
  .\scripts\restore.ps1 .\backups\dental-center-20261101-020000.dump
.EXAMPLE
  .\scripts\restore.ps1 .\backups\dental-center-20261101-020000.dump -Live
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true, Position = 0)][string]$BackupFile,
  [switch]$Live,
  [switch]$KeepScratch,
  [string]$ConfirmDatabase = '',   # for automation only: must equal the database name
  [string]$BackupDir = 'backups'
)
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)

$ComposeExtra = @()
if ($env:DC_COMPOSE_ARGS) { $ComposeExtra = @($env:DC_COMPOSE_ARGS -split '\s+' | Where-Object { $_ }) }
function Invoke-Compose {
  & docker compose @ComposeExtra @args
  if ($LASTEXITCODE -ne 0) { throw "docker compose $($args -join ' ') failed (exit code $LASTEXITCODE)" }
}
function Stop-WithError([string]$message) { Write-Host "ERROR: $message" -ForegroundColor Red; exit 1 }

if (-not (Test-Path -LiteralPath $BackupFile -PathType Leaf)) { Stop-WithError "file not found: $BackupFile" }
$BackupFile = (Resolve-Path -LiteralPath $BackupFile).Path
$running = & docker compose @ComposeExtra ps --status running --services
if ($running -notcontains 'db') { Stop-WithError 'the database container is not running (start it with: docker compose up -d db)' }

$Db   = ((& docker compose @ComposeExtra exec -T db printenv POSTGRES_DB)   | Select-Object -First 1).ToString().Trim()
$User = ((& docker compose @ComposeExtra exec -T db printenv POSTGRES_USER) | Select-Object -First 1).ToString().Trim()
if ($Db -notmatch '^[a-z0-9_]+$' -or $User -notmatch '^[a-z0-9_]+$') { Stop-WithError 'unexpected database/user name (only a-z, 0-9 and _ are supported by this script)' }

# optional checksum
$sumFile = "$BackupFile.sha256"
if (Test-Path -LiteralPath $sumFile) {
  $expected = ((Get-Content -LiteralPath $sumFile -TotalCount 1) -split '\s+')[0].ToLower()
  $actual   = (Get-FileHash -Algorithm SHA256 -LiteralPath $BackupFile).Hash.ToLower()
  if ($expected -ne $actual) { Stop-WithError 'checksum mismatch: the backup file is damaged' }
  Write-Host 'Checksum OK.'
}

$inside = "/tmp/dc-restore-$PID.dump"
$CountSql = (@'
SELECT c.relname || E'\t' || (xpath('/row/c/text()', query_to_xml(format('select count(*) as c from %I.%I', n.nspname, c.relname), false, true, '')))[1]::text
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind = 'r' AND n.nspname = 'public' ORDER BY 1
'@) -replace '\r?\n', ' '

function Get-Counts([string]$database) {
  $lines = & docker compose @ComposeExtra exec -T db psql -At -U $User -d $database -c $CountSql
  if ($LASTEXITCODE -ne 0) { throw "could not read table counts from $database" }
  $map = [ordered]@{}
  foreach ($l in $lines) { $p = ([string]$l).Trim() -split "`t"; if ($p.Count -eq 2) { $map[$p[0]] = $p[1] } }
  return $map
}
function Invoke-Admin { & docker compose @ComposeExtra exec -T db psql -v ON_ERROR_STOP=1 -q -U $User -d postgres @args; if ($LASTEXITCODE -ne 0) { throw "psql failed (exit code $LASTEXITCODE)" } }

try {
  Invoke-Compose cp $BackupFile "db:$inside"
  & docker compose @ComposeExtra exec -T db pg_restore --list $inside | Out-Null
  if ($LASTEXITCODE -ne 0) { Stop-WithError 'this file is not a readable backup (pg_restore --list failed); nothing was changed' }

  if (-not $Live) {
    $scratch = "${Db}_restore_check"
    Write-Host "Safe check: restoring into temporary database '$scratch' (live database '$Db' is not touched) ..."
    Invoke-Admin -c "DROP DATABASE IF EXISTS $scratch" -c "CREATE DATABASE $scratch"
    & docker compose @ComposeExtra exec -T db pg_restore --no-owner --no-privileges --exit-on-error -U $User -d $scratch $inside
    if ($LASTEXITCODE -ne 0) {
      Invoke-Admin -c "DROP DATABASE IF EXISTS $scratch"
      Stop-WithError 'the restore into the scratch database FAILED: do not rely on this backup'
    }
    $inBackup = Get-Counts $scratch
    $liveNow  = Get-Counts $Db
    $migrations = ((& docker compose @ComposeExtra exec -T db psql -At -U $User -d $scratch -c 'SELECT count(*) FROM schema_migrations') | Select-Object -First 1).ToString().Trim()
    Write-Host ''
    Write-Host ('{0,-28} {1,12} {2,12}' -f 'table', 'in backup', 'live now')
    foreach ($t in $liveNow.Keys) { Write-Host ('{0,-28} {1,12} {2,12}' -f $t, $inBackup[$t], $liveNow[$t]) }
    if (-not $KeepScratch) { Invoke-Admin -c "DROP DATABASE IF EXISTS $scratch" }
    if ([int]$migrations -le 0) { Stop-WithError 'the restored database has no migration history: the backup looks empty or foreign' }
    Write-Host ''
    Write-Host "RESTORE CHECK PASSED: the backup restored completely ($migrations migrations recorded). Live data was not modified." -ForegroundColor Green
    if ($KeepScratch) { Write-Host "Scratch database '$scratch' was kept (drop it with: docker compose exec db psql -U $User -d postgres -c `"DROP DATABASE $scratch`")." }
    exit 0
  }

  # ------------------------------------------------------------ live restore
  Write-Host '!!! LIVE RESTORE !!!' -ForegroundColor Yellow
  Write-Host "This will REPLACE ALL CURRENT DATA in database '$Db' with the contents of: $BackupFile"
  Write-Host 'Anything entered after that backup was made (bookings, patients, records) will be gone from the live database.'
  $typed = $ConfirmDatabase
  if (-not $typed) { $typed = Read-Host "To continue, type the database name ($Db)" }
  if ($typed -ne $Db) { Stop-WithError 'confirmation did not match; nothing was changed' }

  Write-Host 'Step 1/5: backing up the CURRENT data first (pre-restore) ...'
  try { & (Join-Path $PSScriptRoot 'backup.ps1') -BackupDir $BackupDir -Keep 0 -Prefix 'pre-restore' }
  catch { Stop-WithError "could not take the safety backup; nothing was changed ($($_.Exception.Message))" }
  $preFile = Get-ChildItem -LiteralPath $BackupDir -Filter 'pre-restore-*.dump' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  $pre = if ($preFile) { $preFile.FullName } else { '<see the backups folder>' }

  Write-Host 'Step 2/5: stopping the application ...'
  & docker compose @ComposeExtra stop backend 2>$null | Out-Null
  & docker compose @ComposeExtra stop web 2>$null | Out-Null

  function Stop-Failed([string]$message) {
    Write-Host "ERROR: $message" -ForegroundColor Red
    Write-Host "The application was left STOPPED. Your previous data is in: $pre"
    Write-Host "To roll back: .\scripts\restore.ps1 `"$pre`" -Live"
    exit 1
  }

  Write-Host 'Step 3/5: replacing the database ...'
  try {
    Invoke-Admin -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$Db' AND pid <> pg_backend_pid()" -c "DROP DATABASE IF EXISTS $Db" -c "CREATE DATABASE $Db OWNER $User" | Out-Null
  } catch { Stop-Failed "could not recreate the database ($($_.Exception.Message))" }
  & docker compose @ComposeExtra exec -T db pg_restore --no-owner --no-privileges --exit-on-error -U $User -d $Db $inside
  if ($LASTEXITCODE -ne 0) { Stop-Failed 'pg_restore failed' }

  Write-Host 'Step 4/5: applying any newer migrations ...'
  & docker compose @ComposeExtra run --rm migrate
  if ($LASTEXITCODE -ne 0) { Stop-Failed 'migrations failed after the restore' }

  Write-Host 'Step 5/5: starting the application ...'
  & docker compose @ComposeExtra up -d backend | Out-Null
  if ($LASTEXITCODE -ne 0) { Stop-Failed 'could not start the backend' }
  & docker compose @ComposeExtra up -d web 2>$null | Out-Null

  Write-Host ''
  $after = Get-Counts $Db
  foreach ($t in $after.Keys) { Write-Host ('{0,-28} {1,12}' -f $t, $after[$t]) }
  Write-Host ''
  Write-Host "LIVE RESTORE COMPLETE. Check the site, then keep the pre-restore backup until you are sure: $pre" -ForegroundColor Green
}
finally {
  & docker compose @ComposeExtra exec -T db rm -f $inside 2>$null | Out-Null
}
