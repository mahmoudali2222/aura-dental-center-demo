#!/usr/bin/env node
/**
 * End-to-end smoke test against a RUNNING deployment (no dependencies, Node 22+).
 *   node scripts/smoke-api.mjs http://localhost:8480
 * Optional: SMOKE_INTEGRATION_KEY=<key> also checks the n8n integration API.
 *
 * WARNING: it creates two test patients named "ZZ Smoke ..." (and cancels their appointment). Run it against a fresh or
 * throw-away environment, not against the live clinic database.
 */
const base = (process.argv[2] ?? 'http://localhost:8480').replace(/\/$/, '');
const integrationKey = process.env.SMOKE_INTEGRATION_KEY;
let failures = 0;
const ok = (name, cond, extra = '') => { if (!cond) failures++; console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : `  ${extra}`}`); return cond; };

class Client {
  cookies = new Map(); csrf = '';
  async call(method, url, body, headers = {}) {
    const h = { accept: 'application/json', ...headers };
    if (body !== undefined) h['content-type'] = 'application/json';
    if (this.cookies.size) h.cookie = [...this.cookies].map(([k, v]) => `${k}=${v}`).join('; ');
    if (this.csrf && method !== 'GET' && !('x-csrf-token' in h)) h['x-csrf-token'] = this.csrf;
    const res = await fetch(base + url, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body), redirect: 'manual' });
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); this.cookies.set(pair.slice(0, i), pair.slice(i + 1)); }
    const text = await res.text(); let json; try { json = text ? JSON.parse(text) : undefined; } catch { json = undefined; }
    return { status: res.status, json, headers: res.headers };
  }
}

const rnd = (n) => String(Math.floor(Math.random() * 10 ** n)).padStart(n, '0');
const phone = (suffix) => `010${rnd(8)}`.slice(0, 11) + (suffix ?? '');
const dateIn = (n) => new Date(Date.now() + n * 86400_000 + 3 * 3600_000).toISOString().slice(0, 10); // Cairo date, good enough for "days ahead"

try {
  const anon = new Client();
  let r = await anon.call('GET', '/api/health'); ok('GET /api/health is ok', r.status === 200 && r.json?.status === 'ok', JSON.stringify(r.json));
  r = await anon.call('GET', '/api/ready'); ok('GET /api/ready (database reachable and migrated)', r.status === 200, `${r.status} ${JSON.stringify(r.json)}`);
  r = await anon.call('GET', '/api/v1/public/center?locale=en');
  ok('center: Cairo time zone and four 2-hour slots', r.json?.data?.timezone === 'Africa/Cairo' && r.json?.data?.slots?.length === 4 && r.json.data.slots[0].startTime === '16:00' && r.json.data.slots[3].endTime === '00:00', JSON.stringify(r.json?.data?.slots));
  ok('security headers present once (not repeated by both nginx and the backend), no x-powered-by', r.headers.get('x-content-type-options') === 'nosniff' && r.headers.get('x-frame-options') === 'DENY' && !r.headers.has('strict-transport-security') && !r.headers.get('x-powered-by'), `x-content-type-options="${r.headers.get('x-content-type-options')}" x-frame-options="${r.headers.get('x-frame-options')}" hsts=${r.headers.has('strict-transport-security')}`);
  const SEVEN = ['restorative-dentistry', 'endodontics', 'orthodontics', 'periodontics', 'pediatric-dentistry', 'prosthodontics', 'oral-surgery'];
  for (const locale of ['ar', 'en', 'fr']) {
    r = await anon.call('GET', `/api/v1/public/departments?locale=${locale}`);
    ok(`departments in ${locale}: exactly the seven, all named, each with working days`, r.status === 200 && r.json.data.length === 7 && SEVEN.every((slug) => r.json.data.some((d) => d.slug === slug && d.name && Array.isArray(d.workingDays) && d.workingDays.length >= 1)), `${r.json?.data?.map((d) => d.slug)}`);
  }
  const depts = (await anon.call('GET', '/api/v1/public/departments?locale=en')).json.data;
  const dept = depts.find((d) => d.slug === 'endodontics' && d.bookable) ?? depts.find((d) => d.bookable) ?? depts[0];
  ok('every department has one dentist', depts.every((d) => d.dentist), `${depts.filter((d) => !d.dentist).map((d) => d.slug)}`);

  // Pick a day the API itself says is open (the administrator may have switched weekdays off), at least 3 days ahead so cancelling is allowed.
  const weekdayOf = (iso) => ((new Date(`${iso}T00:00:00Z`).getUTCDay() + 6) % 7) + 1;
  r = await anon.call('GET', `/api/v1/public/departments/${dept.slug}/availability?from=${dateIn(3)}&to=${dateIn(30)}`);
  const days = r.json?.data?.days ?? [];
  const openDay = days.find((d) => d.status === 'open' && d.slots.length > 0);
  ok('availability has at least one open day in the next month', !!openDay, JSON.stringify(days.slice(0, 3)));
  if (!openDay) throw new Error('no open day to book: check the working days and closed dates in the dashboard');
  const date = openDay.date; const slot = openDay.slots[Math.floor(Math.random() * openDay.slots.length)].slotNumber;
  ok('every day of a weekday the department does not work is reported closed, and every open day is a working day', days.every((d) => (dept.workingDays.includes(weekdayOf(d.date)) ? true : d.status === 'closed')) && days.filter((d) => d.status === 'open').every((d) => dept.workingDays.includes(weekdayOf(d.date))),
    JSON.stringify({ workingDays: dept.workingDays, days: days.map((d) => `${d.date}:${d.status}`) }));

  const p1 = new Client(); const ph1 = phone();
  r = await p1.call('POST', '/api/v1/patient/auth/register', { fullName: 'ZZ Smoke One', phone: ph1, password: 'Smoke-Test-Pass-1' });
  ok('register patient (phone + password only)', r.status === 201 && p1.cookies.has('dc_patient'), `${r.status} ${JSON.stringify(r.json)}`); p1.csrf = r.json?.data?.csrfToken ?? '';
  r = await p1.call('GET', '/api/v1/patient/me'); ok('session cookie works', r.status === 200 && r.json?.data?.patient?.phone?.startsWith('+20'), JSON.stringify(r.json));
  r = await p1.call('POST', '/api/v1/patient/appointments', { departmentId: dept.id, date, slotNumber: slot }, { 'x-csrf-token': 'wrong' });
  ok('state-changing request with a wrong CSRF token is refused', r.status === 403 && r.json?.error?.code === 'CSRF_INVALID', `${r.status}`);
  r = await p1.call('GET', `/api/v1/public/departments/${dept.slug}/availability?from=${date}&to=${date}`);
  ok('availability lists the slot', r.json?.data?.days?.[0]?.slots?.some((s) => s.slotNumber === slot), JSON.stringify(r.json?.data?.days?.[0]));
  r = await p1.call('POST', '/api/v1/patient/appointments', { departmentId: dept.id, date, slotNumber: slot });
  const appt = r.json?.data; ok('book an appointment', r.status === 201 && appt?.status === 'booked' && appt.date === date, `${r.status} ${JSON.stringify(r.json)}`);
  ok('appointment is exactly two hours in Cairo time', appt && (new Date(appt.endsAt) - new Date(appt.startsAt)) === 7200_000);

  const p2 = new Client();
  r = await p2.call('POST', '/api/v1/patient/auth/register', { fullName: 'ZZ Smoke Two', phone: phone(), password: 'Smoke-Test-Pass-2' }); p2.csrf = r.json?.data?.csrfToken ?? '';
  r = await p2.call('POST', '/api/v1/patient/appointments', { departmentId: dept.id, date, slotNumber: slot });
  ok('same slot for another patient is refused (SLOT_UNAVAILABLE)', r.status === 409 && r.json?.error?.code === 'SLOT_UNAVAILABLE', `${r.status} ${JSON.stringify(r.json)}`);
  r = await p2.call('POST', `/api/v1/patient/appointments/${appt?.id}/cancel`, {});
  ok("another patient cannot cancel it (404, not 403)", r.status === 404, `${r.status}`);
  r = await p1.call('POST', `/api/v1/patient/appointments/${appt?.id}/cancel`, {});
  ok('owner cancels it (>= 24 h ahead)', r.status === 200 && r.json?.data?.status === 'cancelled', `${r.status} ${JSON.stringify(r.json)}`);
  r = await p2.call('POST', '/api/v1/patient/appointments', { departmentId: dept.id, date, slotNumber: slot });
  ok('cancelled slot is released and bookable again', r.status === 201, `${r.status} ${JSON.stringify(r.json)}`);
  await p2.call('POST', `/api/v1/patient/appointments/${r.json?.data?.id}/cancel`, {});

  // A department that does not work every day must refuse a booking on a day off (skipped when it works every day).
  const dayOff = days.find((d) => !dept.workingDays.includes(weekdayOf(d.date)));
  if (dayOff) {
    r = await p2.call('POST', '/api/v1/patient/appointments', { departmentId: dept.id, date: dayOff.date, slotNumber: 1 });
    ok('booking on a day the department does not work is refused (DEPARTMENT_NOT_WORKING_DAY or DATE_CLOSED)', r.status === 422 && ['DEPARTMENT_NOT_WORKING_DAY', 'DATE_CLOSED'].includes(r.json?.error?.code), `${r.status} ${JSON.stringify(r.json)}`);
  } else console.log('SKIP  day-off refusal: this department works every day');

  r = await p1.call('POST', '/api/v1/patient/auth/logout', {}); ok('logout', r.status === 204 || r.status === 200, `${r.status}`);
  r = await p1.call('GET', '/api/v1/patient/me'); ok('session is dead after logout', r.status === 401, `${r.status}`);
  r = await anon.call('GET', '/api/v1/admin/patients'); ok('admin API is closed without a session', r.status === 401, `${r.status}`);
  r = await anon.call('POST', '/api/v1/patient/auth/forgot-password', {}); ok('there is no unauthenticated password-reset endpoint', r.status === 404, `${r.status}`);

  if (integrationKey) {
    r = await anon.call('GET', '/api/v1/integrations/center'); ok('integration API refuses requests without a key', r.status === 401, `${r.status}`);
    r = await anon.call('GET', '/api/v1/integrations/center?locale=en', undefined, { authorization: `Bearer ${integrationKey}` }); ok('integration API accepts the configured key', r.status === 200, `${r.status}`);
    r = await anon.call('GET', '/api/v1/integrations/telegram/999000111/appointments', undefined, { authorization: `Bearer ${integrationKey}` });
    ok('unlinked Telegram user gets TELEGRAM_NOT_LINKED', r.status === 403 && r.json?.error?.code === 'TELEGRAM_NOT_LINKED', `${r.status}`);
  } else {
    r = await anon.call('GET', '/api/v1/integrations/center'); ok('integration API is closed without a key (503 when the server has none configured, 401 when it has)', r.status === 503 || r.status === 401, `${r.status}`);
  }
} catch (err) {
  failures++; console.log(`FAIL  smoke test crashed: ${err?.cause?.code ?? ''} ${err?.message ?? err}`);
}
console.log(failures === 0 ? '\nSMOKE TEST PASSED' : `\nSMOKE TEST FAILED (${failures} problem(s))`);
process.exit(failures === 0 ? 0 : 1);
