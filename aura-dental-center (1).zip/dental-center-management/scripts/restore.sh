#!/usr/bin/env sh
# Restores a backup made by scripts/backup.sh.
#
#   scripts/restore.sh backups/dental-center-20261101-020000.dump
#       SAFE CHECK (default): restores into a temporary scratch database, prints table row counts
#       (backup vs. live) and drops the scratch database. The live database is NOT touched.
#
#   scripts/restore.sh backups/dental-center-20261101-020000.dump --live
#       REPLACES the live database with the backup. Needs you to type the database name to confirm
#       (or DC_CONFIRM=<name> for automation). Before replacing anything it takes a "pre-restore" backup of the current
#       data, stops the backend, restores, applies newer migrations, and starts the backend again.
#       If anything fails the backend stays stopped and the pre-restore backup path is printed for rollback.
set -eu
cd "$(dirname "$0")/.."

COMPOSE="${DC_COMPOSE:-docker compose}"
say() { printf '%s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

dump=""; live=0; keep=0
for a in "$@"; do
  case "$a" in
    --live) live=1 ;;
    --keep) keep=1 ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    -*) die "unknown option: $a" ;;
    *) [ -z "$dump" ] || die "only one backup file can be given"; dump="$a" ;;
  esac
done
[ -n "$dump" ] || die "usage: scripts/restore.sh <backup.dump> [--live] [--keep]"
[ -f "$dump" ] || die "file not found: $dump"
$COMPOSE ps --status running --services 2>/dev/null | grep -qx db || die "the database container is not running (start it with: docker compose up -d db)"

DB="$($COMPOSE exec -T db printenv POSTGRES_DB | tr -d '\r\n')"
USER_NAME="$($COMPOSE exec -T db printenv POSTGRES_USER | tr -d '\r\n')"
case "$DB$USER_NAME" in *[!a-z0-9_]*|'') die "unexpected database/user name (only a-z, 0-9 and _ are supported by this script)";; esac

# optional checksum
if [ -f "$dump.sha256" ]; then
  if command -v sha256sum >/dev/null 2>&1; then (cd "$(dirname "$dump")" && sha256sum -c "$(basename "$dump").sha256" >/dev/null) || die "checksum mismatch: the backup file is damaged"; say "Checksum OK."; fi
fi

inside="/tmp/dc-restore-$$.dump"
cleanup() { $COMPOSE exec -T db rm -f "$inside" >/dev/null 2>&1 || true; }
trap cleanup EXIT
$COMPOSE cp "$dump" "db:$inside" >/dev/null || die "could not copy the backup into the database container"
$COMPOSE exec -T db pg_restore --list "$inside" >/dev/null || die "this file is not a readable backup (pg_restore --list failed); nothing was changed"

psql_admin() { $COMPOSE exec -T db psql -v ON_ERROR_STOP=1 -q -U "$USER_NAME" -d postgres "$@"; }
COUNT_SQL="SELECT c.relname || E'\\t' || (xpath('/row/c/text()', query_to_xml(format('select count(*) as c from %I.%I', n.nspname, c.relname), false, true, '')))[1]::text FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind = 'r' AND n.nspname = 'public' ORDER BY 1"
counts() { $COMPOSE exec -T db psql -At -U "$USER_NAME" -d "$1" -c "$COUNT_SQL" | tr -d '\r'; }

if [ "$live" -eq 0 ]; then
  scratch="${DB}_restore_check"
  say "Safe check: restoring into temporary database '$scratch' (live database '$DB' is not touched) ..."
  psql_admin -c "DROP DATABASE IF EXISTS $scratch" -c "CREATE DATABASE $scratch"
  if ! $COMPOSE exec -T db pg_restore --no-owner --no-privileges --exit-on-error -U "$USER_NAME" -d "$scratch" "$inside"; then
    psql_admin -c "DROP DATABASE IF EXISTS $scratch" || true
    die "the restore into the scratch database FAILED: do not rely on this backup"
  fi
  a="$(mktemp)"; b="$(mktemp)"; counts "$scratch" > "$a"; counts "$DB" > "$b"
  migrations="$($COMPOSE exec -T db psql -At -U "$USER_NAME" -d "$scratch" -c 'SELECT count(*) FROM schema_migrations' | tr -d '\r\n')"
  say ""; printf '%-28s %12s %12s\n' "table" "in backup" "live now"
  awk -F'\t' 'NR==FNR{a[$1]=$2;next}{printf "%-28s %12s %12s\n",$1,a[$1],$2}' "$a" "$b"
  rm -f "$a" "$b"
  [ "$keep" -eq 1 ] || psql_admin -c "DROP DATABASE IF EXISTS $scratch"
  [ "${migrations:-0}" -gt 0 ] || die "the restored database has no migration history: the backup looks empty or foreign"
  say ""; say "RESTORE CHECK PASSED: the backup restored completely ($migrations migrations recorded). Live data was not modified."
  [ "$keep" -eq 0 ] || say "Scratch database '$scratch' was kept (drop it with: docker compose exec db psql -U $USER_NAME -d postgres -c 'DROP DATABASE $scratch')."
  exit 0
fi

# ---------------------------------------------------------------- live restore
say "!!! LIVE RESTORE !!!"
say "This will REPLACE ALL CURRENT DATA in database '$DB' with the contents of: $dump"
say "Anything entered after that backup was made (bookings, patients, records) will be gone from the live database."
if [ -n "${DC_CONFIRM:-}" ]; then typed="$DC_CONFIRM"; else printf "To continue, type the database name (%s): " "$DB"; read -r typed || typed=""; fi
[ "$typed" = "$DB" ] || die "confirmation did not match; nothing was changed"

say "Step 1/5: backing up the CURRENT data first (pre-restore) ..."
BACKUP_PREFIX=pre-restore KEEP=0 DC_COMPOSE="$COMPOSE" sh scripts/backup.sh || die "could not take the safety backup; nothing was changed"
pre="$(ls -1t "${BACKUP_DIR:-backups}"/pre-restore-*.dump 2>/dev/null | head -n 1)"

say "Step 2/5: stopping the application ..."
$COMPOSE stop backend >/dev/null 2>&1 || true
$COMPOSE stop web >/dev/null 2>&1 || true

say "Step 3/5: replacing the database ..."
fail() { printf 'ERROR: %s\n' "$1" >&2; say "The application was left STOPPED. Your previous data is in: ${pre:-<see backups folder>}"; say "To roll back: scripts/restore.sh ${pre:-<that file>} --live"; exit 1; }
psql_admin -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB' AND pid <> pg_backend_pid()" -c "DROP DATABASE IF EXISTS $DB" -c "CREATE DATABASE $DB OWNER $USER_NAME" >/dev/null || fail "could not recreate the database"
$COMPOSE exec -T db pg_restore --no-owner --no-privileges --exit-on-error -U "$USER_NAME" -d "$DB" "$inside" || fail "pg_restore failed"

say "Step 4/5: applying any newer migrations ..."
$COMPOSE run --rm migrate || fail "migrations failed after the restore"

say "Step 5/5: starting the application ..."
$COMPOSE up -d backend >/dev/null || fail "could not start the backend"
$COMPOSE up -d web >/dev/null 2>&1 || true
say ""; counts "$DB" | awk -F'\t' '{printf "%-28s %12s\n",$1,$2}'
say ""; say "LIVE RESTORE COMPLETE. Check the site, then keep the pre-restore backup until you are sure: ${pre:-}"
