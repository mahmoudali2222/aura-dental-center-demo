<#
.SYNOPSIS  Prints a random URL-safe secret (default 48 hex characters). Usage: .\scripts\new-secret.ps1 [-Bytes 24]
#>
param([int]$Bytes = 24)
$buf = New-Object byte[] $Bytes
[System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($buf)
($buf | ForEach-Object { $_.ToString('x2') }) -join ''
