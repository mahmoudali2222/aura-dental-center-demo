#!/usr/bin/env bash
# Runs the REAL web-container nginx configuration (frontend/nginx/*.conf) on this machine, in the foreground, against a
# backend that is already running here. Used by the browser tests (and handy for a manual check) where Docker is unavailable.
#
#   scripts/run-local-web.sh [web-port=8480] [backend-port=3480] [dist-dir=frontend/dist]
#
# Only four things differ from the container: the web root, the backend address, the listen port and the snippet folder.
# Everything else (locations, headers, caching, redirects, proxy settings) is the file that ships in the image.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
port="${1:-8480}"; backend="${2:-3480}"; dist="${3:-$here/frontend/dist}"
tmp="$(mktemp -d /tmp/dental-web.XXXXXX)"; chmod 755 "$tmp"
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/snippets"; cp "$here"/frontend/nginx/{security-headers,proxy-api,integrations-access,real-ip}.conf "$tmp/snippets/"
mkdir -p "$tmp/root"; cp -r "$dist"/. "$tmp/root/"; chmod -R a+rX "$tmp/root"
sed -e "s#/usr/share/nginx/html#$tmp/root#" -e "s#listen 8080#listen $port#" -e "s#/etc/nginx/snippets/#$tmp/snippets/#g" "$here/frontend/nginx/default.conf" > "$tmp/default.conf"
sed -i "s#http://backend:3480#http://127.0.0.1:$backend#" "$tmp/snippets/proxy-api.conf"
cat > "$tmp/nginx.conf" <<CONF
worker_processes 1; daemon off; pid $tmp/nginx.pid; error_log $tmp/error.log warn;
events { worker_connections 128; }
http {
  include /etc/nginx/mime.types; default_type application/octet-stream; access_log $tmp/access.log;
  client_body_temp_path $tmp/c; proxy_temp_path $tmp/p; fastcgi_temp_path $tmp/f; uwsgi_temp_path $tmp/u; scgi_temp_path $tmp/s;
  include $tmp/default.conf;
}
CONF
nginx -t -c "$tmp/nginx.conf" >&2
echo "web on http://127.0.0.1:$port  ->  backend 127.0.0.1:$backend  (config: frontend/nginx)" >&2
nginx -c "$tmp/nginx.conf" &
pid=$!
trap 'kill $pid 2>/dev/null; wait $pid 2>/dev/null; rm -rf "$tmp"' EXIT INT TERM
wait $pid
