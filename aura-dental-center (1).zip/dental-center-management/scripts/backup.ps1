<#
.SYNOPSIS
  Creates a verified backup of the clinic database (PostgreSQL custom format) in .\backups

.DESCRIPTION
  A backup is only reported as good after it was (1) written, (2) read back with pg_restore --list,
  (3) copied out of the container with an identical size, and (4) given a SHA-256 checksum file.
  Run it from anywhere; it moves to the project folder itself. The "db" container must be running.

.EXAMPLE
  .\scripts\backup.ps1                    # one backup, keeps the newest 14
.EXAMPLE
  .\scripts\backup.ps1 -Keep 30           # keep the newest 30 (0 = keep everything)
.EXAMPLE
  .\scripts\backup.ps1 -BackupDir D:\clinic-backups
#>
[CmdletBinding()]
param(
  [string]$BackupDir = 'backups',
  [int]$Keep = 14,
  [string]$Prefix = 'dental-center'
)
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)

# Optional extra arguments for docker compose (used by scripts\verify-docker.ps1), e.g. "-p dental-center-verify --env-file .env.verify"
$ComposeExtra = @()
if ($env:DC_COMPOSE_ARGS) { $ComposeExtra = @($env:DC_COMPOSE_ARGS -split '\s+' | Where-Object { $_ }) }

function Invoke-Compose {
  & docker compose @ComposeExtra @args
  if ($LASTEXITCODE -ne 0) { throw "docker compose $($args -join ' ') failed (exit code $LASTEXITCODE)" }
}

$running = & docker compose @ComposeExtra ps --status running --services
if ($running -notcontains 'db') { throw 'The database container is not running (start it with: docker compose up -d db)' }

$stamp  = Get-Date -Format 'yyyyMMdd-HHmmss'
$name   = "$Prefix-$stamp.dump"
$file   = Join-Path $BackupDir $name
$inside = "/tmp/dc-backup-$stamp.dump"
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null

try {
  Write-Host 'Creating backup ...'
  # The database user/name are read from the container's own environment, so no secrets pass through this script.
  Invoke-Compose exec -T db sh -c ('pg_dump --format=custom --no-owner --no-privileges -U $POSTGRES_USER -d $POSTGRES_DB -f ' + $inside)
  Invoke-Compose exec -T db pg_restore --list $inside | Out-Null
  $sizeIn = [int64](((& docker compose @ComposeExtra exec -T db sh -c ('wc -c < ' + $inside)) | Select-Object -First 1).ToString().Trim())
  Invoke-Compose cp "db:$inside" $file
  $sizeOut = (Get-Item $file).Length
  if ($sizeIn -ne $sizeOut -or $sizeOut -lt 1000) {
    Remove-Item $file -Force -ErrorAction SilentlyContinue
    throw "The copied backup is incomplete ($sizeOut of $sizeIn bytes); it was deleted."
  }
}
finally {
  & docker compose @ComposeExtra exec -T db rm -f $inside 2>$null | Out-Null
}

# sha256sum-compatible checksum file (LF line ending, no BOM) so it can also be verified on Linux
$hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $file).Hash.ToLower()
[System.IO.File]::WriteAllText("$((Resolve-Path $file).Path).sha256", "$hash  $name`n")

if ($Keep -gt 0) {
  Get-ChildItem -LiteralPath $BackupDir -Filter "$Prefix-*.dump" |
    Sort-Object LastWriteTime -Descending |
    Select-Object -Skip $Keep |
    ForEach-Object {
      Remove-Item -LiteralPath $_.FullName -Force
      Remove-Item -LiteralPath "$($_.FullName).sha256" -Force -ErrorAction SilentlyContinue
      Write-Host "Removed old backup: $($_.Name)"
    }
}

Write-Host "Backup OK (verified): $file ($sizeOut bytes)"
Write-Host 'IMPORTANT: copy this file to another disk or cloud storage. A backup stored only on this computer is lost with it.'
