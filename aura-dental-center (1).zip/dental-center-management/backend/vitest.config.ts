import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/**/*.test.ts'],
    environment: 'node',
    // Integration tests create their own database per file; run files one after another so a
    // single local PostgreSQL is not flooded, but keep tests inside a file free to run concurrent requests.
    fileParallelism: false,
    testTimeout: 30_000,
    hookTimeout: 60_000,
  },
});
