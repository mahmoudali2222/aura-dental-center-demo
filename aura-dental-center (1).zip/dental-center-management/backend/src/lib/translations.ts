import { z } from 'zod';
import type { Tx } from '../database/pool.js';
import { LOCALES, type Locale } from './locale.js';
import { badRequest } from './errors.js';

/**
 * Shared admin write path for the *_translations tables.
 * Semantics per locale entry:
 *   - primary field non-empty  -> insert or update that locale (other fields are updated only when provided)
 *   - primary field empty ("") -> delete that locale (the documented fallback chain then applies)
 *   - locale omitted           -> left untouched
 * At least one locale must remain after the change.
 */
export interface TranslationSpec {
  table: string;
  idColumn: string;
  /** Required text column, e.g. "name" or "display_name"; null when no field is mandatory (gallery). */
  primary: string | null;
  /** Other text columns that may be set. */
  others: string[];
}

export type TranslationInput = Partial<Record<Locale, Record<string, string | undefined>>>;

export function translationsSchema(fields: Record<string, { max: number }>) {
  const entry = z.object(
    Object.fromEntries(
      Object.entries(fields).map(([k, v]) => [k, z.string().trim().max(v.max, 'TEXT_TOO_LONG').optional()]),
    ) as Record<string, z.ZodOptional<z.ZodString>>,
  );
  return z.object({ ar: entry.optional(), en: entry.optional(), fr: entry.optional() });
}

export async function applyTranslations(tx: Tx, spec: TranslationSpec, id: string, rawInput: TranslationInput | undefined): Promise<void> {
  const input: TranslationInput = rawInput ?? {};
  const columns = spec.primary ? [spec.primary, ...spec.others] : spec.others;
  for (const locale of LOCALES) {
    const entry = input[locale];
    if (!entry) continue;
    const primaryValue = spec.primary ? (entry[spec.primary] ?? '') : undefined;
    if (spec.primary && entry[spec.primary] !== undefined && primaryValue!.trim() === '') {
      await tx.query(`DELETE FROM ${spec.table} WHERE ${spec.idColumn} = $1 AND locale = $2`, [id, locale]);
      continue;
    }
    const provided = columns.filter((c) => entry[c] !== undefined);
    if (provided.length === 0) continue;
    const exists = (await tx.query(`SELECT 1 FROM ${spec.table} WHERE ${spec.idColumn} = $1 AND locale = $2`, [id, locale])).rowCount;
    if (!exists && spec.primary && !entry[spec.primary]) {
      throw badRequest('TRANSLATION_NAME_REQUIRED', `${spec.primary} is required to add the ${locale} translation`, [{ field: `translations.${locale}.${spec.primary}`, code: 'REQUIRED' }]);
    }
    const values = provided.map((c) => entry[c] ?? '');
    const cols = [spec.idColumn, 'locale', ...provided];
    const params = [id, locale, ...values];
    const placeholders = params.map((_, i) => `$${i + 1}`).join(', ');
    const updates = provided.map((c) => `${c} = EXCLUDED.${c}`).join(', ');
    await tx.query(
      `INSERT INTO ${spec.table} (${cols.join(', ')}) VALUES (${placeholders})
       ON CONFLICT (${spec.idColumn}, locale) DO UPDATE SET ${updates}`,
      params,
    );
  }
  const remaining = (await tx.query<{ n: string }>(`SELECT count(*) AS n FROM ${spec.table} WHERE ${spec.idColumn} = $1`, [id])).rows[0]!.n;
  if (spec.primary && Number(remaining) === 0) {
    throw badRequest('AT_LEAST_ONE_TRANSLATION', 'At least one language is required', [{ field: 'translations', code: 'AT_LEAST_ONE_TRANSLATION' }]);
  }
}

/** Builds { ar: {...}, en: {...}, fr: {...} } from the jsonb_object_agg column returned by SQL. */
export type TranslationMap<T> = Partial<Record<Locale, T>>;
