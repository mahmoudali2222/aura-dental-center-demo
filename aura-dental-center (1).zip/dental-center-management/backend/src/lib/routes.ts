import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { z, ZodType } from 'zod';
import { forbidden, unauthorized, unavailable } from './errors.js';
import { parseWith } from './validation.js';
import { safeEqual } from './crypto.js';
import { COOKIES, loadSession } from '../modules/auth/session.service.js';
import type { AdminPrincipal, AppContext, PatientPrincipal, SessionInfo } from '../types.js';

/**
 * Route framework: every endpoint is declared once with its auth requirement, input schemas and handler.
 * The same declaration drives Fastify registration, input validation, authentication/CSRF, and the OpenAPI document,
 * so documentation cannot drift from behavior.
 *
 * auth kinds:
 *   public        no credentials
 *   patient       patient session cookie (+ CSRF header on unsafe methods)
 *   admin         admin session cookie, password change already completed
 *   admin-setup   admin session cookie, allowed while a forced password change is pending
 *   integration   Authorization: Bearer <INTEGRATION_API_KEY> (machine-to-machine; n8n)
 */
export type AuthKind = 'public' | 'patient' | 'admin' | 'admin-setup' | 'integration';
type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

type Infer<T> = T extends ZodType ? z.infer<T> : undefined;
type Principals<A> = A extends 'patient'
  ? { patient: PatientPrincipal; session: SessionInfo }
  : A extends 'admin' | 'admin-setup'
    ? { admin: AdminPrincipal; session: SessionInfo }
    : object;

export type HandlerContext<A extends AuthKind, B, Q, P> = {
  req: FastifyRequest;
  reply: FastifyReply;
  app: AppContext;
  body: Infer<B>;
  query: Infer<Q>;
  params: Infer<P>;
  ip: string;
} & Principals<A>;

/** Wrap list results to include pagination metadata. */
export class Paged<T> {
  constructor(
    public readonly rows: T[],
    public readonly meta: Record<string, unknown>,
  ) {}
}
/** Return from a handler to send 204 No Content. */
export const NO_CONTENT = Symbol('no-content');

export interface RouteDef<A extends AuthKind, B extends ZodType | undefined, Q extends ZodType | undefined, P extends ZodType | undefined> {
  method: Method;
  url: string;
  auth: A;
  summary: string;
  tags: string[];
  body?: B;
  query?: Q;
  params?: P;
  /** Success status (default 200). */
  status?: number;
  /** Per-route rate limit (in addition to the global one). */
  rateLimit?: { max: number; windowMs: number };
  /** Error codes this endpoint can return, for the generated docs. */
  errors?: string[];
  handler: (ctx: HandlerContext<A, B, Q, P>) => Promise<unknown>;
}

export interface RouteMeta {
  method: Method;
  url: string;
  auth: AuthKind;
  summary: string;
  tags: string[];
  body?: ZodType;
  query?: ZodType;
  params?: ZodType;
  status: number;
  errors: string[];
}

/** All registered routes, for OpenAPI generation and for tests that assert on the route table. */
export const routeRegistry: RouteMeta[] = [];

export function route<A extends AuthKind, B extends ZodType | undefined = undefined, Q extends ZodType | undefined = undefined, P extends ZodType | undefined = undefined>(
  def: RouteDef<A, B, Q, P>,
): RouteDef<A, B, Q, P> {
  return def;
}

const UNSAFE = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

function bearerToken(req: FastifyRequest): string | null {
  const h = req.headers.authorization;
  if (!h) return null;
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m?.[1]?.trim() ?? null;
}

function assertCsrf(req: FastifyRequest, session: SessionInfo): void {
  const header = req.headers['x-csrf-token'];
  if (typeof header !== 'string' || !safeEqual(header, session.csrfToken)) {
    throw forbidden('CSRF_INVALID', 'Missing or invalid CSRF token');
  }
}

async function authenticate(app: AppContext, req: FastifyRequest, auth: AuthKind): Promise<Record<string, unknown>> {
  if (auth === 'public') return {};

  if (auth === 'integration') {
    if (app.config.integrationKeys.length === 0) throw unavailable('INTEGRATION_DISABLED', 'Integration API is not configured');
    const token = bearerToken(req);
    // Compare against every configured key without short-circuiting on the first match (constant work).
    let ok = false;
    if (token) for (const key of app.config.integrationKeys) ok = safeEqual(token, key) || ok;
    if (!ok) throw unauthorized('INVALID_INTEGRATION_KEY', 'Invalid integration credentials');
    return {};
  }

  const kind = auth === 'patient' ? 'patient' : 'admin';
  const cookie = COOKIES[kind];
  const token = req.cookies[cookie.name];
  if (!token) throw unauthorized();
  const loaded = kind === 'patient' ? await loadSession(app, 'patient', token) : await loadSession(app, 'admin', token);
  if (!loaded) throw unauthorized('SESSION_EXPIRED', 'Session is missing, expired or revoked');
  if (UNSAFE.has(req.method)) assertCsrf(req, loaded.session);
  if (auth === 'admin' && 'admin' in loaded && loaded.admin.mustChangePassword) {
    throw forbidden('PASSWORD_CHANGE_REQUIRED', 'The initial password must be changed before using the dashboard');
  }
  return loaded as unknown as Record<string, unknown>;
}

export function registerRoutes(fastify: FastifyInstance, app: AppContext, prefix: string, defs: RouteDef<AuthKind, never, never, never>[]): void {
  for (const raw of defs) {
    const def = raw as unknown as RouteDef<AuthKind, ZodType | undefined, ZodType | undefined, ZodType | undefined>;
    const fullUrl = `${prefix}${def.url}`;
    routeRegistry.push({
      method: def.method,
      url: fullUrl,
      auth: def.auth,
      summary: def.summary,
      tags: def.tags,
      body: def.body,
      query: def.query,
      params: def.params,
      status: def.status ?? 200,
      errors: def.errors ?? [],
    });

    fastify.route({
      method: def.method,
      url: fullUrl,
      config: def.rateLimit ? { rateLimit: { max: def.rateLimit.max, timeWindow: def.rateLimit.windowMs } } : undefined,
      handler: async (req, reply) => {
        const principals = await authenticate(app, req, def.auth);
        const params = def.params ? parseWith(def.params, req.params) : undefined;
        const query = def.query ? parseWith(def.query, req.query) : undefined;
        const body = def.body ? parseWith(def.body, req.body ?? {}) : undefined;
        reply.header('Cache-Control', 'no-store');
        const result = await def.handler({ req, reply, app, ip: req.ip, params, query, body, ...principals } as never);
        if (reply.sent) return reply;
        if (result === NO_CONTENT) return reply.status(204).send();
        reply.status(def.status ?? 200);
        if (result instanceof Paged) return reply.send({ data: result.rows, meta: result.meta });
        return reply.send({ data: result ?? null });
      },
    });
  }
}

/** Groups route declarations into the (type-erased) list that registerRoutes accepts. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const defs = (...list: RouteDef<any, any, any, any>[]): RouteDef<AuthKind, never, never, never>[] => list as unknown as RouteDef<AuthKind, never, never, never>[];
