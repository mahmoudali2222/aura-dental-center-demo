export const LOCALES = ['ar', 'en', 'fr'] as const;
export type Locale = (typeof LOCALES)[number];

export function isLocale(value: unknown): value is Locale {
  return typeof value === 'string' && (LOCALES as readonly string[]).includes(value);
}

/**
 * Content fallback policy (documented in docs/ARCHITECTURE.md §6):
 *   requested locale -> center default locale -> en -> ar -> fr
 * Internal keys are never returned; if every locale is empty the caller gets null and omits/blanks the field.
 */
export function fallbackChain(requested: Locale | null | undefined, centerDefault: Locale): Locale[] {
  const chain: Locale[] = [];
  for (const l of [requested, centerDefault, 'en', 'ar', 'fr'] as (Locale | null | undefined)[]) {
    if (l && !chain.includes(l)) chain.push(l);
  }
  return chain;
}

/** Picks the first non-empty translation along the chain. `field` must be a string field of T. */
export function pickText<T extends object>(
  translations: Partial<Record<Locale, T>> | null | undefined,
  chain: Locale[],
  field: keyof T & string,
): string {
  if (!translations) return '';
  for (const l of chain) {
    const v = (translations[l] as Record<string, unknown> | undefined)?.[field];
    if (typeof v === 'string' && v.trim() !== '') return v;
  }
  return '';
}

/** Parses an Accept-Language header and returns the best supported locale, if any. */
export function parseAcceptLanguage(header: string | undefined): Locale | null {
  if (!header) return null;
  const candidates = header
    .split(',')
    .map((part) => {
      const [tag = '', ...params] = part.trim().split(';');
      const q = params.map((p) => p.trim()).find((p) => p.startsWith('q='));
      return { tag: tag.toLowerCase(), q: q ? Number(q.slice(2)) : 1 };
    })
    .filter((c) => c.tag && Number.isFinite(c.q) && c.q > 0)
    .sort((a, b) => b.q - a.q);
  for (const c of candidates) {
    const base = c.tag.split('-')[0];
    if (isLocale(base)) return base;
  }
  return null;
}
