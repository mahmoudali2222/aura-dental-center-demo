import { z, type ZodType } from 'zod';
import type { AuthKind, RouteMeta } from './routes.js';

/**
 * OpenAPI 3.1 document generated from the route registry, i.e. from the very declarations that register the routes
 * and validate their input. It therefore cannot describe an endpoint that does not exist or omit one that does
 * (tests/unit/openapi.test.ts also compares the committed docs/openapi.json with a fresh generation).
 */
type Json = Record<string, unknown>;

const SECURITY: Record<AuthKind, Json[]> = {
  public: [],
  patient: [{ patientSession: [] }],
  admin: [{ adminSession: [] }],
  'admin-setup': [{ adminSession: [] }],
  integration: [{ integrationKey: [] }],
};
const UNSAFE = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

/** `format: uuid` already says it all; zod's long UUID regex only bloats the document. */
function slim(node: unknown): void {
  if (Array.isArray(node)) { node.forEach(slim); return; }
  if (node && typeof node === 'object') {
    const o = node as Json;
    if (o.format === 'uuid') delete o.pattern;
    Object.values(o).forEach(slim);
  }
}

function toSchema(schema: ZodType): Json {
  const js = z.toJSONSchema(schema, { io: 'input', unrepresentable: 'any' }) as Json;
  delete js.$schema;
  slim(js);
  return js;
}

function parametersFrom(schema: ZodType | undefined, where: 'path' | 'query'): Json[] {
  if (!schema) return [];
  const js = toSchema(schema) as { properties?: Record<string, Json>; required?: string[] };
  return Object.entries(js.properties ?? {}).map(([name, s]) => ({
    name,
    in: where,
    required: where === 'path' ? true : (js.required ?? []).includes(name),
    schema: s,
  }));
}

const openApiPath = (url: string) => url.replace(/:([A-Za-z0-9_]+)/g, '{$1}');

export function operationId(r: Pick<RouteMeta, 'method' | 'url'>): string {
  const words = r.url.replace(/^\/api\/v1\//, '').split('/').filter(Boolean).map((seg) => {
    const param = /^:(.+)$/.exec(seg);
    return param ? `By${param[1]![0]!.toUpperCase()}${param[1]!.slice(1)}` : seg.replace(/[^A-Za-z0-9]+(.)?/g, (_m, c: string | undefined) => (c ? c.toUpperCase() : ''));
  });
  const joined = words.map((w, i) => (i === 0 || w.startsWith('By') ? w : w[0]!.toUpperCase() + w.slice(1))).join('');
  return `${r.method.toLowerCase()}${joined[0]!.toUpperCase()}${joined.slice(1)}`;
}

export function dedupeRoutes(routes: RouteMeta[]): RouteMeta[] {
  const seen = new Map<string, RouteMeta>();
  for (const r of routes) seen.set(`${r.method} ${r.url}`, r); // the registry grows with every app instance built in-process
  return [...seen.values()].sort((a, b) => (a.url === b.url ? a.method.localeCompare(b.method) : a.url.localeCompare(b.url)));
}

export function buildOpenApi(routeList: RouteMeta[], info: { version: string; timezone: string }): Json {
  const routes = dedupeRoutes(routeList);
  const paths: Record<string, Record<string, Json>> = {};
  const tags = new Set<string>();

  for (const r of routes) {
    r.tags.forEach((t) => tags.add(t));
    const needsCsrf = UNSAFE.has(r.method) && (r.auth === 'patient' || r.auth === 'admin' || r.auth === 'admin-setup');
    const security = SECURITY[r.auth].map((s) => (needsCsrf ? { ...s, csrfToken: [] } : s));
    const responses: Record<string, Json> = {};
    if (r.status === 204) responses['204'] = { description: 'Success, no content.' };
    else responses[String(r.status)] = { description: 'Success.', content: { 'application/json': { schema: { $ref: '#/components/schemas/DataEnvelope' } } } };
    const fail = (code: number, description: string) => { responses[String(code)] = { description, content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } } }; };
    if (r.body || r.query || r.params) fail(400, 'Validation failed (`VALIDATION_ERROR`, with per-field codes in `details`).');
    if (r.auth !== 'public') fail(401, r.auth === 'integration' ? '`INVALID_INTEGRATION_KEY`.' : '`UNAUTHENTICATED` or `SESSION_EXPIRED`.');
    if (needsCsrf) fail(403, '`CSRF_INVALID` (missing/invalid `X-CSRF-Token`), or a business-rule refusal.');
    if (r.auth === 'integration') fail(503, '`INTEGRATION_DISABLED` when no integration key is configured.');
    fail(429, '`RATE_LIMITED` / `TOO_MANY_ATTEMPTS`.');

    const op: Json = {
      operationId: operationId(r),
      summary: r.summary.split(/(?<=\.)\s/)[0],
      description: r.summary,
      tags: r.tags,
      security,
      parameters: [...parametersFrom(r.params, 'path'), ...parametersFrom(r.query, 'query')],
      ...(r.body ? { requestBody: { required: true, content: { 'application/json': { schema: toSchema(r.body) } } } } : {}),
      responses,
      ...(r.errors.length ? { 'x-error-codes': r.errors } : {}),
    };
    (paths[openApiPath(r.url)] ??= {})[r.method.toLowerCase()] = op;
  }

  return {
    openapi: '3.1.0',
    info: {
      title: 'Dental Center Management API',
      version: info.version,
      description:
        'REST API for the patient website, the admin dashboard and the n8n/Telegram assistant.\n\n' +
        `All times are in the center's time zone (${info.timezone}). Success: \`{ "data": ... }\` (lists add \`meta\`). ` +
        'Failure: `{ "error": { "code", "message", "details?" } }` — clients must switch on `code`, never on `message`. ' +
        'Browser sessions use HttpOnly cookies plus an `X-CSRF-Token` header on state-changing requests; n8n uses a bearer key.',
    },
    servers: [{ url: '/' }],
    tags: [...tags].sort().map((name) => ({ name })),
    paths,
    components: {
      securitySchemes: {
        patientSession: { type: 'apiKey', in: 'cookie', name: 'dc_patient', description: 'Patient session cookie (HttpOnly), set by patient login/register.' },
        adminSession: { type: 'apiKey', in: 'cookie', name: 'dc_admin', description: 'Admin session cookie (HttpOnly), set by admin login.' },
        csrfToken: { type: 'apiKey', in: 'header', name: 'X-CSRF-Token', description: 'Per-session token returned by login/me; required on POST/PUT/PATCH/DELETE with a session cookie.' },
        integrationKey: { type: 'http', scheme: 'bearer', description: 'Machine key for n8n (INTEGRATION_API_KEY). Never accepted by patient/admin routes.' },
      },
      schemas: {
        DataEnvelope: { type: 'object', properties: { data: {}, meta: { type: 'object', description: 'Pagination: page, pageSize, total, totalPages.' } }, required: ['data'] },
        Error: {
          type: 'object',
          properties: { error: { type: 'object', properties: { code: { type: 'string', examples: ['SLOT_UNAVAILABLE'] }, message: { type: 'string' }, details: {} }, required: ['code', 'message'] } },
          required: ['error'],
        },
      },
    },
  };
}

/** Compact, human-readable endpoint table (docs/API_REFERENCE.md). Generated; do not edit by hand. */
export function buildEndpointMarkdown(routeList: RouteMeta[]): string {
  const routes = dedupeRoutes(routeList);
  const lines = [
    '# API reference (generated)',
    '',
    '> Generated from the route declarations by `npm run openapi`. Do not edit by hand; edit the code and regenerate.',
    '> The machine-readable version is [`openapi.json`](./openapi.json). Conventions are explained in [API.md](./API.md).',
    '',
  ];
  const byTag = new Map<string, RouteMeta[]>();
  for (const r of routes) { const t = r.tags[0] ?? 'Other'; byTag.set(t, [...(byTag.get(t) ?? []), r]); }
  const authLabel: Record<AuthKind, string> = { public: 'none', patient: 'patient session', admin: 'admin session', 'admin-setup': 'admin session (password change allowed)', integration: 'integration key' };
  for (const [tag, list] of [...byTag].sort((a, b) => a[0].localeCompare(b[0]))) {
    lines.push(`## ${tag}`, '', '| Method | Path | Auth | Purpose | Error codes |', '|---|---|---|---|---|');
    for (const r of list) {
      const esc = (s: string) => s.replace(/\|/g, '\\|').replace(/\n/g, ' ');
      lines.push(`| ${r.method} | \`${r.url}\` | ${authLabel[r.auth]} | ${esc(r.summary)} | ${r.errors.map((e) => `\`${e}\``).join(', ')} |`);
    }
    lines.push('');
  }
  return lines.join('\n');
}
