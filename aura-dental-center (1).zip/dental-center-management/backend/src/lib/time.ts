import { DateTime } from 'luxon';

/**
 * All business-day arithmetic lives here. Rules:
 *  - A "business date" is a Cairo-local calendar date string, `YYYY-MM-DD`.
 *  - A slot's window is built from (business date + local start time) in the center timezone;
 *    its end is start + exactly 2 REAL hours. Luxon adds hours as absolute time, so DST can never
 *    stretch or shrink an appointment, and the 22:00 slot is never mistaken for part of the next day.
 *  - Cancellation/reschedule policy compares absolute instants, so DST cannot distort the 24 h rule.
 */

export const SLOT_MINUTES = 120;
export const SELF_SERVICE_NOTICE_MS = 24 * 60 * 60 * 1000;

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function isValidDateString(value: string): boolean {
  return DATE_RE.test(value) && DateTime.fromISO(value, { zone: 'utc' }).isValid;
}

/** Today's calendar date in the center timezone. */
export function centerToday(zone: string, now: Date): string {
  return DateTime.fromJSDate(now, { zone }).toISODate()!;
}

export function addDays(dateStr: string, days: number): string {
  return DateTime.fromISO(dateStr, { zone: 'utc' }).plus({ days }).toISODate()!;
}

/** Whole days from a to b (b - a), both `YYYY-MM-DD`. */
export function diffDays(a: string, b: string): number {
  return Math.round(DateTime.fromISO(b, { zone: 'utc' }).diff(DateTime.fromISO(a, { zone: 'utc' }), 'days').days);
}

/** ISO weekday of a business date: 1 = Monday ... 7 = Sunday. */
export function isoWeekday(dateStr: string): number {
  return DateTime.fromISO(dateStr, { zone: 'utc' }).weekday;
}

export interface SlotWindow {
  startsAt: Date;
  endsAt: Date;
}

/** `startTime` is the local wall-clock start, "HH:MM" or "HH:MM:SS". */
export function slotWindow(zone: string, dateStr: string, startTime: string): SlotWindow {
  const [hh = '0', mm = '0'] = startTime.split(':');
  const start = DateTime.fromISO(dateStr, { zone }).set({ hour: Number(hh), minute: Number(mm), second: 0, millisecond: 0 });
  if (!start.isValid) throw new Error(`Invalid slot window: ${dateStr} ${startTime} ${zone}`);
  const end = start.plus({ minutes: SLOT_MINUTES });
  return { startsAt: start.toJSDate(), endsAt: end.toJSDate() };
}

/** ISO-8601 string with the center's UTC offset, e.g. "2026-11-03T22:00:00+02:00". */
export function toCenterIso(zone: string, instant: Date): string {
  return DateTime.fromJSDate(instant, { zone }).toISO({ suppressMilliseconds: true })!;
}

/** Local wall-clock "HH:mm" in the center timezone (useful for display fields). */
export function toCenterClock(zone: string, instant: Date): string {
  return DateTime.fromJSDate(instant, { zone }).toFormat('HH:mm');
}

export function isValidZone(zone: string): boolean {
  return DateTime.local().setZone(zone).isValid;
}

/** Self-service rule: allowed iff at least 24 h remain before the (original) start. Boundary is inclusive. */
export function hasSelfServiceNotice(startsAt: Date, now: Date): boolean {
  return startsAt.getTime() - now.getTime() >= SELF_SERVICE_NOTICE_MS;
}
