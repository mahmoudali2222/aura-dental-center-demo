// 'max' metadata knows real number ranges per country (e.g. Egyptian mobiles start 010/011/012/015); the default 'min' is lenient.
import { parsePhoneNumberFromString } from 'libphonenumber-js/max';

const ARABIC_INDIC = '٠١٢٣٤٥٦٧٨٩';
const EXTENDED_ARABIC_INDIC = '۰۱۲۳۴۵۶۷۸۹';

function toAsciiDigits(input: string): string {
  return input.replace(/[٠-٩۰-۹]/g, (ch) => {
    const a = ARABIC_INDIC.indexOf(ch);
    if (a >= 0) return String(a);
    return String(EXTENDED_ARABIC_INDIC.indexOf(ch));
  });
}

/**
 * Normalizes a phone number to E.164 (e.g. "+201012345678"), or returns null when it is not a valid number.
 * Accepts local Egyptian format (01012345678), international (+20 101 234 5678), 00-prefixed (0020...)
 * and Arabic-Indic digits. Two spellings of the same number always normalize to the same string,
 * which is what the UNIQUE constraint on patients.phone_e164 relies on.
 *
 * NOTE: the number is only *normalized*, never verified: the system has no OTP/SMS step by design.
 */
export function normalizePhone(input: string, defaultCountry: 'EG' = 'EG'): string | null {
  let s = toAsciiDigits(input).trim();
  s = s.replace(/[\s\-().‎‏]/g, '');
  if (s.startsWith('00')) s = `+${s.slice(2)}`;
  if (!/^\+?\d{6,16}$/.test(s)) return null;
  const parsed = parsePhoneNumberFromString(s, defaultCountry);
  if (!parsed || !parsed.isValid()) return null;
  return parsed.number; // E.164
}
