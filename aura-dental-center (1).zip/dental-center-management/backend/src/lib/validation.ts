import { z, type ZodType } from 'zod';
import { AppError, type FieldIssue } from './errors.js';
import { isValidDateString } from './time.js';
import { LOCALES } from './locale.js';

/**
 * Validation messages that look like UPPER_SNAKE_CASE are treated as stable error codes the frontend can translate
 * (e.g. z.string().min(8, 'PASSWORD_TOO_SHORT')). Anything else falls back to zod's own issue code.
 */
const CODE_RE = /^[A-Z][A-Z0-9_]+$/;

export function parseWith<T extends ZodType>(schema: T, data: unknown): z.infer<T> {
  const result = schema.safeParse(data);
  if (result.success) return result.data;
  const issues: FieldIssue[] = result.error.issues.map((i) => ({
    field: i.path.map(String).join('.'),
    code: CODE_RE.test(i.message) ? i.message : i.code,
  }));
  throw new AppError(400, 'VALIDATION_ERROR', 'Request validation failed', issues);
}

export const uuidSchema = z.string().uuid('INVALID_ID');
export const localeSchema = z.enum(LOCALES, { error: 'INVALID_LOCALE' });
export const dateSchema = z.string().refine(isValidDateString, 'INVALID_DATE');
export const slotNumberSchema = z.number().int().min(1, 'INVALID_SLOT').max(4, 'INVALID_SLOT');

/** Optional localized text for each supported locale. Admin payloads send all three they want to set. */
export const textByLocale = (opts: { required?: boolean; max?: number } = {}) => {
  const field = z.string().trim().max(opts.max ?? 2000, 'TEXT_TOO_LONG');
  return z.object({
    ar: opts.required ? field.min(1, 'REQUIRED') : field.optional(),
    en: opts.required ? field.min(1, 'REQUIRED') : field.optional(),
    fr: opts.required ? field.min(1, 'REQUIRED') : field.optional(),
  });
};

export const pageQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
});

export function pageMeta(page: number, pageSize: number, total: number) {
  return { page, pageSize, total, totalPages: Math.max(1, Math.ceil(total / pageSize)) };
}

/** Escapes LIKE wildcards so user text is matched literally. */
export function likePattern(input: string): string {
  return `%${input.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
}

/** Query-string booleans ("true"/"false"). */
export const boolQuery = z.enum(['true', 'false']).transform((v) => v === 'true');

/** Image references are site-relative paths under /assets/ (no external URLs, no traversal, no javascript: URLs). */
export const imagePathSchema = z
  .string()
  .max(200, 'INVALID_IMAGE_PATH')
  .regex(/^\/assets\/[A-Za-z0-9._\-/]+$/, 'INVALID_IMAGE_PATH')
  .refine((p) => !p.includes('..') && !p.includes('//'), 'INVALID_IMAGE_PATH');

/** ISO weekdays (1 = Monday ... 7 = Sunday): at least one, no duplicates, sorted. Used for the center's and for each department's working days. */
export const workingDaysSchema = z
  .array(z.number().int().min(1, 'INVALID_WEEKDAY').max(7, 'INVALID_WEEKDAY'))
  .min(1, 'AT_LEAST_ONE_WORKING_DAY')
  .max(7, 'INVALID_WEEKDAY')
  .transform((d) => [...new Set(d)].sort((a, b) => a - b));
