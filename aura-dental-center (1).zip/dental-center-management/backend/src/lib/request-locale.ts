import type { FastifyRequest } from 'fastify';
import { isLocale, parseAcceptLanguage, type Locale } from './locale.js';

/** Requested content language: ?locale= first, then Accept-Language, then the caller's saved preference. */
export function requestLocale(req: FastifyRequest, preferred?: Locale | null): Locale | null {
  const q = (req.query as { locale?: unknown } | undefined)?.locale;
  if (isLocale(q)) return q;
  const header = parseAcceptLanguage(req.headers['accept-language']);
  return header ?? preferred ?? null;
}
