/**
 * One error type for everything the API deliberately rejects.
 * `code` is a stable machine-readable string: the frontends translate it, so never reword an existing code.
 * `message` is a short English description for developers and logs, never shown to patients as-is.
 */
export class AppError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message?: string,
    public readonly details?: unknown,
  ) {
    super(message ?? code);
    this.name = 'AppError';
  }

  /** Fastify and its plugins read `statusCode`. */
  get statusCode(): number {
    return this.status;
  }
}

export const badRequest = (code: string, message?: string, details?: unknown) => new AppError(400, code, message, details);
export const unauthorized = (code = 'UNAUTHENTICATED', message = 'Authentication required') => new AppError(401, code, message);
export const forbidden = (code = 'FORBIDDEN', message = 'Not allowed') => new AppError(403, code, message);
export const notFound = (code = 'NOT_FOUND', message = 'Resource not found') => new AppError(404, code, message);
export const conflict = (code: string, message?: string, details?: unknown) => new AppError(409, code, message, details);
/** The request is well-formed but a business rule forbids it (past slot, closed day, 24-hour policy ...). */
export const unprocessable = (code: string, message?: string, details?: unknown) => new AppError(422, code, message, details);
export const tooMany = (code = 'RATE_LIMITED', message = 'Too many requests') => new AppError(429, code, message);
export const unavailable = (code: string, message?: string) => new AppError(503, code, message);

export interface FieldIssue {
  field: string;
  code: string;
}
