import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import type { AppConfig } from './config/env.js';
import { createPool, type Db } from './database/pool.js';
import { systemClock, type Clock } from './lib/clock.js';
import { AppError, forbidden } from './lib/errors.js';
import { registerRoutes } from './lib/routes.js';
import { AttemptLimiter } from './middleware/attempt-limiter.js';
import type { AppContext } from './types.js';
import { publicRoutes } from './modules/public/public.routes.js';
import { adminAuthRoutes, patientAuthRoutes } from './modules/auth/auth.routes.js';
import { patientSelfRoutes } from './modules/patients/patient-self.routes.js';
import { patientAdminRoutes } from './modules/patients/patient-admin.routes.js';
import { adminAppointmentRoutes } from './modules/admin/appointments.routes.js';
import { adminCatalogRoutes } from './modules/admin/catalog.routes.js';
import { adminSettingsRoutes } from './modules/admin/settings.routes.js';
import { medicalRecordRoutes } from './modules/medical-records/medical-record.routes.js';
import { auditRoutes } from './modules/audit/audit.routes.js';
import { integrationRoutes } from './modules/integrations/integration.routes.js';

export interface BuildAppOptions {
  config: AppConfig;
  /** Provide a pool to share it (tests); otherwise one is created and closed with the app. */
  db?: Db;
  clock?: Clock;
  /** Test hook: capture log output to assert that nothing sensitive is written. */
  logStream?: NodeJS.WritableStream;
}

const UNSAFE = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

export async function buildApp(opts: BuildAppOptions) {
  const { config } = opts;
  const ownsPool = !opts.db;
  const db = opts.db ?? createPool(config.databaseUrl, config.dbPoolMax);
  const clock = opts.clock ?? systemClock;

  const app = Fastify({
    logger:
      config.logLevel === 'silent'
        ? false
        : {
            level: config.logLevel,
            // Never write credentials to logs. Bodies are never logged at all.
            redact: { paths: ['req.headers.authorization', 'req.headers.cookie', 'res.headers["set-cookie"]'], censor: '[redacted]' },
            ...(opts.logStream ? { stream: opts.logStream } : {}),
          },
    trustProxy: config.trustProxy,
    bodyLimit: 256 * 1024,
    routerOptions: { ignoreTrailingSlash: true },
  });

  const ctx: AppContext = { config, db, clock, loginLimiter: new AttemptLimiter(config.rateLimits.loginPerAccount, clock) };

  if (ownsPool) app.addHook('onClose', async () => { await db.end(); });

  await app.register(helmet, { contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } }, crossOriginResourcePolicy: { policy: 'same-site' } });
  await app.register(cors, {
    origin: (origin, cb) => cb(null, !origin || config.allowedOrigins.includes(origin)),
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'X-CSRF-Token', 'Authorization', 'Accept-Language'],
    maxAge: 600,
  });
  await app.register(cookie);
  await app.register(rateLimit, {
    global: true,
    max: config.rateLimits.api.max,
    timeWindow: config.rateLimits.api.windowMs,
    keyGenerator: (req) => req.ip,
    errorResponseBuilder: () => new AppError(429, 'RATE_LIMITED', 'Too many requests, please slow down'),
  });

  // Browser state-changing requests must come from an allowed origin (defense in depth next to SameSite + CSRF token).
  app.addHook('onRequest', async (req) => {
    if (!UNSAFE.has(req.method)) return;
    if (!req.url.startsWith('/api/v1/patient') && !req.url.startsWith('/api/v1/admin')) return;
    const origin = req.headers.origin;
    if (origin && !config.allowedOrigins.includes(origin)) throw forbidden('ORIGIN_NOT_ALLOWED', 'Request origin is not allowed');
  });

  app.setNotFoundHandler((_req, reply) => reply.status(404).send({ error: { code: 'NOT_FOUND', message: 'Route not found' } }));

  app.setErrorHandler((err: Error & { statusCode?: number; code?: string; constraint?: string }, req, reply) => {
    if (err instanceof AppError) {
      return reply.status(err.status).send({ error: { code: err.code, message: err.message, ...(err.details !== undefined ? { details: err.details } : {}) } });
    }
    const status = err.statusCode;
    if (status === 429) return reply.status(429).send({ error: { code: 'RATE_LIMITED', message: 'Too many requests, please slow down' } });
    if (err.code === 'FST_ERR_CTP_INVALID_JSON_BODY' || err.code === 'FST_ERR_CTP_EMPTY_JSON_BODY') return reply.status(400).send({ error: { code: 'INVALID_JSON', message: 'Request body is not valid JSON' } });
    if (err.code === 'FST_ERR_CTP_BODY_TOO_LARGE') return reply.status(413).send({ error: { code: 'BODY_TOO_LARGE', message: 'Request body is too large' } });
    if (err.code === 'FST_ERR_CTP_INVALID_MEDIA_TYPE') return reply.status(415).send({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Use application/json' } });
    // Unexpected: log what is useful but NOT the raw error object (database errors can embed row values).
    req.log.error({ errName: err.name, errCode: err.code, constraint: err.constraint, stack: err.stack?.split('\n').slice(0, 6).join('\n') }, 'unhandled error');
    return reply.status(500).send({ error: { code: 'INTERNAL_ERROR', message: 'Something went wrong' } });
  });

  // --- health --------------------------------------------------------------------------------
  app.get('/api/health', { config: { rateLimit: false } }, async () => ({ status: 'ok' }));
  app.get('/api/ready', { config: { rateLimit: false } }, async (_req, reply) => {
    try {
      await db.query('SELECT 1');
      const m = await db.query('SELECT 1 FROM schema_migrations LIMIT 1');
      if (!m.rowCount) return reply.status(503).send({ status: 'not_ready', reason: 'database has no migrations applied' });
      return { status: 'ready' };
    } catch {
      return reply.status(503).send({ status: 'not_ready', reason: 'database unavailable' });
    }
  });

  // --- API --------------------------------------------------------------------------------------
  registerRoutes(app, ctx, '/api/v1/public', publicRoutes(ctx));
  registerRoutes(app, ctx, '/api/v1/patient/auth', patientAuthRoutes(ctx));
  registerRoutes(app, ctx, '/api/v1/patient', patientSelfRoutes(ctx));
  registerRoutes(app, ctx, '/api/v1/admin/auth', adminAuthRoutes(ctx));
  registerRoutes(app, ctx, '/api/v1/admin', [
    ...adminAppointmentRoutes(ctx),
    ...patientAdminRoutes(ctx),
    ...adminCatalogRoutes(ctx),
    ...adminSettingsRoutes(ctx),
    ...medicalRecordRoutes(ctx),
    ...auditRoutes(ctx),
  ]);
  registerRoutes(app, ctx, '/api/v1/integrations', integrationRoutes(ctx));

  // Returned in a wrapper: a Fastify instance is thenable, so returning it directly from an async function would
  // make the promise adopt it (and call ready()) instead of handing it back.
  return { app, ctx };
}

export type BuiltApp = Awaited<ReturnType<typeof buildApp>>;
