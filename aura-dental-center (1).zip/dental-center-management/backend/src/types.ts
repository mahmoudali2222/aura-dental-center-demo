import type { AppConfig } from './config/env.js';
import type { Clock } from './lib/clock.js';
import type { Db } from './database/pool.js';
import type { Locale } from './lib/locale.js';
import type { AttemptLimiter } from './middleware/attempt-limiter.js';

/** Everything a module needs from the running application. Passed explicitly: no globals. */
export interface AppContext {
  config: AppConfig;
  db: Db;
  clock: Clock;
  loginLimiter: AttemptLimiter;
}

export interface PatientPrincipal {
  id: string;
  fullName: string;
  phone: string;
  preferredLocale: Locale | null;
}

export interface AdminPrincipal {
  id: string;
  username: string;
  fullName: string;
  mustChangePassword: boolean;
}

export interface SessionInfo {
  id: string;
  csrfToken: string;
}

/** Who performed an action, for audit records and permission-sensitive branches. */
export type Actor =
  | { type: 'patient'; id: string }
  | { type: 'admin'; id: string }
  | { type: 'integration'; id: string };
