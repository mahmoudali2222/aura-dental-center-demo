import { buildApp } from './app.js';
import { ConfigError, loadConfig } from './config/env.js';
import { pruneSessions } from './modules/auth/session.service.js';

async function main() {
  let config;
  try {
    config = loadConfig();
  } catch (err) {
    if (err instanceof ConfigError) {
      console.error(err.message); // names variables and rules only, never values
      process.exit(1);
    }
    throw err;
  }

  const { app, ctx } = await buildApp({ config });
  if (config.integrationKeys.length === 0) app.log.warn('INTEGRATION_API_KEY is not set: the n8n integration API is disabled (503).');

  const prune = setInterval(() => { pruneSessions(ctx).catch((e) => app.log.warn({ err: e?.code }, 'session pruning failed')); }, 6 * 3_600_000);
  prune.unref();

  const shutdown = async (signal: string) => {
    app.log.info({ signal }, 'shutting down');
    clearInterval(prune);
    try {
      await app.close(); // stops accepting, drains in-flight requests, closes the pool
      process.exit(0);
    } catch (err) {
      app.log.error({ err }, 'error during shutdown');
      process.exit(1);
    }
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));

  await app.listen({ host: config.host, port: config.port });
}

main().catch((err) => {
  console.error('Fatal startup error:', err?.message ?? err);
  process.exit(1);
});
