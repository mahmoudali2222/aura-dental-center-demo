import { z } from 'zod';
import { isValidZone } from '../lib/time.js';

/**
 * Environment configuration, validated once at startup.
 * Secrets (DB password, integration key) are never echoed: errors name the variable and the rule, not the value.
 * Business-editable settings (address, phone, working days ...) are NOT here; they live in the database.
 */

const boolString = z
  .enum(['true', 'false'])
  .transform((v) => v === 'true');

const rawSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  HOST: z.string().default('0.0.0.0'),
  PORT: z.coerce.number().int().min(1).max(65535).default(3480),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),

  DATABASE_URL: z.string().regex(/^postgres(ql)?:\/\//, 'must start with postgres:// or postgresql://'),
  DB_POOL_MAX: z.coerce.number().int().min(2).max(100).default(10),

  PUBLIC_APP_URL: z.string().url(),
  /** Extra browser origins allowed to call the API (comma separated), e.g. the Vite dev servers. */
  ALLOWED_ORIGINS: z.string().optional(),
  COOKIE_SECURE: boolString.optional(),
  TRUST_PROXY: boolString.default(false),

  CENTER_TIMEZONE: z.string().default('Africa/Cairo'),

  SESSION_PATIENT_TTL_HOURS: z.coerce.number().positive().default(168),
  SESSION_PATIENT_IDLE_MINUTES: z.coerce.number().positive().default(1440),
  SESSION_ADMIN_TTL_HOURS: z.coerce.number().positive().default(8),
  SESSION_ADMIN_IDLE_MINUTES: z.coerce.number().positive().default(30),

  /** Machine credential for n8n. Unset = integration API disabled (503). */
  INTEGRATION_API_KEY: z.string().min(32, 'must be at least 32 characters').optional(),
  /** Second accepted key, for zero-downtime rotation. */
  INTEGRATION_API_KEY_NEXT: z.string().min(32, 'must be at least 32 characters').optional(),
});

export interface RateLimitRule {
  max: number;
  windowMs: number;
}

export interface AppConfig {
  env: 'development' | 'test' | 'production';
  host: string;
  port: number;
  logLevel: string;
  databaseUrl: string;
  dbPoolMax: number;
  publicAppUrl: string;
  /** Origins that may send state-changing browser requests (publicAppUrl + ALLOWED_ORIGINS). */
  allowedOrigins: string[];
  cookieSecure: boolean;
  trustProxy: boolean;
  timezone: string;
  session: {
    patientTtlMs: number;
    patientIdleMs: number;
    adminTtlMs: number;
    adminIdleMs: number;
  };
  integrationKeys: string[];
  rateLimits: {
    login: RateLimitRule; // per IP, patient + admin login
    loginPerAccount: RateLimitRule; // per phone / username
    register: RateLimitRule;
    integration: RateLimitRule;
    api: RateLimitRule; // global per-IP ceiling
  };
}

export class ConfigError extends Error {
  constructor(public readonly problems: string[]) {
    super(`Invalid configuration:\n - ${problems.join('\n - ')}`);
    this.name = 'ConfigError';
  }
}

const isLocalUrl = (url: string) => /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?(\/|$)/i.test(url);

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  // Docker Compose passes every variable named in docker-compose.yml, using an EMPTY string when .env leaves it blank
  // (for example INTEGRATION_API_KEY= to switch the integration off). A blank value therefore means "not set".
  const cleaned: NodeJS.ProcessEnv = Object.fromEntries(Object.entries(env).filter(([, v]) => v !== undefined && v.trim() !== ''));
  const parsed = rawSchema.safeParse(cleaned);
  const problems: string[] = [];
  if (!parsed.success) {
    for (const issue of parsed.error.issues) problems.push(`${issue.path.join('.') || '(root)'}: ${issue.message}`);
    throw new ConfigError(problems);
  }
  const e = parsed.data;

  if (!isValidZone(e.CENTER_TIMEZONE)) problems.push(`CENTER_TIMEZONE: "${e.CENTER_TIMEZONE}" is not a valid IANA time zone`);

  const origin = new URL(e.PUBLIC_APP_URL).origin;
  const extra = (e.ALLOWED_ORIGINS ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  for (const o of extra) {
    try {
      new URL(o);
    } catch {
      problems.push(`ALLOWED_ORIGINS: "${o}" is not a valid origin`);
    }
  }

  // Secure cookies: mandatory in production unless the app is served from localhost (local Docker over plain HTTP).
  const cookieSecure = e.COOKIE_SECURE ?? e.NODE_ENV === 'production';
  if (e.NODE_ENV === 'production' && !cookieSecure && !isLocalUrl(e.PUBLIC_APP_URL)) {
    problems.push('COOKIE_SECURE must be true in production unless PUBLIC_APP_URL points at localhost');
  }
  if (e.NODE_ENV === 'production' && !isLocalUrl(e.PUBLIC_APP_URL) && !e.PUBLIC_APP_URL.startsWith('https://')) {
    problems.push('PUBLIC_APP_URL must use https:// in production (except localhost)');
  }
  if (e.INTEGRATION_API_KEY && e.INTEGRATION_API_KEY_NEXT && e.INTEGRATION_API_KEY === e.INTEGRATION_API_KEY_NEXT) {
    problems.push('INTEGRATION_API_KEY_NEXT must differ from INTEGRATION_API_KEY');
  }
  if (problems.length) throw new ConfigError(problems);

  const isTest = e.NODE_ENV === 'test';
  return {
    env: e.NODE_ENV,
    host: e.HOST,
    port: e.PORT,
    logLevel: e.LOG_LEVEL,
    databaseUrl: e.DATABASE_URL,
    dbPoolMax: e.DB_POOL_MAX,
    publicAppUrl: e.PUBLIC_APP_URL,
    allowedOrigins: [...new Set([origin, ...extra.map((o) => new URL(o).origin)])],
    cookieSecure,
    trustProxy: e.TRUST_PROXY,
    timezone: e.CENTER_TIMEZONE,
    session: {
      patientTtlMs: e.SESSION_PATIENT_TTL_HOURS * 3_600_000,
      patientIdleMs: e.SESSION_PATIENT_IDLE_MINUTES * 60_000,
      adminTtlMs: e.SESSION_ADMIN_TTL_HOURS * 3_600_000,
      adminIdleMs: e.SESSION_ADMIN_IDLE_MINUTES * 60_000,
    },
    integrationKeys: [e.INTEGRATION_API_KEY, e.INTEGRATION_API_KEY_NEXT].filter((k): k is string => !!k),
    rateLimits: {
      login: { max: isTest ? 1000 : 20, windowMs: 15 * 60_000 },
      loginPerAccount: { max: 8, windowMs: 15 * 60_000 },
      register: { max: isTest ? 1000 : 10, windowMs: 60 * 60_000 },
      integration: { max: isTest ? 100000 : 240, windowMs: 60_000 },
      api: { max: isTest ? 100000 : 600, windowMs: 60_000 },
    },
  };
}
