import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildApp } from '../app.js';
import { loadConfig } from '../config/env.js';
import { routeRegistry } from '../lib/routes.js';
import { buildEndpointMarkdown, buildOpenApi } from '../lib/openapi.js';

/**
 * Writes docs/openapi.json and docs/API_REFERENCE.md from the real route table.
 * Needs no database: the app is built (not started) with placeholder settings.
 * Usage: npm run openapi            (write files)
 *        npm run openapi -- --check (exit 1 if the committed files are out of date)
 */
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const check = process.argv.includes('--check');

const config = loadConfig({
  NODE_ENV: 'development',
  DATABASE_URL: 'postgres://openapi:openapi@127.0.0.1:1/openapi',
  PUBLIC_APP_URL: 'http://localhost:8480',
  INTEGRATION_API_KEY: 'x'.repeat(32),
  LOG_LEVEL: 'silent',
} as NodeJS.ProcessEnv);
const { app } = await buildApp({ config });
await app.ready();
const pkg = JSON.parse(await readFile(path.join(root, 'backend/package.json'), 'utf8')) as { version: string };

const outputs: [string, string][] = [
  [path.join(root, 'docs/openapi.json'), `${JSON.stringify(buildOpenApi(routeRegistry, { version: pkg.version, timezone: config.timezone }), null, 2)}\n`],
  [path.join(root, 'docs/API_REFERENCE.md'), `${buildEndpointMarkdown(routeRegistry)}\n`],
];
let stale = false;
for (const [file, content] of outputs) {
  if (check) {
    const current = await readFile(file, 'utf8').catch(() => '');
    if (current !== content) { console.error(`out of date: ${path.relative(root, file)}`); stale = true; }
  } else {
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, content);
    console.log(`wrote ${path.relative(root, file)}`);
  }
}
await app.close();
process.exit(stale ? 1 : 0);
