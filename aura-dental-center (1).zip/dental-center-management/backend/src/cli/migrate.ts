import { migrate } from '../database/migrate.js';

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is not set');
  process.exit(1);
}
try {
  const r = await migrate(url);
  console.log(r.applied.length ? `Applied ${r.applied.length} migration(s): ${r.applied.join(', ')}` : `Database is up to date (${r.alreadyApplied} migration(s) already applied).`);
} catch (err) {
  console.error((err as Error).message);
  process.exit(1);
}
