import { bootstrapAdmin } from '../modules/auth/bootstrap.js';

const url = process.env.DATABASE_URL;
const username = process.env.ADMIN_BOOTSTRAP_USERNAME;
const password = process.env.ADMIN_BOOTSTRAP_PASSWORD;
if (!url || !username || !password) {
  console.error('DATABASE_URL, ADMIN_BOOTSTRAP_USERNAME and ADMIN_BOOTSTRAP_PASSWORD must be set.');
  process.exit(1);
}
try {
  const r = await bootstrapAdmin(url, username, password);
  console.log(
    r.created
      ? `Initial admin "${r.username}" created. It must change its password at first login. You can now remove ADMIN_BOOTSTRAP_PASSWORD from your .env.`
      : 'An admin account already exists: nothing changed (this command never resets an existing account).',
  );
} catch (err) {
  console.error((err as Error).message); // never includes the password
  process.exit(1);
}
