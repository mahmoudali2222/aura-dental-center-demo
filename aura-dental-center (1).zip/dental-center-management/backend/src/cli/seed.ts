import { seedCatalog } from '../database/seed.js';

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is not set');
  process.exit(1);
}
try {
  const r = await seedCatalog(url);
  console.log(`Sample catalog: ${r.departmentsInserted} department(s) added, ${r.departmentsSkipped} already existed (left untouched).`);
} catch (err) {
  console.error((err as Error).message);
  process.exit(1);
}
