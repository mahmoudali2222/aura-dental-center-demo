import { resetAdminPassword } from '../modules/auth/bootstrap.js';

// Lock-out recovery (docs/TROUBLESHOOTING.md). Reuses ADMIN_BOOTSTRAP_USERNAME / ADMIN_BOOTSTRAP_PASSWORD from .env:
// the named administrator gets that password and must choose a new one at the next login.
const url = process.env.DATABASE_URL;
const username = process.env.ADMIN_BOOTSTRAP_USERNAME;
const password = process.env.ADMIN_BOOTSTRAP_PASSWORD;
if (!url || !username || !password) {
  console.error('DATABASE_URL, ADMIN_BOOTSTRAP_USERNAME and ADMIN_BOOTSTRAP_PASSWORD must be set.');
  process.exit(1);
}
try {
  const r = await resetAdminPassword(url, username, password);
  if (r.reset) {
    console.log(`The password of administrator "${r.username}" was replaced. All its sessions were closed and a new password must be chosen at the next login. You can now remove ADMIN_BOOTSTRAP_PASSWORD from your .env.`);
  } else {
    console.error(`No administrator named "${r.username}" exists: nothing changed. Check ADMIN_BOOTSTRAP_USERNAME.`);
    process.exit(1);
  }
} catch (err) {
  console.error((err as Error).message); // never includes the password
  process.exit(1);
}
