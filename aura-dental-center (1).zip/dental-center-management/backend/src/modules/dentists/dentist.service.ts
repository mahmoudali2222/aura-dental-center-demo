import type { Queryable } from '../../database/pool.js';
import { pgConstraint, pgErrorCode, withTransaction } from '../../database/pool.js';
import type { AppContext } from '../../types.js';
import { conflict, notFound } from '../../lib/errors.js';
import { applyTranslations, type TranslationInput, type TranslationMap } from '../../lib/translations.js';
import { recordAudit } from '../audit/audit.service.js';

interface DentistRow {
  id: string; department_id: string; photo_path: string | null; is_active: boolean; is_sample: boolean;
  tr: TranslationMap<{ name: string; bio: string }> | null;
}

const SELECT = `SELECT n.id, n.department_id, n.photo_path, n.is_active, n.is_sample,
       (SELECT jsonb_object_agg(t.locale, jsonb_build_object('name', t.display_name, 'bio', t.bio))
          FROM dentist_translations t WHERE t.dentist_id = n.id) AS tr
  FROM dentists n`;

const dto = (r: DentistRow) => ({
  id: r.id, departmentId: r.department_id, photoPath: r.photo_path, isActive: r.is_active, isSample: r.is_sample, translations: r.tr ?? {},
});

export async function listDentists(db: Queryable, departmentId?: string) {
  const { rows } = await db.query<DentistRow>(`${SELECT} WHERE ($1::uuid IS NULL OR n.department_id = $1::uuid) ORDER BY n.department_id, n.is_active DESC, n.created_at`, [departmentId ?? null]);
  return rows.map(dto);
}

export async function getDentist(db: Queryable, id: string) {
  const { rows } = await db.query<DentistRow>(`${SELECT} WHERE n.id = $1`, [id]);
  if (!rows[0]) throw notFound('DENTIST_NOT_FOUND', 'Dentist not found');
  return dto(rows[0]);
}

const SPEC = { table: 'dentist_translations', idColumn: 'dentist_id', primary: 'display_name', others: ['bio'] };

/** Admin payloads use { name, bio }; the table columns are display_name / bio. */
function toColumns(t: Partial<Record<'ar' | 'en' | 'fr', { name?: string; bio?: string }>> | undefined): TranslationInput | undefined {
  if (!t) return undefined;
  const out: TranslationInput = {};
  for (const l of ['ar', 'en', 'fr'] as const) {
    const e = t[l];
    if (e) out[l] = { ...(e.name !== undefined ? { display_name: e.name } : {}), ...(e.bio !== undefined ? { bio: e.bio } : {}) };
  }
  return out;
}

export interface DentistInput {
  photoPath?: string | null;
  isActive?: boolean;
  translations?: Partial<Record<'ar' | 'en' | 'fr', { name?: string; bio?: string }>>;
}

/**
 * Assigns a dentist to a department. A department has exactly one ACTIVE dentist, so when one already exists the caller
 * must pass `replaceExisting`: the old dentist is deactivated (kept for history) in the same transaction.
 */
export async function createDentist(app: AppContext, adminId: string, input: DentistInput & { departmentId: string; replaceExisting?: boolean }, ip?: string) {
  try {
    const id = await withTransaction(app.db, async (tx) => {
      if (!(await tx.query('SELECT 1 FROM departments WHERE id = $1 FOR UPDATE', [input.departmentId])).rowCount) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
      const current = (await tx.query<{ id: string }>('SELECT id FROM dentists WHERE department_id = $1 AND is_active', [input.departmentId])).rows[0];
      if (current) {
        if (!input.replaceExisting) throw conflict('DEPARTMENT_HAS_DENTIST', 'This department already has an active dentist; pass replaceExisting to replace them', { currentDentistId: current.id });
        await tx.query('UPDATE dentists SET is_active = false WHERE id = $1', [current.id]);
      }
      const res = await tx.query<{ id: string }>('INSERT INTO dentists (department_id, photo_path, is_active) VALUES ($1,$2,true) RETURNING id', [input.departmentId, input.photoPath ?? null]);
      const id = res.rows[0]!.id;
      await applyTranslations(tx, SPEC, id, toColumns(input.translations));
      await recordAudit(tx, {
        actorType: 'admin', actorId: adminId, action: current ? 'dentist.replaced' : 'dentist.created', entityType: 'dentist', entityId: id, ip,
        metadata: { departmentId: input.departmentId, previousDentistId: current?.id },
      });
      return id;
    });
    return getDentist(app.db, id);
  } catch (err) {
    if (pgErrorCode(err) === '23505' && pgConstraint(err) === 'dentists_one_active_per_department') throw conflict('DEPARTMENT_HAS_DENTIST', 'This department already has an active dentist');
    throw err;
  }
}

export async function updateDentist(app: AppContext, adminId: string, id: string, input: DentistInput, ip?: string) {
  try {
    await withTransaction(app.db, async (tx) => {
      if (!(await tx.query('SELECT 1 FROM dentists WHERE id = $1 FOR UPDATE', [id])).rowCount) throw notFound('DENTIST_NOT_FOUND', 'Dentist not found');
      await tx.query(
        `UPDATE dentists SET photo_path = CASE WHEN $2::boolean THEN $3 ELSE photo_path END, is_active = COALESCE($4, is_active),
                             is_sample = CASE WHEN $5::boolean THEN false ELSE is_sample END
          WHERE id = $1`,
        // Editing the name/bio means the admin is replacing the placeholder: it is no longer "sample" data.
        [id, input.photoPath !== undefined, input.photoPath ?? null, input.isActive ?? null, input.translations !== undefined],
      );
      await applyTranslations(tx, SPEC, id, toColumns(input.translations));
      await recordAudit(tx, {
        actorType: 'admin', actorId: adminId, action: 'dentist.updated', entityType: 'dentist', entityId: id, ip,
        metadata: { fields: Object.keys(input).filter((k) => (input as Record<string, unknown>)[k] !== undefined) },
      });
    });
    return getDentist(app.db, id);
  } catch (err) {
    if (pgErrorCode(err) === '23505' && pgConstraint(err) === 'dentists_one_active_per_department') throw conflict('DEPARTMENT_HAS_DENTIST', 'This department already has another active dentist');
    throw err;
  }
}
