import type { Tx } from '../../database/pool.js';
import { pgConstraint, pgErrorCode, withTransaction } from '../../database/pool.js';
import type { Actor, AppContext } from '../../types.js';
import { AppError, badRequest, conflict, forbidden, notFound, unprocessable } from '../../lib/errors.js';
import { centerToday, hasSelfServiceNotice, slotWindow, toCenterClock, toCenterIso, SELF_SERVICE_NOTICE_MS } from '../../lib/time.js';
import { fallbackChain, pickText, type Locale } from '../../lib/locale.js';
import type { TranslationMap } from '../../lib/translations.js';
import { recordAudit } from '../audit/audit.service.js';
import {
  loadBookedSlots,
  loadClosures,
  loadSchedulingSettings,
  slotUnavailableReason,
  type UnavailableReason,
} from '../scheduling/scheduling.service.js';
import { loadCenter } from '../center/center.service.js';

/**
 * The ONLY module that writes to `appointments`. The website, the admin dashboard and the n8n integration
 * all call these functions, so every booking rule is implemented exactly once.
 *
 * Lifecycle (also enforced by a database trigger):
 *   booked -> cancelled | completed | no_show;  no_show -> completed (admin correction);  cancelled/completed are terminal.
 * Capacity: booked, completed and no_show keep their slot; cancelled releases it.
 */

export type AppointmentStatus = 'booked' | 'cancelled' | 'completed' | 'no_show';
export type CreatedVia = 'web' | 'admin' | 'telegram';

export const APPOINTMENT_SELECT = `
  SELECT a.id, a.patient_id, a.department_id, a.dentist_id, a.service_id, a.appointment_date, a.slot_number,
         a.starts_at, a.ends_at, a.status, a.patient_note, a.created_via, a.rescheduled_count,
         a.cancelled_at, a.cancelled_by, a.cancel_reason, a.created_at,
         d.slug AS department_slug,
         p.full_name AS patient_name, p.phone_e164 AS patient_phone,
         (SELECT jsonb_object_agg(t.locale, jsonb_build_object('name', t.name)) FROM department_translations t WHERE t.department_id = a.department_id) AS department_tr,
         (SELECT jsonb_object_agg(t.locale, jsonb_build_object('name', t.display_name)) FROM dentist_translations t WHERE t.dentist_id = a.dentist_id) AS dentist_tr,
         (SELECT jsonb_object_agg(t.locale, jsonb_build_object('name', t.name)) FROM service_translations t WHERE t.service_id = a.service_id) AS service_tr
    FROM appointments a
    JOIN departments d ON d.id = a.department_id
    JOIN patients p ON p.id = a.patient_id`;

export interface AppointmentRow {
  id: string;
  patient_id: string;
  department_id: string;
  dentist_id: string | null;
  service_id: string | null;
  appointment_date: string;
  slot_number: number;
  starts_at: Date;
  ends_at: Date;
  status: AppointmentStatus;
  patient_note: string | null;
  created_via: CreatedVia;
  rescheduled_count: number;
  cancelled_at: Date | null;
  cancelled_by: string | null;
  cancel_reason: string | null;
  created_at: Date;
  department_slug: string;
  patient_name: string;
  patient_phone: string;
  department_tr: TranslationMap<{ name: string }> | null;
  dentist_tr: TranslationMap<{ name: string }> | null;
  service_tr: TranslationMap<{ name: string }> | null;
}

export interface DtoOptions {
  locale: Locale | null;
  defaultLocale: Locale;
  /** Admin views include the patient's identity; patient/integration views do not need it. */
  includePatient?: boolean;
}

/** Maps a DB row to the API shape, computing the self-service policy (24 h rule) at read time. */
export function toAppointmentDto(app: AppContext, row: AppointmentRow, opts: DtoOptions) {
  const zone = app.config.timezone;
  const chain = fallbackChain(opts.locale, opts.defaultLocale);
  const now = app.clock.now();
  const isBooked = row.status === 'booked';
  const noticeOk = hasSelfServiceNotice(row.starts_at, now);
  const selfServiceAllowed = isBooked && noticeOk;
  return {
    id: row.id,
    status: row.status,
    department: { id: row.department_id, slug: row.department_slug, name: pickText(row.department_tr, chain, 'name') },
    dentist: row.dentist_id ? { id: row.dentist_id, name: pickText(row.dentist_tr, chain, 'name') } : null,
    service: row.service_id ? { id: row.service_id, name: pickText(row.service_tr, chain, 'name') } : null,
    date: row.appointment_date,
    slotNumber: row.slot_number,
    startsAt: toCenterIso(zone, row.starts_at),
    endsAt: toCenterIso(zone, row.ends_at),
    startTime: toCenterClock(zone, row.starts_at),
    endTime: toCenterClock(zone, row.ends_at),
    endsNextDay: centerToday(zone, row.ends_at) !== row.appointment_date,
    patientNote: row.patient_note,
    createdVia: row.created_via,
    rescheduledCount: row.rescheduled_count,
    cancelledAt: row.cancelled_at ? toCenterIso(zone, row.cancelled_at) : null,
    cancelledBy: row.cancelled_by,
    selfService: {
      canCancel: selfServiceAllowed,
      canReschedule: selfServiceAllowed,
      /** Last instant at which the patient may still cancel/reschedule on their own. */
      deadline: toCenterIso(zone, new Date(row.starts_at.getTime() - SELF_SERVICE_NOTICE_MS)),
      blockedReason: !isBooked ? 'NOT_BOOKED' : noticeOk ? null : 'WITHIN_24H_WINDOW',
    },
    ...(opts.includePatient
      ? { patient: { id: row.patient_id, fullName: row.patient_name, phone: row.patient_phone }, cancelReason: row.cancel_reason }
      : {}),
  };
}

export async function dtoOptions(app: AppContext, locale: Locale | null, includePatient = false): Promise<DtoOptions> {
  const c = await loadCenter(app.db);
  return { locale, defaultLocale: c.defaultLocale, includePatient };
}

// -----------------------------------------------------------------------------------------------
// Error mapping
// -----------------------------------------------------------------------------------------------
const REASON_ERRORS: Record<UnavailableReason, () => AppError> = {
  slot_disabled: () => unprocessable('DATE_CLOSED', 'This time slot is not offered'),
  closed_day: () => unprocessable('DATE_CLOSED', 'The center is closed on this day'),
  department_day_off: () => unprocessable('DEPARTMENT_NOT_WORKING_DAY', 'This department does not work on this day of the week'),
  closure: () => unprocessable('DATE_CLOSED', 'The center is closed on this date'),
  past: () => unprocessable('SLOT_IN_PAST', 'This slot has already started or passed'),
  beyond_horizon: () => unprocessable('BEYOND_BOOKING_HORIZON', 'This date is too far in the future to book'),
  booked: () => conflict('SLOT_UNAVAILABLE', 'This slot is already booked'),
  capacity: () => conflict('DAILY_CAPACITY_REACHED', 'The department is fully booked for this day'),
};

/** Translates a database constraint violation raised by a concurrent booking into a clean API error. */
function mapBookingConstraintError(err: unknown): never {
  const code = pgErrorCode(err);
  const constraint = pgConstraint(err);
  if (code === '23505' && constraint === 'appointments_active_slot_uq') throw conflict('SLOT_UNAVAILABLE', 'This slot has just been booked by someone else');
  if (code === '23P01' && constraint === 'appointments_no_department_overlap') throw conflict('SLOT_UNAVAILABLE', 'This slot overlaps an existing appointment');
  if (code === '23P01' && constraint === 'appointments_no_patient_overlap') throw conflict('PATIENT_OVERLAP', 'The patient already has an appointment at this time');
  throw err;
}

async function lockDepartmentDay(tx: Tx, departmentId: string, date: string): Promise<void> {
  // Serializes everyone booking/moving into this department-day. Released automatically at COMMIT/ROLLBACK.
  await tx.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`appointments:${departmentId}:${date}`]);
}

// -----------------------------------------------------------------------------------------------
// Create
// -----------------------------------------------------------------------------------------------
export interface CreateInput {
  patientId: string;
  departmentId: string;
  serviceId?: string | null;
  date: string;
  slotNumber: number;
  patientNote?: string | null;
  createdVia: CreatedVia;
  actor: Actor;
  ip?: string;
}

export async function createAppointment(app: AppContext, input: CreateInput): Promise<string> {
  const zone = app.config.timezone;
  try {
    return await withTransaction(app.db, async (tx) => {
      // FOR SHARE: an administrator changing the department's working days (which takes a conflicting lock) and this booking
      // cannot interleave, so a booking can never slip onto a day that has just been switched off.
      const dept = (await tx.query<{ is_active: boolean; working_days: number[] }>('SELECT is_active, working_days FROM departments WHERE id = $1 FOR SHARE', [input.departmentId])).rows[0];
      if (!dept) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
      if (!dept.is_active) throw unprocessable('DEPARTMENT_INACTIVE', 'This department is not accepting bookings');
      const dentist = (await tx.query<{ id: string }>('SELECT id FROM dentists WHERE department_id = $1 AND is_active', [input.departmentId])).rows[0];
      if (!dentist) throw unprocessable('NO_ACTIVE_DENTIST', 'This department has no assigned dentist right now');

      if (input.serviceId) {
        const svc = (await tx.query<{ department_id: string; is_active: boolean }>('SELECT department_id, is_active FROM services WHERE id = $1', [input.serviceId])).rows[0];
        if (!svc || svc.department_id !== input.departmentId) throw badRequest('SERVICE_NOT_IN_DEPARTMENT', 'The service does not belong to this department', [{ field: 'serviceId', code: 'SERVICE_NOT_IN_DEPARTMENT' }]);
        if (!svc.is_active) throw unprocessable('SERVICE_INACTIVE', 'This service is not available');
      }

      const patient = (await tx.query<{ is_active: boolean }>('SELECT is_active FROM patients WHERE id = $1', [input.patientId])).rows[0];
      if (!patient) throw notFound('PATIENT_NOT_FOUND', 'Patient not found');
      if (!patient.is_active) throw forbidden('ACCOUNT_DISABLED', 'This account is disabled');

      await lockDepartmentDay(tx, input.departmentId, input.date);

      const settings = await loadSchedulingSettings(tx);
      const slot = settings.slots.find((s) => s.slotNumber === input.slotNumber);
      if (!slot) throw badRequest('INVALID_SLOT', 'Unknown slot', [{ field: 'slotNumber', code: 'INVALID_SLOT' }]);
      const closures = await loadClosures(tx, input.departmentId, input.date, input.date);
      const booked = (await loadBookedSlots(tx, input.departmentId, input.date, input.date)).get(input.date) ?? new Set<number>();
      const reason = slotUnavailableReason({ zone, now: app.clock.now(), date: input.date, slot, settings, departmentWorkingDays: dept.working_days, closures, bookedSlotNumbers: booked });
      if (reason) throw REASON_ERRORS[reason]();

      const w = slotWindow(zone, input.date, slot.startTime);
      const res = await tx.query<{ id: string }>(
        `INSERT INTO appointments (patient_id, department_id, dentist_id, service_id, appointment_date, slot_number,
                                   starts_at, ends_at, patient_note, created_via, created_by_admin)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
        [
          input.patientId, input.departmentId, dentist.id, input.serviceId ?? null, input.date, slot.slotNumber,
          w.startsAt, w.endsAt, input.patientNote ?? null, input.createdVia, input.actor.type === 'admin' ? input.actor.id : null,
        ],
      );
      const id = res.rows[0]!.id;
      await recordAudit(tx, {
        actorType: input.actor.type, actorId: input.actor.id, action: 'appointment.created', entityType: 'appointment', entityId: id, ip: input.ip,
        metadata: { patientId: input.patientId, departmentId: input.departmentId, date: input.date, slotNumber: slot.slotNumber, via: input.createdVia },
      });
      return id;
    });
  } catch (err) {
    return mapBookingConstraintError(err);
  }
}

// -----------------------------------------------------------------------------------------------
// Cancel / reschedule (patient self-service, Telegram, and admin with explicit override)
// -----------------------------------------------------------------------------------------------
export interface PolicyOptions {
  actor: Actor;
  /** Admin only: allow acting inside the 24-hour window. Requires a reason. */
  override?: boolean;
  reason?: string;
  ip?: string;
}

/** Locks and loads the appointment; `patientScope` makes another patient's row indistinguishable from "not found". */
async function lockAppointment(tx: Tx, id: string, patientScope?: string) {
  const res = await tx.query<{
    id: string; patient_id: string; department_id: string; appointment_date: string; slot_number: number;
    starts_at: Date; ends_at: Date; status: AppointmentStatus;
  }>(
    `SELECT id, patient_id, department_id, appointment_date, slot_number, starts_at, ends_at, status
       FROM appointments WHERE id = $1 AND ($2::uuid IS NULL OR patient_id = $2::uuid) FOR UPDATE`,
    [id, patientScope ?? null],
  );
  const row = res.rows[0];
  if (!row) throw notFound('APPOINTMENT_NOT_FOUND', 'Appointment not found');
  return row;
}

/** Applies the 24-hour policy. Non-admin actors can never bypass it; admins can only with override + reason. */
function enforceNoticePolicy(app: AppContext, startsAt: Date, opts: PolicyOptions): { overridden: boolean } {
  const now = app.clock.now();
  if (hasSelfServiceNotice(startsAt, now)) return { overridden: false };
  const details = { deadline: toCenterIso(app.config.timezone, new Date(startsAt.getTime() - SELF_SERVICE_NOTICE_MS)) };
  if (opts.actor.type !== 'admin') throw unprocessable('WITHIN_24H_WINDOW', 'Appointments can only be changed at least 24 hours before they start; please contact the center', details);
  if (!opts.override) throw unprocessable('WITHIN_24H_WINDOW', 'Less than 24 hours remain; repeat with override and a reason to proceed', { ...details, overrideAvailable: true });
  if (!opts.reason || opts.reason.trim().length < 3) throw badRequest('OVERRIDE_REASON_REQUIRED', 'A reason is required to override the 24-hour policy', [{ field: 'reason', code: 'OVERRIDE_REASON_REQUIRED' }]);
  return { overridden: true };
}

export async function cancelAppointment(app: AppContext, id: string, opts: PolicyOptions & { patientScope?: string }): Promise<void> {
  await withTransaction(app.db, async (tx) => {
    const row = await lockAppointment(tx, id, opts.patientScope);
    if (row.status !== 'booked') throw conflict('APPOINTMENT_NOT_ACTIVE', `Only booked appointments can be cancelled (current status: ${row.status})`);
    const { overridden } = enforceNoticePolicy(app, row.starts_at, opts);
    await tx.query(
      `UPDATE appointments SET status = 'cancelled', cancelled_at = $2, cancelled_by = $3, cancel_reason = $4 WHERE id = $1`,
      [id, app.clock.now(), opts.actor.type === 'integration' ? 'telegram' : opts.actor.type, opts.reason?.trim().slice(0, 500) || null],
    );
    await recordAudit(tx, {
      actorType: opts.actor.type, actorId: opts.actor.id, action: 'appointment.cancelled', entityType: 'appointment', entityId: id, ip: opts.ip,
      metadata: { patientId: row.patient_id, date: row.appointment_date, slotNumber: row.slot_number, policyOverridden: overridden, reason: opts.reason },
    });
  });
}

export async function rescheduleAppointment(
  app: AppContext,
  id: string,
  target: { date: string; slotNumber: number },
  opts: PolicyOptions & { patientScope?: string },
): Promise<void> {
  const zone = app.config.timezone;
  try {
    await withTransaction(app.db, async (tx) => {
      const row = await lockAppointment(tx, id, opts.patientScope);
      if (row.status !== 'booked') throw conflict('APPOINTMENT_NOT_ACTIVE', `Only booked appointments can be rescheduled (current status: ${row.status})`);
      // The 24-hour rule is measured against the ORIGINAL start time.
      const { overridden } = enforceNoticePolicy(app, row.starts_at, opts);
      if (row.appointment_date === target.date && row.slot_number === target.slotNumber) {
        throw badRequest('RESCHEDULE_NO_CHANGE', 'The new slot is the same as the current one');
      }

      const dept = (await tx.query<{ is_active: boolean; working_days: number[] }>('SELECT is_active, working_days FROM departments WHERE id = $1 FOR SHARE', [row.department_id])).rows[0];
      if (!dept?.is_active) throw unprocessable('DEPARTMENT_INACTIVE', 'This department is not accepting bookings');
      const dentist = (await tx.query<{ id: string }>('SELECT id FROM dentists WHERE department_id = $1 AND is_active', [row.department_id])).rows[0];
      if (!dentist) throw unprocessable('NO_ACTIVE_DENTIST', 'This department has no assigned dentist right now');

      await lockDepartmentDay(tx, row.department_id, target.date);

      const settings = await loadSchedulingSettings(tx);
      const slot = settings.slots.find((s) => s.slotNumber === target.slotNumber);
      if (!slot) throw badRequest('INVALID_SLOT', 'Unknown slot', [{ field: 'slotNumber', code: 'INVALID_SLOT' }]);
      const closures = await loadClosures(tx, row.department_id, target.date, target.date);
      // Exclude this appointment itself: moving within the same day must not count it twice.
      const booked = (await loadBookedSlots(tx, row.department_id, target.date, target.date, id)).get(target.date) ?? new Set<number>();
      const reason = slotUnavailableReason({ zone, now: app.clock.now(), date: target.date, slot, settings, departmentWorkingDays: dept.working_days, closures, bookedSlotNumbers: booked });
      if (reason) throw REASON_ERRORS[reason]();

      const w = slotWindow(zone, target.date, slot.startTime);
      await tx.query(
        `UPDATE appointments
            SET appointment_date = $2, slot_number = $3, starts_at = $4, ends_at = $5, dentist_id = $6,
                rescheduled_count = rescheduled_count + 1
          WHERE id = $1`,
        [id, target.date, slot.slotNumber, w.startsAt, w.endsAt, dentist.id],
      );
      await recordAudit(tx, {
        actorType: opts.actor.type, actorId: opts.actor.id, action: 'appointment.rescheduled', entityType: 'appointment', entityId: id, ip: opts.ip,
        metadata: {
          patientId: row.patient_id, fromDate: row.appointment_date, fromSlot: row.slot_number,
          toDate: target.date, toSlot: slot.slotNumber, policyOverridden: overridden, reason: opts.reason,
        },
      });
    });
  } catch (err) {
    mapBookingConstraintError(err);
  }
}

// -----------------------------------------------------------------------------------------------
// Admin status changes (operational tracking)
// -----------------------------------------------------------------------------------------------
export async function setAppointmentStatus(app: AppContext, id: string, status: 'completed' | 'no_show', actor: Actor, ip?: string): Promise<void> {
  await withTransaction(app.db, async (tx) => {
    const row = await lockAppointment(tx, id);
    const allowed = (row.status === 'booked') || (row.status === 'no_show' && status === 'completed');
    if (!allowed || row.status === status) throw conflict('INVALID_STATUS_TRANSITION', `Cannot change status from ${row.status} to ${status}`, { from: row.status, to: status });
    if (app.clock.now().getTime() < row.starts_at.getTime()) throw unprocessable('APPOINTMENT_NOT_STARTED', 'An appointment cannot be completed or marked no-show before it starts');
    await tx.query('UPDATE appointments SET status = $2 WHERE id = $1', [id, status]);
    await recordAudit(tx, {
      actorType: actor.type, actorId: actor.id, action: 'appointment.status_changed', entityType: 'appointment', entityId: id, ip,
      metadata: { patientId: row.patient_id, from: row.status, to: status },
    });
  });
}

// -----------------------------------------------------------------------------------------------
// Reads
// -----------------------------------------------------------------------------------------------
export async function getAppointmentRow(app: AppContext, id: string, patientScope?: string): Promise<AppointmentRow> {
  const res = await app.db.query<AppointmentRow>(`${APPOINTMENT_SELECT} WHERE a.id = $1 AND ($2::uuid IS NULL OR a.patient_id = $2::uuid)`, [id, patientScope ?? null]);
  const row = res.rows[0];
  if (!row) throw notFound('APPOINTMENT_NOT_FOUND', 'Appointment not found');
  return row;
}

export type PatientScope = 'upcoming' | 'history' | 'all';

export async function listPatientAppointments(app: AppContext, patientId: string, scope: PatientScope, page: number, pageSize: number) {
  const now = app.clock.now();
  const where =
    scope === 'upcoming' ? `a.status = 'booked' AND a.ends_at > $2`
    : scope === 'history' ? `NOT (a.status = 'booked' AND a.ends_at > $2)`
    : `$2::timestamptz IS NOT NULL`;
  const order = scope === 'upcoming' ? 'a.starts_at ASC' : 'a.starts_at DESC';
  const count = await app.db.query<{ n: string }>(`SELECT count(*) AS n FROM appointments a WHERE a.patient_id = $1 AND ${where}`, [patientId, now]);
  const rows = await app.db.query<AppointmentRow>(
    `${APPOINTMENT_SELECT} WHERE a.patient_id = $1 AND ${where} ORDER BY ${order} LIMIT $3 OFFSET $4`,
    [patientId, now, pageSize, (page - 1) * pageSize],
  );
  return { rows: rows.rows, total: Number(count.rows[0]!.n) };
}
