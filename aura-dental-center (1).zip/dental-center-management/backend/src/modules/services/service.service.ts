import type { Queryable } from '../../database/pool.js';
import { withTransaction } from '../../database/pool.js';
import type { AppContext } from '../../types.js';
import { notFound } from '../../lib/errors.js';
import { fallbackChain, pickText, type Locale } from '../../lib/locale.js';
import { applyTranslations, type TranslationInput, type TranslationMap } from '../../lib/translations.js';
import { recordAudit } from '../audit/audit.service.js';

type SvcTr = TranslationMap<{ name: string; description: string }>;

interface SvcRow {
  id: string; department_id: string; price: string | null; display_order: number; is_active: boolean; is_sample: boolean;
  image_path: string | null; tr: SvcTr | null;
}

const SVC_SELECT = `SELECT s.id, s.department_id, s.price, s.display_order, s.is_active, s.is_sample, s.image_path,
       (SELECT jsonb_object_agg(t.locale, jsonb_build_object('name', t.name, 'description', t.description))
          FROM service_translations t WHERE t.service_id = s.id) AS tr
  FROM services s`;

export async function listPublicServices(db: Queryable, departmentId: string, chain: Locale[], currency: string) {
  const { rows } = await db.query<SvcRow>(`${SVC_SELECT} WHERE s.department_id = $1 AND s.is_active ORDER BY s.display_order, s.id`, [departmentId]);
  return rows
    .map((r) => ({
      id: r.id,
      name: pickText(r.tr, chain, 'name'),
      description: pickText(r.tr, chain, 'description'),
      price: r.price === null ? null : Number(r.price),
      currency: r.price === null ? null : currency,
      imagePath: r.image_path,
      isSample: r.is_sample,
    }))
    .filter((s) => s.name !== '');
}

export function adminServiceDto(r: SvcRow) {
  return {
    id: r.id, departmentId: r.department_id, price: r.price === null ? null : Number(r.price),
    displayOrder: r.display_order, isActive: r.is_active, isSample: r.is_sample, imagePath: r.image_path, translations: r.tr ?? {},
  };
}

export async function listAdminServices(db: Queryable, departmentId?: string) {
  const { rows } = await db.query<SvcRow>(`${SVC_SELECT} WHERE ($1::uuid IS NULL OR s.department_id = $1::uuid) ORDER BY s.department_id, s.display_order, s.id`, [departmentId ?? null]);
  return rows.map(adminServiceDto);
}

export async function getAdminService(db: Queryable, id: string) {
  const { rows } = await db.query<SvcRow>(`${SVC_SELECT} WHERE s.id = $1`, [id]);
  if (!rows[0]) throw notFound('SERVICE_NOT_FOUND', 'Service not found');
  return adminServiceDto(rows[0]);
}

const SVC_TRANSLATION = { table: 'service_translations', idColumn: 'service_id', primary: 'name', others: ['description'] };

export interface ServiceInput {
  departmentId?: string;
  price?: number | null;
  displayOrder?: number;
  isActive?: boolean;
  imagePath?: string | null;
  translations?: TranslationInput;
}

export async function createService(app: AppContext, adminId: string, input: ServiceInput & { departmentId: string }, ip?: string) {
  const id = await withTransaction(app.db, async (tx) => {
    if (!(await tx.query('SELECT 1 FROM departments WHERE id = $1', [input.departmentId])).rowCount) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
    const res = await tx.query<{ id: string }>(
      'INSERT INTO services (department_id, price, display_order, is_active, image_path) VALUES ($1,$2,$3,$4,$5) RETURNING id',
      [input.departmentId, input.price ?? null, input.displayOrder ?? 0, input.isActive ?? true, input.imagePath ?? null],
    );
    const id = res.rows[0]!.id;
    await applyTranslations(tx, SVC_TRANSLATION, id, input.translations);
    await recordAudit(tx, { actorType: 'admin', actorId: adminId, action: 'service.created', entityType: 'service', entityId: id, ip, metadata: { departmentId: input.departmentId } });
    return id;
  });
  return getAdminService(app.db, id);
}

export async function updateService(app: AppContext, adminId: string, id: string, input: ServiceInput, ip?: string) {
  await withTransaction(app.db, async (tx) => {
    if (!(await tx.query('SELECT 1 FROM services WHERE id = $1 FOR UPDATE', [id])).rowCount) throw notFound('SERVICE_NOT_FOUND', 'Service not found');
    if (input.departmentId && !(await tx.query('SELECT 1 FROM departments WHERE id = $1', [input.departmentId])).rowCount) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
    await tx.query(
      `UPDATE services SET
         department_id = COALESCE($2, department_id),
         price = CASE WHEN $3::boolean THEN $4 ELSE price END,
         display_order = COALESCE($5, display_order), is_active = COALESCE($6, is_active),
         image_path = CASE WHEN $7::boolean THEN $8 ELSE image_path END
       WHERE id = $1`,
      [id, input.departmentId ?? null, input.price !== undefined, input.price ?? null, input.displayOrder ?? null, input.isActive ?? null, input.imagePath !== undefined, input.imagePath ?? null],
    );
    await applyTranslations(tx, SVC_TRANSLATION, id, input.translations);
    await recordAudit(tx, {
      actorType: 'admin', actorId: adminId, action: 'service.updated', entityType: 'service', entityId: id, ip,
      metadata: { fields: Object.keys(input).filter((k) => (input as Record<string, unknown>)[k] !== undefined) },
    });
  });
  return getAdminService(app.db, id);
}

export { fallbackChain };
