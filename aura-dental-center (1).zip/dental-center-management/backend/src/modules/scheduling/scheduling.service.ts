import type { Queryable } from '../../database/pool.js';
import type { AppContext } from '../../types.js';
import { addDays, centerToday, diffDays, isoWeekday, slotWindow, toCenterClock, toCenterIso } from '../../lib/time.js';
import { loadCenter, loadSlotTemplates, type SlotTemplate } from '../center/center.service.js';

/** A department can hold at most this many active appointments per calendar day (= the four daily slots). */
export const DAILY_CAPACITY = 4;
/** Statuses that keep a slot and count toward daily capacity. Only 'cancelled' releases it. */
export const ACTIVE_STATUSES = ['booked', 'completed', 'no_show'] as const;

export interface SchedulingSettings {
  workingDays: number[];
  horizonDays: number;
  slots: SlotTemplate[];
}

export interface ClosureRange {
  from: string;
  to: string;
}

export type UnavailableReason = 'slot_disabled' | 'closed_day' | 'department_day_off' | 'closure' | 'past' | 'beyond_horizon' | 'booked' | 'capacity';

export async function loadSchedulingSettings(db: Queryable): Promise<SchedulingSettings> {
  const [c, slots] = await Promise.all([loadCenter(db), loadSlotTemplates(db)]);
  return { workingDays: c.workingDays, horizonDays: c.bookingHorizonDays, slots };
}

/** Closures (center-wide or for this department) that overlap [from, to]. */
export async function loadClosures(db: Queryable, departmentId: string, from: string, to: string): Promise<ClosureRange[]> {
  const { rows } = await db.query<{ date_from: string; date_to: string }>(
    `SELECT date_from, date_to FROM closures
      WHERE (department_id IS NULL OR department_id = $1) AND date_from <= $3::date AND date_to >= $2::date`,
    [departmentId, from, to],
  );
  return rows.map((r) => ({ from: r.date_from, to: r.date_to }));
}

/** Active (capacity-consuming) appointments of a department in [from, to], grouped by date -> slot numbers. */
export async function loadBookedSlots(db: Queryable, departmentId: string, from: string, to: string, excludeAppointmentId?: string): Promise<Map<string, Set<number>>> {
  const { rows } = await db.query<{ appointment_date: string; slot_number: number }>(
    `SELECT appointment_date, slot_number FROM appointments
      WHERE department_id = $1 AND appointment_date BETWEEN $2::date AND $3::date
        AND status IN ('booked','completed','no_show') AND ($4::uuid IS NULL OR id <> $4::uuid)`,
    [departmentId, from, to, excludeAppointmentId ?? null],
  );
  const map = new Map<string, Set<number>>();
  for (const r of rows) {
    const set = map.get(r.appointment_date) ?? new Set<number>();
    set.add(r.slot_number);
    map.set(r.appointment_date, set);
  }
  return map;
}

export interface SlotCheckInput {
  zone: string;
  now: Date;
  date: string;
  slot: SlotTemplate;
  settings: SchedulingSettings;
  /** ISO weekdays (1 = Monday ... 7 = Sunday) on which THIS department works. The center's own working days apply on top. */
  departmentWorkingDays: number[];
  closures: ClosureRange[];
  /** Slot numbers already taken in this department on this date (by other appointments). */
  bookedSlotNumbers: Set<number>;
}

/**
 * THE single definition of "is this slot bookable?". Both the availability endpoint and the booking transaction
 * call it, so what patients are shown and what the server accepts can never disagree.
 * Returns null when bookable, otherwise the first rule that blocks it.
 */
export function slotUnavailableReason(i: SlotCheckInput): UnavailableReason | null {
  if (!i.slot.isActive) return 'slot_disabled';
  const weekday = isoWeekday(i.date);
  if (!i.settings.workingDays.includes(weekday)) return 'closed_day';
  if (!i.departmentWorkingDays.includes(weekday)) return 'department_day_off';
  if (i.closures.some((c) => i.date >= c.from && i.date <= c.to)) return 'closure';
  const today = centerToday(i.zone, i.now);
  const { startsAt } = slotWindow(i.zone, i.date, i.slot.startTime);
  if (startsAt.getTime() <= i.now.getTime()) return 'past';
  if (diffDays(today, i.date) > i.settings.horizonDays) return 'beyond_horizon';
  if (i.bookedSlotNumbers.has(i.slot.slotNumber)) return 'booked';
  if (i.bookedSlotNumbers.size >= DAILY_CAPACITY) return 'capacity';
  return null;
}

export type DayStatus = 'open' | 'full' | 'closed' | 'past' | 'beyond_horizon' | 'unavailable';

export interface AvailabilityDay {
  date: string;
  status: DayStatus;
  availableCount: number;
  /** Only genuinely bookable slots are listed. */
  slots: {
    slotNumber: number;
    startTime: string;
    endTime: string;
    endsNextDay: boolean;
    startsAt: string;
    endsAt: string;
  }[];
}

/**
 * Availability for one department over [from, to] (inclusive), in the center's calendar.
 * `departmentBookable` is false when the department has no active dentist; every day is then 'unavailable'.
 * `departmentWorkingDays` are the department's own working days; a day it does not work is reported as 'closed'.
 */
export async function getAvailability(
  app: AppContext, departmentId: string, from: string, to: string, departmentBookable: boolean, departmentWorkingDays: number[],
): Promise<AvailabilityDay[]> {
  const settings = await loadSchedulingSettings(app.db);
  const closures = await loadClosures(app.db, departmentId, from, to);
  const booked = await loadBookedSlots(app.db, departmentId, from, to);
  const now = app.clock.now();
  const days: AvailabilityDay[] = [];

  for (let date = from; date <= to; date = addDays(date, 1)) {
    const taken = booked.get(date) ?? new Set<number>();
    const slots: AvailabilityDay['slots'] = [];
    const reasons = new Set<UnavailableReason>();
    for (const slot of settings.slots) {
      const reason = departmentBookable ? slotUnavailableReason({ zone: app.config.timezone, now, date, slot, settings, departmentWorkingDays, closures, bookedSlotNumbers: taken }) : null;
      if (departmentBookable && reason) {
        reasons.add(reason);
        continue;
      }
      if (!departmentBookable) continue;
      const w = slotWindow(app.config.timezone, date, slot.startTime);
      slots.push({
        slotNumber: slot.slotNumber,
        startTime: slot.startTime,
        endTime: toCenterClock(app.config.timezone, w.endsAt),
        // Derived from the real window: on the two DST-change nights the 22:00 slot ends at 23:00 or 01:00 local time.
        endsNextDay: centerToday(app.config.timezone, w.endsAt) !== date,
        startsAt: toCenterIso(app.config.timezone, w.startsAt),
        endsAt: toCenterIso(app.config.timezone, w.endsAt),
      });
    }
    let status: DayStatus;
    if (!departmentBookable) status = 'unavailable';
    else if (slots.length > 0) status = 'open';
    else if (reasons.has('beyond_horizon')) status = 'beyond_horizon';
    else if (reasons.has('closed_day') || reasons.has('department_day_off') || reasons.has('closure') || reasons.has('slot_disabled')) status = 'closed';
    else if (reasons.has('booked') || reasons.has('capacity')) status = 'full';
    else status = 'past';
    days.push({ date, status, availableCount: slots.length, slots });
  }
  return days;
}

export const MAX_AVAILABILITY_RANGE_DAYS = 62;
