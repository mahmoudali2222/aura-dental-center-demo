import type { Queryable } from '../../database/pool.js';
import { withTransaction } from '../../database/pool.js';
import type { AppContext } from '../../types.js';
import { badRequest, notFound } from '../../lib/errors.js';
import { fallbackChain, pickText, type Locale } from '../../lib/locale.js';
import { applyTranslations, type TranslationInput, type TranslationMap } from '../../lib/translations.js';
import { recordAudit } from '../audit/audit.service.js';
import { loadCenter } from '../center/center.service.js';

type Tr = TranslationMap<{ title: string; description: string; altBefore: string; altAfter: string }>;

interface Row {
  id: string; department_id: string; department_slug: string; service_id: string | null;
  before_image_path: string; after_image_path: string; case_kind: 'real' | 'sample'; consent_confirmed: boolean;
  is_published: boolean; display_order: number; tr: Tr | null;
}

const SELECT = `SELECT g.id, g.department_id, d.slug AS department_slug, g.service_id, g.before_image_path, g.after_image_path,
       g.case_kind, g.consent_confirmed, g.is_published, g.display_order,
       (SELECT jsonb_object_agg(t.locale, jsonb_build_object('title', t.title, 'description', t.description, 'altBefore', t.alt_before, 'altAfter', t.alt_after))
          FROM gallery_case_translations t WHERE t.case_id = g.id) AS tr
  FROM gallery_cases g JOIN departments d ON d.id = g.department_id`;

/** Published cases only. Sample content is always labelled `isSample: true`; real cases require recorded consent. */
export async function listPublicGallery(app: AppContext, locale: Locale | null, departmentSlug?: string) {
  const center = await loadCenter(app.db);
  const chain = fallbackChain(locale, center.defaultLocale);
  const { rows } = await app.db.query<Row>(
    `${SELECT} WHERE g.is_published AND d.is_active AND ($1::text IS NULL OR d.slug = $1::text) ORDER BY g.display_order, g.created_at`,
    [departmentSlug ?? null],
  );
  return rows.map((r) => ({
    id: r.id,
    departmentSlug: r.department_slug,
    serviceId: r.service_id,
    beforeImagePath: r.before_image_path,
    afterImagePath: r.after_image_path,
    caseKind: r.case_kind,
    isSample: r.case_kind === 'sample',
    title: pickText(r.tr, chain, 'title'),
    description: pickText(r.tr, chain, 'description'),
    altBefore: pickText(r.tr, chain, 'altBefore'),
    altAfter: pickText(r.tr, chain, 'altAfter'),
  }));
}

const adminDto = (r: Row) => ({
  id: r.id, departmentId: r.department_id, departmentSlug: r.department_slug, serviceId: r.service_id,
  beforeImagePath: r.before_image_path, afterImagePath: r.after_image_path, caseKind: r.case_kind,
  consentConfirmed: r.consent_confirmed, isPublished: r.is_published, displayOrder: r.display_order, translations: r.tr ?? {},
});

export async function listAdminGallery(db: Queryable) {
  const { rows } = await db.query<Row>(`${SELECT} ORDER BY d.display_order, g.display_order, g.created_at`);
  return rows.map(adminDto);
}

async function getAdminCase(db: Queryable, id: string) {
  const { rows } = await db.query<Row>(`${SELECT} WHERE g.id = $1`, [id]);
  if (!rows[0]) throw notFound('GALLERY_CASE_NOT_FOUND', 'Gallery case not found');
  return adminDto(rows[0]);
}

const SPEC = { table: 'gallery_case_translations', idColumn: 'case_id', primary: null, others: ['title', 'description', 'alt_before', 'alt_after'] };

export interface GalleryInput {
  departmentId?: string;
  serviceId?: string | null;
  beforeImagePath?: string;
  afterImagePath?: string;
  caseKind?: 'real' | 'sample';
  consentConfirmed?: boolean;
  isPublished?: boolean;
  displayOrder?: number;
  translations?: Partial<Record<'ar' | 'en' | 'fr', { title?: string; description?: string; altBefore?: string; altAfter?: string }>>;
}

function toColumns(t: GalleryInput['translations']): TranslationInput | undefined {
  if (!t) return undefined;
  const out: TranslationInput = {};
  for (const l of ['ar', 'en', 'fr'] as const) {
    const e = t[l];
    if (!e) continue;
    out[l] = {
      ...(e.title !== undefined ? { title: e.title } : {}),
      ...(e.description !== undefined ? { description: e.description } : {}),
      ...(e.altBefore !== undefined ? { alt_before: e.altBefore } : {}),
      ...(e.altAfter !== undefined ? { alt_after: e.altAfter } : {}),
    };
  }
  return out;
}

/** Publishing a real case without recorded patient consent is refused here and by a CHECK constraint. */
function assertPublishable(kind: 'real' | 'sample', consent: boolean, published: boolean) {
  if (published && kind === 'real' && !consent) {
    throw badRequest('CONSENT_REQUIRED', 'A real case can only be published after patient consent has been confirmed', [{ field: 'consentConfirmed', code: 'CONSENT_REQUIRED' }]);
  }
}

export async function createGalleryCase(app: AppContext, adminId: string, input: GalleryInput & { departmentId: string; beforeImagePath: string; afterImagePath: string }, ip?: string) {
  const kind = input.caseKind ?? 'sample';
  assertPublishable(kind, input.consentConfirmed ?? false, input.isPublished ?? false);
  const id = await withTransaction(app.db, async (tx) => {
    if (!(await tx.query('SELECT 1 FROM departments WHERE id = $1', [input.departmentId])).rowCount) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
    const res = await tx.query<{ id: string }>(
      `INSERT INTO gallery_cases (department_id, service_id, before_image_path, after_image_path, case_kind, consent_confirmed, is_published, display_order)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [input.departmentId, input.serviceId ?? null, input.beforeImagePath, input.afterImagePath, kind, input.consentConfirmed ?? false, input.isPublished ?? false, input.displayOrder ?? 0],
    );
    const id = res.rows[0]!.id;
    await applyTranslations(tx, SPEC, id, toColumns(input.translations));
    await recordAudit(tx, { actorType: 'admin', actorId: adminId, action: 'gallery.created', entityType: 'gallery_case', entityId: id, ip, metadata: { caseKind: kind, published: input.isPublished ?? false } });
    return id;
  });
  return getAdminCase(app.db, id);
}

export async function updateGalleryCase(app: AppContext, adminId: string, id: string, input: GalleryInput, ip?: string) {
  await withTransaction(app.db, async (tx) => {
    const cur = (await tx.query<{ case_kind: 'real' | 'sample'; consent_confirmed: boolean; is_published: boolean }>('SELECT case_kind, consent_confirmed, is_published FROM gallery_cases WHERE id = $1 FOR UPDATE', [id])).rows[0];
    if (!cur) throw notFound('GALLERY_CASE_NOT_FOUND', 'Gallery case not found');
    const kind = input.caseKind ?? cur.case_kind;
    const consent = input.consentConfirmed ?? cur.consent_confirmed;
    const published = input.isPublished ?? cur.is_published;
    assertPublishable(kind, consent, published);
    await tx.query(
      `UPDATE gallery_cases SET department_id = COALESCE($2, department_id),
         service_id = CASE WHEN $3::boolean THEN $4 ELSE service_id END,
         before_image_path = COALESCE($5, before_image_path), after_image_path = COALESCE($6, after_image_path),
         case_kind = $7, consent_confirmed = $8, is_published = $9, display_order = COALESCE($10, display_order)
       WHERE id = $1`,
      [id, input.departmentId ?? null, input.serviceId !== undefined, input.serviceId ?? null, input.beforeImagePath ?? null, input.afterImagePath ?? null, kind, consent, published, input.displayOrder ?? null],
    );
    await applyTranslations(tx, SPEC, id, toColumns(input.translations));
    await recordAudit(tx, { actorType: 'admin', actorId: adminId, action: 'gallery.updated', entityType: 'gallery_case', entityId: id, ip, metadata: { caseKind: kind, published, consent } });
  });
  return getAdminCase(app.db, id);
}

export async function deleteGalleryCase(app: AppContext, adminId: string, id: string, ip?: string) {
  await withTransaction(app.db, async (tx) => {
    const res = await tx.query('DELETE FROM gallery_cases WHERE id = $1', [id]);
    if (!res.rowCount) throw notFound('GALLERY_CASE_NOT_FOUND', 'Gallery case not found');
    await recordAudit(tx, { actorType: 'admin', actorId: adminId, action: 'gallery.deleted', entityType: 'gallery_case', entityId: id, ip });
  });
}
