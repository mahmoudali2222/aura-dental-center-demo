import type { Queryable } from '../../database/pool.js';

export type ActorType = 'admin' | 'patient' | 'integration' | 'system' | 'anonymous';
export type Outcome = 'success' | 'failure' | 'denied';

export interface AuditInput {
  actorType: ActorType;
  actorId?: string | null;
  action: string;
  entityType?: string;
  entityId?: string;
  outcome?: Outcome;
  metadata?: Record<string, unknown>;
  ip?: string | null;
}

/** Keys whose values must never reach the audit log (credentials, tokens, and clinical text). */
const SENSITIVE_KEY =
  /pass(word)?|secret|token|hash|authorization|cookie|csrf|api[-_]?key|credential|medical|history|allerg|diagnos|treatment|clinical|^notes?$|note$/i;
const MAX_STRING = 200;
const MAX_DEPTH = 4;
const MAX_JSON_BYTES = 4096;

export function sanitizeMetadata(value: unknown, depth = 0): unknown {
  if (value === null || value === undefined) return value ?? null;
  if (typeof value === 'string') return value.length > MAX_STRING ? `${value.slice(0, MAX_STRING)}…` : value;
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (value instanceof Date) return value.toISOString();
  if (depth >= MAX_DEPTH) return '[truncated]';
  if (Array.isArray(value)) return value.slice(0, 50).map((v) => sanitizeMetadata(v, depth + 1));
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SENSITIVE_KEY.test(k) ? '[redacted]' : sanitizeMetadata(v, depth + 1);
    }
    return out;
  }
  return String(value);
}

/**
 * Appends one audit event. Pass the transaction client when the audited change happens in a transaction,
 * so the change and its audit record commit (or roll back) together.
 */
export async function recordAudit(db: Queryable, event: AuditInput): Promise<void> {
  let metadata = sanitizeMetadata(event.metadata ?? {}) as Record<string, unknown>;
  if (JSON.stringify(metadata).length > MAX_JSON_BYTES) metadata = { truncated: true };
  await db.query(
    `INSERT INTO audit_events (actor_type, actor_id, action, entity_type, entity_id, outcome, metadata, ip)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [
      event.actorType,
      event.actorId ?? null,
      event.action,
      event.entityType ?? null,
      event.entityId ?? null,
      event.outcome ?? 'success',
      JSON.stringify(metadata),
      event.ip ?? null,
    ],
  );
}
