import { z } from 'zod';
import { defs, Paged, route } from '../../lib/routes.js';
import { dateSchema, pageMeta, pageQuerySchema } from '../../lib/validation.js';
import type { AppContext } from '../../types.js';

interface Row { id: string; occurred_at: Date; actor_type: string; actor_id: string | null; action: string; entity_type: string | null; entity_id: string | null; outcome: string; metadata: Record<string, unknown>; ip: string | null }

export function auditRoutes(_app: AppContext) {
  const list = route({
    method: 'GET', url: '/audit-events', auth: 'admin', tags: ['Admin: audit'],
    summary: 'Browse the append-only audit log (newest first). Read-only: there is no write or delete endpoint.',
    query: pageQuerySchema.extend({
      action: z.string().max(80).optional(), entityType: z.string().max(60).optional(), entityId: z.string().max(80).optional(), actorId: z.string().max(80).optional(),
      outcome: z.enum(['success', 'failure', 'denied']).optional(), from: dateSchema.optional(), to: dateSchema.optional(),
    }),
    handler: async ({ app, query }) => {
      const where: string[] = [];
      const params: unknown[] = [];
      const add = (sql: string, v: unknown) => { params.push(v); where.push(sql.replace('?', `$${params.length}`)); };
      if (query.action) add('action = ?', query.action);
      if (query.entityType) add('entity_type = ?', query.entityType);
      if (query.entityId) add('entity_id = ?', query.entityId);
      if (query.actorId) add('actor_id = ?', query.actorId);
      if (query.outcome) add('outcome = ?', query.outcome);
      // Dates are Cairo calendar days.
      if (query.from) add(`occurred_at >= (?::date::timestamp AT TIME ZONE '${app.config.timezone}')`, query.from);
      if (query.to) add(`occurred_at < ((?::date + 1)::timestamp AT TIME ZONE '${app.config.timezone}')`, query.to);
      const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
      const total = Number((await app.db.query<{ n: string }>(`SELECT count(*) AS n FROM audit_events ${w}`, params)).rows[0]!.n);
      const rows = await app.db.query<Row>(`SELECT id, occurred_at, actor_type, actor_id, action, entity_type, entity_id, outcome, metadata, ip FROM audit_events ${w} ORDER BY id DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, query.pageSize, (query.page - 1) * query.pageSize]);
      return new Paged(rows.rows.map((r) => ({
        id: r.id, occurredAt: r.occurred_at.toISOString(), actorType: r.actor_type, actorId: r.actor_id, action: r.action,
        entityType: r.entity_type, entityId: r.entity_id, outcome: r.outcome, metadata: r.metadata, ip: r.ip,
      })), pageMeta(query.page, query.pageSize, total));
    },
  });
  return defs(list);
}
