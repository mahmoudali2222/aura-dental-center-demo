import { z } from 'zod';
import { defs, route } from '../../lib/routes.js';
import { badRequest } from '../../lib/errors.js';
import { dateSchema, localeSchema } from '../../lib/validation.js';
import { addDays, centerToday, diffDays } from '../../lib/time.js';
import { requestLocale } from '../../lib/request-locale.js';
import { getPublicCenter } from '../center/center.service.js';
import { listPublicDepartments } from '../departments/department.service.js';
import { listPublicGallery } from '../gallery/gallery.service.js';
import { MAX_AVAILABILITY_RANGE_DAYS } from '../scheduling/scheduling.service.js';
import { getPublicAvailability, getPublicDepartmentDetail } from './public.service.js';
import type { AppContext } from '../../types.js';

const localeQuery = z.object({ locale: localeSchema.optional() });

export const availabilityQuery = z.object({
  from: dateSchema.optional(),
  to: dateSchema.optional(),
  locale: localeSchema.optional(),
});

/** Resolves the default range (today .. +13 days) and validates its size. Shared with the n8n integration routes. */
export function resolveRange(app: AppContext, q: { from?: string; to?: string }) {
  const today = centerToday(app.config.timezone, app.clock.now());
  const from = q.from ?? today;
  const to = q.to ?? addDays(from, 13);
  if (to < from) throw badRequest('INVALID_RANGE', '`to` must not be before `from`', [{ field: 'to', code: 'INVALID_RANGE' }]);
  if (diffDays(from, to) + 1 > MAX_AVAILABILITY_RANGE_DAYS) throw badRequest('RANGE_TOO_LARGE', `At most ${MAX_AVAILABILITY_RANGE_DAYS} days can be requested at once`, [{ field: 'to', code: 'RANGE_TOO_LARGE' }]);
  return { from, to };
}

export function publicRoutes(app: AppContext) {
  const center = route({
    method: 'GET', url: '/center', auth: 'public', tags: ['Public'],
    summary: 'Center details (name, address, contact, hours, slots, timezone). Single source of truth, also used by the n8n assistant.',
    query: localeQuery,
    handler: async ({ app, req }) => getPublicCenter(app, requestLocale(req)),
  });

  const departments = route({
    method: 'GET', url: '/departments', auth: 'public', tags: ['Public'],
    summary: 'Active departments with their assigned dentist, localized.',
    query: localeQuery,
    handler: async ({ app, req }) => listPublicDepartments(app, requestLocale(req)),
  });

  const department = route({
    method: 'GET', url: '/departments/:slug', auth: 'public', tags: ['Public'],
    summary: 'One department landing-page payload: services, dentist and published before/after cases.',
    params: z.object({ slug: z.string().min(1).max(80) }),
    query: localeQuery,
    errors: ['DEPARTMENT_NOT_FOUND'],
    handler: async ({ app, req, params }) => getPublicDepartmentDetail(app, params.slug, requestLocale(req)),
  });

  const availability = route({
    method: 'GET', url: '/departments/:slug/availability', auth: 'public', tags: ['Public', 'Booking'],
    summary: 'Genuinely bookable slots per day for a department (default: today + 13 days; max 62 days).',
    params: z.object({ slug: z.string().min(1).max(80) }),
    query: availabilityQuery,
    errors: ['DEPARTMENT_NOT_FOUND', 'INVALID_RANGE', 'RANGE_TOO_LARGE'],
    handler: async ({ app, params, query }) => {
      const { from, to } = resolveRange(app, query);
      return getPublicAvailability(app, params.slug, from, to);
    },
  });

  const gallery = route({
    method: 'GET', url: '/gallery', auth: 'public', tags: ['Public'],
    summary: 'Published before/after cases. Sample content is labelled isSample=true; real cases require recorded consent.',
    query: z.object({ department: z.string().max(80).optional(), locale: localeSchema.optional() }),
    handler: async ({ app, req, query }) => listPublicGallery(app, requestLocale(req), query.department),
  });

  return defs(center, departments, department, availability, gallery);
}
