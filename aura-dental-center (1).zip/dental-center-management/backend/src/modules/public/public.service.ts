import type { AppContext } from '../../types.js';
import { notFound } from '../../lib/errors.js';
import { fallbackChain, pickText, type Locale } from '../../lib/locale.js';
import { loadCenter } from '../center/center.service.js';
import { findActiveDepartmentBySlug, isBookable, publicDentist, sortedDays } from '../departments/department.service.js';
import { listPublicServices } from '../services/service.service.js';
import { listPublicGallery } from '../gallery/gallery.service.js';
import { getAvailability } from '../scheduling/scheduling.service.js';

/** Shared by the website routes and the n8n routes so both always return the same content. */
export async function getPublicDepartmentDetail(app: AppContext, slug: string, locale: Locale | null) {
  const row = await findActiveDepartmentBySlug(app.db, slug);
  if (!row) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
  const c = await loadCenter(app.db);
  const chain = fallbackChain(locale, c.defaultLocale);
  const [services, gallery] = await Promise.all([listPublicServices(app.db, row.id, chain, c.currency), listPublicGallery(app, locale, slug)]);
  return {
    id: row.id,
    slug: row.slug,
    name: pickText(row.tr, chain, 'name'),
    description: pickText(row.tr, chain, 'description'),
    imagePath: row.image_path,
    workingDays: sortedDays(row.working_days),
    dentist: publicDentist(row.dentist, chain),
    bookable: isBookable(row),
    services,
    gallery,
  };
}

export async function getPublicAvailability(app: AppContext, slug: string, from: string, to: string) {
  const row = await findActiveDepartmentBySlug(app.db, slug);
  if (!row) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
  const days = await getAvailability(app, row.id, from, to, isBookable(row), row.working_days);
  return { department: { id: row.id, slug: row.slug }, timezone: app.config.timezone, from, to, days };
}
