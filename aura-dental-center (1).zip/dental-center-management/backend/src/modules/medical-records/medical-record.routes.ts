import { z } from 'zod';
import { defs, route } from '../../lib/routes.js';
import { notFound, badRequest } from '../../lib/errors.js';
import { uuidSchema } from '../../lib/validation.js';
import { withTransaction } from '../../database/pool.js';
import { recordAudit } from '../audit/audit.service.js';
import type { Queryable } from '../../database/pool.js';
import type { AppContext } from '../../types.js';

/**
 * Medical records: Admin Dashboard ONLY. There is no patient or integration route for this data, every route here
 * requires an admin session, and the audit log records who touched which record, never the clinical text itself.
 */
interface Row {
  id: string; patient_id: string; appointment_id: string | null; medical_history: string; allergies: string; diagnosis: string; treatment: string; notes: string;
  created_by: string; updated_by: string; created_by_name: string; updated_by_name: string; created_at: Date; updated_at: Date;
}

const SELECT = `SELECT m.id, m.patient_id, m.appointment_id, m.medical_history, m.allergies, m.diagnosis, m.treatment, m.notes,
       m.created_by, m.updated_by, cb.username AS created_by_name, ub.username AS updated_by_name, m.created_at, m.updated_at
  FROM medical_records m JOIN admin_users cb ON cb.id = m.created_by JOIN admin_users ub ON ub.id = m.updated_by`;

const dto = (r: Row) => ({
  id: r.id, patientId: r.patient_id, appointmentId: r.appointment_id,
  medicalHistory: r.medical_history, allergies: r.allergies, diagnosis: r.diagnosis, treatment: r.treatment, notes: r.notes,
  createdBy: { id: r.created_by, username: r.created_by_name }, updatedBy: { id: r.updated_by, username: r.updated_by_name },
  createdAt: r.created_at.toISOString(), updatedAt: r.updated_at.toISOString(),
});

const field = z.string().max(20000, 'TEXT_TOO_LONG');
const content = { medicalHistory: field.optional(), allergies: field.optional(), diagnosis: field.optional(), treatment: field.optional(), notes: field.optional() };
const hasContent = (o: Record<string, unknown>) => Object.keys(content).some((k) => typeof o[k] === 'string' && (o[k] as string).trim() !== '');

async function assertAppointmentBelongs(db: Queryable, appointmentId: string, patientId: string) {
  const r = await db.query('SELECT 1 FROM appointments WHERE id = $1 AND patient_id = $2', [appointmentId, patientId]);
  if (!r.rowCount) throw badRequest('APPOINTMENT_NOT_FOR_PATIENT', 'The appointment does not belong to this patient', [{ field: 'appointmentId', code: 'APPOINTMENT_NOT_FOR_PATIENT' }]);
}

export function medicalRecordRoutes(_app: AppContext) {
  const tags = ['Admin: medical records'];

  const list = route({
    method: 'GET', url: '/patients/:patientId/medical-records', auth: 'admin', tags, params: z.object({ patientId: uuidSchema }),
    summary: 'All medical records of a patient, newest first. Admin only; the access is audited.', errors: ['PATIENT_NOT_FOUND'],
    handler: async ({ app, params, admin, ip }) => {
      if (!(await app.db.query('SELECT 1 FROM patients WHERE id = $1', [params.patientId])).rowCount) throw notFound('PATIENT_NOT_FOUND', 'Patient not found');
      const rows = await app.db.query<Row>(`${SELECT} WHERE m.patient_id = $1 ORDER BY m.created_at DESC, m.id`, [params.patientId]);
      await recordAudit(app.db, { actorType: 'admin', actorId: admin.id, action: 'medical_record.listed', entityType: 'patient', entityId: params.patientId, ip, metadata: { count: rows.rowCount } });
      return rows.rows.map(dto);
    },
  });

  const create = route({
    method: 'POST', url: '/patients/:patientId/medical-records', auth: 'admin', tags, status: 201, params: z.object({ patientId: uuidSchema }),
    summary: 'Create a medical record (history, allergies, diagnosis, treatment, notes). At least one field must have content.',
    body: z.object({ appointmentId: uuidSchema.nullable().optional(), ...content }).refine(hasContent, { message: 'EMPTY_RECORD' }),
    errors: ['PATIENT_NOT_FOUND', 'APPOINTMENT_NOT_FOR_PATIENT'],
    handler: async ({ app, params, body, admin, ip }) => {
      const id = await withTransaction(app.db, async (tx) => {
        if (!(await tx.query('SELECT 1 FROM patients WHERE id = $1', [params.patientId])).rowCount) throw notFound('PATIENT_NOT_FOUND', 'Patient not found');
        if (body.appointmentId) await assertAppointmentBelongs(tx, body.appointmentId, params.patientId);
        const res = await tx.query<{ id: string }>(
          `INSERT INTO medical_records (patient_id, appointment_id, medical_history, allergies, diagnosis, treatment, notes, created_by, updated_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8) RETURNING id`,
          [params.patientId, body.appointmentId ?? null, body.medicalHistory ?? '', body.allergies ?? '', body.diagnosis ?? '', body.treatment ?? '', body.notes ?? '', admin.id],
        );
        // Audit metadata names WHICH fields were written, never their content.
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'medical_record.created', entityType: 'medical_record', entityId: res.rows[0]!.id, ip, metadata: { patientId: params.patientId, fieldsProvided: Object.keys(content).filter((k) => (body as Record<string, unknown>)[k]) } });
        return res.rows[0]!.id;
      });
      return dto((await app.db.query<Row>(`${SELECT} WHERE m.id = $1`, [id])).rows[0]!);
    },
  });

  const get = route({
    method: 'GET', url: '/medical-records/:id', auth: 'admin', tags, params: z.object({ id: uuidSchema }), summary: 'One medical record (audited as a view).', errors: ['MEDICAL_RECORD_NOT_FOUND'],
    handler: async ({ app, params, admin, ip }) => {
      const row = (await app.db.query<Row>(`${SELECT} WHERE m.id = $1`, [params.id])).rows[0];
      if (!row) throw notFound('MEDICAL_RECORD_NOT_FOUND', 'Medical record not found');
      await recordAudit(app.db, { actorType: 'admin', actorId: admin.id, action: 'medical_record.viewed', entityType: 'medical_record', entityId: params.id, ip, metadata: { patientId: row.patient_id } });
      return dto(row);
    },
  });

  const update = route({
    method: 'PATCH', url: '/medical-records/:id', auth: 'admin', tags, params: z.object({ id: uuidSchema }),
    summary: 'Update a medical record. Records are never deleted; corrections are updates (who/when kept in updatedBy/updatedAt and the audit log).',
    body: z.object({ appointmentId: uuidSchema.nullable().optional(), ...content }), errors: ['MEDICAL_RECORD_NOT_FOUND', 'APPOINTMENT_NOT_FOR_PATIENT'],
    handler: async ({ app, params, body, admin, ip }) => {
      await withTransaction(app.db, async (tx) => {
        const cur = (await tx.query<{ patient_id: string }>('SELECT patient_id FROM medical_records WHERE id = $1 FOR UPDATE', [params.id])).rows[0];
        if (!cur) throw notFound('MEDICAL_RECORD_NOT_FOUND', 'Medical record not found');
        if (body.appointmentId) await assertAppointmentBelongs(tx, body.appointmentId, cur.patient_id);
        await tx.query(
          `UPDATE medical_records SET
             appointment_id = CASE WHEN $2::boolean THEN $3 ELSE appointment_id END,
             medical_history = COALESCE($4, medical_history), allergies = COALESCE($5, allergies), diagnosis = COALESCE($6, diagnosis),
             treatment = COALESCE($7, treatment), notes = COALESCE($8, notes), updated_by = $9
           WHERE id = $1`,
          [params.id, body.appointmentId !== undefined, body.appointmentId ?? null, body.medicalHistory ?? null, body.allergies ?? null, body.diagnosis ?? null, body.treatment ?? null, body.notes ?? null, admin.id],
        );
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'medical_record.updated', entityType: 'medical_record', entityId: params.id, ip, metadata: { patientId: cur.patient_id, fieldsChanged: Object.keys({ ...content, appointmentId: 1 }).filter((k) => (body as Record<string, unknown>)[k] !== undefined) } });
      });
      return dto((await app.db.query<Row>(`${SELECT} WHERE m.id = $1`, [params.id])).rows[0]!);
    },
  });

  return defs(list, create, get, update);
}
