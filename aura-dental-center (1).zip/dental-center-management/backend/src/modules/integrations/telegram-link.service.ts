import type { Queryable } from '../../database/pool.js';
import { pgConstraint, pgErrorCode, withTransaction } from '../../database/pool.js';
import type { Actor, AppContext } from '../../types.js';
import { conflict, forbidden, notFound } from '../../lib/errors.js';
import { normalizeLinkCode, randomLinkCode, sha256Hex } from '../../lib/crypto.js';
import { recordAudit } from '../audit/audit.service.js';

/**
 * Telegram <-> patient linking. A Telegram user ID alone proves nothing, so linking requires a code created inside the
 * patient's authenticated website session:
 *   1. patient (logged in) asks for a code -> 12 random chars, valid 10 minutes, single use, only its SHA-256 is stored
 *   2. patient sends the code to the bot; n8n forwards it with the Telegram user ID (supplied by Telegram itself)
 *   3. the backend redeems the code atomically and stores the association
 * No password or long-lived secret ever travels through Telegram.
 */
export const LINK_TTL_MS = 10 * 60 * 1000;

interface LinkRow {
  id: string;
  patient_id: string;
  telegram_user_id: string;
  created_at: Date;
}

export async function getActiveLink(db: Queryable, patientId: string): Promise<LinkRow | null> {
  const { rows } = await db.query<LinkRow>('SELECT id, patient_id, telegram_user_id, created_at FROM telegram_links WHERE patient_id = $1 AND revoked_at IS NULL', [patientId]);
  return rows[0] ?? null;
}

export async function createLinkToken(app: AppContext, patientId: string, ip?: string) {
  const code = randomLinkCode();
  const now = app.clock.now();
  const expiresAt = new Date(now.getTime() + LINK_TTL_MS);
  await withTransaction(app.db, async (tx) => {
    // Only the newest code is valid: older unused ones are burned.
    await tx.query('UPDATE telegram_link_tokens SET used_at = $2 WHERE patient_id = $1 AND used_at IS NULL', [patientId, now]);
    await tx.query('INSERT INTO telegram_link_tokens (token_hash, patient_id, created_at, expires_at) VALUES ($1,$2,$3,$4)', [sha256Hex(normalizeLinkCode(code)), patientId, now, expiresAt]);
    await recordAudit(tx, { actorType: 'patient', actorId: patientId, action: 'telegram.link_token_created', entityType: 'patient', entityId: patientId, ip });
  });
  return { code, expiresAt: expiresAt.toISOString(), ttlSeconds: LINK_TTL_MS / 1000 };
}

/** Called by the integration API. Invalid, expired and already-used codes are indistinguishable on purpose. */
export async function redeemLinkToken(app: AppContext, rawCode: string, telegramUserId: string, ip?: string): Promise<{ linked: true }> {
  const limiterKey = `tg-link:${telegramUserId}`;
  app.loginLimiter.assertAllowed(limiterKey);
  const hash = sha256Hex(normalizeLinkCode(rawCode));
  const now = app.clock.now();
  try {
    await withTransaction(app.db, async (tx) => {
      const tok = (
        await tx.query<{ id: string; patient_id: string; expires_at: Date; used_at: Date | null; is_active: boolean }>(
          `SELECT t.id, t.patient_id, t.expires_at, t.used_at, p.is_active
             FROM telegram_link_tokens t JOIN patients p ON p.id = t.patient_id
            WHERE t.token_hash = $1 FOR UPDATE OF t`,
          [hash],
        )
      ).rows[0];
      if (!tok || tok.used_at || tok.expires_at.getTime() <= now.getTime() || !tok.is_active) {
        throw notFound('LINK_CODE_INVALID', 'The linking code is invalid or has expired');
      }
      await tx.query('UPDATE telegram_link_tokens SET used_at = $2 WHERE id = $1', [tok.id, now]);
      // A new link replaces any previous one for this patient AND for this Telegram account.
      await tx.query(
        `UPDATE telegram_links SET revoked_at = $3, revoked_by = 'replaced'
          WHERE revoked_at IS NULL AND (patient_id = $1 OR telegram_user_id = $2)`,
        [tok.patient_id, telegramUserId, now],
      );
      await tx.query('INSERT INTO telegram_links (patient_id, telegram_user_id, created_at) VALUES ($1,$2,$3)', [tok.patient_id, telegramUserId, now]);
      await recordAudit(tx, { actorType: 'integration', actorId: 'n8n', action: 'telegram.linked', entityType: 'patient', entityId: tok.patient_id, ip });
    });
  } catch (err) {
    if (pgErrorCode(err) === '23505' && (pgConstraint(err) ?? '').startsWith('telegram_links_active')) throw conflict('LINK_CONFLICT', 'Could not link this account, please try again');
    if ((err as { code?: string }).code === 'LINK_CODE_INVALID') app.loginLimiter.recordFailure(limiterKey);
    throw err;
  }
  app.loginLimiter.reset(limiterKey);
  return { linked: true };
}

export async function revokeLink(app: AppContext, patientId: string, by: 'patient' | 'admin' | 'integration', actor: Actor, ip?: string): Promise<boolean> {
  return withTransaction(app.db, async (tx) => {
    const res = await tx.query('UPDATE telegram_links SET revoked_at = $2, revoked_by = $3 WHERE patient_id = $1 AND revoked_at IS NULL', [patientId, app.clock.now(), by]);
    if (res.rowCount) await recordAudit(tx, { actorType: actor.type, actorId: actor.id, action: 'telegram.link_revoked', entityType: 'patient', entityId: patientId, metadata: { by }, ip });
    return (res.rowCount ?? 0) > 0;
  });
}

export async function resolveLinkedPatientId(db: Queryable, telegramUserId: string): Promise<string | null> {
  const { rows } = await db.query<{ patient_id: string }>(
    `SELECT l.patient_id FROM telegram_links l JOIN patients p ON p.id = l.patient_id
      WHERE l.telegram_user_id = $1 AND l.revoked_at IS NULL AND p.is_active`,
    [telegramUserId],
  );
  return rows[0]?.patient_id ?? null;
}

/** Personal operations require a live link. Unlinked users get a clear, non-leaking 403. */
export async function requireLinkedPatient(db: Queryable, telegramUserId: string): Promise<string> {
  const id = await resolveLinkedPatientId(db, telegramUserId);
  if (!id) throw forbidden('TELEGRAM_NOT_LINKED', 'This Telegram account is not linked to a patient account');
  return id;
}
