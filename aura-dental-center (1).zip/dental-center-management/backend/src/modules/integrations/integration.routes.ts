import { z } from 'zod';
import { defs, NO_CONTENT, Paged, route } from '../../lib/routes.js';
import { dateSchema, localeSchema, pageMeta, pageQuerySchema, slotNumberSchema, uuidSchema } from '../../lib/validation.js';
import { requestLocale } from '../../lib/request-locale.js';
import { badRequest, notFound } from '../../lib/errors.js';
import type { Actor, AppContext } from '../../types.js';
import { getPublicCenter } from '../center/center.service.js';
import { listPublicDepartments } from '../departments/department.service.js';
import { getPublicAvailability, getPublicDepartmentDetail } from '../public/public.service.js';
import { availabilityQuery, resolveRange } from '../public/public.routes.js';
import {
  cancelAppointment, createAppointment, dtoOptions, getAppointmentRow, listPatientAppointments, rescheduleAppointment, toAppointmentDto,
} from '../appointments/appointment.service.js';
import { redeemLinkToken, requireLinkedPatient, resolveLinkedPatientId, revokeLink } from './telegram-link.service.js';

/**
 * n8n / Telegram integration API. Authenticated by a dedicated bearer key (never an admin session).
 * It exposes only: public information, availability, Telegram linking, and appointment operations for a patient whose
 * Telegram account is linked. It can NOT reach admin routes, medical records, or password data, and it returns the
 * same appointment shape as the website without patient contact details.
 * Every booking rule is enforced by the shared appointment service; n8n has no scheduling logic of its own.
 */
const INTEGRATION_ACTOR: Actor = { type: 'integration', id: 'n8n' };
const telegramId = z.string().regex(/^[1-9]\d{0,14}$/, 'INVALID_TELEGRAM_ID');
const tgParams = z.object({ telegramUserId: telegramId });
const tgAppointmentParams = tgParams.extend({ id: uuidSchema });
const localeQuery = z.object({ locale: localeSchema.optional() });

export function integrationRoutes(app: AppContext) {
  const limit = app.config.rateLimits.integration;
  const base = { auth: 'integration' as const, tags: ['Integration (n8n)'], rateLimit: limit };

  const center = route({ ...base, method: 'GET', url: '/center', summary: 'Center details (address, contact, hours). The assistant must read these from here, never from its prompt.', query: localeQuery,
    handler: async ({ app, req }) => getPublicCenter(app, requestLocale(req)) });

  const departments = route({ ...base, method: 'GET', url: '/departments', summary: 'Active departments with dentist.', query: localeQuery,
    handler: async ({ app, req }) => listPublicDepartments(app, requestLocale(req)) });

  const department = route({ ...base, method: 'GET', url: '/departments/:slug', summary: 'Department with services, dentist and prices (when configured).',
    params: z.object({ slug: z.string().min(1).max(80) }), query: localeQuery, errors: ['DEPARTMENT_NOT_FOUND'],
    handler: async ({ app, req, params }) => getPublicDepartmentDetail(app, params.slug, requestLocale(req)) });

  const availability = route({ ...base, method: 'GET', url: '/availability', summary: 'Bookable slots for a department (same rules and data as the website).',
    query: availabilityQuery.extend({ department: z.string().min(1).max(80) }), errors: ['DEPARTMENT_NOT_FOUND', 'INVALID_RANGE', 'RANGE_TOO_LARGE'],
    handler: async ({ app, query }) => {
      const { from, to } = resolveRange(app, query);
      return getPublicAvailability(app, query.department, from, to);
    } });

  const link = route({ ...base, method: 'POST', url: '/telegram/link', summary: 'Redeem a one-time linking code created by a logged-in patient and bind it to this Telegram user.',
    body: z.object({ code: z.string().trim().min(8).max(32), telegramUserId: telegramId }), errors: ['LINK_CODE_INVALID', 'TOO_MANY_ATTEMPTS'],
    handler: async ({ app, body, ip }) => redeemLinkToken(app, body.code, body.telegramUserId, ip) });

  const status = route({ ...base, method: 'GET', url: '/telegram/:telegramUserId/status', summary: 'Is this Telegram user linked to a patient account?', params: tgParams,
    handler: async ({ app, params }) => ({ linked: (await resolveLinkedPatientId(app.db, params.telegramUserId)) !== null }) });

  const unlink = route({ ...base, method: 'DELETE', url: '/telegram/:telegramUserId/link', summary: 'Unlink this Telegram user (e.g. a /unlink bot command).', status: 204, params: tgParams,
    handler: async ({ app, params, ip }) => {
      const patientId = await resolveLinkedPatientId(app.db, params.telegramUserId);
      if (patientId) await revokeLink(app, patientId, 'integration', INTEGRATION_ACTOR, ip);
      return NO_CONTENT;
    } });

  const myAppointments = route({ ...base, method: 'GET', url: '/telegram/:telegramUserId/appointments', summary: 'Appointments of the linked patient.',
    params: tgParams, query: pageQuerySchema.extend({ scope: z.enum(['upcoming', 'history', 'all']).default('upcoming'), locale: localeSchema.optional() }), errors: ['TELEGRAM_NOT_LINKED'],
    handler: async ({ app, req, params, query }) => {
      const patientId = await requireLinkedPatient(app.db, params.telegramUserId);
      const { rows, total } = await listPatientAppointments(app, patientId, query.scope, query.page, query.pageSize);
      const opts = await dtoOptions(app, requestLocale(req));
      return new Paged(rows.map((r) => toAppointmentDto(app, r, opts)), pageMeta(query.page, query.pageSize, total));
    } });

  const book = route({ ...base, method: 'POST', url: '/telegram/:telegramUserId/appointments', status: 201, summary: 'Book for the linked patient. Success is only reported when the backend has persisted the appointment.',
    params: tgParams, query: localeQuery,
    body: z.object({ departmentSlug: z.string().min(1).max(80), serviceId: uuidSchema.nullable().optional(), date: dateSchema, slotNumber: slotNumberSchema }),
    errors: ['TELEGRAM_NOT_LINKED', 'SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'DEPARTMENT_NOT_WORKING_DAY', 'BEYOND_BOOKING_HORIZON', 'PATIENT_OVERLAP', 'DEPARTMENT_NOT_FOUND'],
    handler: async ({ app, req, params, body, ip }) => {
      const patientId = await requireLinkedPatient(app.db, params.telegramUserId);
      const dept = (await app.db.query<{ id: string }>('SELECT id FROM departments WHERE slug = $1 AND is_active', [body.departmentSlug])).rows[0];
      if (!dept) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
      const id = await createAppointment(app, { patientId, departmentId: dept.id, serviceId: body.serviceId, date: body.date, slotNumber: body.slotNumber, createdVia: 'telegram', actor: INTEGRATION_ACTOR, ip });
      return toAppointmentDto(app, await getAppointmentRow(app, id, patientId), await dtoOptions(app, requestLocale(req)));
    } });

  const cancel = route({ ...base, method: 'POST', url: '/telegram/:telegramUserId/appointments/:id/cancel', summary: 'Cancel the linked patient\'s appointment (24-hour rule enforced by the backend).',
    params: tgAppointmentParams, query: localeQuery, errors: ['TELEGRAM_NOT_LINKED', 'APPOINTMENT_NOT_FOUND', 'APPOINTMENT_NOT_ACTIVE', 'WITHIN_24H_WINDOW'],
    handler: async ({ app, req, params, ip }) => {
      const patientId = await requireLinkedPatient(app.db, params.telegramUserId);
      await cancelAppointment(app, params.id, { actor: INTEGRATION_ACTOR, patientScope: patientId, ip });
      return toAppointmentDto(app, await getAppointmentRow(app, params.id, patientId), await dtoOptions(app, requestLocale(req)));
    } });

  const reschedule = route({ ...base, method: 'POST', url: '/telegram/:telegramUserId/appointments/:id/reschedule', summary: 'Reschedule the linked patient\'s appointment (24-hour rule enforced by the backend).',
    params: tgAppointmentParams, query: localeQuery, body: z.object({ date: dateSchema, slotNumber: slotNumberSchema }),
    errors: ['TELEGRAM_NOT_LINKED', 'APPOINTMENT_NOT_FOUND', 'APPOINTMENT_NOT_ACTIVE', 'WITHIN_24H_WINDOW', 'SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'DEPARTMENT_NOT_WORKING_DAY', 'RESCHEDULE_NO_CHANGE'],
    handler: async ({ app, req, params, body, ip }) => {
      const patientId = await requireLinkedPatient(app.db, params.telegramUserId);
      await rescheduleAppointment(app, params.id, { date: body.date, slotNumber: body.slotNumber }, { actor: INTEGRATION_ACTOR, patientScope: patientId, ip });
      return toAppointmentDto(app, await getAppointmentRow(app, params.id, patientId), await dtoOptions(app, requestLocale(req)));
    } });

  void badRequest;
  return defs(center, departments, department, availability, link, status, unlink, myAppointments, book, cancel, reschedule);
}
