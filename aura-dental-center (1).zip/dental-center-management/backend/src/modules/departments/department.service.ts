import type { Queryable, Tx } from '../../database/pool.js';
import { pgConstraint, pgErrorCode, withTransaction } from '../../database/pool.js';
import type { AppContext } from '../../types.js';
import { conflict, notFound } from '../../lib/errors.js';
import { fallbackChain, pickText, type Locale } from '../../lib/locale.js';
import { applyTranslations, type TranslationInput, type TranslationMap } from '../../lib/translations.js';
import { recordAudit } from '../audit/audit.service.js';
import { loadCenter } from '../center/center.service.js';

type DeptTr = TranslationMap<{ name: string; description: string }>;
type DentistTr = TranslationMap<{ name: string; bio: string }>;

const DEPT_TR = `(SELECT jsonb_object_agg(t.locale, jsonb_build_object('name', t.name, 'description', t.description))
                    FROM department_translations t WHERE t.department_id = d.id)`;
const DENTIST_JSON = `(SELECT jsonb_build_object(
                          'id', dn.id, 'photoPath', dn.photo_path, 'isSample', dn.is_sample, 'isActive', dn.is_active,
                          'translations', (SELECT jsonb_object_agg(t.locale, jsonb_build_object('name', t.display_name, 'bio', t.bio))
                                             FROM dentist_translations t WHERE t.dentist_id = dn.id))
                     FROM dentists dn WHERE dn.department_id = d.id AND dn.is_active)`;

interface DeptRow {
  id: string; slug: string; display_order: number; is_active: boolean; image_path: string | null; working_days: number[];
  created_at: Date; updated_at: Date; tr: DeptTr | null;
  dentist: { id: string; photoPath: string | null; isSample: boolean; isActive: boolean; translations: DentistTr | null } | null;
  service_count: string;
}

const DEPT_SELECT = `SELECT d.id, d.slug, d.display_order, d.is_active, d.image_path, d.working_days, d.created_at, d.updated_at,
       ${DEPT_TR} AS tr, ${DENTIST_JSON} AS dentist,
       (SELECT count(*) FROM services s WHERE s.department_id = d.id AND s.is_active) AS service_count
  FROM departments d`;

export function publicDentist(d: NonNullable<DeptRow['dentist']> | null, chain: Locale[]) {
  if (!d) return null;
  return {
    id: d.id,
    name: pickText(d.translations, chain, 'name'),
    bio: pickText(d.translations, chain, 'bio'),
    photoPath: d.photoPath,
    isSample: d.isSample,
  };
}

/** ISO weekdays, ascending (the database keeps them in the order they were written). */
export const sortedDays = (d: number[]) => [...d].sort((a, b) => a - b);

/** A department can take bookings only if it is active AND has an active dentist. */
export const isBookable = (r: Pick<DeptRow, 'is_active' | 'dentist'>) => r.is_active && r.dentist !== null;

export async function listPublicDepartments(app: AppContext, locale: Locale | null) {
  const center = await loadCenter(app.db);
  const chain = fallbackChain(locale, center.defaultLocale);
  const { rows } = await app.db.query<DeptRow>(`${DEPT_SELECT} WHERE d.is_active ORDER BY d.display_order, d.slug`);
  return rows
    .map((r) => ({
      id: r.id,
      slug: r.slug,
      name: pickText(r.tr, chain, 'name'),
      description: pickText(r.tr, chain, 'description'),
      imagePath: r.image_path,
      workingDays: sortedDays(r.working_days),
      dentist: publicDentist(r.dentist, chain),
      serviceCount: Number(r.service_count),
      bookable: isBookable(r),
    }))
    .filter((d) => d.name !== ''); // never expose a department without any usable name
}

export async function findActiveDepartmentBySlug(db: Queryable, slug: string) {
  const { rows } = await db.query<DeptRow>(`${DEPT_SELECT} WHERE d.slug = $1 AND d.is_active`, [slug]);
  return rows[0] ?? null;
}

// ------------------------------------------------------------------------------------------------
// Admin
// ------------------------------------------------------------------------------------------------
export function adminDepartmentDto(r: DeptRow) {
  return {
    id: r.id,
    slug: r.slug,
    displayOrder: r.display_order,
    isActive: r.is_active,
    imagePath: r.image_path,
    workingDays: sortedDays(r.working_days),
    translations: r.tr ?? {},
    dentist: r.dentist ? { id: r.dentist.id, photoPath: r.dentist.photoPath, isSample: r.dentist.isSample, translations: r.dentist.translations ?? {} } : null,
    serviceCount: Number(r.service_count),
    bookable: isBookable(r),
    createdAt: r.created_at.toISOString(),
    updatedAt: r.updated_at.toISOString(),
  };
}

export async function listAdminDepartments(db: Queryable) {
  const { rows } = await db.query<DeptRow>(`${DEPT_SELECT} ORDER BY d.display_order, d.slug`);
  return rows.map(adminDepartmentDto);
}

export async function getAdminDepartment(db: Queryable, id: string) {
  const { rows } = await db.query<DeptRow>(`${DEPT_SELECT} WHERE d.id = $1`, [id]);
  if (!rows[0]) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
  return adminDepartmentDto(rows[0]);
}

const DEPT_TRANSLATION = { table: 'department_translations', idColumn: 'department_id', primary: 'name', others: ['description'] };

export interface DepartmentInput {
  slug?: string;
  displayOrder?: number;
  isActive?: boolean;
  imagePath?: string | null;
  /** ISO weekdays (1 = Monday ... 7 = Sunday) on which the department takes bookings. */
  workingDays?: number[];
  /** Update only: confirms that booked appointments on days being switched off stay booked (they are never cancelled automatically). */
  acknowledgeExistingAppointments?: boolean;
  translations?: TranslationInput;
}

function mapSlugConflict(err: unknown): never {
  if (pgErrorCode(err) === '23505' && pgConstraint(err) === 'departments_slug_key') throw conflict('SLUG_TAKEN', 'Another department already uses this slug');
  throw err;
}

export async function createDepartment(app: AppContext, adminId: string, input: DepartmentInput & { slug: string }, ip?: string) {
  try {
    const id = await withTransaction(app.db, async (tx: Tx) => {
      const res = await tx.query<{ id: string }>(
        'INSERT INTO departments (slug, display_order, is_active, image_path, working_days) VALUES ($1,$2,$3,$4,COALESCE($5::smallint[], ARRAY[1,2,3,4,5,6,7]::smallint[])) RETURNING id',
        [input.slug, input.displayOrder ?? 0, input.isActive ?? true, input.imagePath ?? null, input.workingDays ?? null],
      );
      const id = res.rows[0]!.id;
      await applyTranslations(tx, DEPT_TRANSLATION, id, input.translations); // throws AT_LEAST_ONE_TRANSLATION if none given
      await recordAudit(tx, { actorType: 'admin', actorId: adminId, action: 'department.created', entityType: 'department', entityId: id, ip, metadata: { slug: input.slug } });
      return id;
    });
    return getAdminDepartment(app.db, id);
  } catch (err) {
    return mapSlugConflict(err);
  }
}

export async function updateDepartment(app: AppContext, adminId: string, id: string, input: DepartmentInput, ip?: string) {
  try {
    await withTransaction(app.db, async (tx) => {
      // The row lock also keeps bookings (which take a conflicting lock on this row) out while the working days change, so the
      // count below is exact and no appointment can be created on a day that is being switched off.
      const existing = (await tx.query<{ working_days: number[] }>('SELECT working_days FROM departments WHERE id = $1 FOR UPDATE', [id])).rows[0];
      if (!existing) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');

      let affected = 0;
      if (input.workingDays) {
        const removed = existing.working_days.filter((d) => !input.workingDays!.includes(d));
        if (removed.length > 0) {
          affected = Number((await tx.query<{ n: string }>(
            `SELECT count(*) AS n FROM appointments
              WHERE department_id = $1 AND status = 'booked' AND ends_at > $2::timestamptz
                AND EXTRACT(ISODOW FROM appointment_date)::int = ANY($3::int[])`,
            [id, app.clock.now(), removed],
          )).rows[0]!.n);
          if (affected > 0 && !input.acknowledgeExistingAppointments) {
            throw conflict('WORKING_DAYS_HAVE_APPOINTMENTS', `${affected} booked appointment(s) fall on the days being switched off; they are not cancelled automatically. Repeat with acknowledgeExistingAppointments to confirm.`, { count: affected });
          }
        }
      }

      await tx.query(
        `UPDATE departments SET
           slug = COALESCE($2, slug), display_order = COALESCE($3, display_order),
           is_active = COALESCE($4, is_active),
           image_path = CASE WHEN $5::boolean THEN $6 ELSE image_path END,
           working_days = COALESCE($7::smallint[], working_days)
         WHERE id = $1`,
        [id, input.slug ?? null, input.displayOrder ?? null, input.isActive ?? null, input.imagePath !== undefined, input.imagePath ?? null, input.workingDays ?? null],
      );
      await applyTranslations(tx, DEPT_TRANSLATION, id, input.translations);
      await recordAudit(tx, {
        actorType: 'admin', actorId: adminId, action: 'department.updated', entityType: 'department', entityId: id, ip,
        metadata: {
          fields: Object.keys(input).filter((k) => k !== 'acknowledgeExistingAppointments' && (input as Record<string, unknown>)[k] !== undefined), isActive: input.isActive,
          ...(input.workingDays ? { workingDays: input.workingDays, appointmentsOnRemovedDays: affected } : {}),
        },
      });
    });
    return getAdminDepartment(app.db, id);
  } catch (err) {
    return mapSlugConflict(err);
  }
}
