import type { Queryable } from '../../database/pool.js';
import type { AppContext } from '../../types.js';
import { LOCALES, fallbackChain, pickText, type Locale } from '../../lib/locale.js';
import type { TranslationMap } from '../../lib/translations.js';

export interface CenterTranslation {
  name: string;
  address: string;
  introduction: string;
  hoursNote: string;
}

export interface CenterRaw {
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  mapUrl: string | null;
  defaultLocale: Locale;
  currency: string;
  bookingHorizonDays: number;
  workingDays: number[];
  translations: TranslationMap<CenterTranslation>;
}

export interface SlotTemplate {
  slotNumber: number;
  startTime: string; // "HH:mm"
  endTime: string; // "HH:mm" (00:00 for the last slot)
  endsNextDay: boolean;
  isActive: boolean;
}

export async function loadCenter(db: Queryable): Promise<CenterRaw> {
  const c = (
    await db.query<{
      phone: string | null; whatsapp: string | null; email: string | null; map_url: string | null;
      default_locale: Locale; currency: string; booking_horizon_days: number; working_days: number[];
    }>('SELECT phone, whatsapp, email, map_url, default_locale, currency, booking_horizon_days, working_days FROM center_profile WHERE id = 1')
  ).rows[0]!;
  const t = await db.query<{ locale: Locale; name: string; address: string; introduction: string; hours_note: string }>(
    'SELECT locale, name, address, introduction, hours_note FROM center_profile_translations',
  );
  const translations: TranslationMap<CenterTranslation> = {};
  for (const r of t.rows) translations[r.locale] = { name: r.name, address: r.address, introduction: r.introduction, hoursNote: r.hours_note };
  return {
    phone: c.phone, whatsapp: c.whatsapp, email: c.email, mapUrl: c.map_url,
    defaultLocale: c.default_locale, currency: c.currency, bookingHorizonDays: c.booking_horizon_days,
    workingDays: [...c.working_days].sort((a, b) => a - b), translations,
  };
}

export async function loadSlotTemplates(db: Queryable): Promise<SlotTemplate[]> {
  const { rows } = await db.query<{ slot_number: number; start_time: string; is_active: boolean }>(
    'SELECT slot_number, to_char(start_time, \'HH24:MI\') AS start_time, is_active FROM slot_templates ORDER BY slot_number',
  );
  return rows.map((r) => {
    const startHour = Number(r.start_time.slice(0, 2));
    const endHour = (startHour + 2) % 24;
    return {
      slotNumber: r.slot_number,
      startTime: r.start_time,
      endTime: `${String(endHour).padStart(2, '0')}:${r.start_time.slice(3)}`,
      endsNextDay: startHour + 2 >= 24,
      isActive: r.is_active,
    };
  });
}

/** Public, localized view of the single source of truth for center details. Used by the website AND by n8n. */
export async function getPublicCenter(app: AppContext, locale: Locale | null) {
  const [c, slots] = await Promise.all([loadCenter(app.db), loadSlotTemplates(app.db)]);
  const chain = fallbackChain(locale, c.defaultLocale);
  const address = pickText(c.translations, chain, 'address');
  return {
    name: pickText(c.translations, chain, 'name'),
    address,
    addressConfigured: address.trim() !== '',
    introduction: pickText(c.translations, chain, 'introduction'),
    hoursNote: pickText(c.translations, chain, 'hoursNote'),
    phone: c.phone,
    whatsapp: c.whatsapp,
    email: c.email,
    mapUrl: c.mapUrl,
    timezone: app.config.timezone,
    currency: c.currency,
    defaultLocale: c.defaultLocale,
    workingDays: c.workingDays,
    bookingHorizonDays: c.bookingHorizonDays,
    slots: slots.filter((s) => s.isActive),
    locales: [...LOCALES],
  };
}
