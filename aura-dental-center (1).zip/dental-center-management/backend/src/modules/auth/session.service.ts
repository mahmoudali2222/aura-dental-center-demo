import type { AppContext, AdminPrincipal, PatientPrincipal, SessionInfo } from '../../types.js';
import type { Queryable } from '../../database/pool.js';
import { randomToken, sha256Hex } from '../../lib/crypto.js';
import type { Locale } from '../../lib/locale.js';

export type SessionKind = 'patient' | 'admin';

/** Cookie names and the API path each cookie is scoped to (an admin cookie is never sent to patient routes). */
export const COOKIES = {
  patient: { name: 'dc_patient', path: '/api/v1/patient' },
  admin: { name: 'dc_admin', path: '/api/v1/admin' },
} as const;

export interface NewSession {
  token: string;
  csrfToken: string;
  expiresAt: Date;
}

function limits(ctx: AppContext, kind: SessionKind) {
  return kind === 'patient'
    ? { ttl: ctx.config.session.patientTtlMs, idle: ctx.config.session.patientIdleMs }
    : { ttl: ctx.config.session.adminTtlMs, idle: ctx.config.session.adminIdleMs };
}

/** Creates a session with a fresh random token (never reused across logins: no session fixation). */
export async function createSession(ctx: AppContext, kind: SessionKind, userId: string, db: Queryable = ctx.db): Promise<NewSession> {
  const token = randomToken(32);
  const csrfToken = randomToken(24);
  const now = ctx.clock.now();
  const expiresAt = new Date(now.getTime() + limits(ctx, kind).ttl);
  await db.query(
    `INSERT INTO sessions (token_hash, kind, patient_id, admin_id, csrf_token, created_at, expires_at, last_seen_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$6)`,
    [sha256Hex(token), kind, kind === 'patient' ? userId : null, kind === 'admin' ? userId : null, csrfToken, now, expiresAt],
  );
  return { token, csrfToken, expiresAt };
}

export type LoadedSession<K extends SessionKind> = {
  session: SessionInfo;
} & (K extends 'patient' ? { patient: PatientPrincipal } : { admin: AdminPrincipal });

interface SessionRow {
  id: string;
  csrf_token: string;
  expires_at: Date;
  last_seen_at: Date;
  patient_id: string | null;
  admin_id: string | null;
}

/** Resolves a cookie token to its session + principal, or null when missing/revoked/expired/idle/inactive. */
export async function loadSession(ctx: AppContext, kind: 'patient', token: string): Promise<LoadedSession<'patient'> | null>;
export async function loadSession(ctx: AppContext, kind: 'admin', token: string): Promise<LoadedSession<'admin'> | null>;
export async function loadSession(ctx: AppContext, kind: SessionKind, token: string): Promise<LoadedSession<SessionKind> | null> {
  const { rows } = await ctx.db.query<SessionRow>(
    `SELECT id, csrf_token, expires_at, last_seen_at, patient_id, admin_id
       FROM sessions WHERE token_hash = $1 AND kind = $2 AND revoked_at IS NULL`,
    [sha256Hex(token), kind],
  );
  const row = rows[0];
  if (!row) return null;

  const now = ctx.clock.now();
  const idle = limits(ctx, kind).idle;
  if (row.expires_at.getTime() <= now.getTime() || now.getTime() - row.last_seen_at.getTime() > idle) {
    await ctx.db.query('UPDATE sessions SET revoked_at = $2 WHERE id = $1 AND revoked_at IS NULL', [row.id, now]);
    return null;
  }

  const session: SessionInfo = { id: row.id, csrfToken: row.csrf_token };
  let result: LoadedSession<SessionKind> | null = null;

  if (kind === 'patient' && row.patient_id) {
    const p = await ctx.db.query<{ id: string; full_name: string; phone_e164: string; preferred_locale: Locale | null; is_active: boolean }>(
      'SELECT id, full_name, phone_e164, preferred_locale, is_active FROM patients WHERE id = $1',
      [row.patient_id],
    );
    const patient = p.rows[0];
    if (patient?.is_active) {
      result = { session, patient: { id: patient.id, fullName: patient.full_name, phone: patient.phone_e164, preferredLocale: patient.preferred_locale } };
    }
  } else if (kind === 'admin' && row.admin_id) {
    const a = await ctx.db.query<{ id: string; username: string; full_name: string; must_change_password: boolean; is_active: boolean }>(
      'SELECT id, username, full_name, must_change_password, is_active FROM admin_users WHERE id = $1',
      [row.admin_id],
    );
    const admin = a.rows[0];
    if (admin?.is_active) {
      result = { session, admin: { id: admin.id, username: admin.username, fullName: admin.full_name, mustChangePassword: admin.must_change_password } };
    }
  }
  if (!result) return null;

  // Sliding idle window: refresh at most once a minute to avoid a write on every request.
  if (now.getTime() - row.last_seen_at.getTime() > 60_000) {
    await ctx.db.query('UPDATE sessions SET last_seen_at = $2 WHERE id = $1', [row.id, now]);
  }
  return result;
}

export async function revokeSessionByToken(ctx: AppContext, token: string): Promise<void> {
  await ctx.db.query('UPDATE sessions SET revoked_at = $2 WHERE token_hash = $1 AND revoked_at IS NULL', [sha256Hex(token), ctx.clock.now()]);
}

/** Revokes every active session of a patient (password reset, deactivation), optionally keeping one. */
export async function revokePatientSessions(ctx: AppContext, patientId: string, exceptSessionId?: string, db: Queryable = ctx.db): Promise<number> {
  const res = await db.query(
    `UPDATE sessions SET revoked_at = $2
      WHERE patient_id = $1 AND revoked_at IS NULL AND ($3::uuid IS NULL OR id <> $3::uuid)`,
    [patientId, ctx.clock.now(), exceptSessionId ?? null],
  );
  return res.rowCount ?? 0;
}

export async function revokeAdminSessions(ctx: AppContext, adminId: string, exceptSessionId?: string, db: Queryable = ctx.db): Promise<number> {
  const res = await db.query(
    `UPDATE sessions SET revoked_at = $2
      WHERE admin_id = $1 AND revoked_at IS NULL AND ($3::uuid IS NULL OR id <> $3::uuid)`,
    [adminId, ctx.clock.now(), exceptSessionId ?? null],
  );
  return res.rowCount ?? 0;
}

/** Housekeeping: delete sessions that expired more than a day ago. Safe to run any time. */
export async function pruneSessions(ctx: AppContext): Promise<number> {
  const cutoff = new Date(ctx.clock.now().getTime() - 24 * 3_600_000);
  const res = await ctx.db.query('DELETE FROM sessions WHERE expires_at < $1 OR revoked_at < $1', [cutoff]);
  return res.rowCount ?? 0;
}
