import { z } from 'zod';
import type { FastifyReply } from 'fastify';
import { NO_CONTENT, route, type RouteDef, type AuthKind } from '../../lib/routes.js';
import { conflict, forbidden, unauthorized } from '../../lib/errors.js';
import { badRequest } from '../../lib/errors.js';
import { normalizePhone } from '../../lib/phone.js';
import { localeSchema } from '../../lib/validation.js';
import { withTransaction, pgConstraint, pgErrorCode } from '../../database/pool.js';
import { recordAudit } from '../audit/audit.service.js';
import { assertPasswordPolicy, hashPassword, needsRehash, verifyAgainstDummy, verifyPassword } from './password.js';
import {
  COOKIES,
  createSession,
  revokeAdminSessions,
  revokePatientSessions,
  revokeSessionByToken,
  type NewSession,
  type SessionKind,
} from './session.service.js';
import type { AppContext } from '../../types.js';
import { patientDto } from '../patients/patient.dto.js';

function setSessionCookie(app: AppContext, reply: FastifyReply, kind: SessionKind, s: NewSession): void {
  reply.setCookie(COOKIES[kind].name, s.token, {
    httpOnly: true,
    secure: app.config.cookieSecure,
    sameSite: 'lax',
    path: COOKIES[kind].path,
    expires: s.expiresAt,
  });
}

function clearSessionCookie(app: AppContext, reply: FastifyReply, kind: SessionKind): void {
  reply.clearCookie(COOKIES[kind].name, { httpOnly: true, secure: app.config.cookieSecure, sameSite: 'lax', path: COOKIES[kind].path });
}

const phoneField = z.string().trim().min(1, 'REQUIRED').max(40, 'INVALID_PHONE');
const loginPasswordField = z.string().min(1, 'REQUIRED').max(256, 'INVALID_CREDENTIALS');

// ---------------------------------------------------------------------------------------------
// Patient authentication
// ---------------------------------------------------------------------------------------------
export function patientAuthRoutes(app: AppContext): RouteDef<AuthKind, never, never, never>[] {
  const rl = app.config.rateLimits;

  const register = route({
    method: 'POST',
    url: '/register',
    auth: 'public',
    tags: ['Patient auth'],
    summary: 'Create a patient account (phone + password) and sign in. The phone number is normalized but NOT verified.',
    status: 201,
    rateLimit: rl.register,
    errors: ['VALIDATION_ERROR', 'INVALID_PHONE', 'PHONE_ALREADY_REGISTERED', 'PASSWORD_TOO_SHORT', 'PASSWORD_TOO_WEAK'],
    body: z.object({
      fullName: z.string().trim().min(2, 'NAME_TOO_SHORT').max(120, 'NAME_TOO_LONG'),
      phone: phoneField,
      password: z.string().max(256, 'PASSWORD_TOO_LONG'),
      locale: localeSchema.optional(),
    }),
    handler: async ({ app, reply, body, ip }) => {
      const phone = normalizePhone(body.phone);
      if (!phone) throw badRequest('INVALID_PHONE', 'Phone number is not valid', [{ field: 'phone', code: 'INVALID_PHONE' }]);
      assertPasswordPolicy(body.password, 'patient', { phone });
      const passwordHash = await hashPassword(body.password);
      try {
        const { patient, session } = await withTransaction(app.db, async (tx) => {
          const res = await tx.query<{ id: string }>(
            `INSERT INTO patients (phone_e164, full_name, password_hash, preferred_locale)
             VALUES ($1,$2,$3,$4) RETURNING id`,
            [phone, body.fullName, passwordHash, body.locale ?? null],
          );
          const id = res.rows[0]!.id;
          await recordAudit(tx, { actorType: 'patient', actorId: id, action: 'patient.registered', entityType: 'patient', entityId: id, ip });
          const session = await createSession(app, 'patient', id, tx);
          return { patient: { id, fullName: body.fullName, phone, preferredLocale: body.locale ?? null }, session };
        });
        setSessionCookie(app, reply, 'patient', session);
        return { patient: patientDto(patient), csrfToken: session.csrfToken };
      } catch (err) {
        if (pgErrorCode(err) === '23505' && pgConstraint(err) === 'patients_phone_e164_key') {
          throw conflict('PHONE_ALREADY_REGISTERED', 'An account with this phone number already exists');
        }
        throw err;
      }
    },
  });

  const login = route({
    method: 'POST',
    url: '/login',
    auth: 'public',
    tags: ['Patient auth'],
    summary: 'Sign in with phone + password. Failures are generic and rate limited per IP and per phone.',
    rateLimit: rl.login,
    errors: ['VALIDATION_ERROR', 'INVALID_CREDENTIALS', 'TOO_MANY_ATTEMPTS', 'RATE_LIMITED'],
    body: z.object({ phone: phoneField, password: loginPasswordField }),
    handler: async ({ app, reply, body, ip }) => {
      const phone = normalizePhone(body.phone);
      const limiterKey = `patient:${phone ?? body.phone.toLowerCase()}`;
      app.loginLimiter.assertAllowed(limiterKey);

      const row = phone
        ? (
            await app.db.query<{ id: string; full_name: string; phone_e164: string; preferred_locale: 'ar' | 'en' | 'fr' | null; password_hash: string; is_active: boolean }>(
              'SELECT id, full_name, phone_e164, preferred_locale, password_hash, is_active FROM patients WHERE phone_e164 = $1',
              [phone],
            )
          ).rows[0]
        : undefined;

      let ok = false;
      if (row) ok = (await verifyPassword(row.password_hash, body.password)) && row.is_active;
      else await verifyAgainstDummy(body.password);

      if (!ok || !row) {
        const locked = app.loginLimiter.recordFailure(limiterKey);
        if (locked) {
          await recordAudit(app.db, { actorType: 'anonymous', action: 'patient.login_throttled', entityType: 'patient', entityId: row?.id, outcome: 'denied', ip }).catch(() => undefined);
        }
        throw unauthorized('INVALID_CREDENTIALS', 'Invalid phone number or password');
      }

      app.loginLimiter.reset(limiterKey);
      if (needsRehash(row.password_hash)) {
        await app.db.query('UPDATE patients SET password_hash = $2 WHERE id = $1', [row.id, await hashPassword(body.password)]);
      }
      await app.db.query('UPDATE patients SET last_login_at = $2 WHERE id = $1', [row.id, app.clock.now()]);
      const session = await createSession(app, 'patient', row.id);
      setSessionCookie(app, reply, 'patient', session);
      return {
        patient: patientDto({ id: row.id, fullName: row.full_name, phone: row.phone_e164, preferredLocale: row.preferred_locale }),
        csrfToken: session.csrfToken,
      };
    },
  });

  const logout = route({
    method: 'POST',
    url: '/logout',
    auth: 'patient',
    tags: ['Patient auth'],
    summary: 'Sign out: revokes the current session and clears the cookie.',
    status: 204,
    handler: async ({ app, req, reply }) => {
      const token = req.cookies[COOKIES.patient.name];
      if (token) await revokeSessionByToken(app, token);
      clearSessionCookie(app, reply, 'patient');
      return NO_CONTENT;
    },
  });

  const changePassword = route({
    method: 'POST',
    url: '/password',
    auth: 'patient',
    tags: ['Patient auth'],
    summary: 'Change own password (requires the current password). Other sessions are revoked.',
    status: 204,
    errors: ['INVALID_CREDENTIALS', 'PASSWORD_TOO_SHORT', 'PASSWORD_TOO_WEAK'],
    body: z.object({ currentPassword: loginPasswordField, newPassword: z.string().max(256, 'PASSWORD_TOO_LONG') }),
    handler: async ({ app, body, patient, session, ip }) => {
      const key = `patient-pw:${patient.id}`;
      app.loginLimiter.assertAllowed(key);
      const row = (await app.db.query<{ password_hash: string }>('SELECT password_hash FROM patients WHERE id = $1', [patient.id])).rows[0];
      if (!row || !(await verifyPassword(row.password_hash, body.currentPassword))) {
        app.loginLimiter.recordFailure(key);
        throw unauthorized('INVALID_CREDENTIALS', 'Current password is incorrect');
      }
      assertPasswordPolicy(body.newPassword, 'patient', { phone: patient.phone });
      const hash = await hashPassword(body.newPassword);
      await withTransaction(app.db, async (tx) => {
        await tx.query('UPDATE patients SET password_hash = $2 WHERE id = $1', [patient.id, hash]);
        await revokePatientSessions(app, patient.id, session.id, tx);
        await recordAudit(tx, { actorType: 'patient', actorId: patient.id, action: 'patient.password_changed', entityType: 'patient', entityId: patient.id, ip });
      });
      app.loginLimiter.reset(key);
      return NO_CONTENT;
    },
  });

  return [register, login, logout, changePassword] as unknown as RouteDef<AuthKind, never, never, never>[];
}

// ---------------------------------------------------------------------------------------------
// Admin authentication
// ---------------------------------------------------------------------------------------------
export function adminAuthRoutes(app: AppContext): RouteDef<AuthKind, never, never, never>[] {
  const rl = app.config.rateLimits;

  const login = route({
    method: 'POST',
    url: '/login',
    auth: 'public',
    tags: ['Admin auth'],
    summary: 'Admin sign in. If `mustChangePassword` is true, only change-password, me and logout are allowed until it is done.',
    rateLimit: rl.login,
    errors: ['VALIDATION_ERROR', 'INVALID_CREDENTIALS', 'TOO_MANY_ATTEMPTS', 'RATE_LIMITED'],
    body: z.object({ username: z.string().trim().toLowerCase().min(1, 'REQUIRED').max(64, 'INVALID_CREDENTIALS'), password: loginPasswordField }),
    handler: async ({ app, reply, body, ip }) => {
      const key = `admin:${body.username}`;
      app.loginLimiter.assertAllowed(key);
      const row = (
        await app.db.query<{ id: string; username: string; full_name: string; password_hash: string; must_change_password: boolean; is_active: boolean }>(
          'SELECT id, username, full_name, password_hash, must_change_password, is_active FROM admin_users WHERE username = $1',
          [body.username],
        )
      ).rows[0];

      let ok = false;
      if (row) ok = (await verifyPassword(row.password_hash, body.password)) && row.is_active;
      else await verifyAgainstDummy(body.password);

      if (!ok || !row) {
        app.loginLimiter.recordFailure(key);
        await recordAudit(app.db, {
          actorType: row ? 'admin' : 'anonymous',
          actorId: row?.id,
          action: 'admin.login_failed',
          entityType: 'admin',
          entityId: row?.id,
          outcome: 'failure',
          metadata: { username: body.username.slice(0, 64) },
          ip,
        }).catch(() => undefined);
        throw unauthorized('INVALID_CREDENTIALS', 'Invalid username or password');
      }

      app.loginLimiter.reset(key);
      await app.db.query('UPDATE admin_users SET last_login_at = $2 WHERE id = $1', [row.id, app.clock.now()]);
      const session = await createSession(app, 'admin', row.id);
      await recordAudit(app.db, { actorType: 'admin', actorId: row.id, action: 'admin.login', entityType: 'admin', entityId: row.id, ip });
      setSessionCookie(app, reply, 'admin', session);
      return {
        admin: { id: row.id, username: row.username, fullName: row.full_name, mustChangePassword: row.must_change_password },
        csrfToken: session.csrfToken,
      };
    },
  });

  const me = route({
    method: 'GET',
    url: '/me',
    auth: 'admin-setup',
    tags: ['Admin auth'],
    summary: 'Current admin and CSRF token (also usable while a password change is pending).',
    handler: async ({ admin, session }) => ({ admin, csrfToken: session.csrfToken }),
  });

  const logout = route({
    method: 'POST',
    url: '/logout',
    auth: 'admin-setup',
    tags: ['Admin auth'],
    summary: 'Sign out of the dashboard.',
    status: 204,
    handler: async ({ app, req, reply, admin, ip }) => {
      const token = req.cookies[COOKIES.admin.name];
      if (token) await revokeSessionByToken(app, token);
      clearSessionCookie(app, reply, 'admin');
      await recordAudit(app.db, { actorType: 'admin', actorId: admin.id, action: 'admin.logout', entityType: 'admin', entityId: admin.id, ip }).catch(() => undefined);
      return NO_CONTENT;
    },
  });

  const changePassword = route({
    method: 'POST',
    url: '/change-password',
    auth: 'admin-setup',
    tags: ['Admin auth'],
    summary: 'Change the admin password (mandatory after first login). Clears the forced-change flag and revokes other sessions.',
    status: 204,
    errors: ['INVALID_CREDENTIALS', 'PASSWORD_TOO_SHORT', 'PASSWORD_TOO_WEAK', 'PASSWORD_UNCHANGED'],
    body: z.object({ currentPassword: loginPasswordField, newPassword: z.string().max(256, 'PASSWORD_TOO_LONG') }),
    handler: async ({ app, body, admin, session, ip }) => {
      const key = `admin-pw:${admin.id}`;
      app.loginLimiter.assertAllowed(key);
      const row = (await app.db.query<{ password_hash: string }>('SELECT password_hash FROM admin_users WHERE id = $1', [admin.id])).rows[0];
      if (!row || !(await verifyPassword(row.password_hash, body.currentPassword))) {
        app.loginLimiter.recordFailure(key);
        await recordAudit(app.db, { actorType: 'admin', actorId: admin.id, action: 'admin.password_change_failed', entityType: 'admin', entityId: admin.id, outcome: 'failure', ip }).catch(() => undefined);
        throw unauthorized('INVALID_CREDENTIALS', 'Current password is incorrect');
      }
      if (body.currentPassword === body.newPassword) throw badRequest('PASSWORD_UNCHANGED', 'The new password must differ from the current one', [{ field: 'newPassword', code: 'PASSWORD_UNCHANGED' }]);
      assertPasswordPolicy(body.newPassword, 'admin', { username: admin.username });
      const hash = await hashPassword(body.newPassword);
      await withTransaction(app.db, async (tx) => {
        await tx.query('UPDATE admin_users SET password_hash = $2, must_change_password = false WHERE id = $1', [admin.id, hash]);
        await revokeAdminSessions(app, admin.id, session.id, tx);
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'admin.password_changed', entityType: 'admin', entityId: admin.id, ip });
      });
      app.loginLimiter.reset(key);
      return NO_CONTENT;
    },
  });

  return [login, me, logout, changePassword] as unknown as RouteDef<AuthKind, never, never, never>[];
}

export { forbidden };
