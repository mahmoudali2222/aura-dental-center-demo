import argon2 from 'argon2';
import { badRequest } from '../../lib/errors.js';

/**
 * Argon2id with the OWASP-recommended minimum profile (19 MiB, 2 iterations, 1 lane).
 * Tune on the target hardware; hashes carry their own parameters, so raising them later is backward compatible.
 */
const OPTIONS = { type: argon2.argon2id, memoryCost: 19_456, timeCost: 2, parallelism: 1 } as const;

export function hashPassword(plain: string): Promise<string> {
  return argon2.hash(plain, OPTIONS);
}

export async function verifyPassword(hash: string, plain: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plain);
  } catch {
    return false;
  }
}

let dummyHash: Promise<string> | undefined;
/** Burns the same CPU as a real check when the account does not exist, so response time does not reveal it. */
export async function verifyAgainstDummy(plain: string): Promise<void> {
  dummyHash ??= hashPassword('dummy-password-for-timing-equalization');
  await verifyPassword(await dummyHash, plain);
}

export function needsRehash(hash: string): boolean {
  return argon2.needsRehash(hash, OPTIONS);
}

const COMMON = new Set(['12345678', '123456789', '1234567890', 'password', 'password1', 'qwertyui', '11111111', '00000000', 'iloveyou', 'abcdefgh', '12341234']);

/** Patient: 8-128 chars. Admin: 12-128 chars. Throws a coded validation error. */
export function assertPasswordPolicy(password: string, kind: 'patient' | 'admin', context: { phone?: string; username?: string } = {}): void {
  const min = kind === 'admin' ? 12 : 8;
  if (password.length < min) throw badRequest('PASSWORD_TOO_SHORT', `Password must be at least ${min} characters`, [{ field: 'password', code: 'PASSWORD_TOO_SHORT' }]);
  if (password.length > 128) throw badRequest('PASSWORD_TOO_LONG', 'Password must be at most 128 characters', [{ field: 'password', code: 'PASSWORD_TOO_LONG' }]);
  const lower = password.toLowerCase();
  const phoneDigits = context.phone?.replace(/\D/g, '');
  // A password that is just the phone number (international or local spelling) is trivially guessable.
  const isPhoneNumber = !!phoneDigits && /^\d{7,}$/.test(password) && phoneDigits.endsWith(password.replace(/^0+/, ''));
  if (COMMON.has(lower) || /^(.)\1+$/.test(password) || isPhoneNumber || (context.username && lower === context.username)) {
    throw badRequest('PASSWORD_TOO_WEAK', 'Password is too easy to guess', [{ field: 'password', code: 'PASSWORD_TOO_WEAK' }]);
  }
}
