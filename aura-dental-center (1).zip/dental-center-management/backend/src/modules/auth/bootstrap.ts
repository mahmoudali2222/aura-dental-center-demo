import pg from 'pg';
import { assertPasswordPolicy, hashPassword } from './password.js';
import { recordAudit } from '../audit/audit.service.js';
import { badRequest } from '../../lib/errors.js';

export interface BootstrapResult {
  created: boolean;
  username: string;
}

/**
 * Creates the initial admin account ONLY IF no admin exists yet. Never resets an existing account:
 * running it again (or restarting the stack) is a no-op. The account is flagged must_change_password,
 * so nothing but the password change is usable until the initial password has been replaced.
 * The password is read from the caller (environment), hashed with Argon2id, and never logged.
 */
export async function bootstrapAdmin(databaseUrl: string, username: string, password: string): Promise<BootstrapResult> {
  const normalized = username.trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,64}$/.test(normalized)) throw badRequest('INVALID_USERNAME', 'Admin username must be 3-64 chars: a-z, 0-9, dot, underscore, dash');
  assertPasswordPolicy(password, 'admin', { username: normalized });

  const client = new pg.Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('LOCK TABLE admin_users IN SHARE ROW EXCLUSIVE MODE');
    const existing = await client.query('SELECT 1 FROM admin_users LIMIT 1');
    if (existing.rowCount) {
      await client.query('ROLLBACK');
      return { created: false, username: normalized };
    }
    const hash = await hashPassword(password);
    const res = await client.query<{ id: string }>(
      `INSERT INTO admin_users (username, full_name, password_hash, must_change_password)
       VALUES ($1, 'Administrator', $2, true) RETURNING id`,
      [normalized, hash],
    );
    await recordAudit(client, { actorType: 'system', action: 'admin.bootstrap', entityType: 'admin', entityId: res.rows[0]!.id, metadata: { username: normalized } });
    await client.query('COMMIT');
    return { created: true, username: normalized };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    await client.end().catch(() => undefined);
  }
}

export interface ResetAdminResult {
  reset: boolean;
  username: string;
}

/**
 * Lock-out recovery for an administrator who forgot the password. It is NOT reachable over the network: it is a command-line
 * tool (docker compose run --rm reset-admin-password), so only someone who controls the server and its .env can use it, the
 * same trust level as direct database access.
 * Sets the given password (it must satisfy the admin password policy), forces a password change at the next login, revokes every
 * session of that account and writes an audit event (without the password). An unknown username changes nothing.
 */
export async function resetAdminPassword(databaseUrl: string, username: string, password: string): Promise<ResetAdminResult> {
  const normalized = username.trim().toLowerCase();
  assertPasswordPolicy(password, 'admin', { username: normalized });
  const client = new pg.Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    await client.query('BEGIN');
    const found = await client.query<{ id: string }>('SELECT id FROM admin_users WHERE username = $1 FOR UPDATE', [normalized]);
    const id = found.rows[0]?.id;
    if (!id) {
      await client.query('ROLLBACK');
      return { reset: false, username: normalized };
    }
    const hash = await hashPassword(password);
    await client.query('UPDATE admin_users SET password_hash = $2, must_change_password = true WHERE id = $1', [id, hash]);
    await client.query('UPDATE sessions SET revoked_at = now() WHERE admin_id = $1 AND revoked_at IS NULL', [id]);
    await recordAudit(client, { actorType: 'system', action: 'admin.password_reset_cli', entityType: 'admin', entityId: id, metadata: { username: normalized } });
    await client.query('COMMIT');
    return { reset: true, username: normalized };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    await client.end().catch(() => undefined);
  }
}
