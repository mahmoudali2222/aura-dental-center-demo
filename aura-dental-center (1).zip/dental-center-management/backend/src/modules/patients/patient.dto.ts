import type { Locale } from '../../lib/locale.js';

export interface PatientDtoInput {
  id: string;
  fullName: string;
  phone: string;
  preferredLocale: Locale | null;
}

/** The only shape in which a patient leaves the backend toward a patient-facing client: never any hash or internals. */
export function patientDto(p: PatientDtoInput) {
  return { id: p.id, fullName: p.fullName, phone: p.phone, preferredLocale: p.preferredLocale };
}
