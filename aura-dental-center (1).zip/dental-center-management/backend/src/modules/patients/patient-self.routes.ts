import { z } from 'zod';
import { defs, NO_CONTENT, Paged, route } from '../../lib/routes.js';
import { dateSchema, localeSchema, pageMeta, pageQuerySchema, slotNumberSchema, uuidSchema } from '../../lib/validation.js';
import { requestLocale } from '../../lib/request-locale.js';
import { notFound } from '../../lib/errors.js';
import { withTransaction } from '../../database/pool.js';
import { recordAudit } from '../audit/audit.service.js';
import { patientDto } from './patient.dto.js';
import {
  cancelAppointment, createAppointment, dtoOptions, getAppointmentRow, listPatientAppointments, rescheduleAppointment, toAppointmentDto,
} from '../appointments/appointment.service.js';
import { createLinkToken, getActiveLink, revokeLink } from '../integrations/telegram-link.service.js';
import type { AppContext } from '../../types.js';

const appointmentId = z.object({ id: uuidSchema });

export function patientSelfRoutes(_app: AppContext) {
  const me = route({
    method: 'GET', url: '/me', auth: 'patient', tags: ['Patient'],
    summary: 'Current patient profile and CSRF token (call after a page reload to restore the session).',
    handler: async ({ patient, session }) => ({ patient: patientDto(patient), csrfToken: session.csrfToken }),
  });

  const updateMe = route({
    method: 'PATCH', url: '/me', auth: 'patient', tags: ['Patient'],
    summary: 'Update permitted profile fields (name, language). The phone number is the account identity and is changed only by staff.',
    body: z.object({ fullName: z.string().trim().min(2, 'NAME_TOO_SHORT').max(120, 'NAME_TOO_LONG').optional(), preferredLocale: localeSchema.nullable().optional() }),
    handler: async ({ app, body, patient }) => {
      const res = await app.db.query<{ full_name: string; preferred_locale: 'ar' | 'en' | 'fr' | null }>(
        `UPDATE patients SET full_name = COALESCE($2, full_name),
                             preferred_locale = CASE WHEN $3::boolean THEN $4 ELSE preferred_locale END
          WHERE id = $1 RETURNING full_name, preferred_locale`,
        [patient.id, body.fullName ?? null, body.preferredLocale !== undefined, body.preferredLocale ?? null],
      );
      const r = res.rows[0]!;
      return { patient: patientDto({ id: patient.id, fullName: r.full_name, phone: patient.phone, preferredLocale: r.preferred_locale }) };
    },
  });

  const list = route({
    method: 'GET', url: '/appointments', auth: 'patient', tags: ['Patient', 'Booking'],
    summary: 'Own appointments. scope=upcoming (booked, not finished), history (everything else) or all.',
    query: pageQuerySchema.extend({ scope: z.enum(['upcoming', 'history', 'all']).default('upcoming'), locale: localeSchema.optional() }),
    handler: async ({ app, req, query, patient }) => {
      const { rows, total } = await listPatientAppointments(app, patient.id, query.scope, query.page, query.pageSize);
      const opts = await dtoOptions(app, requestLocale(req, patient.preferredLocale));
      return new Paged(rows.map((r) => toAppointmentDto(app, r, opts)), pageMeta(query.page, query.pageSize, total));
    },
  });

  const get = route({
    method: 'GET', url: '/appointments/:id', auth: 'patient', tags: ['Patient', 'Booking'],
    summary: 'One of the patient\'s own appointments. Someone else\'s appointment ID returns 404, never 403.',
    params: appointmentId, query: z.object({ locale: localeSchema.optional() }),
    errors: ['APPOINTMENT_NOT_FOUND'],
    handler: async ({ app, req, params, patient }) => {
      const row = await getAppointmentRow(app, params.id, patient.id);
      return toAppointmentDto(app, row, await dtoOptions(app, requestLocale(req, patient.preferredLocale)));
    },
  });

  const book = route({
    method: 'POST', url: '/appointments', auth: 'patient', tags: ['Patient', 'Booking'], status: 201,
    summary: 'Book a slot. All rules are enforced server-side inside a transaction.',
    body: z.object({
      departmentId: uuidSchema, serviceId: uuidSchema.nullable().optional(), date: dateSchema, slotNumber: slotNumberSchema,
      patientNote: z.string().trim().max(500, 'TEXT_TOO_LONG').optional(),
    }),
    errors: ['SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'DEPARTMENT_NOT_WORKING_DAY', 'BEYOND_BOOKING_HORIZON', 'PATIENT_OVERLAP', 'DEPARTMENT_NOT_FOUND', 'DEPARTMENT_INACTIVE', 'NO_ACTIVE_DENTIST', 'SERVICE_NOT_IN_DEPARTMENT'],
    handler: async ({ app, req, body, patient, ip }) => {
      const id = await createAppointment(app, {
        patientId: patient.id, departmentId: body.departmentId, serviceId: body.serviceId, date: body.date, slotNumber: body.slotNumber,
        patientNote: body.patientNote || null, createdVia: 'web', actor: { type: 'patient', id: patient.id }, ip,
      });
      const row = await getAppointmentRow(app, id, patient.id);
      return toAppointmentDto(app, row, await dtoOptions(app, requestLocale(req, patient.preferredLocale)));
    },
  });

  const cancel = route({
    method: 'POST', url: '/appointments/:id/cancel', auth: 'patient', tags: ['Patient', 'Booking'],
    summary: 'Cancel an own appointment. Allowed only if at least 24 hours remain before it starts.',
    params: appointmentId, query: z.object({ locale: localeSchema.optional() }),
    errors: ['APPOINTMENT_NOT_FOUND', 'APPOINTMENT_NOT_ACTIVE', 'WITHIN_24H_WINDOW'],
    handler: async ({ app, req, params, patient, ip }) => {
      await cancelAppointment(app, params.id, { actor: { type: 'patient', id: patient.id }, patientScope: patient.id, ip });
      const row = await getAppointmentRow(app, params.id, patient.id);
      return toAppointmentDto(app, row, await dtoOptions(app, requestLocale(req, patient.preferredLocale)));
    },
  });

  const reschedule = route({
    method: 'POST', url: '/appointments/:id/reschedule', auth: 'patient', tags: ['Patient', 'Booking'],
    summary: 'Move an own appointment to another available slot of the same department. The 24-hour rule applies to the ORIGINAL start.',
    params: appointmentId, query: z.object({ locale: localeSchema.optional() }),
    body: z.object({ date: dateSchema, slotNumber: slotNumberSchema }),
    errors: ['APPOINTMENT_NOT_FOUND', 'APPOINTMENT_NOT_ACTIVE', 'WITHIN_24H_WINDOW', 'SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'DEPARTMENT_NOT_WORKING_DAY', 'RESCHEDULE_NO_CHANGE', 'PATIENT_OVERLAP'],
    handler: async ({ app, req, params, body, patient, ip }) => {
      await rescheduleAppointment(app, params.id, { date: body.date, slotNumber: body.slotNumber }, { actor: { type: 'patient', id: patient.id }, patientScope: patient.id, ip });
      const row = await getAppointmentRow(app, params.id, patient.id);
      return toAppointmentDto(app, row, await dtoOptions(app, requestLocale(req, patient.preferredLocale)));
    },
  });

  // --- Telegram linking (patient side) -------------------------------------------------------
  const telegramStatus = route({
    method: 'GET', url: '/telegram', auth: 'patient', tags: ['Patient', 'Telegram'],
    summary: 'Whether a Telegram account is linked to this patient.',
    handler: async ({ app, patient }) => {
      const link = await getActiveLink(app.db, patient.id);
      return { linked: !!link, linkedAt: link?.created_at.toISOString() ?? null };
    },
  });

  const telegramToken = route({
    method: 'POST', url: '/telegram/link-token', auth: 'patient', tags: ['Patient', 'Telegram'], status: 201,
    summary: 'Create a short-lived (10 min), single-use code. The patient sends it to the Telegram bot to link their account.',
    handler: async ({ app, patient, ip }) => createLinkToken(app, patient.id, ip),
  });

  const telegramRevoke = route({
    method: 'DELETE', url: '/telegram', auth: 'patient', tags: ['Patient', 'Telegram'], status: 204,
    summary: 'Unlink the Telegram account. The bot loses access to this patient\'s data immediately.',
    handler: async ({ app, patient, ip }) => {
      await revokeLink(app, patient.id, 'patient', { type: 'patient', id: patient.id }, ip);
      return NO_CONTENT;
    },
  });

  void notFound; void withTransaction; void recordAudit;
  return defs(me, updateMe, list, get, book, cancel, reschedule, telegramStatus, telegramToken, telegramRevoke);
}
