import { z } from 'zod';
import { defs, NO_CONTENT, Paged, route } from '../../lib/routes.js';
import { badRequest, conflict, notFound } from '../../lib/errors.js';
import { likePattern, localeSchema, pageMeta, pageQuerySchema, uuidSchema } from '../../lib/validation.js';
import { normalizePhone } from '../../lib/phone.js';
import { pgConstraint, pgErrorCode, withTransaction } from '../../database/pool.js';
import { recordAudit } from '../audit/audit.service.js';
import { assertPasswordPolicy, hashPassword } from '../auth/password.js';
import { revokePatientSessions } from '../auth/session.service.js';
import { getActiveLink, revokeLink } from '../integrations/telegram-link.service.js';
import type { AppContext } from '../../types.js';

interface PatientRow {
  id: string; phone_e164: string; full_name: string; preferred_locale: 'ar' | 'en' | 'fr' | null; is_active: boolean;
  last_login_at: Date | null; created_at: Date;
}

const SELECT = 'SELECT id, phone_e164, full_name, preferred_locale, is_active, last_login_at, created_at FROM patients';

const dto = (r: PatientRow) => ({
  id: r.id, phone: r.phone_e164, fullName: r.full_name, preferredLocale: r.preferred_locale, isActive: r.is_active,
  lastLoginAt: r.last_login_at?.toISOString() ?? null, createdAt: r.created_at.toISOString(),
});

const idParam = z.object({ id: uuidSchema });

export function patientAdminRoutes(_app: AppContext) {
  const tags = ['Admin: patients'];

  const list = route({
    method: 'GET', url: '/patients', auth: 'admin', tags, summary: 'Search patients by name or phone.',
    query: pageQuerySchema.extend({ q: z.string().trim().max(80).optional(), active: z.enum(['true', 'false']).optional() }),
    handler: async ({ app, query }) => {
      const where: string[] = [];
      const params: unknown[] = [];
      if (query.q) {
        const digits = query.q.replace(/[^\d+]/g, '');
        params.push(likePattern(query.q.toLowerCase()));
        let cond = `lower(full_name) LIKE $${params.length}`;
        if (digits.length >= 3) { params.push(likePattern(digits)); cond += ` OR phone_e164 LIKE $${params.length}`; }
        where.push(`(${cond})`);
      }
      if (query.active) { params.push(query.active === 'true'); where.push(`is_active = $${params.length}`); }
      const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
      const total = Number((await app.db.query<{ n: string }>(`SELECT count(*) AS n FROM patients ${w}`, params)).rows[0]!.n);
      const rows = await app.db.query<PatientRow>(`${SELECT} ${w} ORDER BY created_at DESC, id LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, query.pageSize, (query.page - 1) * query.pageSize]);
      return new Paged(rows.rows.map(dto), pageMeta(query.page, query.pageSize, total));
    },
  });

  const get = route({
    method: 'GET', url: '/patients/:id', auth: 'admin', tags, summary: 'Patient details (never includes the password hash).', params: idParam, errors: ['PATIENT_NOT_FOUND'],
    handler: async ({ app, params }) => {
      const row = (await app.db.query<PatientRow>(`${SELECT} WHERE id = $1`, [params.id])).rows[0];
      if (!row) throw notFound('PATIENT_NOT_FOUND', 'Patient not found');
      const link = await getActiveLink(app.db, params.id);
      return { ...dto(row), telegramLinked: !!link };
    },
  });

  const create = route({
    method: 'POST', url: '/patients', auth: 'admin', tags, status: 201,
    summary: 'Create a patient account at the front desk (e.g. a walk-in who then books).',
    body: z.object({ fullName: z.string().trim().min(2, 'NAME_TOO_SHORT').max(120, 'NAME_TOO_LONG'), phone: z.string().trim().min(1, 'REQUIRED').max(40, 'INVALID_PHONE'), password: z.string().max(256, 'PASSWORD_TOO_LONG'), preferredLocale: localeSchema.optional() }),
    errors: ['INVALID_PHONE', 'PHONE_ALREADY_REGISTERED', 'PASSWORD_TOO_SHORT'],
    handler: async ({ app, body, admin, ip }) => {
      const phone = normalizePhone(body.phone);
      if (!phone) throw badRequest('INVALID_PHONE', 'Phone number is not valid', [{ field: 'phone', code: 'INVALID_PHONE' }]);
      assertPasswordPolicy(body.password, 'patient', { phone });
      const hash = await hashPassword(body.password);
      try {
        const id = await withTransaction(app.db, async (tx) => {
          const res = await tx.query<{ id: string }>('INSERT INTO patients (phone_e164, full_name, password_hash, preferred_locale) VALUES ($1,$2,$3,$4) RETURNING id', [phone, body.fullName, hash, body.preferredLocale ?? null]);
          await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'patient.created_by_admin', entityType: 'patient', entityId: res.rows[0]!.id, ip });
          return res.rows[0]!.id;
        });
        return dto((await app.db.query<PatientRow>(`${SELECT} WHERE id = $1`, [id])).rows[0]!);
      } catch (err) {
        if (pgErrorCode(err) === '23505' && pgConstraint(err) === 'patients_phone_e164_key') throw conflict('PHONE_ALREADY_REGISTERED', 'An account with this phone number already exists');
        throw err;
      }
    },
  });

  const update = route({
    method: 'PATCH', url: '/patients/:id', auth: 'admin', tags, params: idParam,
    summary: 'Edit name, phone, language, or activate/deactivate an account. Deactivation revokes all sessions.',
    body: z.object({ fullName: z.string().trim().min(2, 'NAME_TOO_SHORT').max(120, 'NAME_TOO_LONG').optional(), phone: z.string().trim().max(40, 'INVALID_PHONE').optional(), preferredLocale: localeSchema.nullable().optional(), isActive: z.boolean().optional() }),
    errors: ['PATIENT_NOT_FOUND', 'INVALID_PHONE', 'PHONE_ALREADY_REGISTERED'],
    handler: async ({ app, params, body, admin, ip }) => {
      const phone = body.phone !== undefined ? normalizePhone(body.phone) : undefined;
      if (body.phone !== undefined && !phone) throw badRequest('INVALID_PHONE', 'Phone number is not valid', [{ field: 'phone', code: 'INVALID_PHONE' }]);
      try {
        await withTransaction(app.db, async (tx) => {
          const cur = (await tx.query<{ is_active: boolean; phone_e164: string }>('SELECT is_active, phone_e164 FROM patients WHERE id = $1 FOR UPDATE', [params.id])).rows[0];
          if (!cur) throw notFound('PATIENT_NOT_FOUND', 'Patient not found');
          await tx.query(
            `UPDATE patients SET full_name = COALESCE($2, full_name), phone_e164 = COALESCE($3, phone_e164),
                                 preferred_locale = CASE WHEN $4::boolean THEN $5 ELSE preferred_locale END, is_active = COALESCE($6, is_active)
              WHERE id = $1`,
            [params.id, body.fullName ?? null, phone ?? null, body.preferredLocale !== undefined, body.preferredLocale ?? null, body.isActive ?? null],
          );
          if (body.isActive === false || (phone && phone !== cur.phone_e164)) await revokePatientSessions(app, params.id, undefined, tx);
          await recordAudit(tx, {
            actorType: 'admin', actorId: admin.id, action: 'patient.updated_by_admin', entityType: 'patient', entityId: params.id, ip,
            metadata: { fields: Object.keys(body).filter((k) => (body as Record<string, unknown>)[k] !== undefined), isActive: body.isActive, phoneChanged: !!phone && phone !== cur.phone_e164 },
          });
        });
      } catch (err) {
        if (pgErrorCode(err) === '23505' && pgConstraint(err) === 'patients_phone_e164_key') throw conflict('PHONE_ALREADY_REGISTERED', 'Another account already uses this phone number');
        throw err;
      }
      return dto((await app.db.query<PatientRow>(`${SELECT} WHERE id = $1`, [params.id])).rows[0]!);
    },
  });

  const resetPassword = route({
    method: 'POST', url: '/patients/:id/reset-password', auth: 'admin', tags, status: 204, params: idParam,
    summary: 'Staff-assisted password recovery. The admin must confirm the patient\'s identity in person (identityVerified: true). All the patient\'s sessions are revoked; the action is audited without the password.',
    body: z.object({ newPassword: z.string().max(256, 'PASSWORD_TOO_LONG'), identityVerified: z.literal(true, { error: 'IDENTITY_CONFIRMATION_REQUIRED' }) }),
    errors: ['PATIENT_NOT_FOUND', 'IDENTITY_CONFIRMATION_REQUIRED', 'PASSWORD_TOO_SHORT', 'PASSWORD_TOO_WEAK'],
    handler: async ({ app, params, body, admin, ip }) => {
      const cur = (await app.db.query<{ phone_e164: string }>('SELECT phone_e164 FROM patients WHERE id = $1', [params.id])).rows[0];
      if (!cur) throw notFound('PATIENT_NOT_FOUND', 'Patient not found');
      assertPasswordPolicy(body.newPassword, 'patient', { phone: cur.phone_e164 });
      const hash = await hashPassword(body.newPassword);
      await withTransaction(app.db, async (tx) => {
        await tx.query('UPDATE patients SET password_hash = $2 WHERE id = $1', [params.id, hash]);
        const revoked = await revokePatientSessions(app, params.id, undefined, tx);
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'patient.password_reset_by_admin', entityType: 'patient', entityId: params.id, ip, metadata: { sessionsRevoked: revoked, identityVerifiedInPerson: true } });
      });
      app.loginLimiter.reset(`patient:${cur.phone_e164}`);
      return NO_CONTENT;
    },
  });

  const revokeTelegram = route({
    method: 'POST', url: '/patients/:id/telegram/revoke', auth: 'admin', tags, status: 204, params: idParam,
    summary: 'Unlink a patient\'s Telegram account.',
    handler: async ({ app, params, admin, ip }) => {
      await revokeLink(app, params.id, 'admin', { type: 'admin', id: admin.id }, ip);
      return NO_CONTENT;
    },
  });

  return defs(list, get, create, update, resetPassword, revokeTelegram);
}
