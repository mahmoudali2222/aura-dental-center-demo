import { z } from 'zod';
import { defs, Paged, route } from '../../lib/routes.js';
import { boolQuery, dateSchema, localeSchema, pageMeta, pageQuerySchema, slotNumberSchema, uuidSchema, likePattern } from '../../lib/validation.js';
import { requestLocale } from '../../lib/request-locale.js';
import { centerToday, addDays } from '../../lib/time.js';
import { notFound } from '../../lib/errors.js';
import type { AppContext } from '../../types.js';
import {
  APPOINTMENT_SELECT, cancelAppointment, createAppointment, dtoOptions, getAppointmentRow, rescheduleAppointment, setAppointmentStatus, toAppointmentDto,
  type AppointmentRow,
} from '../appointments/appointment.service.js';

const idParam = z.object({ id: uuidSchema });
const localeQuery = z.object({ locale: localeSchema.optional() });

export function adminAppointmentRoutes(_app: AppContext) {
  const tags = ['Admin: appointments'];

  const list = route({
    method: 'GET', url: '/appointments', auth: 'admin', tags,
    summary: 'List/filter appointments (date range, department, status, patient, free-text on patient name/phone).',
    query: pageQuerySchema.extend({
      from: dateSchema.optional(), to: dateSchema.optional(), departmentId: uuidSchema.optional(), patientId: uuidSchema.optional(),
      status: z.enum(['booked', 'cancelled', 'completed', 'no_show']).optional(), q: z.string().trim().max(80).optional(),
      sort: z.enum(['asc', 'desc']).default('asc'), locale: localeSchema.optional(),
    }),
    handler: async ({ app, req, query }) => {
      const where: string[] = [];
      const params: unknown[] = [];
      const add = (sql: string, v: unknown) => { params.push(v); where.push(sql.replace('?', `$${params.length}`)); };
      if (query.from) add('a.appointment_date >= ?::date', query.from);
      if (query.to) add('a.appointment_date <= ?::date', query.to);
      if (query.departmentId) add('a.department_id = ?', query.departmentId);
      if (query.patientId) add('a.patient_id = ?', query.patientId);
      if (query.status) add('a.status = ?', query.status);
      if (query.q) {
        params.push(likePattern(query.q.toLowerCase()));
        const nameIdx = params.length;
        const digits = query.q.replace(/[^\d]/g, '');
        let cond = `lower(p.full_name) LIKE $${nameIdx}`;
        if (digits.length >= 3) { params.push(likePattern(digits)); cond += ` OR p.phone_e164 LIKE $${params.length}`; }
        where.push(`(${cond})`);
      }
      const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
      const total = Number((await app.db.query<{ n: string }>(`SELECT count(*) AS n FROM appointments a JOIN patients p ON p.id = a.patient_id ${w}`, params)).rows[0]!.n);
      const dir = query.sort === 'desc' ? 'DESC' : 'ASC';
      const rows = await app.db.query<AppointmentRow>(`${APPOINTMENT_SELECT} ${w} ORDER BY a.starts_at ${dir}, a.id LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, query.pageSize, (query.page - 1) * query.pageSize]);
      const opts = await dtoOptions(app, requestLocale(req), true);
      return new Paged(rows.rows.map((r) => toAppointmentDto(app, r, opts)), pageMeta(query.page, query.pageSize, total));
    },
  });

  const get = route({
    method: 'GET', url: '/appointments/:id', auth: 'admin', tags, summary: 'One appointment with patient details.', params: idParam, query: localeQuery, errors: ['APPOINTMENT_NOT_FOUND'],
    handler: async ({ app, req, params }) => toAppointmentDto(app, await getAppointmentRow(app, params.id), await dtoOptions(app, requestLocale(req), true)),
  });

  const create = route({
    method: 'POST', url: '/appointments', auth: 'admin', tags, status: 201, query: localeQuery,
    summary: 'Book on behalf of a patient. Slot, capacity, closure and past-time rules still apply (no override exists for them).',
    body: z.object({ patientId: uuidSchema, departmentId: uuidSchema, serviceId: uuidSchema.nullable().optional(), date: dateSchema, slotNumber: slotNumberSchema, patientNote: z.string().trim().max(500, 'TEXT_TOO_LONG').optional() }),
    errors: ['PATIENT_NOT_FOUND', 'SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'DEPARTMENT_NOT_WORKING_DAY', 'BEYOND_BOOKING_HORIZON', 'PATIENT_OVERLAP', 'DEPARTMENT_NOT_FOUND', 'NO_ACTIVE_DENTIST'],
    handler: async ({ app, req, body, admin, ip }) => {
      const id = await createAppointment(app, { ...body, patientNote: body.patientNote || null, createdVia: 'admin', actor: { type: 'admin', id: admin.id }, ip });
      return toAppointmentDto(app, await getAppointmentRow(app, id), await dtoOptions(app, requestLocale(req), true));
    },
  });

  const cancel = route({
    method: 'POST', url: '/appointments/:id/cancel', auth: 'admin', tags, params: idParam, query: localeQuery,
    summary: 'Cancel. Inside the 24-hour window an explicit `override: true` and a reason are required; both are audited.',
    body: z.object({ reason: z.string().trim().max(500, 'TEXT_TOO_LONG').optional(), override: z.boolean().optional() }),
    errors: ['APPOINTMENT_NOT_FOUND', 'APPOINTMENT_NOT_ACTIVE', 'WITHIN_24H_WINDOW', 'OVERRIDE_REASON_REQUIRED'],
    handler: async ({ app, req, params, body, admin, ip }) => {
      await cancelAppointment(app, params.id, { actor: { type: 'admin', id: admin.id }, override: body.override, reason: body.reason, ip });
      return toAppointmentDto(app, await getAppointmentRow(app, params.id), await dtoOptions(app, requestLocale(req), true));
    },
  });

  const reschedule = route({
    method: 'POST', url: '/appointments/:id/reschedule', auth: 'admin', tags, params: idParam, query: localeQuery,
    summary: 'Move an appointment to another slot of the same department. Override rules as for cancel.',
    body: z.object({ date: dateSchema, slotNumber: slotNumberSchema, reason: z.string().trim().max(500, 'TEXT_TOO_LONG').optional(), override: z.boolean().optional() }),
    errors: ['APPOINTMENT_NOT_FOUND', 'APPOINTMENT_NOT_ACTIVE', 'WITHIN_24H_WINDOW', 'OVERRIDE_REASON_REQUIRED', 'SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'DEPARTMENT_NOT_WORKING_DAY', 'RESCHEDULE_NO_CHANGE'],
    handler: async ({ app, req, params, body, admin, ip }) => {
      await rescheduleAppointment(app, params.id, { date: body.date, slotNumber: body.slotNumber }, { actor: { type: 'admin', id: admin.id }, override: body.override, reason: body.reason, ip });
      return toAppointmentDto(app, await getAppointmentRow(app, params.id), await dtoOptions(app, requestLocale(req), true));
    },
  });

  const status = route({
    method: 'POST', url: '/appointments/:id/status', auth: 'admin', tags, params: idParam, query: localeQuery,
    summary: 'Mark an appointment completed or no-show (only after it has started). Cancellation has its own endpoint.',
    body: z.object({ status: z.enum(['completed', 'no_show'], { error: 'INVALID_STATUS' }) }),
    errors: ['APPOINTMENT_NOT_FOUND', 'INVALID_STATUS_TRANSITION', 'APPOINTMENT_NOT_STARTED'],
    handler: async ({ app, req, params, body, admin, ip }) => {
      await setAppointmentStatus(app, params.id, body.status, { type: 'admin', id: admin.id }, ip);
      return toAppointmentDto(app, await getAppointmentRow(app, params.id), await dtoOptions(app, requestLocale(req), true));
    },
  });

  const dashboard = route({
    method: 'GET', url: '/dashboard', auth: 'admin', tags: ['Admin: dashboard'], query: localeQuery,
    summary: 'Today\'s appointments, status counts, per-department load (x of 4) and the next 7 days at a glance.',
    handler: async ({ app, req }) => {
      const today = centerToday(app.config.timezone, app.clock.now());
      const opts = await dtoOptions(app, requestLocale(req), true);
      const rows = await app.db.query<AppointmentRow>(`${APPOINTMENT_SELECT} WHERE a.appointment_date = $1::date ORDER BY a.starts_at, a.id`, [today]);
      const counts = { booked: 0, completed: 0, no_show: 0, cancelled: 0 };
      for (const r of rows.rows) counts[r.status] += 1;
      const load = await app.db.query<{ id: string; slug: string; name: string | null; active: string }>(
        `SELECT d.id, d.slug,
                (SELECT t.name FROM department_translations t WHERE t.department_id = d.id ORDER BY (t.locale = $2) DESC, (t.locale = 'en') DESC, t.locale LIMIT 1) AS name,
                (SELECT count(*) FROM appointments a WHERE a.department_id = d.id AND a.appointment_date = $1::date AND a.status IN ('booked','completed','no_show')) AS active
           FROM departments d WHERE d.is_active ORDER BY d.display_order, d.slug`,
        [today, opts.locale ?? opts.defaultLocale],
      );
      const upcoming = await app.db.query<{ appointment_date: string; n: string }>(
        `SELECT appointment_date, count(*) AS n FROM appointments
          WHERE status = 'booked' AND appointment_date > $1::date AND appointment_date <= $2::date GROUP BY 1 ORDER BY 1`,
        [today, addDays(today, 7)],
      );
      return {
        date: today,
        timezone: app.config.timezone,
        counts,
        appointments: rows.rows.map((r) => toAppointmentDto(app, r, opts)),
        departments: load.rows.map((d) => ({ id: d.id, slug: d.slug, name: d.name ?? d.slug, activeToday: Number(d.active), capacity: 4 })),
        next7Days: upcoming.rows.map((u) => ({ date: u.appointment_date, booked: Number(u.n) })),
      };
    },
  });

  void notFound; void boolQuery;
  return defs(dashboard, list, get, create, cancel, reschedule, status);
}
