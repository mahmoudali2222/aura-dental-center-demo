import { z } from 'zod';
import { defs, NO_CONTENT, route } from '../../lib/routes.js';
import { conflict, notFound, unprocessable } from '../../lib/errors.js';
import { dateSchema, localeSchema, uuidSchema, workingDaysSchema } from '../../lib/validation.js';
import { withTransaction } from '../../database/pool.js';
import { LOCALES } from '../../lib/locale.js';
import { recordAudit } from '../audit/audit.service.js';
import { loadCenter, loadSlotTemplates } from '../center/center.service.js';
import type { AppContext } from '../../types.js';

const text = (max: number) => z.string().trim().max(max, 'TEXT_TOO_LONG');
const entry = z.object({ name: text(160).optional(), address: text(500).optional(), introduction: text(4000).optional(), hoursNote: text(500).optional() });

export function adminSettingsRoutes(_app: AppContext) {
  const tags = ['Admin: settings'];

  const getCenter = route({
    method: 'GET', url: '/settings/center', auth: 'admin', tags, summary: 'Center profile with every translation (single source of truth for address/contact).',
    handler: async ({ app }) => ({ ...(await loadCenter(app.db)), timezone: app.config.timezone }),
  });

  const putCenter = route({
    method: 'PUT', url: '/settings/center', auth: 'admin', tags,
    summary: 'Update the center profile. Only the fields you send change. Per-language text accepts empty strings (e.g. to clear an address).',
    body: z.object({
      phone: text(40).nullable().optional(), whatsapp: text(40).nullable().optional(), email: z.string().trim().email('INVALID_EMAIL').max(160).nullable().optional(),
      mapUrl: z.string().trim().url('INVALID_URL').max(500).refine((u) => /^https?:\/\//i.test(u), 'INVALID_URL').nullable().optional(),
      defaultLocale: localeSchema.optional(), currency: z.string().trim().regex(/^[A-Z]{3}$/, 'INVALID_CURRENCY').optional(),
      bookingHorizonDays: z.number().int().min(1, 'INVALID_HORIZON').max(365, 'INVALID_HORIZON').optional(),
      workingDays: workingDaysSchema.optional(),
      translations: z.object({ ar: entry.optional(), en: entry.optional(), fr: entry.optional() }).optional(),
    }),
    handler: async ({ app, body, admin, ip }) => {
      await withTransaction(app.db, async (tx) => {
        const has = (k: keyof typeof body) => body[k] !== undefined;
        await tx.query(
          `UPDATE center_profile SET
             phone = CASE WHEN $1::boolean THEN $2 ELSE phone END, whatsapp = CASE WHEN $3::boolean THEN $4 ELSE whatsapp END,
             email = CASE WHEN $5::boolean THEN $6 ELSE email END, map_url = CASE WHEN $7::boolean THEN $8 ELSE map_url END,
             default_locale = COALESCE($9, default_locale), currency = COALESCE($10, currency),
             booking_horizon_days = COALESCE($11, booking_horizon_days), working_days = COALESCE($12::smallint[], working_days)
           WHERE id = 1`,
          [has('phone'), body.phone ?? null, has('whatsapp'), body.whatsapp ?? null, has('email'), body.email ?? null, has('mapUrl'), body.mapUrl ?? null,
           body.defaultLocale ?? null, body.currency ?? null, body.bookingHorizonDays ?? null, body.workingDays ?? null],
        );
        for (const l of LOCALES) {
          const e = body.translations?.[l];
          if (!e) continue;
          await tx.query(
            `INSERT INTO center_profile_translations (locale, name, address, introduction, hours_note) VALUES ($1, COALESCE($2,''), COALESCE($3,''), COALESCE($4,''), COALESCE($5,''))
             ON CONFLICT (locale) DO UPDATE SET
               name = COALESCE($2, center_profile_translations.name), address = COALESCE($3, center_profile_translations.address),
               introduction = COALESCE($4, center_profile_translations.introduction), hours_note = COALESCE($5, center_profile_translations.hours_note)`,
            [l, e.name ?? null, e.address ?? null, e.introduction ?? null, e.hoursNote ?? null],
          );
        }
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'center.updated', entityType: 'center', entityId: '1', ip, metadata: { fields: Object.keys(body), languages: body.translations ? Object.keys(body.translations) : [] } });
      });
      return { ...(await loadCenter(app.db)), timezone: app.config.timezone };
    },
  });

  const getSlots = route({ method: 'GET', url: '/settings/slots', auth: 'admin', tags, summary: 'The four daily two-hour slots (4 PM - 12 AM, Africa/Cairo).', handler: async ({ app }) => loadSlotTemplates(app.db) });

  const patchSlot = route({
    method: 'PATCH', url: '/settings/slots/:slotNumber', auth: 'admin', tags,
    summary: 'Enable/disable a slot. Existing appointments are untouched; start times and the 2-hour length are fixed by design.',
    params: z.object({ slotNumber: z.coerce.number().int().min(1).max(4) }), body: z.object({ isActive: z.boolean() }), errors: ['AT_LEAST_ONE_SLOT'],
    handler: async ({ app, params, body, admin, ip }) => {
      await withTransaction(app.db, async (tx) => {
        await tx.query('LOCK TABLE slot_templates IN SHARE ROW EXCLUSIVE MODE');
        if (!body.isActive) {
          const others = Number((await tx.query<{ n: string }>('SELECT count(*) AS n FROM slot_templates WHERE is_active AND slot_number <> $1', [params.slotNumber])).rows[0]!.n);
          if (others === 0) throw unprocessable('AT_LEAST_ONE_SLOT', 'At least one slot must stay active');
        }
        await tx.query('UPDATE slot_templates SET is_active = $2 WHERE slot_number = $1', [params.slotNumber, body.isActive]);
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'slot.updated', entityType: 'slot_template', entityId: String(params.slotNumber), ip, metadata: { isActive: body.isActive } });
      });
      return loadSlotTemplates(app.db);
    },
  });

  interface ClosureRow { id: string; date_from: string; date_to: string; department_id: string | null; reason: string }
  const cdto = (r: ClosureRow) => ({ id: r.id, dateFrom: r.date_from, dateTo: r.date_to, departmentId: r.department_id, reason: r.reason });

  const listClosures = route({
    method: 'GET', url: '/closures', auth: 'admin', tags, summary: 'Closed dates (whole center when departmentId is null).',
    query: z.object({ from: dateSchema.optional(), to: dateSchema.optional() }),
    handler: async ({ app, query }) => (await app.db.query<ClosureRow>(
      `SELECT id, date_from, date_to, department_id, reason FROM closures
        WHERE ($1::date IS NULL OR date_to >= $1::date) AND ($2::date IS NULL OR date_from <= $2::date) ORDER BY date_from, id`, [query.from ?? null, query.to ?? null])).rows.map(cdto),
  });

  const createClosure = route({
    method: 'POST', url: '/closures', auth: 'admin', tags, status: 201,
    summary: 'Close a date range (whole center, or one department). If active appointments already exist in it, the request is refused until acknowledged: those appointments are NOT cancelled automatically.',
    body: z.object({ dateFrom: dateSchema, dateTo: dateSchema, departmentId: uuidSchema.nullable().optional(), reason: text(300).optional(), acknowledgeExistingAppointments: z.boolean().optional() }),
    errors: ['INVALID_RANGE', 'CLOSURE_HAS_APPOINTMENTS', 'DEPARTMENT_NOT_FOUND'],
    handler: async ({ app, body, admin, ip }) => {
      if (body.dateTo < body.dateFrom) throw unprocessable('INVALID_RANGE', '`dateTo` must not be before `dateFrom`');
      return withTransaction(app.db, async (tx) => {
        if (body.departmentId && !(await tx.query('SELECT 1 FROM departments WHERE id = $1', [body.departmentId])).rowCount) throw notFound('DEPARTMENT_NOT_FOUND', 'Department not found');
        const n = Number((await tx.query<{ n: string }>(
          `SELECT count(*) AS n FROM appointments WHERE status = 'booked' AND appointment_date BETWEEN $1::date AND $2::date AND ($3::uuid IS NULL OR department_id = $3::uuid)`,
          [body.dateFrom, body.dateTo, body.departmentId ?? null])).rows[0]!.n);
        if (n > 0 && !body.acknowledgeExistingAppointments) throw conflict('CLOSURE_HAS_APPOINTMENTS', `${n} booked appointment(s) fall in this range; handle them manually, then repeat with acknowledgeExistingAppointments`, { count: n });
        const res = await tx.query<ClosureRow>('INSERT INTO closures (date_from, date_to, department_id, reason) VALUES ($1,$2,$3,$4) RETURNING id, date_from, date_to, department_id, reason', [body.dateFrom, body.dateTo, body.departmentId ?? null, body.reason ?? '']);
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'closure.created', entityType: 'closure', entityId: res.rows[0]!.id, ip, metadata: { dateFrom: body.dateFrom, dateTo: body.dateTo, departmentId: body.departmentId ?? null, existingAppointments: n } });
        return cdto(res.rows[0]!);
      });
    },
  });

  const deleteClosure = route({
    method: 'DELETE', url: '/closures/:id', auth: 'admin', tags, status: 204, params: z.object({ id: uuidSchema }), summary: 'Reopen a closed range.', errors: ['CLOSURE_NOT_FOUND'],
    handler: async ({ app, params, admin, ip }) => {
      await withTransaction(app.db, async (tx) => {
        const r = await tx.query('DELETE FROM closures WHERE id = $1', [params.id]);
        if (!r.rowCount) throw notFound('CLOSURE_NOT_FOUND', 'Closure not found');
        await recordAudit(tx, { actorType: 'admin', actorId: admin.id, action: 'closure.deleted', entityType: 'closure', entityId: params.id, ip });
      });
      return NO_CONTENT;
    },
  });

  return defs(getCenter, putCenter, getSlots, patchSlot, listClosures, createClosure, deleteClosure);
}
