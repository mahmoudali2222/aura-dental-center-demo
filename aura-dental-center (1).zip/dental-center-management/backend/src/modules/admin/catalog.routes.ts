import { z } from 'zod';
import { defs, NO_CONTENT, route } from '../../lib/routes.js';
import { imagePathSchema, uuidSchema, workingDaysSchema } from '../../lib/validation.js';
import { translationsSchema } from '../../lib/translations.js';
import type { AppContext } from '../../types.js';
import { createDepartment, getAdminDepartment, listAdminDepartments, updateDepartment } from '../departments/department.service.js';
import { createService, getAdminService, listAdminServices, updateService } from '../services/service.service.js';
import { createDentist, getDentist, listDentists, updateDentist } from '../dentists/dentist.service.js';
import { createGalleryCase, deleteGalleryCase, listAdminGallery, updateGalleryCase } from '../gallery/gallery.service.js';

const idParam = z.object({ id: uuidSchema });
const slug = z.string().trim().min(2, 'INVALID_SLUG').max(60, 'INVALID_SLUG').regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'INVALID_SLUG');
const nameDesc = translationsSchema({ name: { max: 120 }, description: { max: 2000 } });
const dentistTr = translationsSchema({ name: { max: 120 }, bio: { max: 2000 } });
const galleryTr = translationsSchema({ title: { max: 160 }, description: { max: 2000 }, altBefore: { max: 300 }, altAfter: { max: 300 } });

export function adminCatalogRoutes(_app: AppContext) {
  const dTags = ['Admin: departments'];
  const sTags = ['Admin: services'];
  const nTags = ['Admin: dentists'];
  const gTags = ['Admin: gallery'];

  // --- Departments -------------------------------------------------------------------------
  const deptList = route({ method: 'GET', url: '/departments', auth: 'admin', tags: dTags, summary: 'All departments (including inactive) with all translations.', handler: async ({ app }) => listAdminDepartments(app.db) });
  const deptGet = route({ method: 'GET', url: '/departments/:id', auth: 'admin', tags: dTags, summary: 'One department.', params: idParam, errors: ['DEPARTMENT_NOT_FOUND'], handler: async ({ app, params }) => getAdminDepartment(app.db, params.id) });
  const deptCreate = route({
    method: 'POST', url: '/departments', auth: 'admin', tags: dTags, status: 201,
    summary: 'Add a department. Needs a unique slug and at least one language. Working days default to every day. Assign its dentist afterwards.',
    body: z.object({ slug, displayOrder: z.number().int().min(0).max(10000).optional(), isActive: z.boolean().optional(), imagePath: imagePathSchema.nullable().optional(), workingDays: workingDaysSchema.optional(), translations: nameDesc }),
    errors: ['SLUG_TAKEN', 'AT_LEAST_ONE_TRANSLATION', 'AT_LEAST_ONE_WORKING_DAY'],
    handler: async ({ app, body, admin, ip }) => createDepartment(app, admin.id, { ...body, slug: body.slug }, ip),
  });
  const deptUpdate = route({
    method: 'PATCH', url: '/departments/:id', auth: 'admin', tags: dTags, params: idParam,
    summary: 'Edit a department. Per language: a non-empty name saves/updates it, an empty name removes that language. Deactivate instead of deleting. '
      + 'Working days control which weekdays patients can book in this department (together with the center\'s own working days). Removing a weekday on which booked, '
      + 'unfinished appointments exist is refused with WORKING_DAYS_HAVE_APPOINTMENTS (details.count) until repeated with acknowledgeExistingAppointments; those appointments are never cancelled automatically.',
    body: z.object({
      slug: slug.optional(), displayOrder: z.number().int().min(0).max(10000).optional(), isActive: z.boolean().optional(), imagePath: imagePathSchema.nullable().optional(),
      workingDays: workingDaysSchema.optional(), acknowledgeExistingAppointments: z.boolean().optional(), translations: nameDesc.optional(),
    }),
    errors: ['DEPARTMENT_NOT_FOUND', 'SLUG_TAKEN', 'AT_LEAST_ONE_TRANSLATION', 'AT_LEAST_ONE_WORKING_DAY', 'WORKING_DAYS_HAVE_APPOINTMENTS'],
    handler: async ({ app, params, body, admin, ip }) => updateDepartment(app, admin.id, params.id, body, ip),
  });

  // --- Services ---------------------------------------------------------------------------------
  const price = z.number().min(0, 'INVALID_PRICE').max(10_000_000, 'INVALID_PRICE').refine((n) => Math.round(n * 100) / 100 === n, 'INVALID_PRICE');
  const svcList = route({ method: 'GET', url: '/services', auth: 'admin', tags: sTags, summary: 'All services, optionally of one department.', query: z.object({ departmentId: uuidSchema.optional() }), handler: async ({ app, query }) => listAdminServices(app.db, query.departmentId) });
  const svcGet = route({ method: 'GET', url: '/services/:id', auth: 'admin', tags: sTags, summary: 'One service.', params: idParam, errors: ['SERVICE_NOT_FOUND'], handler: async ({ app, params }) => getAdminService(app.db, params.id) });
  const svcCreate = route({
    method: 'POST', url: '/services', auth: 'admin', tags: sTags, status: 201, summary: 'Add a service to a department. Price is optional (null = not shown).',
    body: z.object({ departmentId: uuidSchema, price: price.nullable().optional(), displayOrder: z.number().int().min(0).max(10000).optional(), isActive: z.boolean().optional(), imagePath: imagePathSchema.nullable().optional(), translations: nameDesc }),
    errors: ['DEPARTMENT_NOT_FOUND', 'AT_LEAST_ONE_TRANSLATION'],
    handler: async ({ app, body, admin, ip }) => createService(app, admin.id, body, ip),
  });
  const svcUpdate = route({
    method: 'PATCH', url: '/services/:id', auth: 'admin', tags: sTags, params: idParam, summary: 'Edit a service (deactivate instead of deleting; past appointments keep referencing it).',
    body: z.object({ departmentId: uuidSchema.optional(), price: price.nullable().optional(), displayOrder: z.number().int().min(0).max(10000).optional(), isActive: z.boolean().optional(), imagePath: imagePathSchema.nullable().optional(), translations: nameDesc.optional() }),
    errors: ['SERVICE_NOT_FOUND', 'DEPARTMENT_NOT_FOUND', 'AT_LEAST_ONE_TRANSLATION'],
    handler: async ({ app, params, body, admin, ip }) => updateService(app, admin.id, params.id, body, ip),
  });

  // --- Dentists ----------------------------------------------------------------------------------
  const dnList = route({ method: 'GET', url: '/dentists', auth: 'admin', tags: nTags, summary: 'All dentists (active and historical).', query: z.object({ departmentId: uuidSchema.optional() }), handler: async ({ app, query }) => listDentists(app.db, query.departmentId) });
  const dnGet = route({ method: 'GET', url: '/dentists/:id', auth: 'admin', tags: nTags, summary: 'One dentist.', params: idParam, errors: ['DENTIST_NOT_FOUND'], handler: async ({ app, params }) => getDentist(app.db, params.id) });
  const dnCreate = route({
    method: 'POST', url: '/dentists', auth: 'admin', tags: nTags, status: 201,
    summary: 'Assign a dentist to a department. If one is active, pass replaceExisting: true to deactivate them (kept for history). Dentists have no login.',
    body: z.object({ departmentId: uuidSchema, replaceExisting: z.boolean().optional(), photoPath: imagePathSchema.nullable().optional(), translations: dentistTr }),
    errors: ['DEPARTMENT_NOT_FOUND', 'DEPARTMENT_HAS_DENTIST', 'AT_LEAST_ONE_TRANSLATION'],
    handler: async ({ app, body, admin, ip }) => createDentist(app, admin.id, body, ip),
  });
  const dnUpdate = route({
    method: 'PATCH', url: '/dentists/:id', auth: 'admin', tags: nTags, params: idParam, summary: 'Edit a dentist\'s display information, or deactivate them.',
    body: z.object({ photoPath: imagePathSchema.nullable().optional(), isActive: z.boolean().optional(), translations: dentistTr.optional() }),
    errors: ['DENTIST_NOT_FOUND', 'DEPARTMENT_HAS_DENTIST', 'AT_LEAST_ONE_TRANSLATION'],
    handler: async ({ app, params, body, admin, ip }) => updateDentist(app, admin.id, params.id, body, ip),
  });

  // --- Gallery -----------------------------------------------------------------------------------
  const gList = route({ method: 'GET', url: '/gallery', auth: 'admin', tags: gTags, summary: 'All before/after cases including unpublished.', handler: async ({ app }) => listAdminGallery(app.db) });
  const gBody = {
    serviceId: uuidSchema.nullable().optional(), caseKind: z.enum(['real', 'sample']).optional(), consentConfirmed: z.boolean().optional(),
    isPublished: z.boolean().optional(), displayOrder: z.number().int().min(0).max(10000).optional(), translations: galleryTr.optional(),
  };
  const gCreate = route({
    method: 'POST', url: '/gallery', auth: 'admin', tags: gTags, status: 201,
    summary: 'Add a case. `real` cases can be published only after consent is confirmed; `sample` placeholders are always labelled as samples on the website.',
    body: z.object({ departmentId: uuidSchema, beforeImagePath: imagePathSchema, afterImagePath: imagePathSchema, ...gBody }),
    errors: ['DEPARTMENT_NOT_FOUND', 'CONSENT_REQUIRED'],
    handler: async ({ app, body, admin, ip }) => createGalleryCase(app, admin.id, body, ip),
  });
  const gUpdate = route({
    method: 'PATCH', url: '/gallery/:id', auth: 'admin', tags: gTags, params: idParam, summary: 'Edit/publish/unpublish a case.',
    body: z.object({ departmentId: uuidSchema.optional(), beforeImagePath: imagePathSchema.optional(), afterImagePath: imagePathSchema.optional(), ...gBody }),
    errors: ['GALLERY_CASE_NOT_FOUND', 'CONSENT_REQUIRED'],
    handler: async ({ app, params, body, admin, ip }) => updateGalleryCase(app, admin.id, params.id, body, ip),
  });
  const gDelete = route({
    method: 'DELETE', url: '/gallery/:id', auth: 'admin', tags: gTags, status: 204, params: idParam, summary: 'Remove a case.', errors: ['GALLERY_CASE_NOT_FOUND'],
    handler: async ({ app, params, admin, ip }) => { await deleteGalleryCase(app, admin.id, params.id, ip); return NO_CONTENT; },
  });

  return defs(deptList, deptGet, deptCreate, deptUpdate, svcList, svcGet, svcCreate, svcUpdate, dnList, dnGet, dnCreate, dnUpdate, gList, gCreate, gUpdate, gDelete);
}
