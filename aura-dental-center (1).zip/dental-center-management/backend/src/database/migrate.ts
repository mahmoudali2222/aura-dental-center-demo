import { createHash } from 'node:crypto';
import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

/** Repo-root `database/migrations`, resolved relative to this file (works from src/ and from dist/). */
export const DEFAULT_MIGRATIONS_DIR = fileURLToPath(new URL('../../../database/migrations', import.meta.url));
export const DEFAULT_SEEDS_DIR = fileURLToPath(new URL('../../../database/seeds', import.meta.url));

const FILE_RE = /^(\d{4})_[a-z0-9_]+\.sql$/;
const LOCK_KEY = 727_001; // arbitrary constant: serializes concurrent migrators

export interface MigrationResult {
  applied: string[];
  alreadyApplied: number;
}

/**
 * Applies pending SQL migrations in filename order, each inside its own transaction.
 * - Applied migrations are recorded with a SHA-256 checksum; editing an applied file aborts the run.
 * - A session-level advisory lock prevents two processes (e.g. two containers) migrating at once.
 * - Migrations are forward-only and never drop data on their own.
 */
export async function migrate(databaseUrl: string, dir: string = DEFAULT_MIGRATIONS_DIR): Promise<MigrationResult> {
  const files = (await readdir(dir)).filter((f) => FILE_RE.test(f)).sort();
  const client = new pg.Client({ connectionString: databaseUrl });
  await client.connect();
  const applied: string[] = [];
  let already = 0;
  try {
    await client.query('SELECT pg_advisory_lock($1)', [LOCK_KEY]);
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version     text PRIMARY KEY,
        checksum    text NOT NULL,
        applied_at  timestamptz NOT NULL DEFAULT now()
      )`);
    const { rows } = await client.query<{ version: string; checksum: string }>('SELECT version, checksum FROM schema_migrations');
    const done = new Map(rows.map((r) => [r.version, r.checksum]));

    for (const file of files) {
      const sql = await readFile(path.join(dir, file), 'utf8');
      const checksum = createHash('sha256').update(sql).digest('hex');
      const existing = done.get(file);
      if (existing !== undefined) {
        if (existing !== checksum) {
          throw new Error(`Migration ${file} was modified after being applied (checksum mismatch). Never edit applied migrations; add a new one.`);
        }
        already++;
        continue;
      }
      try {
        await client.query('BEGIN');
        await client.query(sql);
        await client.query('INSERT INTO schema_migrations (version, checksum) VALUES ($1, $2)', [file, checksum]);
        await client.query('COMMIT');
      } catch (err) {
        await client.query('ROLLBACK').catch(() => undefined);
        throw new Error(`Migration ${file} failed and was rolled back: ${(err as Error).message}`);
      }
      applied.push(file);
    }
    return { applied, alreadyApplied: already };
  } finally {
    await client.query('SELECT pg_advisory_unlock($1)', [LOCK_KEY]).catch(() => undefined);
    await client.end().catch(() => undefined);
  }
}
