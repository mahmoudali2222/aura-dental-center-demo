import pg from 'pg';

// DATE columns are business dates ("YYYY-MM-DD"). Never let node-postgres turn them into a JS Date
// at local midnight, which would shift the day depending on the server's timezone.
pg.types.setTypeParser(1082, (v: string) => v);

export type Db = pg.Pool;
export type Tx = pg.PoolClient;
/** Anything that can run a query: the pool, or a client inside a transaction. */
export type Queryable = Pick<pg.Pool, 'query'> | Pick<pg.PoolClient, 'query'>;

export function createPool(connectionString: string, max = 10): Db {
  const pool = new pg.Pool({ connectionString, max, idleTimeoutMillis: 30_000, connectionTimeoutMillis: 10_000 });
  // An idle client erroring (e.g. DB restart) must not crash the process; the pool discards it.
  pool.on('error', () => undefined);
  return pool;
}

const RETRYABLE = new Set(['40001', '40P01']); // serialization_failure, deadlock_detected

/**
 * Runs `fn` in a transaction (READ COMMITTED). Retries a few times on deadlock / serialization failure.
 * `fn` must be free of side effects outside the transaction, because it can run more than once.
 * Inside `fn`, use ONLY the supplied client: touching the pool while holding a client can exhaust it.
 */
export async function withTransaction<T>(pool: Db, fn: (tx: Tx) => Promise<T>, attempts = 3): Promise<T> {
  for (let attempt = 1; ; attempt++) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn(client);
      await client.query('COMMIT');
      return result;
    } catch (err) {
      try {
        await client.query('ROLLBACK');
      } catch {
        /* connection is gone; release below discards it */
      }
      const code = (err as { code?: string }).code;
      if (code && RETRYABLE.has(code) && attempt < attempts) continue;
      throw err;
    } finally {
      client.release();
    }
  }
}

export function pgErrorCode(err: unknown): string | undefined {
  return (err as { code?: string } | null)?.code;
}

export function pgConstraint(err: unknown): string | undefined {
  return (err as { constraint?: string } | null)?.constraint;
}
