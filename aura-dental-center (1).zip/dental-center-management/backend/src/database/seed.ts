import { readFile } from 'node:fs/promises';
import path from 'node:path';
import pg from 'pg';
import { DEFAULT_SEEDS_DIR } from './migrate.js';
import { LOCALES } from '../lib/locale.js';

type Names = Record<'ar' | 'en' | 'fr', string>;

interface Catalog {
  center: Record<string, { name?: string }>;
  sampleDentist: { names: Names; bios: Names };
  departments: {
    slug: string;
    order: number;
    /** Site-relative picture of the department (see docs/IMAGE_ASSETS.md); optional. Set only when the department is created. */
    imagePath?: string;
    names: Names;
    descriptions: Names;
    services: { names: Names; descriptions?: Partial<Names> }[];
  }[];
}

export interface SeedResult {
  departmentsInserted: number;
  departmentsSkipped: number;
}

/**
 * Loads the sample catalog. Idempotent and non-destructive:
 *  - a department is created only if its slug does not exist, together with its picture path, its sample dentist and sample
 *    services; an existing department (possibly edited by the admin, including a picture the admin removed) is never touched;
 *  - center names are filled only where still empty.
 * Contains no secrets and no real people; every dentist/service it creates is flagged is_sample.
 */
export async function seedCatalog(databaseUrl: string, seedsDir: string = DEFAULT_SEEDS_DIR): Promise<SeedResult> {
  const catalog = JSON.parse(await readFile(path.join(seedsDir, 'catalog.sample.json'), 'utf8')) as Catalog;
  const client = new pg.Client({ connectionString: databaseUrl });
  await client.connect();
  let inserted = 0;
  let skipped = 0;
  try {
    await client.query('BEGIN');

    for (const locale of LOCALES) {
      const name = catalog.center[locale]?.name;
      if (name) {
        await client.query(
          `INSERT INTO center_profile_translations (locale, name) VALUES ($1, $2)
           ON CONFLICT (locale) DO UPDATE SET name = EXCLUDED.name
           WHERE center_profile_translations.name = ''`,
          [locale, name],
        );
      }
    }

    for (const d of catalog.departments) {
      const res = await client.query<{ id: string }>(
        `INSERT INTO departments (slug, display_order, image_path) VALUES ($1, $2, $3)
         ON CONFLICT (slug) DO NOTHING RETURNING id`,
        [d.slug, d.order, d.imagePath ?? null],
      );
      const deptId = res.rows[0]?.id;
      if (!deptId) {
        skipped++;
        continue;
      }
      inserted++;
      for (const l of LOCALES) {
        await client.query(
          'INSERT INTO department_translations (department_id, locale, name, description) VALUES ($1,$2,$3,$4)',
          [deptId, l, d.names[l], d.descriptions[l]],
        );
      }
      const dentist = await client.query<{ id: string }>(
        'INSERT INTO dentists (department_id, is_sample) VALUES ($1, true) RETURNING id',
        [deptId],
      );
      for (const l of LOCALES) {
        await client.query(
          'INSERT INTO dentist_translations (dentist_id, locale, display_name, bio) VALUES ($1,$2,$3,$4)',
          [dentist.rows[0]!.id, l, catalog.sampleDentist.names[l], catalog.sampleDentist.bios[l]],
        );
      }
      let order = 1;
      for (const s of d.services) {
        const svc = await client.query<{ id: string }>(
          'INSERT INTO services (department_id, display_order, is_sample) VALUES ($1,$2,true) RETURNING id',
          [deptId, order++],
        );
        for (const l of LOCALES) {
          await client.query('INSERT INTO service_translations (service_id, locale, name, description) VALUES ($1,$2,$3,$4)', [
            svc.rows[0]!.id,
            l,
            s.names[l],
            s.descriptions?.[l] ?? '',
          ]);
        }
      }
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    await client.end().catch(() => undefined);
  }
  return { departmentsInserted: inserted, departmentsSkipped: skipped };
}
