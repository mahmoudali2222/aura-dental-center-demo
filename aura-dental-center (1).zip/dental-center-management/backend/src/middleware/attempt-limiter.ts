import { tooMany } from '../lib/errors.js';
import type { Clock } from '../lib/clock.js';
import type { RateLimitRule } from '../config/env.js';

/**
 * Failed-attempt throttle keyed by account (phone / username), complementing the per-IP limit.
 * In-memory by design (single backend instance): counters reset on restart and are not shared across replicas.
 * Trade-off: an attacker can temporarily lock a victim's login by failing on purpose; the lock expires on its own.
 */
export class AttemptLimiter {
  private readonly hits = new Map<string, { count: number; resetAt: number }>();

  constructor(
    private readonly rule: RateLimitRule,
    private readonly clock: Clock,
  ) {}

  /** Throws 429 if the key has used up its failures for the current window. */
  assertAllowed(key: string): void {
    const entry = this.live(key);
    if (entry && entry.count >= this.rule.max) throw tooMany('TOO_MANY_ATTEMPTS', 'Too many failed attempts; try again later');
  }

  /** Records a failure; returns true when this failure just exhausted the allowance. */
  recordFailure(key: string): boolean {
    const now = this.clock.now().getTime();
    const entry = this.live(key) ?? { count: 0, resetAt: now + this.rule.windowMs };
    entry.count += 1;
    this.hits.set(key, entry);
    if (this.hits.size > 10_000) this.sweep(now);
    return entry.count === this.rule.max;
  }

  reset(key: string): void {
    this.hits.delete(key);
  }

  private live(key: string) {
    const entry = this.hits.get(key);
    if (!entry) return undefined;
    if (entry.resetAt <= this.clock.now().getTime()) {
      this.hits.delete(key);
      return undefined;
    }
    return entry;
  }

  private sweep(now: number) {
    for (const [k, v] of this.hits) if (v.resetAt <= now) this.hits.delete(k);
  }
}
