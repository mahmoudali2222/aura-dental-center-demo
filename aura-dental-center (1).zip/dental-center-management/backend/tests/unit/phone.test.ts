import { describe, expect, it } from 'vitest';
import { normalizePhone } from '../../src/lib/phone.js';

describe('phone normalization (AUTH-02)', () => {
  it('maps every common spelling of the same Egyptian mobile to one E.164 value', () => {
    const variants = ['01012345678', '+201012345678', '00201012345678', '+20 101 234 5678', '0101-234-5678', '٠١٠١٢٣٤٥٦٧٨', '(+20) 101 2345678'];
    for (const v of variants) expect(normalizePhone(v), v).toBe('+201012345678');
  });
  it('accepts other valid international numbers', () => {
    expect(normalizePhone('+14155552671')).toBe('+14155552671');
  });
  it('rejects garbage and invalid numbers', () => {
    for (const v of ['', 'abc', '123', '0101234', '+2010123456789012', '01912345678', 'DROP TABLE']) expect(normalizePhone(v), v).toBeNull();
  });
});
