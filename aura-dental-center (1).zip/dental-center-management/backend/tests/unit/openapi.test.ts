import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { routeRegistry } from '../../src/lib/routes.js';
import { buildEndpointMarkdown, buildOpenApi, dedupeRoutes } from '../../src/lib/openapi.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const config = loadConfig({ NODE_ENV: 'development', DATABASE_URL: 'postgres://openapi:openapi@127.0.0.1:1/openapi', PUBLIC_APP_URL: 'http://localhost:8480', INTEGRATION_API_KEY: 'x'.repeat(32), LOG_LEVEL: 'silent' } as NodeJS.ProcessEnv);
const { app } = await buildApp({ config });
await app.ready();
const routes = dedupeRoutes(routeRegistry);
const pkg = JSON.parse(await readFile(path.join(root, 'backend/package.json'), 'utf8')) as { version: string };
const doc = buildOpenApi(routeRegistry, { version: pkg.version, timezone: config.timezone }) as any;

describe('API documentation cannot drift from the code', () => {
  it('docs/openapi.json and docs/API_REFERENCE.md equal a fresh generation (run `npm run openapi` after changing routes)', async () => {
    expect(await readFile(path.join(root, 'docs/openapi.json'), 'utf8')).toBe(`${JSON.stringify(doc, null, 2)}\n`);
    expect(await readFile(path.join(root, 'docs/API_REFERENCE.md'), 'utf8')).toBe(`${buildEndpointMarkdown(routeRegistry)}\n`);
  });

  it('documents every registered Fastify route and nothing else', () => {
    const documented = Object.entries(doc.paths).flatMap(([p, ms]) => Object.keys(ms as object).map((m) => `${m.toUpperCase()} ${p.replace(/\{(\w+)\}/g, ':$1')}`)).sort();
    const registered = routes.map((r) => `${r.method} ${r.url}`).sort();
    expect(documented).toEqual(registered);
    for (const r of routes) {
      const hasRoute = app.hasRoute({ method: r.method, url: r.url });
      expect(hasRoute, `${r.method} ${r.url}`).toBe(true);
    }
  });

  it('has unique operation ids, a summary on every operation, and a described auth scheme for each non-public one', () => {
    const ops = Object.values(doc.paths).flatMap((m) => Object.values(m as object)) as any[];
    const ids = ops.map((o) => o.operationId);
    expect(new Set(ids).size).toBe(ids.length);
    for (const o of ops) {
      expect(o.summary.length, o.operationId).toBeGreaterThan(5);
      for (const sec of o.security) for (const name of Object.keys(sec)) expect(doc.components.securitySchemes[name], name).toBeTruthy();
    }
  });

  it('declares CSRF on every state-changing session route, and never on integration or public routes', () => {
    for (const r of routes) {
      const op = doc.paths[r.url.replace(/:(\w+)/g, '{$1}')][r.method.toLowerCase()];
      const names = op.security.flatMap((s: object) => Object.keys(s));
      const unsafe = r.method !== 'GET';
      if ((r.auth === 'patient' || r.auth === 'admin' || r.auth === 'admin-setup') && unsafe) expect(names, `${r.method} ${r.url}`).toContain('csrfToken');
      else expect(names, `${r.method} ${r.url}`).not.toContain('csrfToken');
    }
  });

  it('the route table has the expected security shape', () => {
    // only the public auth endpoints and public content are reachable without credentials
    const open = routes.filter((r) => r.auth === 'public').map((r) => r.url);
    for (const url of open) expect(url).toMatch(/^\/api\/v1\/(public\/|patient\/auth\/(register|login)$|admin\/auth\/login$)/);
    expect(routes.filter((r) => r.url.startsWith('/api/v1/admin/') && !/\/auth\//.test(r.url)).every((r) => r.auth === 'admin')).toBe(true);
    expect(routes.filter((r) => r.url.includes('/medical')).every((r) => r.auth === 'admin')).toBe(true);
    // there is no unauthenticated password-reset route (recovery is staff-assisted only) and no OTP/SMS route
    for (const r of routes) expect(r.url, r.url).not.toMatch(/forgot|otp|sms|verify-phone|verification/i);
    const reset = routes.filter((r) => /reset-password/.test(r.url));
    expect(reset.length).toBe(1);
    expect(reset[0]).toMatchObject({ auth: 'admin', method: 'POST' });
    // the patient site has no AI/chat endpoint
    for (const r of routes) expect(r.url, r.url).not.toMatch(/chat|assistant|ai\b|llm|completion/i);
  });

  it('documents the error codes of the booking endpoints (the codes the frontends translate)', () => {
    const create = doc.paths['/api/v1/patient/appointments'].post['x-error-codes'] as string[];
    for (const code of ['SLOT_UNAVAILABLE', 'SLOT_IN_PAST', 'DATE_CLOSED', 'PATIENT_OVERLAP']) expect(create, code).toContain(code);
    const cancel = doc.paths['/api/v1/patient/appointments/{id}/cancel'].post['x-error-codes'] as string[];
    expect(cancel).toContain('WITHIN_24H_WINDOW');
  });
});
