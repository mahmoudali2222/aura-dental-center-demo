import { describe, expect, it } from 'vitest';
import { centerToday, diffDays, hasSelfServiceNotice, isoWeekday, isValidDateString, slotWindow, toCenterClock, toCenterIso } from '../../src/lib/time.js';

const Z = 'Africa/Cairo';

describe('slot windows (BOOK-07, BOOK-16)', () => {
  it('builds the four standard slots, each exactly two hours', () => {
    const expected: [string, string, string][] = [
      ['16:00', '2026-11-03T16:00:00+02:00', '2026-11-03T18:00:00+02:00'],
      ['18:00', '2026-11-03T18:00:00+02:00', '2026-11-03T20:00:00+02:00'],
      ['20:00', '2026-11-03T20:00:00+02:00', '2026-11-03T22:00:00+02:00'],
      ['22:00', '2026-11-03T22:00:00+02:00', '2026-11-04T00:00:00+02:00'],
    ];
    for (const [start, s, e] of expected) {
      const w = slotWindow(Z, '2026-11-03', start);
      expect(toCenterIso(Z, w.startsAt)).toBe(s);
      expect(toCenterIso(Z, w.endsAt)).toBe(e);
      expect(w.endsAt.getTime() - w.startsAt.getTime()).toBe(2 * 3600_000);
    }
  });

  it('the last slot ends at midnight but still belongs to the day it starts', () => {
    const w = slotWindow(Z, '2026-11-03', '22:00');
    expect(centerToday(Z, w.startsAt)).toBe('2026-11-03');
    expect(centerToday(Z, w.endsAt)).toBe('2026-11-04'); // 00:00 is the next calendar date...
    expect(toCenterClock(Z, w.endsAt)).toBe('00:00'); // ...displayed as midnight
  });

  it('fall-back night (Thu 29 Oct 2026): the 22:00 slot is still exactly 2 real hours and ends at 23:00 local', () => {
    const w = slotWindow(Z, '2026-10-29', '22:00');
    expect(w.endsAt.getTime() - w.startsAt.getTime()).toBe(2 * 3600_000);
    expect(toCenterIso(Z, w.startsAt)).toBe('2026-10-29T22:00:00+03:00');
    expect(toCenterIso(Z, w.endsAt)).toBe('2026-10-29T23:00:00+02:00');
  });

  it('spring-forward night (Thu 23 Apr 2026): the 22:00 slot is exactly 2 real hours and ends at 01:00 local', () => {
    const w = slotWindow(Z, '2026-04-23', '22:00');
    expect(w.endsAt.getTime() - w.startsAt.getTime()).toBe(2 * 3600_000);
    expect(toCenterIso(Z, w.startsAt)).toBe('2026-04-23T22:00:00+02:00');
    expect(toCenterIso(Z, w.endsAt)).toBe('2026-04-24T01:00:00+03:00');
  });

  it('the business date of a slot follows the Cairo calendar, not UTC', () => {
    // 23:30 Cairo on 3 Nov is 21:30Z on 3 Nov; 00:30 Cairo on 4 Nov is 22:30Z on 3 Nov
    expect(centerToday(Z, new Date('2026-11-03T22:30:00Z'))).toBe('2026-11-04');
    expect(centerToday(Z, new Date('2026-11-03T21:30:00Z'))).toBe('2026-11-03');
  });
});

describe('24-hour self-service rule (BOOK-11)', () => {
  const start = new Date('2026-11-10T14:00:00Z');
  const at = (msBefore: number) => new Date(start.getTime() - msBefore);
  it('is allowed 24:00:01 before start', () => expect(hasSelfServiceNotice(start, at(24 * 3600_000 + 1000))).toBe(true));
  it('is allowed exactly 24:00:00 before start (inclusive)', () => expect(hasSelfServiceNotice(start, at(24 * 3600_000))).toBe(true));
  it('is refused 23:59:59 before start', () => expect(hasSelfServiceNotice(start, at(24 * 3600_000 - 1000))).toBe(false));
  it('is refused after the start', () => expect(hasSelfServiceNotice(start, at(-1000))).toBe(false));
});

describe('date helpers', () => {
  it('validates real calendar dates only', () => {
    expect(isValidDateString('2026-02-29')).toBe(false);
    expect(isValidDateString('2028-02-29')).toBe(true);
    expect(isValidDateString('2026-13-01')).toBe(false);
    expect(isValidDateString('26-1-1')).toBe(false);
  });
  it('computes ISO weekdays and day differences', () => {
    expect(isoWeekday('2026-11-02')).toBe(1); // Monday
    expect(isoWeekday('2026-11-08')).toBe(7); // Sunday
    expect(diffDays('2026-11-02', '2026-11-12')).toBe(10);
  });
});
