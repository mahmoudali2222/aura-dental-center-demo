import { describe, expect, it } from 'vitest';
import { ConfigError, loadConfig } from '../../src/config/env.js';

const base = { DATABASE_URL: 'postgres://user:pw@db:5432/app', PUBLIC_APP_URL: 'https://clinic.example.com' };
const problemsOf = (env: Record<string, string>): string[] => {
  try { loadConfig(env as NodeJS.ProcessEnv); } catch (e) { if (e instanceof ConfigError) return e.problems; throw e; }
  return [];
};

describe('OPS-02 configuration validation', () => {
  it('accepts a minimal production configuration and applies safe defaults', () => {
    const c = loadConfig({ ...base, NODE_ENV: 'production' } as NodeJS.ProcessEnv);
    expect(c).toMatchObject({ env: 'production', cookieSecure: true, timezone: 'Africa/Cairo', port: 3480, trustProxy: false });
    expect(c.integrationKeys).toEqual([]); // integration disabled until a key is set
    expect(c.allowedOrigins).toEqual(['https://clinic.example.com']);
    expect(c.session.adminIdleMs).toBe(30 * 60_000); // staff sessions are short by default
    expect(c.rateLimits.login.max).toBe(20); // production limits, not the relaxed test ones
  });

  it('reports every missing or malformed required variable by name, in one go', () => {
    const p = problemsOf({ NODE_ENV: 'production' });
    expect(p.some((x) => x.startsWith('DATABASE_URL'))).toBe(true);
    expect(p.some((x) => x.startsWith('PUBLIC_APP_URL'))).toBe(true);
    expect(problemsOf({ ...base, DATABASE_URL: 'mysql://x' }).join()).toMatch(/DATABASE_URL.*postgres/);
    expect(problemsOf({ ...base, PORT: '70000' }).join()).toMatch(/PORT/);
    expect(problemsOf({ ...base, NODE_ENV: 'staging' }).join()).toMatch(/NODE_ENV/);
    expect(problemsOf({ ...base, PUBLIC_APP_URL: 'not a url' }).join()).toMatch(/PUBLIC_APP_URL/);
    expect(problemsOf({ ...base, SESSION_ADMIN_TTL_HOURS: '-1' }).join()).toMatch(/SESSION_ADMIN_TTL_HOURS/);
  });

  it('production refuses insecure cookies / plain http on a public address, but allows localhost', () => {
    expect(problemsOf({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'http://clinic.example.com' }).join('\n')).toMatch(/https/);
    expect(problemsOf({ ...base, NODE_ENV: 'production', COOKIE_SECURE: 'false' }).join('\n')).toMatch(/COOKIE_SECURE/);
    // Secure cookies are the production default even on localhost; a plain-http local Docker run opts out explicitly.
    const localDefault = loadConfig({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'http://localhost:8480' } as NodeJS.ProcessEnv);
    expect(localDefault.cookieSecure).toBe(true);
    const localHttp = loadConfig({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'http://localhost:8480', COOKIE_SECURE: 'false' } as NodeJS.ProcessEnv);
    expect(localHttp.cookieSecure).toBe(false);
    expect(loadConfig({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'http://127.0.0.1:8480', COOKIE_SECURE: 'false' } as NodeJS.ProcessEnv).cookieSecure).toBe(false);
    // development defaults to non-secure so the dev servers work out of the box
    expect(loadConfig({ ...base, NODE_ENV: 'development', PUBLIC_APP_URL: 'http://localhost:5173' } as NodeJS.ProcessEnv).cookieSecure).toBe(false);
  });

  it('checks the cheap schema rules first and the cross-field rules once those pass (two stages)', () => {
    const stage1 = problemsOf({ NODE_ENV: 'production', DATABASE_URL: 'mysql://x', PUBLIC_APP_URL: 'http://clinic.example.com' });
    expect(stage1.some((x) => x.startsWith('DATABASE_URL'))).toBe(true);
    expect(stage1.join()).not.toMatch(/must use https/); // reported after DATABASE_URL is fixed
    expect(problemsOf({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'http://clinic.example.com' }).join()).toMatch(/must use https/);
  });

  it('validates the time zone, extra origins and the integration keys', () => {
    expect(problemsOf({ ...base, CENTER_TIMEZONE: 'Mars/Olympus' }).join()).toMatch(/CENTER_TIMEZONE/);
    expect(problemsOf({ ...base, ALLOWED_ORIGINS: 'https://ok.example.com, not-an-origin' }).join()).toMatch(/ALLOWED_ORIGINS/);
    expect(loadConfig({ ...base, ALLOWED_ORIGINS: 'http://localhost:5173, http://localhost:5174' } as NodeJS.ProcessEnv).allowedOrigins)
      .toEqual(['https://clinic.example.com', 'http://localhost:5173', 'http://localhost:5174']);
    const k = 'k'.repeat(32);
    expect(problemsOf({ ...base, INTEGRATION_API_KEY: 'short' }).join()).toMatch(/INTEGRATION_API_KEY.*32/);
    expect(problemsOf({ ...base, INTEGRATION_API_KEY: k, INTEGRATION_API_KEY_NEXT: k }).join()).toMatch(/must differ/);
    expect(loadConfig({ ...base, INTEGRATION_API_KEY: k, INTEGRATION_API_KEY_NEXT: 'n'.repeat(32) } as NodeJS.ProcessEnv).integrationKeys).toEqual([k, 'n'.repeat(32)]);
  });

  it('treats blank values (what Docker Compose passes for an unset .env entry) as not set', () => {
    // docker-compose.yml names INTEGRATION_API_KEY etc.; an empty entry in .env reaches the container as "". That must switch the
    // integration off, not stop the backend from starting.
    const cfg = loadConfig({ ...base, INTEGRATION_API_KEY: '', INTEGRATION_API_KEY_NEXT: '  ', ALLOWED_ORIGINS: '', LOG_LEVEL: '', PORT: '' } as NodeJS.ProcessEnv);
    expect(cfg.integrationKeys).toEqual([]);
    expect(cfg.allowedOrigins).toEqual(['https://clinic.example.com']);
    expect(cfg.port).toBe(3480);
    // ...but a blank REQUIRED value is still reported as missing
    expect(problemsOf({ ...base, PUBLIC_APP_URL: '' }).join()).toMatch(/PUBLIC_APP_URL/);
    expect(problemsOf({ ...base, DATABASE_URL: ' ' }).join()).toMatch(/DATABASE_URL/);
  });

  it('never echoes secret values in error messages', () => {
    const secrets = ['TopSecretDbPassword', 'short-secret-key-value', 'PrivatePw!'];
    const attempts = [
      { ...base, DATABASE_URL: 'mysql://user:TopSecretDbPassword@host/db' },
      { ...base, INTEGRATION_API_KEY: 'short-secret-key-value' },
      { ...base, DATABASE_URL: 'postgres://u:PrivatePw!@h/db', INTEGRATION_API_KEY: 'x', PORT: 'abc' },
    ];
    for (const env of attempts) {
      let text = '';
      try { loadConfig(env as NodeJS.ProcessEnv); } catch (e) { text = `${(e as Error).message}\n${JSON.stringify((e as ConfigError).problems)}`; }
      expect(text.length).toBeGreaterThan(0);
      for (const s of secrets) expect(text).not.toContain(s);
    }
  });
});
