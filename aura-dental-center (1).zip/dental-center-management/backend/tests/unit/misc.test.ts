import { describe, expect, it } from 'vitest';
import { loadConfig, ConfigError } from '../../src/config/env.js';
import { fallbackChain, parseAcceptLanguage, pickText } from '../../src/lib/locale.js';
import { sanitizeMetadata } from '../../src/modules/audit/audit.service.js';
import { assertPasswordPolicy, hashPassword, verifyPassword } from '../../src/modules/auth/password.js';
import { normalizeLinkCode, randomLinkCode } from '../../src/lib/crypto.js';

const base = { DATABASE_URL: 'postgres://u:p@localhost/db', PUBLIC_APP_URL: 'http://localhost:8480' };

describe('configuration validation (OPS-02)', () => {
  it('accepts a minimal development config', () => {
    const c = loadConfig({ ...base, NODE_ENV: 'development' } as any);
    expect(c.timezone).toBe('Africa/Cairo');
    expect(c.cookieSecure).toBe(false);
    expect(c.integrationKeys).toEqual([]);
  });
  it('fails fast and names the missing variables without printing values', () => {
    expect(() => loadConfig({ NODE_ENV: 'production' } as any)).toThrow(ConfigError);
    try { loadConfig({ NODE_ENV: 'production', DATABASE_URL: 'postgres://u:supersecret@db/x' } as any); } catch (e) {
      expect((e as Error).message).toContain('PUBLIC_APP_URL');
      expect((e as Error).message).not.toContain('supersecret');
    }
  });
  it('requires secure cookies and https in production unless served from localhost', () => {
    expect(() => loadConfig({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'http://clinic.example.com', COOKIE_SECURE: 'false' } as any)).toThrow(/COOKIE_SECURE/);
    expect(() => loadConfig({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'http://clinic.example.com' } as any)).toThrow(/https/);
    expect(loadConfig({ ...base, NODE_ENV: 'production', PUBLIC_APP_URL: 'https://clinic.example.com' } as any).cookieSecure).toBe(true);
    expect(loadConfig({ ...base, NODE_ENV: 'production', COOKIE_SECURE: 'false' } as any).cookieSecure).toBe(false); // localhost docker
  });
  it('rejects short integration keys and an invalid timezone', () => {
    expect(() => loadConfig({ ...base, INTEGRATION_API_KEY: 'short' } as any)).toThrow(/INTEGRATION_API_KEY/);
    expect(() => loadConfig({ ...base, CENTER_TIMEZONE: 'Mars/Base' } as any)).toThrow(/CENTER_TIMEZONE/);
  });
});

describe('locale fallback policy (I18N-02)', () => {
  it('orders requested -> center default -> en -> ar -> fr without duplicates', () => {
    expect(fallbackChain('fr', 'ar')).toEqual(['fr', 'ar', 'en']);
    expect(fallbackChain(null, 'ar')).toEqual(['ar', 'en', 'fr']);
    expect(fallbackChain('en', 'en')).toEqual(['en', 'ar', 'fr']);
  });
  it('falls back through the chain and returns an empty string, never a key, when nothing exists', () => {
    const tr = { ar: { name: 'عربي' }, en: { name: '' }, fr: { name: 'Français' } };
    expect(pickText(tr, fallbackChain('en', 'ar'), 'name')).toBe('عربي');
    expect(pickText(tr, fallbackChain('fr', 'ar'), 'name')).toBe('Français');
    expect(pickText({}, ['en'], 'name')).toBe('');
    expect(pickText(null, ['en'], 'name')).toBe('');
  });
  it('parses Accept-Language by quality', () => {
    expect(parseAcceptLanguage('fr-CH, fr;q=0.9, en;q=0.8')).toBe('fr');
    expect(parseAcceptLanguage('de, en;q=0.5')).toBe('en');
    expect(parseAcceptLanguage('de')).toBeNull();
    expect(parseAcceptLanguage(undefined)).toBeNull();
  });
});

describe('audit metadata hygiene (AUD-03)', () => {
  it('redacts credentials and clinical text, keeps harmless context', () => {
    const out = sanitizeMetadata({
      password: 'x', newPassword: 'y', token: 't', csrfToken: 'c', authorization: 'Bearer a', apiKey: 'k', passwordHash: 'h',
      diagnosis: 'secret dx', treatment: 'tx', allergies: 'penicillin', medicalHistory: 'mh', notes: 'n', patientNote: 'pn',
      date: '2026-11-03', slotNumber: 2, nested: { cookie: 'c', ok: 'fine' },
    }) as Record<string, any>;
    for (const k of ['password', 'newPassword', 'token', 'csrfToken', 'authorization', 'apiKey', 'passwordHash', 'diagnosis', 'treatment', 'allergies', 'medicalHistory', 'notes', 'patientNote']) {
      expect(out[k], k).toBe('[redacted]');
    }
    expect(out.date).toBe('2026-11-03');
    expect(out.slotNumber).toBe(2);
    expect(out.nested).toEqual({ cookie: '[redacted]', ok: 'fine' });
  });
  it('truncates long strings', () => {
    expect((sanitizeMetadata({ a: 'x'.repeat(500) }) as any).a.length).toBeLessThan(250);
  });
});

describe('passwords (AUTH-03, AUTH-05)', () => {
  it('hashes with argon2id and verifies', async () => {
    const h = await hashPassword('correct horse battery');
    expect(h.startsWith('$argon2id$')).toBe(true);
    expect(h).not.toContain('correct horse');
    expect(await verifyPassword(h, 'correct horse battery')).toBe(true);
    expect(await verifyPassword(h, 'wrong')).toBe(false);
    expect(await verifyPassword('not-a-hash', 'x')).toBe(false);
  });
  it('enforces length and weakness rules per account type', () => {
    expect(() => assertPasswordPolicy('short', 'patient')).toThrow();
    expect(() => assertPasswordPolicy('12345678', 'patient')).toThrow();
    expect(() => assertPasswordPolicy('aaaaaaaaaa', 'patient')).toThrow();
    expect(() => assertPasswordPolicy('01012345678', 'patient', { phone: '+201012345678' })).toThrow();
    expect(() => assertPasswordPolicy('Good-enough-1', 'patient')).not.toThrow();
    expect(() => assertPasswordPolicy('only-11-chr', 'admin')).toThrow(); // 12 minimum for admin
  });
});

describe('telegram link codes', () => {
  it('are 12 unambiguous chars and normalize case/dashes', () => {
    const c = randomLinkCode();
    expect(c).toMatch(/^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
    expect(normalizeLinkCode(c.toLowerCase())).toBe(c.replaceAll('-', ''));
  });
});
