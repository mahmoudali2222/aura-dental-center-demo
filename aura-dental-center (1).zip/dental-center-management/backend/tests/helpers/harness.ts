import { randomBytes } from 'node:crypto';
import pg from 'pg';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../../src/app.js';
import { loadConfig, type AppConfig } from '../../src/config/env.js';
import { createPool, type Db } from '../../src/database/pool.js';
import { migrate } from '../../src/database/migrate.js';
import { seedCatalog } from '../../src/database/seed.js';
import { bootstrapAdmin } from '../../src/modules/auth/bootstrap.js';
import { FakeClock } from '../../src/lib/clock.js';
import type { AppContext } from '../../src/types.js';

export const ADMIN_URL = process.env.TEST_DATABASE_ADMIN_URL ?? 'postgres://postgres@127.0.0.1:54329/postgres';
export const INTEGRATION_KEY = 'test-integration-key-0123456789abcdef0123456789';
export const ADMIN_USER = 'owner';
export const ADMIN_PASS_INITIAL = 'Initial-Pass-Change-Me-1';
export const ADMIN_PASS = 'Strong-Admin-Pass-2026!';
/** Monday 2 Nov 2026, 10:00 in Cairo (UTC+2 after the October fall-back). */
export const BASE_NOW = '2026-11-02T08:00:00Z';

export interface TestEnv {
  app: FastifyInstance;
  ctx: AppContext;
  db: Db;
  clock: FakeClock;
  config: AppConfig;
  databaseUrl: string;
  api: Api;
  close: () => Promise<void>;
}

function dbUrl(name: string): string {
  const u = new URL(ADMIN_URL);
  u.pathname = `/${name}`;
  return u.toString();
}

export async function createTestDatabase(): Promise<{ url: string; drop: () => Promise<void> }> {
  const name = `dc_test_${randomBytes(5).toString('hex')}`;
  const admin = new pg.Client({ connectionString: ADMIN_URL });
  await admin.connect();
  await admin.query(`CREATE DATABASE ${name}`);
  await admin.end();
  const url = dbUrl(name);
  await migrate(url);
  return {
    url,
    drop: async () => {
      const c = new pg.Client({ connectionString: ADMIN_URL });
      await c.connect();
      await c.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`);
      await c.end();
    },
  };
}

export interface ApiResult<T = any> {
  status: number;
  body: T;
  headers: Record<string, any>;
  cookies: { name: string; value: string }[];
}

export interface Session {
  cookieName: string;
  token: string;
  csrf: string;
}

export interface Api {
  request: (method: string, url: string, opts?: { body?: unknown; session?: Session | null; headers?: Record<string, string>; ip?: string }) => Promise<ApiResult>;
  get: (url: string, session?: Session | null, headers?: Record<string, string>) => Promise<ApiResult>;
  post: (url: string, body?: unknown, session?: Session | null, headers?: Record<string, string>) => Promise<ApiResult>;
  patch: (url: string, body?: unknown, session?: Session | null) => Promise<ApiResult>;
  put: (url: string, body?: unknown, session?: Session | null) => Promise<ApiResult>;
  del: (url: string, session?: Session | null) => Promise<ApiResult>;
  integration: (method: string, url: string, body?: unknown) => Promise<ApiResult>;
}

export function makeApi(app: FastifyInstance): Api {
  const request: Api['request'] = async (method, url, opts = {}) => {
    const headers: Record<string, string> = { ...(opts.headers ?? {}) };
    if (opts.session) {
      headers.cookie = `${opts.session.cookieName}=${opts.session.token}`;
      if (method !== 'GET') headers['x-csrf-token'] = opts.session.csrf;
    }
    const res = await app.inject({
      method: method as any, url, headers,
      payload: opts.body === undefined ? undefined : (opts.body as any),
      remoteAddress: opts.ip,
    });
    let body: any = undefined;
    const text = res.body;
    if (text) { try { body = JSON.parse(text); } catch { body = text; } }
    return { status: res.statusCode, body, headers: res.headers, cookies: res.cookies.map((c) => ({ name: c.name, value: c.value })) };
  };
  return {
    request,
    get: (url, session, headers) => request('GET', url, { session, headers }),
    post: (url, body, session, headers) => request('POST', url, { body: body ?? {}, session, headers }),
    patch: (url, body, session) => request('PATCH', url, { body: body ?? {}, session }),
    put: (url, body, session) => request('PUT', url, { body: body ?? {}, session }),
    del: (url, session) => request('DELETE', url, { session }),
    integration: (method, url, body) => request(method, `/api/v1/integrations${url}`, { body, headers: { authorization: `Bearer ${INTEGRATION_KEY}` } }),
  };
}

export async function createTestEnv(overrides: Partial<NodeJS.ProcessEnv> = {}, extra: { logStream?: NodeJS.WritableStream } = {}): Promise<TestEnv> {
  const { url, drop } = await createTestDatabase();
  await seedCatalog(url);
  const config = loadConfig({
    NODE_ENV: 'test', DATABASE_URL: url, PUBLIC_APP_URL: 'http://localhost:8480', LOG_LEVEL: 'silent',
    INTEGRATION_API_KEY: INTEGRATION_KEY, DB_POOL_MAX: '30', ...overrides,
  } as NodeJS.ProcessEnv);
  const db = createPool(url, config.dbPoolMax);
  const clock = new FakeClock(new Date(BASE_NOW));
  const { app, ctx } = await buildApp({ config, db, clock, logStream: extra.logStream });
  await app.ready();
  return {
    app, ctx, db, clock, config, databaseUrl: url, api: makeApi(app),
    close: async () => { await app.close(); await db.end(); await drop(); },
  };
}

let phoneCounter = 0;
/** A valid, unique Egyptian mobile number per call. */
export function uniquePhone(): string {
  phoneCounter += 1;
  return `0101${String(1000000 + phoneCounter).slice(-7)}`;
}

export function sessionFrom(res: ApiResult, cookieName: string): Session {
  const c = res.cookies.find((x) => x.name === cookieName);
  if (!c) throw new Error(`no ${cookieName} cookie in response (status ${res.status}: ${JSON.stringify(res.body)})`);
  return { cookieName, token: c.value, csrf: res.body.data.csrfToken };
}

export interface TestPatient { id: string; phone: string; password: string; session: Session }

export async function registerPatient(env: TestEnv, opts: { phone?: string; password?: string; fullName?: string; locale?: string } = {}): Promise<TestPatient> {
  const phone = opts.phone ?? uniquePhone();
  const password = opts.password ?? 'Patient-Pass-123';
  const res = await env.api.post('/api/v1/patient/auth/register', { fullName: opts.fullName ?? 'Test Patient', phone, password, locale: opts.locale });
  if (res.status !== 201) throw new Error(`register failed: ${res.status} ${JSON.stringify(res.body)}`);
  return { id: res.body.data.patient.id, phone, password, session: sessionFrom(res, 'dc_patient') };
}

/** Creates the bootstrap admin, logs in, completes the forced password change and logs in again. */
export async function adminSession(env: TestEnv): Promise<Session> {
  await bootstrapAdmin(env.databaseUrl, ADMIN_USER, ADMIN_PASS_INITIAL);
  const first = await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS_INITIAL });
  if (first.status !== 200) throw new Error(`admin login failed ${first.status} ${JSON.stringify(first.body)}`);
  const s1 = sessionFrom(first, 'dc_admin');
  const ch = await env.api.post('/api/v1/admin/auth/change-password', { currentPassword: ADMIN_PASS_INITIAL, newPassword: ADMIN_PASS }, s1);
  if (ch.status !== 204) throw new Error(`admin change-password failed ${ch.status} ${JSON.stringify(ch.body)}`);
  const second = await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS });
  return sessionFrom(second, 'dc_admin');
}

export async function departmentId(env: TestEnv, slug: string): Promise<string> {
  const r = await env.db.query<{ id: string }>('SELECT id FROM departments WHERE slug = $1', [slug]);
  return r.rows[0]!.id;
}

/** Cairo calendar date `days` after BASE_NOW's date (2026-11-02). */
export function dayOffset(days: number): string {
  const d = new Date(Date.UTC(2026, 10, 2 + days));
  return d.toISOString().slice(0, 10);
}
