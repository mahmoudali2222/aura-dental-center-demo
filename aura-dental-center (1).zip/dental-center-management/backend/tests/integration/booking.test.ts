import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { BASE_NOW, adminSession, createTestEnv, dayOffset, departmentId, registerPatient, type Session, type TestEnv, type TestPatient } from '../helpers/harness.js';

let env: TestEnv;
let admin: Session;
let general: string; // department ids
let endo: string;
let ortho: string;

const LONG_SESSIONS = { SESSION_PATIENT_IDLE_MINUTES: '1000000', SESSION_PATIENT_TTL_HOURS: '100000', SESSION_ADMIN_IDLE_MINUTES: '1000000', SESSION_ADMIN_TTL_HOURS: '100000' };

beforeAll(async () => {
  env = await createTestEnv(LONG_SESSIONS);
  admin = await adminSession(env);
  general = await departmentId(env, 'restorative-dentistry');
  endo = await departmentId(env, 'endodontics');
  ortho = await departmentId(env, 'orthodontics');
});
afterAll(async () => { await env.close(); });
beforeEach(() => { env.clock.set(BASE_NOW); });

const book = (p: TestPatient, departmentId: string, date: string, slotNumber: number, extra: object = {}) =>
  env.api.post('/api/v1/patient/appointments', { departmentId, date, slotNumber, ...extra }, p.session);

const activeCount = async (departmentId: string, date: string) =>
  Number((await env.db.query("SELECT count(*) AS n FROM appointments WHERE department_id = $1 AND appointment_date = $2 AND status IN ('booked','completed','no_show')", [departmentId, date])).rows[0].n);

describe('slots, capacity and midnight', () => {
  it('BOOK-01/07 books each of the four slots; the 10 PM slot ends at midnight but stays on its own date', async () => {
    const date = dayOffset(3); // Thu 5 Nov 2026
    const expected = [['16:00', '18:00'], ['18:00', '20:00'], ['20:00', '22:00'], ['22:00', '00:00']];
    for (let slot = 1; slot <= 4; slot++) {
      const p = await registerPatient(env);
      const res = await book(p, general, date, slot);
      expect(res.status, JSON.stringify(res.body)).toBe(201);
      const a = res.body.data;
      expect(a).toMatchObject({ status: 'booked', date, slotNumber: slot, startTime: expected[slot - 1]![0], endTime: expected[slot - 1]![1] });
      expect(new Date(a.endsAt).getTime() - new Date(a.startsAt).getTime()).toBe(2 * 3600_000);
      if (slot === 4) {
        expect(a.startsAt).toBe('2026-11-05T22:00:00+02:00');
        expect(a.endsAt).toBe('2026-11-06T00:00:00+02:00');
        expect(a.endsNextDay).toBe(true);
      }
    }
    // the midnight slot counts toward 5 Nov, not 6 Nov
    expect(await activeCount(general, date)).toBe(4);
    expect(await activeCount(general, dayOffset(4))).toBe(0);
    // ...and 6 Nov is completely free
    const avail = await env.api.get(`/api/v1/public/departments/restorative-dentistry/availability?from=${dayOffset(4)}&to=${dayOffset(4)}`);
    expect(avail.body.data.days[0]).toMatchObject({ date: dayOffset(4), status: 'open', availableCount: 4 });
  });

  it('BOOK-02 a fifth booking on a full department-day is rejected; availability reports the day as full', async () => {
    const date = dayOffset(6);
    for (let slot = 1; slot <= 4; slot++) expect((await book(await registerPatient(env), endo, date, slot)).status).toBe(201);
    const fifth = await book(await registerPatient(env), endo, date, 2);
    expect(fifth.status).toBe(409);
    expect(['SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED']).toContain(fifth.body.error.code);
    expect(await activeCount(endo, date)).toBe(4);
    const avail = await env.api.get(`/api/v1/public/departments/endodontics/availability?from=${date}&to=${date}`);
    expect(avail.body.data.days[0]).toMatchObject({ status: 'full', availableCount: 0, slots: [] });
  });

  it('BOOK-03 capacity is per department: a full department does not block another one on the same day', async () => {
    const date = dayOffset(7);
    for (let slot = 1; slot <= 4; slot++) await book(await registerPatient(env), general, date, slot);
    const other = await book(await registerPatient(env), ortho, date, 1);
    expect(other.status).toBe(201);
    expect(await activeCount(ortho, date)).toBe(1);
  });

  it('BOOK-04 the same slot cannot be booked twice in a department (but can in another)', async () => {
    const date = dayOffset(8);
    expect((await book(await registerPatient(env), general, date, 3)).status).toBe(201);
    const dup = await book(await registerPatient(env), general, date, 3);
    expect(dup.status).toBe(409);
    expect(dup.body.error.code).toBe('SLOT_UNAVAILABLE');
    expect((await book(await registerPatient(env), endo, date, 3)).status).toBe(201);
  });

  it('BOOK-05 the database itself refuses duplicates, overlaps and a fifth appointment even when the app is bypassed', async () => {
    const date = dayOffset(9);
    const p1 = await registerPatient(env); const p2 = await registerPatient(env);
    expect((await book(p1, general, date, 1)).status).toBe(201); // 16:00-18:00
    const ins = (patient: string, slot: number, startsAtSql: string, endsAtSql: string) =>
      env.db.query(`INSERT INTO appointments (patient_id, department_id, appointment_date, slot_number, starts_at, ends_at, created_via)
                    VALUES ($1,$2,$3,$4, ${startsAtSql}, ${endsAtSql}, 'admin')`, [patient, general, date, slot]);
    // same slot number
    await expect(ins(p2.id, 1, `'${date} 16:00 Africa/Cairo'::timestamptz`, `'${date} 18:00 Africa/Cairo'::timestamptz`)).rejects.toMatchObject({ code: '23505' });
    // different slot number but overlapping time (17:00-19:00 overlaps 16:00-18:00)
    await expect(ins(p2.id, 2, `'${date} 17:00 Africa/Cairo'::timestamptz`, `'${date} 19:00 Africa/Cairo'::timestamptz`)).rejects.toMatchObject({ code: '23P01' });
    // wrong duration
    await expect(ins(p2.id, 3, `'${date} 20:00 Africa/Cairo'::timestamptz`, `'${date} 21:00 Africa/Cairo'::timestamptz`)).rejects.toMatchObject({ code: '23514' });
    // slot number outside 1..4 (this is what caps a department at four per day)
    await expect(ins(p2.id, 5, `'${date} 22:00 Africa/Cairo'::timestamptz`, `'${date} 23:59 Africa/Cairo'::timestamptz`)).rejects.toMatchObject({ code: '23514' });
    expect(await activeCount(general, date)).toBe(1);
  });

  it('BOOK-15 one patient cannot hold two overlapping appointments in different departments; non-overlapping is fine', async () => {
    const date = dayOffset(10);
    const p = await registerPatient(env);
    expect((await book(p, general, date, 2)).status).toBe(201);
    const clash = await book(p, endo, date, 2);
    expect(clash.status).toBe(409);
    expect(clash.body.error.code).toBe('PATIENT_OVERLAP');
    expect((await book(p, endo, date, 3)).status).toBe(201);
  });
});

describe('past, horizon, closures, inactive departments', () => {
  it('BOOK-06 rejects past dates and slots that already started, accepts later slots today', async () => {
    const p = await registerPatient(env);
    const today = dayOffset(0);
    expect((await book(p, general, dayOffset(-1), 4)).body.error.code).toBe('SLOT_IN_PAST');
    env.clock.set('2026-11-02T14:30:00Z'); // 16:30 Cairo: slot 1 (16:00) started, slot 2 (18:00) not yet
    const started = await book(p, general, today, 1);
    expect(started.status).toBe(422);
    expect(started.body.error.code).toBe('SLOT_IN_PAST');
    const later = await book(p, general, today, 2);
    expect(later.status).toBe(201);
    // availability never shows the started slot
    const avail = await env.api.get(`/api/v1/public/departments/orthodontics/availability?from=${today}&to=${today}`);
    expect(avail.body.data.days[0].slots.map((s: any) => s.slotNumber)).toEqual([2, 3, 4]);
  });

  it('BOOK-06b a slot that starts in one second is still bookable; one that started a second ago is not', async () => {
    const p = await registerPatient(env);
    env.clock.set('2026-11-04T13:59:59Z'); // 15:59:59 Cairo
    expect((await book(p, ortho, '2026-11-04', 1)).status).toBe(201);
    const q = await registerPatient(env);
    env.clock.set('2026-11-05T14:00:01Z'); // 16:00:01 Cairo
    expect((await book(q, ortho, '2026-11-05', 1)).body.error.code).toBe('SLOT_IN_PAST');
  });

  it('BOOK-17 enforces the booking horizon (60 days)', async () => {
    const p = await registerPatient(env);
    expect((await book(p, general, dayOffset(60), 1)).status).toBe(201);
    const far = await book(p, general, dayOffset(61), 1);
    expect(far.status).toBe(422);
    expect(far.body.error.code).toBe('BEYOND_BOOKING_HORIZON');
  });

  it('input validation: impossible dates, unknown slots and unknown ids are rejected', async () => {
    const p = await registerPatient(env);
    expect((await book(p, general, '2026-02-30', 1)).body.error.code).toBe('VALIDATION_ERROR');
    expect((await book(p, general, dayOffset(3), 5)).body.error.code).toBe('VALIDATION_ERROR');
    expect((await book(p, general, dayOffset(3), 0)).status).toBe(400);
    expect((await book(p, '00000000-0000-4000-8000-000000000000', dayOffset(3), 1)).body.error.code).toBe('DEPARTMENT_NOT_FOUND');
    expect((await book(p, 'not-a-uuid', dayOffset(3), 1)).status).toBe(400);
    const svc = await env.db.query('SELECT s.id FROM services s WHERE s.department_id <> $1 LIMIT 1', [general]);
    expect((await book(p, general, dayOffset(3), 1, { serviceId: svc.rows[0].id })).body.error.code).toBe('SERVICE_NOT_IN_DEPARTMENT');
  });

  it('BOOK-13 closures, closed weekdays, disabled slots and inactive departments block booking and are not offered', async () => {
    const p = await registerPatient(env);
    const closed = dayOffset(12);
    // 1) a center-wide closure blocks every department
    const wide = await env.api.post('/api/v1/admin/closures', { dateFrom: closed, dateTo: closed, reason: 'Public holiday' }, admin);
    expect(wide.status).toBe(201);
    expect((await book(p, endo, closed, 1)).body.error.code).toBe('DATE_CLOSED');
    expect((await env.api.del(`/api/v1/admin/closures/${wide.body.data.id}`, admin)).status).toBe(204);
    // 2) a department-specific closure blocks only that department
    const mk = await env.api.post('/api/v1/admin/closures', { dateFrom: closed, dateTo: closed, departmentId: general, reason: 'Dentist away' }, admin);
    expect(mk.status).toBe(201);
    let avail = await env.api.get(`/api/v1/public/departments/restorative-dentistry/availability?from=${closed}&to=${closed}`);
    expect(avail.body.data.days[0]).toMatchObject({ status: 'closed', slots: [] });
    expect((await book(p, general, closed, 1)).body.error.code).toBe('DATE_CLOSED');
    // a department-specific closure leaves the other departments open
    expect((await book(p, endo, closed, 1)).status).toBe(201);
    expect((await env.api.del(`/api/v1/admin/closures/${mk.body.data.id}`, admin)).status).toBe(204);
    expect((await book(await registerPatient(env), general, closed, 1)).status).toBe(201);

    // closed weekday: close Fridays (ISO 5) via settings
    const put = await env.api.put('/api/v1/admin/settings/center', { workingDays: [1, 2, 3, 4, 6, 7] }, admin);
    expect(put.status).toBe(200);
    const friday = dayOffset(4); // 6 Nov 2026 is a Friday
    expect((await book(p, ortho, friday, 1)).body.error.code).toBe('DATE_CLOSED');
    await env.api.put('/api/v1/admin/settings/center', { workingDays: [1, 2, 3, 4, 5, 6, 7] }, admin);

    // disabled slot
    expect((await env.api.patch('/api/v1/admin/settings/slots/4', { isActive: false }, admin)).status).toBe(200);
    expect((await book(p, ortho, dayOffset(13), 4)).body.error.code).toBe('DATE_CLOSED');
    await env.api.patch('/api/v1/admin/settings/slots/4', { isActive: true }, admin);

    // inactive department
    const pediatric = await departmentId(env, 'pediatric-dentistry');
    await env.api.patch(`/api/v1/admin/departments/${pediatric}`, { isActive: false }, admin);
    expect((await book(p, pediatric, dayOffset(13), 1)).body.error.code).toBe('DEPARTMENT_INACTIVE');
    expect((await env.api.get('/api/v1/public/departments/pediatric-dentistry')).status).toBe(404);
    const list = await env.api.get('/api/v1/public/departments');
    expect(list.body.data.map((d: any) => d.slug)).not.toContain('pediatric-dentistry');
    await env.api.patch(`/api/v1/admin/departments/${pediatric}`, { isActive: true }, admin);
  });

  it('creating a closure over existing bookings is refused until acknowledged; bookings are never auto-cancelled', async () => {
    const date = dayOffset(14);
    const p = await registerPatient(env);
    const a = await book(p, general, date, 1);
    expect(a.status).toBe(201);
    const refused = await env.api.post('/api/v1/admin/closures', { dateFrom: date, dateTo: date, departmentId: general }, admin);
    expect(refused.status).toBe(409);
    expect(refused.body.error.code).toBe('CLOSURE_HAS_APPOINTMENTS');
    const ok = await env.api.post('/api/v1/admin/closures', { dateFrom: date, dateTo: date, departmentId: general, acknowledgeExistingAppointments: true }, admin);
    expect(ok.status).toBe(201);
    expect((await env.api.get(`/api/v1/patient/appointments/${a.body.data.id}`, p.session)).body.data.status).toBe('booked');
    await env.api.del(`/api/v1/admin/closures/${ok.body.data.id}`, admin);
  });

  it('a department without an active dentist is not bookable', async () => {
    const dept = await departmentId(env, 'prosthodontics');
    const dentist = await env.db.query('SELECT id FROM dentists WHERE department_id = $1 AND is_active', [dept]);
    await env.api.patch(`/api/v1/admin/dentists/${dentist.rows[0].id}`, { isActive: false }, admin);
    const p = await registerPatient(env);
    expect((await book(p, dept, dayOffset(3), 1)).body.error.code).toBe('NO_ACTIVE_DENTIST');
    const av = await env.api.get(`/api/v1/public/departments/prosthodontics/availability?from=${dayOffset(3)}&to=${dayOffset(3)}`);
    expect(av.body.data.days[0].status).toBe('unavailable');
    await env.api.patch(`/api/v1/admin/dentists/${dentist.rows[0].id}`, { isActive: true }, admin);
  });
});

describe('cancel & reschedule (patient)', () => {
  it('BOOK-08 cancelling releases the slot and its capacity immediately', async () => {
    const date = dayOffset(15);
    const p1 = await registerPatient(env);
    const a = await book(p1, general, date, 2);
    for (const slot of [1, 3, 4]) await book(await registerPatient(env), general, date, slot);
    expect(await activeCount(general, date)).toBe(4);
    const p2 = await registerPatient(env);
    expect((await book(p2, general, date, 2)).status).toBe(409);
    const cancel = await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/cancel`, {}, p1.session);
    expect(cancel.status).toBe(200);
    expect(cancel.body.data).toMatchObject({ status: 'cancelled', cancelledBy: 'patient' });
    expect(await activeCount(general, date)).toBe(3);
    expect((await book(p2, general, date, 2)).status).toBe(201);
    expect(await activeCount(general, date)).toBe(4);
    // cancelling twice is a clear conflict, not a silent success
    expect((await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/cancel`, {}, p1.session)).body.error.code).toBe('APPOINTMENT_NOT_ACTIVE');
  });

  it('BOOK-10 reschedule moves the same appointment; a taken target is refused and the original is untouched', async () => {
    const date = dayOffset(16);
    const p = await registerPatient(env); const other = await registerPatient(env);
    const a = await book(p, endo, date, 1);
    await book(other, endo, date, 2);
    const clash = await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/reschedule`, { date, slotNumber: 2 }, p.session);
    expect(clash.status).toBe(409);
    expect(clash.body.error.code).toBe('SLOT_UNAVAILABLE');
    const unchanged = await env.api.get(`/api/v1/patient/appointments/${a.body.data.id}`, p.session);
    expect(unchanged.body.data).toMatchObject({ date, slotNumber: 1, status: 'booked', rescheduledCount: 0 });
    const same = await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/reschedule`, { date, slotNumber: 1 }, p.session);
    expect(same.body.error.code).toBe('RESCHEDULE_NO_CHANGE');
    const moved = await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/reschedule`, { date: dayOffset(17), slotNumber: 4 }, p.session);
    expect(moved.status).toBe(200);
    expect(moved.body.data).toMatchObject({ id: a.body.data.id, date: dayOffset(17), slotNumber: 4, startTime: '22:00', rescheduledCount: 1, status: 'booked' });
    expect(await activeCount(endo, date)).toBe(1); // only `other` remains; the old slot was released
    expect((await book(await registerPatient(env), endo, date, 1)).status).toBe(201);
  });

  it('reschedule within the same day does not count the appointment twice (full day, move to the freed slot)', async () => {
    const date = dayOffset(18);
    const p = await registerPatient(env);
    const a = await book(p, ortho, date, 1);
    for (const s of [2, 3]) await book(await registerPatient(env), ortho, date, s);
    // 3 booked, slot 4 free: moving 1 -> 4 must work even though the department-day looks "almost full"
    const moved = await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/reschedule`, { date, slotNumber: 4 }, p.session);
    expect(moved.status, JSON.stringify(moved.body)).toBe(200);
    expect(await activeCount(ortho, date)).toBe(3);
  });

  it('BOOK-11 the 24-hour rule: allowed at 24:00:01 and 24:00:00 before start, refused at 23:59:59, for cancel and reschedule', async () => {
    // Appointments start 2026-11-07 18:00 Cairo = 16:00:00Z
    const mk = async (dept: string, slot: number, day: number) => { const p = await registerPatient(env); return { p, id: (await book(p, dept, dayOffset(day), slot)).body.data.id as string }; };
    const cases = [
      { label: '24:00:01 before', at: '2026-11-06T15:59:59Z', allowed: true },
      { label: '24:00:00 before', at: '2026-11-06T16:00:00Z', allowed: true },
      { label: '23:59:59 before', at: '2026-11-06T16:00:01Z', allowed: false },
    ];
    for (const c of cases) {
      const a = await mk(general, 2, 5); // 7 Nov slot 2... then cancelled below; use separate departments to avoid conflicts
      env.clock.set(c.at);
      const res = await env.api.post(`/api/v1/patient/appointments/${a.id}/cancel`, {}, a.p.session);
      if (c.allowed) { expect(res.status, `cancel ${c.label}: ${JSON.stringify(res.body)}`).toBe(200); }
      else {
        expect(res.status, `cancel ${c.label}`).toBe(422);
        expect(res.body.error.code).toBe('WITHIN_24H_WINDOW');
        expect(res.body.error.details.deadline).toBe('2026-11-06T18:00:00+02:00');
        const still = await env.api.get(`/api/v1/patient/appointments/${a.id}`, a.p.session);
        expect(still.body.data.status).toBe('booked');
        expect(still.body.data.selfService).toMatchObject({ canCancel: false, canReschedule: false, blockedReason: 'WITHIN_24H_WINDOW' });
        const rs = await env.api.post(`/api/v1/patient/appointments/${a.id}/reschedule`, { date: dayOffset(30), slotNumber: 1 }, a.p.session);
        expect(rs.body.error.code, 'reschedule inside the window').toBe('WITHIN_24H_WINDOW');
      }
      // free the slot for the next case (admin override in the denied case)
      env.clock.set(BASE_NOW);
      if (!c.allowed) await env.api.post(`/api/v1/admin/appointments/${a.id}/cancel`, { override: true, reason: 'test cleanup' }, admin);
    }
    // reschedule boundary
    const a = await mk(general, 2, 5);
    env.clock.set('2026-11-06T16:00:00Z');
    const rs = await env.api.post(`/api/v1/patient/appointments/${a.id}/reschedule`, { date: dayOffset(30), slotNumber: 1 }, a.p.session);
    expect(rs.status, JSON.stringify(rs.body)).toBe(200);
  });

  it('the 24-hour rule is measured against the ORIGINAL start, not the new one', async () => {
    const p = await registerPatient(env);
    const a = await book(p, ortho, dayOffset(25), 1);
    // 30 h before: allowed; moving to a slot that is only 2 days away is fine as long as it is in the future
    env.clock.set('2026-11-26T22:00:00Z'); // original = 27 Nov 16:00 Cairo (14:00Z) is 16 h away -> too late
    const late = await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/reschedule`, { date: dayOffset(35), slotNumber: 1 }, p.session);
    expect(late.body.error.code).toBe('WITHIN_24H_WINDOW');
  });

  it('BOOK-12 admin can override the 24-hour window only explicitly, with a reason, and it is audited', async () => {
    const p = await registerPatient(env);
    const a = await book(p, general, dayOffset(20), 3);
    env.clock.set('2026-11-22T10:00:00Z'); // 22 Nov 12:00 Cairo; appointment 22 Nov 20:00 Cairo -> 8 h away
    const plain = await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/cancel`, {}, admin);
    expect(plain.status).toBe(422);
    expect(plain.body.error.details.overrideAvailable).toBe(true);
    const noReason = await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/cancel`, { override: true }, admin);
    expect(noReason.body.error.code).toBe('OVERRIDE_REASON_REQUIRED');
    const ok = await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/cancel`, { override: true, reason: 'Patient phoned from the clinic' }, admin);
    expect(ok.status).toBe(200);
    expect(ok.body.data).toMatchObject({ status: 'cancelled', cancelledBy: 'admin' });
    const audit = await env.db.query("SELECT metadata, actor_type FROM audit_events WHERE action = 'appointment.cancelled' AND entity_id = $1", [a.body.data.id]);
    expect(audit.rows[0].actor_type).toBe('admin');
    expect(audit.rows[0].metadata).toMatchObject({ policyOverridden: true, reason: 'Patient phoned from the clinic' });
  });

  it('AUTH-13 patients cannot see, cancel or reschedule each other\'s appointments (404, never 403)', async () => {
    const a = await registerPatient(env); const b = await registerPatient(env);
    const appt = await book(a, general, dayOffset(21), 1);
    const id = appt.body.data.id;
    for (const [method, url, body] of [
      ['GET', `/api/v1/patient/appointments/${id}`, undefined],
      ['POST', `/api/v1/patient/appointments/${id}/cancel`, {}],
      ['POST', `/api/v1/patient/appointments/${id}/reschedule`, { date: dayOffset(22), slotNumber: 1 }],
    ] as const) {
      const r = await env.api.request(method, url, { body, session: b.session });
      expect(r.status, `${method} ${url}`).toBe(404);
      expect(r.body.error.code).toBe('APPOINTMENT_NOT_FOUND');
    }
    const list = await env.api.get('/api/v1/patient/appointments?scope=all', b.session);
    expect(list.body.data).toEqual([]);
    expect((await env.api.get(`/api/v1/patient/appointments/${id}`, a.session)).status).toBe(200);
    // a nonexistent id looks identical to someone else's id
    const ghost = await env.api.get('/api/v1/patient/appointments/00000000-0000-4000-8000-000000000000', b.session);
    expect(ghost.body).toEqual((await env.api.get(`/api/v1/patient/appointments/${id}`, b.session)).body);
  });

  it('lists upcoming vs history with localized names and the self-service deadline', async () => {
    const p = await registerPatient(env, { locale: 'fr' });
    const a = await book(p, general, dayOffset(22), 1);
    const b = await book(p, endo, dayOffset(23), 1);
    await env.api.post(`/api/v1/patient/appointments/${b.body.data.id}/cancel`, {}, p.session);
    const up = await env.api.get('/api/v1/patient/appointments?scope=upcoming', p.session);
    expect(up.body.data.map((x: any) => x.id)).toEqual([a.body.data.id]);
    expect(up.body.data[0].department.name).toBe('Dentisterie restauratrice'); // patient's saved language
    expect(up.body.data[0].selfService.canCancel).toBe(true);
    const hist = await env.api.get('/api/v1/patient/appointments?scope=history', p.session);
    expect(hist.body.data.map((x: any) => x.id)).toEqual([b.body.data.id]);
    expect(hist.body.meta).toMatchObject({ total: 1, page: 1 });
    const ar = await env.api.get('/api/v1/patient/appointments?scope=upcoming&locale=ar', p.session);
    expect(ar.body.data[0].department.name).toBe('طب الأسنان الترميمي');
  });
});

describe('lifecycle (admin)', () => {
  it('BOOK-09 completed appointments keep their slot on their own date only; terminal states cannot be changed', async () => {
    const p = await registerPatient(env);
    const a = await book(p, general, dayOffset(1), 1); // 3 Nov 16:00
    const early = await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/status`, { status: 'completed' }, admin);
    expect(early.status).toBe(422);
    expect(early.body.error.code).toBe('APPOINTMENT_NOT_STARTED');
    env.clock.set('2026-11-03T15:00:00Z'); // 17:00 Cairo, during the appointment
    const done = await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/status`, { status: 'completed' }, admin);
    expect(done.status).toBe(200);
    expect(done.body.data.status).toBe('completed');
    expect(await activeCount(general, dayOffset(1))).toBe(1); // still occupies its slot
    expect((await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/cancel`, { override: true, reason: 'try cancel completed' }, admin)).body.error.code).toBe('APPOINTMENT_NOT_ACTIVE');
    expect((await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/status`, { status: 'no_show' }, admin)).body.error.code).toBe('INVALID_STATUS_TRANSITION');
    // other dates are unaffected
    expect((await book(await registerPatient(env), general, dayOffset(2), 1)).status).toBe(201);
    // patient cannot cancel a completed appointment either
    expect((await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/cancel`, {}, p.session)).status).toBe(409);
  });

  it('no_show can be corrected to completed, and keeps its slot', async () => {
    const p = await registerPatient(env);
    const a = await book(p, endo, dayOffset(1), 2);
    env.clock.set('2026-11-03T17:00:00Z');
    expect((await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/status`, { status: 'no_show' }, admin)).body.data.status).toBe('no_show');
    expect(await activeCount(endo, dayOffset(1))).toBe(1);
    expect((await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/status`, { status: 'completed' }, admin)).body.data.status).toBe('completed');
    expect((await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/status`, { status: 'cancelled' }, admin)).status).toBe(400);
  });

  it('BOOK-14 illegal transitions are rejected by the service and by a database trigger', async () => {
    const p = await registerPatient(env);
    const a = await book(p, ortho, dayOffset(26), 1);
    await env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/cancel`, {}, p.session);
    await expect(env.db.query("UPDATE appointments SET status = 'booked', cancelled_at = NULL WHERE id = $1", [a.body.data.id])).rejects.toMatchObject({ code: '23514' });
    await expect(env.db.query("UPDATE appointments SET status = 'completed' WHERE id = $1", [a.body.data.id])).rejects.toMatchObject({ code: '23514' });
    const row = await env.db.query('SELECT status FROM appointments WHERE id = $1', [a.body.data.id]);
    expect(row.rows[0].status).toBe('cancelled');
  });

  it('admin can book on behalf of a patient and filter the list; rules still apply', async () => {
    const p = await registerPatient(env, { fullName: 'Walk In Patient' });
    const date = dayOffset(27);
    const res = await env.api.post('/api/v1/admin/appointments', { patientId: p.id, departmentId: general, date, slotNumber: 3 }, admin);
    expect(res.status, JSON.stringify(res.body)).toBe(201);
    expect(res.body.data).toMatchObject({ createdVia: 'admin', patient: { id: p.id, fullName: 'Walk In Patient' } });
    const dup = await env.api.post('/api/v1/admin/appointments', { patientId: (await registerPatient(env)).id, departmentId: general, date, slotNumber: 3 }, admin);
    expect(dup.body.error.code).toBe('SLOT_UNAVAILABLE');
    const past = await env.api.post('/api/v1/admin/appointments', { patientId: p.id, departmentId: general, date: dayOffset(-2), slotNumber: 1, override: true }, admin);
    expect(past.body.error.code).toBe('SLOT_IN_PAST');
    const list = await env.api.get(`/api/v1/admin/appointments?from=${date}&to=${date}&departmentId=${general}&status=booked`, admin);
    expect(list.body.data.map((a: any) => a.id)).toEqual([res.body.data.id]);
    const byName = await env.api.get('/api/v1/admin/appointments?q=walk%20in', admin);
    expect(byName.body.data.some((a: any) => a.id === res.body.data.id)).toBe(true);
    const dash = await env.api.get('/api/v1/admin/dashboard', admin);
    expect(dash.status).toBe(200);
    expect(dash.body.data.date).toBe('2026-11-02');
  });
});

describe('daylight-saving nights (BOOK-16)', () => {
  it('fall-back night Thu 29 Oct 2026: the 10 PM slot is exactly 2 real hours, ends 23:00 local, counts for 29 Oct', async () => {
    env.clock.set('2026-10-27T08:00:00Z');
    const p = await registerPatient(env);
    const res = await book(p, general, '2026-10-29', 4);
    expect(res.status, JSON.stringify(res.body)).toBe(201);
    expect(res.body.data).toMatchObject({ date: '2026-10-29', startsAt: '2026-10-29T22:00:00+03:00', endsAt: '2026-10-29T23:00:00+02:00', endTime: '23:00', endsNextDay: false });
    const row = await env.db.query("SELECT extract(epoch FROM ends_at - starts_at) AS secs, appointment_date FROM appointments WHERE id = $1", [res.body.data.id]);
    expect(Number(row.rows[0].secs)).toBe(7200);
    expect(row.rows[0].appointment_date).toBe('2026-10-29');
    // all four slots on that day are still independently bookable (no capacity side effects)
    for (const slot of [1, 2, 3]) expect((await book(await registerPatient(env), general, '2026-10-29', slot)).status).toBe(201);
    expect(await activeCount(general, '2026-10-29')).toBe(4);
  });

  it('spring-forward night Thu 29 Apr 2027: the 10 PM slot is exactly 2 real hours and ends 01:00 local on Friday', async () => {
    env.clock.set('2027-04-20T08:00:00Z');
    const p = await registerPatient(env);
    const res = await book(p, endo, '2027-04-29', 4);
    expect(res.status, JSON.stringify(res.body)).toBe(201);
    expect(res.body.data).toMatchObject({ date: '2027-04-29', startsAt: '2027-04-29T22:00:00+02:00', endsAt: '2027-04-30T01:00:00+03:00', endsNextDay: true });
    const row = await env.db.query("SELECT extract(epoch FROM ends_at - starts_at) AS secs FROM appointments WHERE id = $1", [res.body.data.id]);
    expect(Number(row.rows[0].secs)).toBe(7200);
    // the 24-hour rule still uses absolute time across the transition
    env.clock.set('2027-04-28T20:00:00Z'); // exactly 24h before 20:00Z start
    expect((await env.api.post(`/api/v1/patient/appointments/${res.body.data.id}/cancel`, {}, p.session)).status).toBe(200);
  });
});

describe('error handling', () => {
  it('ERR-01 a failure after the insert rolls the whole booking back: no partial row, slot stays free', async () => {
    await env.db.query(`CREATE FUNCTION test_fail_audit() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
      IF NEW.action = 'appointment.created' THEN RAISE EXCEPTION 'simulated failure'; END IF; RETURN NEW; END $$`);
    await env.db.query('CREATE TRIGGER test_fail_audit BEFORE INSERT ON audit_events FOR EACH ROW EXECUTE FUNCTION test_fail_audit()');
    try {
      const p = await registerPatient(env);
      const date = dayOffset(28);
      const res = await book(p, general, date, 1);
      expect(res.status).toBe(500);
      expect(res.body.error).toEqual({ code: 'INTERNAL_ERROR', message: 'Something went wrong' }); // nothing about the cause leaks
      expect(JSON.stringify(res.body)).not.toMatch(/simulated|trigger|audit/i);
      expect(await activeCount(general, date)).toBe(0);
      await env.db.query('DROP TRIGGER test_fail_audit ON audit_events');
      expect((await book(p, general, date, 1)).status).toBe(201); // the slot was never lost
    } finally {
      await env.db.query('DROP TRIGGER IF EXISTS test_fail_audit ON audit_events');
      await env.db.query('DROP FUNCTION IF EXISTS test_fail_audit()');
    }
  });

  it('unknown routes and malformed bodies return structured errors', async () => {
    expect((await env.api.get('/api/v1/nope')).body.error.code).toBe('NOT_FOUND');
    const p = await registerPatient(env);
    const bad = await env.api.request('POST', '/api/v1/patient/appointments', { body: '{not json', session: p.session, headers: { 'content-type': 'application/json' } });
    expect(bad.status).toBe(400);
    expect(bad.body.error.code).toBe('INVALID_JSON');
  });
});

void BASE_NOW;
