import { spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { mkdtemp, readFile, rm, stat, truncate, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import pg from 'pg';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  ADMIN_PASS, ADMIN_URL, ADMIN_USER, BASE_NOW, INTEGRATION_KEY, adminSession, createTestEnv, dayOffset, departmentId, makeApi, registerPatient, sessionFrom,
  type TestEnv, type TestPatient,
} from '../helpers/harness.js';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createPool } from '../../src/database/pool.js';
import { migrate } from '../../src/database/migrate.js';
import { FakeClock } from '../../src/lib/clock.js';

const hasTools = ['pg_dump', 'pg_restore'].every((t) => spawnSync(t, ['--version']).status === 0);
const run = (cmd: string, args: string[]) => spawnSync(cmd, args, { encoding: 'utf8' });
const urlFor = (db: string) => { const u = new URL(ADMIN_URL); u.pathname = `/${db}`; return u.toString(); };

async function q<T extends pg.QueryResultRow = any>(url: string, sql: string, params: unknown[] = []) {
  const c = new pg.Client({ connectionString: url });
  await c.connect();
  try { return (await c.query<T>(sql, params)).rows; } finally { await c.end(); }
}

/** A stable fingerprint of every table's full content (all columns), independent of physical row order. */
async function fingerprint(url: string): Promise<Record<string, { rows: number; md5: string }>> {
  const tables = (await q(url, "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY 1")).map((r) => r.tablename as string);
  const out: Record<string, { rows: number; md5: string }> = {};
  for (const t of tables) {
    const [r] = await q(url, `SELECT count(*)::int AS rows, md5(coalesce(string_agg(x::text, '|' ORDER BY x::text), '')) AS md5 FROM "${t}" x`);
    out[t] = { rows: r.rows, md5: r.md5 };
  }
  return out;
}

describe.skipIf(!hasTools)('OPS-01 backup and isolated restore (pg_dump / pg_restore)', () => {
  let env: TestEnv; let dir: string; let dump: string; let restoredName: string; let restoredUrl: string;
  let patient: TestPatient; let bookedSlot: { date: string; slot: number; deptId: string };
  let source: Record<string, { rows: number; md5: string }>;

  beforeAll(async () => {
    env = await createTestEnv({ SESSION_PATIENT_IDLE_MINUTES: '1000000', SESSION_PATIENT_TTL_HOURS: '100000' });
    dir = await mkdtemp(path.join(tmpdir(), 'dc-backup-'));
    dump = path.join(dir, 'dental-center.dump');
    const admin = await adminSession(env);
    patient = await registerPatient(env, { fullName: 'Backup Patient', password: 'Backup-Pass-123' });
    const other = await registerPatient(env, { fullName: 'Second Patient' });
    const deptId = await departmentId(env, 'orthodontics');
    bookedSlot = { date: dayOffset(6), slot: 2, deptId };
    expect((await env.api.post('/api/v1/patient/appointments', { departmentId: deptId, date: bookedSlot.date, slotNumber: 2 }, patient.session)).status).toBe(201);
    const gone = await env.api.post('/api/v1/patient/appointments', { departmentId: deptId, date: dayOffset(7), slotNumber: 1 }, other.session);
    await env.api.post(`/api/v1/patient/appointments/${gone.body.data.id}/cancel`, {}, other.session);
    await env.api.post(`/api/v1/admin/patients/${patient.id}/medical-records`, { diagnosis: 'Restore-check diagnosis', allergies: 'None known' }, admin);
    await env.api.post('/api/v1/admin/closures', { dateFrom: dayOffset(30), dateTo: dayOffset(31), reason: 'Holiday' }, admin);
    await env.api.put('/api/v1/admin/settings/center', { phone: '+20 2 1111 2222', translations: { en: { address: 'Backup Street 1' } } }, admin);
    const code = (await env.api.post('/api/v1/patient/telegram/link-token', {}, patient.session)).body.data.code;
    await env.api.integration('POST', '/telegram/link', { code, telegramUserId: '555000111' });
    source = await fingerprint(env.databaseUrl);
    restoredName = `dc_restore_${randomBytes(4).toString('hex')}`;
    restoredUrl = urlFor(restoredName);
  });
  afterAll(async () => {
    await env.close();
    await rm(dir, { recursive: true, force: true });
    await q(ADMIN_URL, `DROP DATABASE IF EXISTS ${restoredName} WITH (FORCE)`).catch(() => undefined);
  });

  it('creates a custom-format dump that pg_restore can read, and that contains the real data', async () => {
    const r = run('pg_dump', ['--format=custom', '--no-owner', '--no-privileges', '--file', dump, env.databaseUrl]);
    expect(r.status, r.stderr).toBe(0);
    expect((await stat(dump)).size).toBeGreaterThan(10_000);
    const list = run('pg_restore', ['--list', dump]);
    expect(list.status, list.stderr).toBe(0);
    for (const needle of ['TABLE public appointments', 'TABLE public medical_records', 'TABLE public audit_events', 'TABLE public patients', 'INDEX public appointments_active_slot_uq']) expect(list.stdout, needle).toContain(needle);
    expect(source.patients!.rows).toBe(2);
    expect(source.audit_events!.rows).toBeGreaterThan(5);
  });

  it('a truncated or corrupted dump is detected by the verification step instead of being trusted', async () => {
    const bad = path.join(dir, 'truncated.dump');
    await writeFile(bad, await readFile(dump));
    await truncate(bad, Math.floor((await stat(dump)).size / 2));
    expect(run('pg_restore', ['--list', bad]).status).not.toBe(0);
    const garbage = path.join(dir, 'garbage.dump');
    await writeFile(garbage, 'this is not a backup');
    expect(run('pg_restore', ['--list', garbage]).status).not.toBe(0);
  });

  it('restores into a separate database with identical content in every table (nothing else is touched)', async () => {
    await q(ADMIN_URL, `CREATE DATABASE ${restoredName}`);
    const r = run('pg_restore', ['--no-owner', '--no-privileges', '--exit-on-error', '--dbname', restoredUrl, dump]);
    expect(r.status, r.stderr).toBe(0);
    const restored = await fingerprint(restoredUrl);
    expect(Object.keys(restored).sort()).toEqual(Object.keys(source).sort());
    for (const table of Object.keys(source)) expect(restored[table], table).toEqual(source[table]);
    expect(await fingerprint(env.databaseUrl)).toEqual(source); // the live database was not modified by restoring elsewhere
  });

  it('the restored database keeps its integrity rules (constraints, triggers, audit immutability)', async () => {
    const ins = (patientId: string, dept: string, slot: number, date: string) => q(restoredUrl,
      `INSERT INTO appointments (patient_id, department_id, appointment_date, slot_number, starts_at, ends_at, created_via)
       VALUES ($1::uuid, $2::uuid, $3::date, $4::int,
               ($3::date + time '16:00') AT TIME ZONE 'Africa/Cairo' + ($4::int - 1) * interval '2 hours',
               ($3::date + time '18:00') AT TIME ZONE 'Africa/Cairo' + ($4::int - 1) * interval '2 hours', 'admin')`,
      [patientId, dept, date, slot]);
    const stranger = (await q(restoredUrl, "SELECT id FROM patients WHERE full_name = 'Second Patient'"))[0].id;
    // Which protection fires first depends on index build order after a restore; either one must refuse the booking...
    await expect(ins(stranger, bookedSlot.deptId, bookedSlot.slot, bookedSlot.date)).rejects.toSatisfy((e: { code?: string }) => e.code === '23505' || e.code === '23P01');
    // ...and every one of them must have survived the round trip on its own.
    expect((await q(restoredUrl, "SELECT 1 FROM pg_indexes WHERE indexname = 'appointments_active_slot_uq'")).length).toBe(1);
    const exclusions = (await q(restoredUrl, "SELECT conname FROM pg_constraint WHERE contype = 'x' AND conrelid = 'appointments'::regclass ORDER BY 1")).map((r) => r.conname);
    expect(exclusions).toEqual(['appointments_no_department_overlap', 'appointments_no_patient_overlap']);
    const triggers = (await q(restoredUrl, "SELECT tgname FROM pg_trigger WHERE NOT tgisinternal AND tgname IN ('appointments_status_guard','audit_events_no_update_delete','audit_events_no_truncate') ORDER BY 1")).map((r) => r.tgname);
    expect(triggers).toEqual(['appointments_status_guard', 'audit_events_no_truncate', 'audit_events_no_update_delete']);
    await expect(q(restoredUrl, "UPDATE audit_events SET action = 'tampered'")).rejects.toMatchObject({ code: '42501' });
    await expect(q(restoredUrl, 'TRUNCATE audit_events')).rejects.toMatchObject({ code: '42501' });
    const appt = (await q(restoredUrl, "SELECT id FROM appointments WHERE status = 'cancelled' LIMIT 1"))[0].id;
    await expect(q(restoredUrl, "UPDATE appointments SET status = 'booked', cancelled_at = NULL WHERE id = $1", [appt])).rejects.toMatchObject({ code: '23514' });
    const extension = await q(restoredUrl, "SELECT 1 FROM pg_extension WHERE extname = 'btree_gist'");
    expect(extension.length).toBe(1);
    expect((await migrate(restoredUrl)).applied).toEqual([]); // migration history came along: nothing is re-applied
  });

  it('the application runs on the restored database: original passwords, appointments and rules all work', async () => {
    const config = loadConfig({ NODE_ENV: 'test', DATABASE_URL: restoredUrl, PUBLIC_APP_URL: 'http://localhost:8480', LOG_LEVEL: 'silent', INTEGRATION_API_KEY: INTEGRATION_KEY } as NodeJS.ProcessEnv);
    const db = createPool(restoredUrl, 10);
    const { app } = await buildApp({ config, db, clock: new FakeClock(new Date(BASE_NOW)) });
    await app.ready();
    try {
      const api = makeApi(app);
      const login = await api.post('/api/v1/patient/auth/login', { phone: patient.phone, password: 'Backup-Pass-123' });
      expect(login.status, JSON.stringify(login.body)).toBe(200);
      const session = sessionFrom(login, 'dc_patient');
      const mine = await api.get('/api/v1/patient/appointments?scope=upcoming', session);
      expect(mine.body.data.length).toBe(1);
      expect(mine.body.data[0]).toMatchObject({ date: bookedSlot.date, slotNumber: 2, status: 'booked' });
      const taken = await api.post('/api/v1/patient/appointments', { departmentId: bookedSlot.deptId, date: bookedSlot.date, slotNumber: 2 }, (await registerPatient2(api)).session);
      expect(taken.body.error.code).toBe('SLOT_UNAVAILABLE');
      const adminLogin = await api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS });
      expect(adminLogin.status).toBe(200);
      const adminSess = sessionFrom(adminLogin, 'dc_admin');
      const records = await api.get(`/api/v1/admin/patients/${patient.id}/medical-records`, adminSess);
      expect(records.body.data[0].diagnosis).toBe('Restore-check diagnosis');
      expect((await api.get('/api/v1/public/center?locale=en')).body.data).toMatchObject({ address: 'Backup Street 1', phone: '+20 2 1111 2222' });
      expect((await api.integration('GET', '/telegram/555000111/appointments')).body.data.length).toBe(1); // Telegram link survived
    } finally { await app.close(); await db.end(); }
  });
});

let n = 0;
async function registerPatient2(api: ReturnType<typeof makeApi>) {
  n += 1;
  const phone = `0155${String(5000000 + n).slice(-7)}`;
  const res = await api.post('/api/v1/patient/auth/register', { fullName: 'After Restore', phone, password: 'After-Restore-1' });
  return { session: sessionFrom(res, 'dc_patient') };
}
