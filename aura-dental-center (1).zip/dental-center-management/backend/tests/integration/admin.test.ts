import { Writable } from 'node:stream';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { ADMIN_PASS, ADMIN_USER, BASE_NOW, INTEGRATION_KEY, adminSession, createTestEnv, dayOffset, departmentId, registerPatient, type Session, type TestEnv } from '../helpers/harness.js';
import { routeRegistry } from '../../src/lib/routes.js';

let env: TestEnv;
let admin: Session;
const logs: string[] = [];
const MARKER = 'ZEBRA-CLINICAL-MARKER-7731';

beforeAll(async () => {
  const stream = new Writable({ write(chunk, _enc, cb) { logs.push(chunk.toString()); cb(); } });
  env = await createTestEnv({ LOG_LEVEL: 'info', SESSION_PATIENT_IDLE_MINUTES: '1000000', SESSION_PATIENT_TTL_HOURS: '100000', SESSION_ADMIN_IDLE_MINUTES: '1000000', SESSION_ADMIN_TTL_HOURS: '100000' }, { logStream: stream });
  admin = await adminSession(env);
});
afterAll(async () => { await env.close(); });
beforeEach(() => { env.clock.set(BASE_NOW); });

const auditFor = async (action: string) => (await env.db.query('SELECT * FROM audit_events WHERE action = $1 ORDER BY id', [action])).rows;

describe('medical records (admin only)', () => {
  let patientId: string;
  let recordId: string;

  it('MED-01 admin creates, reads, lists and updates a record with authorship and timestamps', async () => {
    const p = await registerPatient(env, { fullName: 'Record Patient' });
    patientId = p.id;
    const created = await env.api.post(`/api/v1/admin/patients/${patientId}/medical-records`, {
      medicalHistory: 'Hypertension', allergies: 'Penicillin', diagnosis: `Caries ${MARKER}`, treatment: 'Filling tooth 36', notes: 'Review in 2 weeks',
    }, admin);
    expect(created.status, JSON.stringify(created.body)).toBe(201);
    recordId = created.body.data.id;
    expect(created.body.data).toMatchObject({ patientId, medicalHistory: 'Hypertension', allergies: 'Penicillin', treatment: 'Filling tooth 36', createdBy: { username: ADMIN_USER }, updatedBy: { username: ADMIN_USER } });
    expect(created.body.data.createdAt).toBeTruthy();
    const got = await env.api.get(`/api/v1/admin/medical-records/${recordId}`, admin);
    expect(got.status).toBe(200);
    const upd = await env.api.patch(`/api/v1/admin/medical-records/${recordId}`, { treatment: 'Filling tooth 36 + 37' }, admin);
    expect(upd.body.data.treatment).toBe('Filling tooth 36 + 37');
    expect(upd.body.data.diagnosis).toContain(MARKER); // untouched fields stay
    const list = await env.api.get(`/api/v1/admin/patients/${patientId}/medical-records`, admin);
    expect(list.body.data.map((r: any) => r.id)).toEqual([recordId]);
    const empty = await env.api.post(`/api/v1/admin/patients/${patientId}/medical-records`, { notes: '   ' }, admin);
    expect(empty.status).toBe(400);
  });

  it('a record can be linked only to the same patient\'s appointment', async () => {
    const other = await registerPatient(env);
    const dept = await departmentId(env, 'restorative-dentistry');
    const appt = await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date: dayOffset(3), slotNumber: 1 }, other.session);
    const bad = await env.api.post(`/api/v1/admin/patients/${patientId}/medical-records`, { notes: 'x', appointmentId: appt.body.data.id }, admin);
    expect(bad.body.error.code).toBe('APPOINTMENT_NOT_FOR_PATIENT');
    const ok = await env.api.post(`/api/v1/admin/patients/${other.id}/medical-records`, { notes: 'x', appointmentId: appt.body.data.id }, admin);
    expect(ok.status).toBe(201);
  });

  it('MED-02 unauthenticated, patient and integration credentials are all refused', async () => {
    const p = await registerPatient(env);
    const urls: [string, string, unknown?][] = [
      ['GET', `/api/v1/admin/patients/${patientId}/medical-records`], ['POST', `/api/v1/admin/patients/${patientId}/medical-records`, { notes: 'x' }],
      ['GET', `/api/v1/admin/medical-records/${recordId}`], ['PATCH', `/api/v1/admin/medical-records/${recordId}`, { notes: 'hack' }],
    ];
    for (const [method, url, body] of urls) {
      expect((await env.api.request(method, url, { body })).status, `anon ${method} ${url}`).toBe(401);
      expect((await env.api.request(method, url, { body, headers: { cookie: `dc_patient=${p.session.token}`, 'x-csrf-token': p.session.csrf } })).status, `patient ${method} ${url}`).toBe(401);
      expect((await env.api.request(method, url, { body, headers: { authorization: `Bearer ${INTEGRATION_KEY}` } })).status, `integration ${method} ${url}`).toBe(401);
      // patient even if they somehow had the id: same answer on the integration route group
      expect((await env.api.integration(method, url.replace('/api/v1/admin', '') , body)).status, `integration group ${url}`).toBe(404);
    }
    expect((await env.db.query('SELECT notes FROM medical_records WHERE id = $1', [recordId])).rows[0].notes).not.toBe('hack');
  });

  it('MED-02b structurally, medical records exist only under the admin route group', () => {
    const med = routeRegistry.filter((r) => /medical/i.test(r.url));
    expect(med.length).toBeGreaterThan(0);
    for (const r of med) { expect(r.url).toMatch(/^\/api\/v1\/admin\//); expect(r.auth).toBe('admin'); }
  });

  it('MED-03 unknown record ids reveal nothing and look the same every time', async () => {
    const a = await env.api.get('/api/v1/admin/medical-records/00000000-0000-4000-8000-000000000001', admin);
    const b = await env.api.get('/api/v1/admin/medical-records/00000000-0000-4000-8000-000000000002', admin);
    expect(a.status).toBe(404);
    expect(a.body).toEqual(b.body);
    expect(JSON.stringify(a.body)).not.toMatch(/patient|diagnosis|allerg/i);
    expect((await env.api.get('/api/v1/admin/medical-records/not-a-uuid', admin)).status).toBe(400);
    expect((await env.api.get('/api/v1/admin/patients/00000000-0000-4000-8000-000000000001/medical-records', admin)).body.error.code).toBe('PATIENT_NOT_FOUND');
  });

  it('MED-04 clinical text never appears in any other endpoint or in the logs', async () => {
    const p = await registerPatient(env); // a patient's own view
    const dept = await departmentId(env, 'restorative-dentistry');
    await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date: dayOffset(4), slotNumber: 1 }, p.session);
    const probes: [string, Session | null][] = [
      ['/api/v1/public/center', null], ['/api/v1/public/departments', null], ['/api/v1/public/departments/restorative-dentistry', null], ['/api/v1/public/gallery', null],
      ['/api/v1/patient/me', p.session], ['/api/v1/patient/appointments?scope=all', p.session],
      [`/api/v1/admin/patients/${patientId}`, admin], ['/api/v1/admin/patients', admin], ['/api/v1/admin/appointments', admin], ['/api/v1/admin/dashboard', admin],
      ['/api/v1/admin/audit-events?pageSize=100', admin], ['/api/v1/admin/departments', admin], ['/api/v1/admin/gallery', admin], ['/api/v1/admin/settings/center', admin],
    ];
    for (const [url, session] of probes) {
      const r = await env.api.get(url, session);
      expect(r.status, url).toBe(200);
      expect(JSON.stringify(r.body), url).not.toContain(MARKER);
    }
    const out = logs.join('');
    expect(out.length).toBeGreaterThan(100);
    for (const secret of [MARKER, ADMIN_PASS, 'Patient-Pass-123', INTEGRATION_KEY, 'Initial-Pass-Change-Me-1']) expect(out, `logs contain ${secret}`).not.toContain(secret);
    expect(out).not.toMatch(/dc_(patient|admin)=[A-Za-z0-9_-]{20,}/); // no raw session cookies
  });

  it('MED-05 creating, viewing, listing and updating produce audit events that name fields but contain no clinical text', async () => {
    for (const action of ['medical_record.created', 'medical_record.viewed', 'medical_record.listed', 'medical_record.updated']) {
      const ev = await auditFor(action);
      expect(ev.length, action).toBeGreaterThan(0);
      expect(ev[0].actor_type).toBe('admin');
      expect(ev[0].outcome).toBe('success');
    }
    const created = (await auditFor('medical_record.created'))[0];
    expect(created.entity_id).toBe(recordId);
    expect(created.metadata).toMatchObject({ patientId, fieldsProvided: expect.arrayContaining(['diagnosis', 'allergies']) });
    const all = (await env.db.query('SELECT metadata::text AS m FROM audit_events')).rows.map((r) => r.m).join('\n');
    for (const text of [MARKER, 'Penicillin', 'Hypertension', 'tooth 36']) expect(all).not.toContain(text);
  });
});

describe('catalog management & localization', () => {
  it('adds a department with translations; public content follows the documented fallback; keys never leak', async () => {
    const created = await env.api.post('/api/v1/admin/departments', { slug: 'sleep-dentistry', displayOrder: 99, translations: { en: { name: 'Sleep Dentistry', description: 'English only' } } }, admin);
    expect(created.status, JSON.stringify(created.body)).toBe(201);
    const id = created.body.data.id;
    expect(created.body.data.bookable).toBe(false); // no dentist yet
    // Arabic requested, only English exists -> falls back to English, never an empty/raw key
    const ar = await env.api.get('/api/v1/public/departments/sleep-dentistry?locale=ar');
    expect(ar.body.data.name).toBe('Sleep Dentistry');
    expect(ar.body.data.bookable).toBe(false);
    // add Arabic + French
    await env.api.patch(`/api/v1/admin/departments/${id}`, { translations: { ar: { name: 'طب أسنان النوم', description: 'وصف' }, fr: { name: 'Dentisterie du sommeil' } } }, admin);
    expect((await env.api.get('/api/v1/public/departments/sleep-dentistry?locale=ar')).body.data.name).toBe('طب أسنان النوم');
    expect((await env.api.get('/api/v1/public/departments/sleep-dentistry', null, { 'accept-language': 'fr-FR,fr;q=0.9' })).body.data.name).toBe('Dentisterie du sommeil');
    // French description is empty -> falls back to the next language that has one (default locale ar)
    expect((await env.api.get('/api/v1/public/departments/sleep-dentistry?locale=fr')).body.data.description).toBe('وصف');
    // an empty name removes that language
    await env.api.patch(`/api/v1/admin/departments/${id}`, { translations: { fr: { name: '' } } }, admin);
    expect((await env.api.get('/api/v1/public/departments/sleep-dentistry?locale=fr')).body.data.name).toBe('طب أسنان النوم'); // default locale (ar) next in the chain
    // cannot remove the last language
    await env.api.patch(`/api/v1/admin/departments/${id}`, { translations: { ar: { name: '' } } }, admin);
    const last = await env.api.patch(`/api/v1/admin/departments/${id}`, { translations: { en: { name: '' } } }, admin);
    expect(last.status).toBe(400);
    expect(last.body.error.code).toBe('AT_LEAST_ONE_TRANSLATION');
    // slug rules
    expect((await env.api.post('/api/v1/admin/departments', { slug: 'sleep-dentistry', translations: { en: { name: 'Dup' } } }, admin)).body.error.code).toBe('SLUG_TAKEN');
    expect((await env.api.post('/api/v1/admin/departments', { slug: 'Bad Slug!', translations: { en: { name: 'x' } } }, admin)).status).toBe(400);
    expect((await env.api.post('/api/v1/admin/departments', { slug: 'no-names' , translations: {} }, admin)).body.error.code).toBe('AT_LEAST_ONE_TRANSLATION');
  });

  it('exactly the seven departments of the center are seeded, each listed in all three languages with a name, a sample dentist and services', async () => {
    for (const locale of ['ar', 'en', 'fr']) {
      const list = await env.api.get(`/api/v1/public/departments?locale=${locale}`);
      const seeded = list.body.data.filter((d: any) => d.slug !== 'sleep-dentistry');
      expect(seeded.length).toBe(7);
      for (const d of seeded) {
        expect(d.name.length, `${d.slug}/${locale}`).toBeGreaterThan(1);
        expect(d.dentist.isSample).toBe(true);
        expect(d.serviceCount).toBe(2);
        expect(d.bookable).toBe(true);
        expect(d.name).not.toMatch(/^[a-z_.]+$/); // no raw keys
      }
    }
    const slugs = (await env.api.get('/api/v1/public/departments')).body.data.map((d: any) => d.slug);
    expect(slugs.slice(0, 7)).toEqual(['restorative-dentistry', 'endodontics', 'orthodontics', 'periodontics', 'pediatric-dentistry', 'prosthodontics', 'oral-surgery']);
  });

  it('services: prices are optional, validated, and shown with the center currency', async () => {
    const dept = await departmentId(env, 'pediatric-dentistry');
    const priced = await env.api.post('/api/v1/admin/services', { departmentId: dept, price: 1500.5, translations: { en: { name: 'Veneer (sample)' } } }, admin);
    expect(priced.status, JSON.stringify(priced.body)).toBe(201);
    expect(priced.body.data.price).toBe(1500.5);
    expect((await env.api.post('/api/v1/admin/services', { departmentId: dept, price: 10.123, translations: { en: { name: 'x' } } }, admin)).status).toBe(400);
    expect((await env.api.post('/api/v1/admin/services', { departmentId: dept, price: -5, translations: { en: { name: 'x' } } }, admin)).status).toBe(400);
    const pub = await env.api.get('/api/v1/public/departments/pediatric-dentistry?locale=en');
    const svc = pub.body.data.services.find((s: any) => s.name === 'Veneer (sample)');
    expect(svc).toMatchObject({ price: 1500.5, currency: 'EGP', isSample: false });
    expect(pub.body.data.services.find((s: any) => s.name === "Children's check-up")).toMatchObject({ price: null, currency: null, isSample: true });
    await env.api.patch(`/api/v1/admin/services/${priced.body.data.id}`, { isActive: false }, admin);
    expect((await env.api.get('/api/v1/public/departments/pediatric-dentistry?locale=en')).body.data.services.some((s: any) => s.name === 'Veneer (sample)')).toBe(false);
  });

  it('dentists: exactly one active per department; replacing keeps history and new bookings use the new dentist', async () => {
    const dept = await departmentId(env, 'periodontics');
    const p = await registerPatient(env);
    const first = await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date: dayOffset(3), slotNumber: 1 }, p.session);
    const oldDentist = (await env.db.query('SELECT dentist_id FROM appointments WHERE id = $1', [first.body.data.id])).rows[0].dentist_id;
    const refuse = await env.api.post('/api/v1/admin/dentists', { departmentId: dept, translations: { en: { name: 'Dr. Real Person' } } }, admin);
    expect(refuse.status).toBe(409);
    expect(refuse.body.error.code).toBe('DEPARTMENT_HAS_DENTIST');
    const replaced = await env.api.post('/api/v1/admin/dentists', { departmentId: dept, replaceExisting: true, translations: { en: { name: 'Dr. Real Person', bio: 'Bio' }, ar: { name: 'د. شخص حقيقي' } } }, admin);
    expect(replaced.status, JSON.stringify(replaced.body)).toBe(201);
    expect(replaced.body.data.isSample).toBe(false);
    const active = await env.db.query('SELECT id FROM dentists WHERE department_id = $1 AND is_active', [dept]);
    expect(active.rowCount).toBe(1);
    expect(active.rows[0].id).toBe(replaced.body.data.id);
    expect((await env.db.query('SELECT is_active FROM dentists WHERE id = $1', [oldDentist])).rows[0].is_active).toBe(false);
    // history preserved
    expect((await env.db.query('SELECT dentist_id FROM appointments WHERE id = $1', [first.body.data.id])).rows[0].dentist_id).toBe(oldDentist);
    // new booking uses the new dentist; public pages show the new one
    const second = await env.api.post('/api/v1/patient/appointments?locale=en', { departmentId: dept, date: dayOffset(3), slotNumber: 2 }, (await registerPatient(env)).session);
    expect(second.status, JSON.stringify(second.body)).toBe(201);
    expect(second.body.data.dentist.name).toBe('Dr. Real Person');
    expect((await env.api.get('/api/v1/public/departments/periodontics?locale=en')).body.data.dentist).toMatchObject({ name: 'Dr. Real Person', bio: 'Bio', isSample: false });
    expect((await env.api.get('/api/v1/public/departments/periodontics?locale=ar')).body.data.dentist.name).toBe('د. شخص حقيقي');
    // the database refuses a second active dentist even if the API is bypassed
    await expect(env.db.query('INSERT INTO dentists (department_id) VALUES ($1)', [dept])).rejects.toMatchObject({ code: '23505' });
  });

  it('gallery: real cases need consent to publish; samples are always labelled; image paths are restricted', async () => {
    const dept = await departmentId(env, 'orthodontics');
    const base = { departmentId: dept, beforeImagePath: '/assets/gallery/ortho-1-before.jpg', afterImagePath: '/assets/gallery/ortho-1-after.jpg', translations: { en: { title: 'Case', altBefore: 'Before', altAfter: 'After' } } };
    const refused = await env.api.post('/api/v1/admin/gallery', { ...base, caseKind: 'real', isPublished: true }, admin);
    expect(refused.body.error.code).toBe('CONSENT_REQUIRED');
    const real = await env.api.post('/api/v1/admin/gallery', { ...base, caseKind: 'real', consentConfirmed: false, isPublished: false }, admin);
    expect(real.status, JSON.stringify(real.body)).toBe(201);
    expect((await env.api.get('/api/v1/public/gallery')).body.data).toEqual([]); // unpublished -> invisible
    expect((await env.api.patch(`/api/v1/admin/gallery/${real.body.data.id}`, { isPublished: true }, admin)).body.error.code).toBe('CONSENT_REQUIRED');
    await expect(env.db.query('UPDATE gallery_cases SET is_published = true WHERE id = $1', [real.body.data.id])).rejects.toMatchObject({ code: '23514' }); // DB agrees
    expect((await env.api.patch(`/api/v1/admin/gallery/${real.body.data.id}`, { consentConfirmed: true, isPublished: true }, admin)).status).toBe(200);
    const sample = await env.api.post('/api/v1/admin/gallery', { ...base, caseKind: 'sample', isPublished: true }, admin);
    const pub = (await env.api.get('/api/v1/public/gallery?department=orthodontics&locale=en')).body.data;
    expect(pub.length).toBe(2);
    expect(pub.find((c: any) => c.id === real.body.data.id)).toMatchObject({ caseKind: 'real', isSample: false, title: 'Case', altBefore: 'Before' });
    expect(pub.find((c: any) => c.id === sample.body.data.id)).toMatchObject({ caseKind: 'sample', isSample: true });
    // the department landing page carries the same cases
    expect((await env.api.get('/api/v1/public/departments/orthodontics')).body.data.gallery.length).toBe(2);
    for (const bad of ['javascript:alert(1)', 'https://evil.example/x.jpg', '//evil.example/x.jpg', '/assets/../secret.jpg', '/etc/passwd', '/assets/a b.jpg']) {
      const r = await env.api.post('/api/v1/admin/gallery', { ...base, beforeImagePath: bad }, admin);
      expect(r.status, bad).toBe(400);
    }
    expect((await env.api.del(`/api/v1/admin/gallery/${sample.body.data.id}`, admin)).status).toBe(204);
  });

  it('center profile: single source of truth for address/contact, localized, with "not configured" made explicit', async () => {
    const before = await env.api.get('/api/v1/public/center?locale=en');
    expect(before.body.data).toMatchObject({ address: '', addressConfigured: false, timezone: 'Africa/Cairo', name: 'Aura Dental Center' });
    expect(before.body.data.slots.map((s: any) => [s.startTime, s.endTime])).toEqual([['16:00', '18:00'], ['18:00', '20:00'], ['20:00', '22:00'], ['22:00', '00:00']]);
    expect(before.body.data.slots[3].endsNextDay).toBe(true);
    const put = await env.api.put('/api/v1/admin/settings/center', {
      phone: '+20 2 1234 5678', mapUrl: 'https://maps.example.com/clinic',
      translations: { en: { address: '12 Example Street, Cairo (sample)' }, ar: { address: '١٢ شارع المثال، القاهرة (تجريبي)' }, fr: { address: '12 rue Exemple, Le Caire (exemple)' } },
    }, admin);
    expect(put.status, JSON.stringify(put.body)).toBe(200);
    const en = (await env.api.get('/api/v1/public/center?locale=en')).body.data;
    expect(en).toMatchObject({ address: '12 Example Street, Cairo (sample)', addressConfigured: true, phone: '+20 2 1234 5678', mapUrl: 'https://maps.example.com/clinic' });
    expect((await env.api.get('/api/v1/public/center?locale=ar')).body.data.address).toContain('شارع المثال');
    expect((await env.api.get('/api/v1/public/center?locale=fr')).body.data.address).toContain('rue Exemple');
    // the integration endpoint (used by the Telegram assistant) is identical: no drift
    expect((await env.api.integration('GET', '/center?locale=en')).body.data).toEqual(en);
    // validation
    expect((await env.api.put('/api/v1/admin/settings/center', { mapUrl: 'javascript:alert(1)' }, admin)).status).toBe(400);
    expect((await env.api.put('/api/v1/admin/settings/center', { email: 'not-an-email' }, admin)).status).toBe(400);
    expect((await env.api.put('/api/v1/admin/settings/center', { workingDays: [] }, admin)).status).toBe(400);
    expect((await env.api.put('/api/v1/admin/settings/center', { workingDays: [8] }, admin)).status).toBe(400);
    expect((await env.api.put('/api/v1/admin/settings/center', { bookingHorizonDays: 0 }, admin)).status).toBe(400);
    // an address can be cleared again -> the website/assistant must say "not configured"
    await env.api.put('/api/v1/admin/settings/center', { translations: { en: { address: '' }, ar: { address: '' }, fr: { address: '' } } }, admin);
    expect((await env.api.get('/api/v1/public/center?locale=en')).body.data).toMatchObject({ address: '', addressConfigured: false });
  });

  it('cannot disable the last active slot', async () => {
    for (const n of [1, 2, 3]) expect((await env.api.patch(`/api/v1/admin/settings/slots/${n}`, { isActive: false }, admin)).status).toBe(200);
    const last = await env.api.patch('/api/v1/admin/settings/slots/4', { isActive: false }, admin);
    expect(last.status).toBe(422);
    expect(last.body.error.code).toBe('AT_LEAST_ONE_SLOT');
    for (const n of [1, 2, 3]) await env.api.patch(`/api/v1/admin/settings/slots/${n}`, { isActive: true }, admin);
  });
});

describe('closures', () => {
  it('a closure hides the date, refuses to silently ignore booked appointments, and can be reopened', async () => {
    const dept = await departmentId(env, 'endodontics');
    const day = dayOffset(12);
    const p = await registerPatient(env);
    const booked = await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date: day, slotNumber: 1 }, p.session);
    expect(booked.status, JSON.stringify(booked.body)).toBe(201);
    const refused = await env.api.post('/api/v1/admin/closures', { dateFrom: day, dateTo: day, departmentId: dept, reason: 'Maintenance' }, admin);
    expect(refused.status).toBe(409);
    expect(refused.body.error.code).toBe('CLOSURE_HAS_APPOINTMENTS');
    expect(refused.body.error.details).toMatchObject({ count: 1 });
    expect((await env.api.get('/api/v1/admin/closures', admin)).body.data.length).toBe(0); // nothing was created by the refused request
    expect((await env.api.post('/api/v1/admin/closures', { dateFrom: day, dateTo: dayOffset(11), departmentId: dept }, admin)).body.error.code).toBe('INVALID_RANGE');
    const ok = await env.api.post('/api/v1/admin/closures', { dateFrom: day, dateTo: day, departmentId: dept, reason: 'Maintenance', acknowledgeExistingAppointments: true }, admin);
    expect(ok.status, JSON.stringify(ok.body)).toBe(201);
    // the existing appointment is NOT cancelled automatically
    expect((await env.db.query('SELECT status FROM appointments WHERE id = $1', [booked.body.data.id])).rows[0].status).toBe('booked');
    // the day is closed for that department only
    const avail = async (slug: string) => (await env.api.get(`/api/v1/public/departments/${slug}/availability?from=${day}&to=${day}`)).body.data.days[0];
    expect(await avail('endodontics')).toMatchObject({ status: 'closed', availableCount: 0, slots: [] });
    expect(await avail('orthodontics')).toMatchObject({ status: 'open', availableCount: 4 });
    const blocked = await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date: day, slotNumber: 2 }, (await registerPatient(env)).session);
    expect(blocked.status).toBe(422);
    expect(blocked.body.error.code).toBe('DATE_CLOSED');
    // reopen
    expect((await env.api.del(`/api/v1/admin/closures/${ok.body.data.id}`, admin)).status).toBe(204);
    expect((await env.api.del(`/api/v1/admin/closures/${ok.body.data.id}`, admin)).body.error.code).toBe('CLOSURE_NOT_FOUND');
    expect(await avail('endodontics')).toMatchObject({ status: 'open', availableCount: 3 }); // slot 1 is still taken by the existing booking
  });
});

describe('patient administration', () => {
  it('searches by name and phone digits; never exposes password hashes', async () => {
    const p = await registerPatient(env, { fullName: 'Searchable Samir', phone: '01055500123' });
    const byName = await env.api.get('/api/v1/admin/patients?q=searchable', admin);
    expect(byName.body.data.map((x: any) => x.id)).toContain(p.id);
    const byPhone = await env.api.get('/api/v1/admin/patients?q=055500123', admin);
    expect(byPhone.body.data.map((x: any) => x.id)).toContain(p.id);
    const wildcard = await env.api.get('/api/v1/admin/patients?q=%25', admin); // a literal %, not "match all"
    expect(wildcard.body.data.length).toBe(0);
    const one = await env.api.get(`/api/v1/admin/patients/${p.id}`, admin);
    expect(JSON.stringify(one.body)).not.toMatch(/hash|argon2|password/i);
    expect(one.body.data).toMatchObject({ phone: '+201055500123', telegramLinked: false });
  });

  it('deactivating a patient revokes sessions, blocks login and booking; reactivation restores access', async () => {
    const p = await registerPatient(env);
    expect((await env.api.patch(`/api/v1/admin/patients/${p.id}`, { isActive: false }, admin)).status).toBe(200);
    expect((await env.api.get('/api/v1/patient/me', p.session)).status).toBe(401);
    const login = await env.api.post('/api/v1/patient/auth/login', { phone: p.phone, password: p.password });
    expect(login.status).toBe(401);
    expect(login.body.error.code).toBe('INVALID_CREDENTIALS'); // does not reveal the account is disabled
    const dept = await departmentId(env, 'restorative-dentistry');
    expect((await env.api.post('/api/v1/admin/appointments', { patientId: p.id, departmentId: dept, date: dayOffset(5), slotNumber: 1 }, admin)).body.error.code).toBe('ACCOUNT_DISABLED');
    await env.api.patch(`/api/v1/admin/patients/${p.id}`, { isActive: true }, admin);
    expect((await env.api.post('/api/v1/patient/auth/login', { phone: p.phone, password: p.password })).status).toBe(200);
  });

  it('admin can change a phone number (normalized, unique) and create a walk-in account', async () => {
    const a = await registerPatient(env); const b = await registerPatient(env);
    const clash = await env.api.patch(`/api/v1/admin/patients/${a.id}`, { phone: b.phone }, admin);
    expect(clash.status).toBe(409);
    expect(clash.body.error.code).toBe('PHONE_ALREADY_REGISTERED');
    expect((await env.api.patch(`/api/v1/admin/patients/${a.id}`, { phone: 'nonsense' }, admin)).body.error.code).toBe('INVALID_PHONE');
    expect((await env.api.patch(`/api/v1/admin/patients/${a.id}`, { phone: '+20 109 999 8877' }, admin)).body.data.phone).toBe('+201099998877');
    const walkIn = await env.api.post('/api/v1/admin/patients', { fullName: 'Walk In', phone: '01077771111', password: 'Desk-Created-1' }, admin);
    expect(walkIn.status).toBe(201);
    expect((await env.api.post('/api/v1/patient/auth/login', { phone: '01077771111', password: 'Desk-Created-1' })).status).toBe(200);
  });
});

describe('audit log (AUD-01)', () => {
  it('records the administrative actions with actor, entity and outcome, and is readable only by admins', async () => {
    const expected = [
      'department.created', 'department.updated', 'service.created', 'service.updated', 'dentist.replaced', 'closure.created', 'closure.deleted',
      'center.updated', 'slot.updated', 'gallery.created', 'gallery.updated', 'gallery.deleted', 'patient.updated_by_admin', 'patient.created_by_admin',
      'patient.password_reset_by_admin', 'appointment.created', 'appointment.cancelled', 'medical_record.created',
    ];
    // password reset is exercised in auth.test; create one here so the list above is checked in this file too
    const p = await registerPatient(env);
    await env.api.post(`/api/v1/admin/patients/${p.id}/reset-password`, { newPassword: 'Reset-By-Desk-1', identityVerified: true }, admin);
    const dept = await departmentId(env, 'restorative-dentistry');
    const closure = await env.api.post('/api/v1/admin/closures', { dateFrom: dayOffset(40), dateTo: dayOffset(41), reason: 'Holiday' }, admin);
    await env.api.del(`/api/v1/admin/closures/${closure.body.data.id}`, admin);
    const a = await env.api.post('/api/v1/admin/appointments', { patientId: p.id, departmentId: dept, date: dayOffset(30), slotNumber: 1 }, admin);
    await env.api.post(`/api/v1/admin/appointments/${a.body.data.id}/cancel`, {}, admin);
    const rows = (await env.db.query("SELECT action, actor_type, actor_id, entity_type, entity_id, outcome FROM audit_events")).rows;
    for (const action of expected) {
      const ev = rows.find((r) => r.action === action);
      expect(ev, action).toBeTruthy();
      expect(ev.outcome).toBe('success');
      if (action !== 'appointment.created') expect(ev.actor_type).toBe('admin');
      expect(ev.actor_id).toBeTruthy();
      expect(ev.entity_type).toBeTruthy();
    }
    const list = await env.api.get('/api/v1/admin/audit-events?action=appointment.cancelled&pageSize=5', admin);
    expect(list.status).toBe(200);
    expect(list.body.data.every((e: any) => e.action === 'appointment.cancelled')).toBe(true);
    expect(list.body.meta.total).toBeGreaterThan(0);
    const byEntity = await env.api.get(`/api/v1/admin/audit-events?entityType=appointment&entityId=${a.body.data.id}`, admin);
    expect(byEntity.body.data.map((e: any) => e.action).sort()).toEqual(['appointment.cancelled', 'appointment.created']);
    expect((await env.api.get('/api/v1/admin/audit-events')).status).toBe(401);
    expect((await env.api.get('/api/v1/admin/audit-events', p.session)).status).toBe(401);
    // no write endpoints exist for the audit log
    expect(routeRegistry.filter((r) => /audit/.test(r.url)).every((r) => r.method === 'GET')).toBe(true);
  });
});
