import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { BASE_NOW, adminSession, createTestEnv, dayOffset, departmentId, registerPatient, type Session, type TestEnv, type TestPatient } from '../helpers/harness.js';

/**
 * Department working days (ISO weekday, 1 = Monday ... 7 = Sunday). The clock is fixed at Monday 2 Nov 2026, 10:00 in Cairo,
 * so dayOffset(0) is a Monday, dayOffset(5) a Saturday, dayOffset(6) a Sunday, dayOffset(7) the next Monday.
 */
let env: TestEnv;
let admin: Session;

beforeAll(async () => {
  env = await createTestEnv({ SESSION_PATIENT_IDLE_MINUTES: '1000000', SESSION_PATIENT_TTL_HOURS: '100000', SESSION_ADMIN_IDLE_MINUTES: '1000000', SESSION_ADMIN_TTL_HOURS: '100000' });
  admin = await adminSession(env);
});
afterAll(async () => { await env.close(); });
beforeEach(() => { env.clock.set(BASE_NOW); });

const WEEKDAYS = [1, 2, 3, 4, 5];
const weekday = (date: string) => ((new Date(`${date}T00:00:00Z`).getUTCDay() + 6) % 7) + 1; // ISO: Monday = 1
const setDays = (id: string, workingDays: number[], extra: object = {}) => env.api.patch(`/api/v1/admin/departments/${id}`, { workingDays, ...extra }, admin);
const book = (p: TestPatient, departmentId: string, date: string, slotNumber: number) => env.api.post('/api/v1/patient/appointments', { departmentId, date, slotNumber }, p.session);
const availability = async (slug: string, from: string, to: string) => (await env.api.get(`/api/v1/public/departments/${slug}/availability?from=${from}&to=${to}`)).body.data.days as { date: string; status: string; availableCount: number; slots: unknown[] }[];
const centerDays = (workingDays: number[]) => env.api.put('/api/v1/admin/settings/center', { workingDays }, admin);

describe('what an administrator can set', () => {
  it('every seeded department works every day until it is edited', async () => {
    const list = await env.api.get('/api/v1/admin/departments', admin);
    expect(list.body.data).toHaveLength(7);
    for (const d of list.body.data) expect(d.workingDays, d.slug).toEqual([1, 2, 3, 4, 5, 6, 7]);
  });

  it('saves the days sorted and without duplicates, and shows them on the admin and the public views', async () => {
    const perio = await departmentId(env, 'periodontics');
    const res = await setDays(perio, [5, 3, 1, 2, 4, 4]);
    expect(res.status, JSON.stringify(res.body)).toBe(200);
    expect(res.body.data.workingDays).toEqual(WEEKDAYS);
    expect((await env.api.get(`/api/v1/admin/departments/${perio}`, admin)).body.data.workingDays).toEqual(WEEKDAYS);
    const pub = await env.api.get('/api/v1/public/departments?locale=en');
    expect(pub.body.data.find((d: any) => d.slug === 'periodontics').workingDays).toEqual(WEEKDAYS);
    expect(pub.body.data.find((d: any) => d.slug === 'endodontics').workingDays).toEqual([1, 2, 3, 4, 5, 6, 7]);
    expect((await env.api.get('/api/v1/public/departments/periodontics?locale=en')).body.data.workingDays).toEqual(WEEKDAYS);
    expect((await env.api.get('/api/v1/integrations/departments', undefined, { authorization: 'Bearer test-integration-key-0123456789abcdef0123456789' })).body.data.find((d: any) => d.slug === 'periodontics').workingDays).toEqual(WEEKDAYS);
    await setDays(perio, [1, 2, 3, 4, 5, 6, 7]);
  });

  it('refuses an empty list, an unknown weekday and anything that is not a whole number; nothing changes', async () => {
    const perio = await departmentId(env, 'periodontics');
    const code = (r: any) => r.body.error.details?.[0]?.code;
    const empty = await setDays(perio, []);
    expect(empty.status).toBe(400);
    expect(code(empty)).toBe('AT_LEAST_ONE_WORKING_DAY');
    expect(code(await setDays(perio, [0]))).toBe('INVALID_WEEKDAY');
    expect(code(await setDays(perio, [1, 8]))).toBe('INVALID_WEEKDAY');
    expect((await setDays(perio, [1.5] as number[])).status).toBe(400);
    expect((await setDays(perio, ['monday'] as unknown as number[])).status).toBe(400);
    expect((await env.api.patch(`/api/v1/admin/departments/${perio}`, { workingDays: null }, admin)).status).toBe(400);
    expect((await env.api.get(`/api/v1/admin/departments/${perio}`, admin)).body.data.workingDays).toEqual([1, 2, 3, 4, 5, 6, 7]);
  });

  it('a new department works every day unless told otherwise, and can be created with its own days', async () => {
    const make = (slug: string, extra: object) => env.api.post('/api/v1/admin/departments', { slug, translations: { en: { name: slug } }, ...extra }, admin);
    expect((await make('days-default', {})).body.data.workingDays).toEqual([1, 2, 3, 4, 5, 6, 7]);
    expect((await make('days-custom', { workingDays: [6, 7] })).body.data.workingDays).toEqual([6, 7]);
    expect((await make('days-none', { workingDays: [] })).status).toBe(400);
    expect((await env.db.query("SELECT count(*)::int AS n FROM departments WHERE slug = 'days-none'")).rows[0].n).toBe(0);
  });

  it('only an administrator can change them, and the change is audited', async () => {
    const perio = await departmentId(env, 'periodontics');
    expect((await env.api.patch(`/api/v1/admin/departments/${perio}`, { workingDays: [1] })).status).toBe(401);
    const patient = await registerPatient(env);
    expect((await env.api.patch(`/api/v1/admin/departments/${perio}`, { workingDays: [1] }, patient.session)).status).toBe(401);
    await setDays(perio, [1, 2, 3, 4, 5, 6]);
    const audit = (await env.db.query("SELECT metadata FROM audit_events WHERE action = 'department.updated' AND entity_id = $1 ORDER BY id DESC LIMIT 1", [perio])).rows[0].metadata;
    expect(audit.workingDays).toEqual([1, 2, 3, 4, 5, 6]);
    expect(audit.appointmentsOnRemovedDays).toBe(0);
    await setDays(perio, [1, 2, 3, 4, 5, 6, 7]);
  });
});

describe('the working days control availability and booking', () => {
  it('days the department does not work are closed, with no slots; its working days stay open', async () => {
    const dept = await departmentId(env, 'prosthodontics');
    await setDays(dept, WEEKDAYS);
    const days = await availability('prosthodontics', dayOffset(0), dayOffset(13));
    expect(days).toHaveLength(14);
    for (const d of days) {
      if (WEEKDAYS.includes(weekday(d.date))) expect(d, d.date).toMatchObject({ status: 'open', availableCount: 4 });
      else expect(d, d.date).toMatchObject({ status: 'closed', availableCount: 0, slots: [] });
    }
    // another department is not affected
    for (const d of await availability('endodontics', dayOffset(5), dayOffset(6))) expect(d.status).toBe('open');
  });

  it('a booking on a day off is refused with its own error code; on a working day it succeeds', async () => {
    const dept = await departmentId(env, 'prosthodontics');
    const p = await registerPatient(env);
    const saturday = dayOffset(5);
    expect(weekday(saturday)).toBe(6);
    const refused = await book(p, dept, saturday, 1);
    expect(refused.status).toBe(422);
    expect(refused.body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY');
    expect((await env.db.query('SELECT count(*)::int AS n FROM appointments WHERE department_id = $1 AND appointment_date = $2', [dept, saturday])).rows[0].n).toBe(0);
    expect((await book(p, dept, dayOffset(7), 1)).status).toBe(201); // Monday
  });

  it('the same rule applies when the administrator books for a patient and when the Telegram assistant books', async () => {
    const dept = await departmentId(env, 'prosthodontics');
    const p = await registerPatient(env);
    const adminBooking = await env.api.post('/api/v1/admin/appointments', { patientId: p.id, departmentId: dept, date: dayOffset(6), slotNumber: 2 }, admin);
    expect(adminBooking.body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY');

    const token = await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session);
    await env.api.integration('POST', '/telegram/link', { code: token.body.data.code, telegramUserId: '811000111' });
    const viaTelegram = await env.api.integration('POST', '/telegram/811000111/appointments?locale=en', { departmentSlug: 'prosthodontics', date: dayOffset(6), slotNumber: 2 });
    expect(viaTelegram.status).toBe(422);
    expect(viaTelegram.body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY');
    const integrationAvail = await env.api.integration('GET', `/availability?department=prosthodontics&from=${dayOffset(6)}&to=${dayOffset(6)}`);
    expect(integrationAvail.status, JSON.stringify(integrationAvail.body)).toBe(200);
    expect(integrationAvail.body.data.days[0]).toMatchObject({ status: 'closed', availableCount: 0 });
    const monday = await env.api.integration('GET', `/availability?department=prosthodontics&from=${dayOffset(7)}&to=${dayOffset(7)}`);
    expect(monday.body.data.days[0].status).toBe('open'); // a weekday still works
    expect(monday.body.data.days[0].availableCount).toBeGreaterThan(0);
  });

  it('rescheduling onto a day off is refused and leaves the appointment exactly as it was', async () => {
    const dept = await departmentId(env, 'prosthodontics');
    const p = await registerPatient(env);
    const booked = await book(p, dept, dayOffset(8), 3); // Tuesday
    expect(booked.status).toBe(201);
    const move = await env.api.post(`/api/v1/patient/appointments/${booked.body.data.id}/reschedule`, { date: dayOffset(12), slotNumber: 3 }, p.session); // Saturday
    expect(move.status).toBe(422);
    expect(move.body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY');
    expect((await env.api.get(`/api/v1/patient/appointments/${booked.body.data.id}`, p.session)).body.data).toMatchObject({ date: dayOffset(8), slotNumber: 3, status: 'booked', rescheduledCount: 0 });
    expect((await env.api.post(`/api/v1/patient/appointments/${booked.body.data.id}/reschedule`, { date: dayOffset(9), slotNumber: 3 }, p.session)).status).toBe(200); // Wednesday works
  });

  it('a day must be a working day of BOTH the center and the department; the center rule is reported first', async () => {
    const dept = await departmentId(env, 'orthodontics');
    await setDays(dept, [1, 2, 3, 4, 5, 6]); // not Sunday
    expect((await centerDays([1, 2, 3, 4, 5, 7])).status).toBe(200); // the center is closed on Saturday
    try {
      const sat = await availability('orthodontics', dayOffset(5), dayOffset(5));
      const sun = await availability('orthodontics', dayOffset(6), dayOffset(6));
      const mon = await availability('orthodontics', dayOffset(7), dayOffset(7));
      expect([sat[0]!.status, sun[0]!.status, mon[0]!.status]).toEqual(['closed', 'closed', 'open']);
      const p = await registerPatient(env);
      expect((await book(p, dept, dayOffset(5), 1)).body.error.code).toBe('DATE_CLOSED'); // Saturday: closed for the whole center
      expect((await book(p, dept, dayOffset(6), 1)).body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY'); // Sunday: open for the center, not for the department
      expect((await book(p, dept, dayOffset(7), 1)).status).toBe(201);
    } finally {
      await centerDays([1, 2, 3, 4, 5, 6, 7]);
      await setDays(dept, [1, 2, 3, 4, 5, 6, 7]);
    }
  });

  it('closed dates still apply on top of the working days', async () => {
    const dept = await departmentId(env, 'oral-surgery');
    await setDays(dept, [1, 2, 3]);
    await env.api.post('/api/v1/admin/closures', { dateFrom: dayOffset(7), dateTo: dayOffset(7), departmentId: dept }, admin);
    const days = await availability('oral-surgery', dayOffset(7), dayOffset(9));
    expect(days.map((d) => d.status)).toEqual(['closed', 'open', 'open']); // Mon closure, Tue and Wed open
    const p = await registerPatient(env);
    expect((await book(p, dept, dayOffset(7), 1)).body.error.code).toBe('DATE_CLOSED');
    expect((await book(p, dept, dayOffset(10), 1)).body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY'); // Thursday
    await setDays(dept, [1, 2, 3, 4, 5, 6, 7]);
  });

  it('switching a day back on makes it bookable again at once', async () => {
    const dept = await departmentId(env, 'pediatric-dentistry');
    await setDays(dept, WEEKDAYS);
    const p = await registerPatient(env);
    expect((await book(p, dept, dayOffset(5), 1)).body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY');
    await setDays(dept, [...WEEKDAYS, 6]);
    expect((await availability('pediatric-dentistry', dayOffset(5), dayOffset(5)))[0]).toMatchObject({ status: 'open', availableCount: 4 });
    expect((await book(p, dept, dayOffset(5), 1)).status).toBe(201);
  });
});

describe('switching a day off while appointments exist on it', () => {
  it('is refused with the number of affected appointments until the administrator confirms; nothing is cancelled', async () => {
    const dept = await departmentId(env, 'restorative-dentistry');
    const [p1, p2, p3] = [await registerPatient(env), await registerPatient(env), await registerPatient(env)];
    const sat = dayOffset(5);
    expect((await book(p1, dept, sat, 1)).status).toBe(201);
    expect((await book(p2, dept, sat, 2)).status).toBe(201);
    const monday = await book(p3, dept, dayOffset(7), 1);
    expect(monday.status).toBe(201);

    const refused = await setDays(dept, [1, 2, 3, 4, 5, 7]);
    expect(refused.status).toBe(409);
    expect(refused.body.error.code).toBe('WORKING_DAYS_HAVE_APPOINTMENTS');
    expect(refused.body.error.details).toEqual({ count: 2 });
    expect((await env.api.get(`/api/v1/admin/departments/${dept}`, admin)).body.data.workingDays).toEqual([1, 2, 3, 4, 5, 6, 7]);

    const confirmed = await setDays(dept, [1, 2, 3, 4, 5, 7], { acknowledgeExistingAppointments: true });
    expect(confirmed.status, JSON.stringify(confirmed.body)).toBe(200);
    expect(confirmed.body.data.workingDays).toEqual([1, 2, 3, 4, 5, 7]);
    expect((await env.db.query("SELECT count(*)::int AS n FROM appointments WHERE department_id = $1 AND appointment_date = $2 AND status = 'booked'", [dept, sat])).rows[0].n).toBe(2);
    expect((await book(await registerPatient(env), dept, sat, 3)).body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY'); // no NEW bookings on Saturday
    const audit = (await env.db.query("SELECT metadata FROM audit_events WHERE action = 'department.updated' AND entity_id = $1 ORDER BY id DESC LIMIT 1", [dept])).rows[0].metadata;
    expect(audit).toMatchObject({ workingDays: [1, 2, 3, 4, 5, 7], appointmentsOnRemovedDays: 2 });
    expect(JSON.stringify(audit)).not.toContain('acknowledgeExistingAppointments');
    await setDays(dept, [1, 2, 3, 4, 5, 6, 7]);
  });

  it('cancelled and already finished appointments, other weekdays and other departments do not count; adding days never asks', async () => {
    const dept = await departmentId(env, 'endodontics');
    const other = await departmentId(env, 'orthodontics');
    const p = await registerPatient(env);
    const sun = dayOffset(6);
    const cancelled = await book(p, dept, sun, 1);
    expect((await env.api.post(`/api/v1/patient/appointments/${cancelled.body.data.id}/cancel`, {}, p.session)).status).toBe(200);
    expect((await book(await registerPatient(env), other, sun, 1)).status).toBe(201); // another department, same Sunday
    expect((await book(await registerPatient(env), dept, dayOffset(7), 1)).status).toBe(201); // a Monday in this department

    // a booked appointment that is already over (the clock moves past it) is history, not a reason to refuse
    const past = await book(await registerPatient(env), dept, dayOffset(1), 1); // Tuesday 16:00-18:00
    expect(past.status).toBe(201);
    env.clock.set('2026-11-03T19:00:00Z'); // Tuesday 21:00 Cairo: over
    const res = await setDays(dept, [1, 3, 4, 5, 6]); // switches Tuesday and Sunday off
    expect(res.status, JSON.stringify(res.body)).toBe(200);
    expect(res.body.data.workingDays).toEqual([1, 3, 4, 5, 6]);
    expect((await setDays(dept, [1, 2, 3, 4, 5, 6, 7])).status).toBe(200); // adding days: no question asked
  });

  it('a department with no appointments can drop days freely, and a change that removes nothing needs no confirmation', async () => {
    const dept = await departmentId(env, 'periodontics');
    expect((await setDays(dept, [2, 3])).status).toBe(200);
    expect((await setDays(dept, [2, 3])).status).toBe(200);
    expect((await env.api.patch(`/api/v1/admin/departments/${dept}`, { displayOrder: 4 }, admin)).body.data.workingDays).toEqual([2, 3]); // other edits leave the days alone
    await setDays(dept, [1, 2, 3, 4, 5, 6, 7]);
  });
});

describe('bookings and a change of working days at the same moment', () => {
  it('a day switched off without confirmation never ends up with a booking on it (8 racing bookings, 6 rounds)', async () => {
    const dept = await departmentId(env, 'oral-surgery');
    await setDays(dept, [1, 2, 3, 4, 5, 6, 7]);
    const outcomes = { removedFirst: 0, bookingsFirst: 0 };
    for (let round = 0; round < 6; round++) {
      const saturday = dayOffset(5 + 7 * (round + 1)); // a different Saturday each round, all inside the booking horizon
      const patients = await Promise.all(Array.from({ length: 8 }, () => registerPatient(env)));
      const [change, ...bookings] = await Promise.all([
        setDays(dept, [1, 2, 3, 4, 5, 7]),
        ...patients.map((p, i) => book(p, dept, saturday, (i % 4) + 1)),
      ]);
      const landed = Number((await env.db.query("SELECT count(*) AS n FROM appointments WHERE department_id = $1 AND appointment_date = $2 AND status = 'booked'", [dept, saturday])).rows[0].n);
      expect(landed).toBe(bookings.filter((b) => b.status === 201).length);
      for (const b of bookings) expect([201, 409, 422]).toContain(b.status);
      if (change.status === 200) {
        // the days were switched off without anybody confirming anything, so no booking can exist on that Saturday
        expect(landed, `round ${round}: days changed although ${landed} bookings exist`).toBe(0);
        for (const b of bookings) expect(b.body.error.code).toBe('DEPARTMENT_NOT_WORKING_DAY');
        outcomes.removedFirst++;
      } else {
        expect(change.status).toBe(409);
        expect(change.body.error.code).toBe('WORKING_DAYS_HAVE_APPOINTMENTS');
        expect(change.body.error.details.count).toBe(landed);
        outcomes.bookingsFirst++;
      }
      await setDays(dept, [1, 2, 3, 4, 5, 6, 7]);
      // every round starts from a clean Saturday, so the count in the refusal can only be this round's bookings
      await env.db.query('DELETE FROM appointments WHERE department_id = $1 AND appointment_date = $2', [dept, saturday]);
    }
    expect(outcomes.removedFirst + outcomes.bookingsFirst).toBe(6);
  });
});
