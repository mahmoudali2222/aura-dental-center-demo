import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { ADMIN_PASS, ADMIN_PASS_INITIAL, ADMIN_USER, adminSession, createTestEnv, registerPatient, sessionFrom, uniquePhone, type TestEnv } from '../helpers/harness.js';
import { bootstrapAdmin, resetAdminPassword } from '../../src/modules/auth/bootstrap.js';
import { routeRegistry } from '../../src/lib/routes.js';

let env: TestEnv;
beforeAll(async () => { env = await createTestEnv(); });
afterAll(async () => { await env.close(); });

describe('patient registration & login', () => {
  it('AUTH-01 registers a patient, signs them in, and never returns a hash', async () => {
    const res = await env.api.post('/api/v1/patient/auth/register', { fullName: 'Mona Hassan', phone: '01012340001', password: 'Patient-Pass-123', locale: 'ar' });
    expect(res.status).toBe(201);
    expect(res.body.data.patient).toMatchObject({ fullName: 'Mona Hassan', phone: '+201012340001', preferredLocale: 'ar' });
    expect(JSON.stringify(res.body)).not.toMatch(/hash|argon2|password/i);
    const cookie = res.headers['set-cookie'] as string;
    expect(cookie).toMatch(/dc_patient=/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
    expect(cookie).toMatch(/Path=\/api\/v1\/patient/);
  });

  it('AUTH-02 rejects a second account for an equivalent normalized phone', async () => {
    await registerPatient(env, { phone: '01012340002' });
    for (const variant of ['+201012340002', '00201012340002', '٠١٠١٢٣٤٠٠٠٢', '0101 234 0002']) {
      const res = await env.api.post('/api/v1/patient/auth/register', { fullName: 'Dup', phone: variant, password: 'Patient-Pass-123' });
      expect(res.status, variant).toBe(409);
      expect(res.body.error.code).toBe('PHONE_ALREADY_REGISTERED');
    }
    const n = await env.db.query("SELECT count(*)::int AS n FROM patients WHERE phone_e164 = '+201012340002'");
    expect(n.rows[0].n).toBe(1);
  });

  it('AUTH-03 rejects invalid phone, weak and short passwords with stable codes', async () => {
    const bad = await env.api.post('/api/v1/patient/auth/register', { fullName: 'X Y', phone: 'not-a-phone', password: 'Patient-Pass-123' });
    expect(bad.status).toBe(400);
    expect(bad.body.error.code).toBe('INVALID_PHONE');
    const short = await env.api.post('/api/v1/patient/auth/register', { fullName: 'X Y', phone: uniquePhone(), password: 'abc' });
    expect(short.body.error.code).toBe('PASSWORD_TOO_SHORT');
    const weak = await env.api.post('/api/v1/patient/auth/register', { fullName: 'X Y', phone: uniquePhone(), password: '12345678' });
    expect(weak.body.error.code).toBe('PASSWORD_TOO_WEAK');
    const missing = await env.api.post('/api/v1/patient/auth/register', { phone: uniquePhone(), password: 'Patient-Pass-123' });
    expect(missing.status).toBe(400);
    expect(missing.body.error.code).toBe('VALIDATION_ERROR');
    expect(missing.body.error.details).toEqual(expect.arrayContaining([expect.objectContaining({ field: 'fullName' })]));
  });

  it('AUTH-04 login works with any phone spelling; wrong password and unknown phone are indistinguishable', async () => {
    const p = await registerPatient(env, { phone: '01012340003', password: 'Right-Pass-123' });
    const ok = await env.api.post('/api/v1/patient/auth/login', { phone: '+20 101 234 0003', password: 'Right-Pass-123' });
    expect(ok.status).toBe(200);
    expect(ok.body.data.patient.id).toBe(p.id);
    const wrong = await env.api.post('/api/v1/patient/auth/login', { phone: '01012340003', password: 'nope-nope-nope' });
    const unknown = await env.api.post('/api/v1/patient/auth/login', { phone: '01012349999', password: 'nope-nope-nope' });
    const invalidPhone = await env.api.post('/api/v1/patient/auth/login', { phone: 'garbage', password: 'nope-nope-nope' });
    for (const r of [wrong, unknown, invalidPhone]) {
      expect(r.status).toBe(401);
      expect(r.body).toEqual(wrong.body);
    }
    expect(wrong.body.error.code).toBe('INVALID_CREDENTIALS');
  });

  it('AUTH-05 stores an Argon2id hash, never the password', async () => {
    const p = await registerPatient(env, { password: 'Plain-Text-Check-1' });
    const r = await env.db.query('SELECT password_hash FROM patients WHERE id = $1', [p.id]);
    expect(r.rows[0].password_hash).toMatch(/^\$argon2id\$/);
    expect(r.rows[0].password_hash).not.toContain('Plain-Text-Check-1');
  });

  it('AUTH-06 logout revokes the session server-side', async () => {
    const p = await registerPatient(env);
    expect((await env.api.get('/api/v1/patient/me', p.session)).status).toBe(200);
    const out = await env.api.post('/api/v1/patient/auth/logout', {}, p.session);
    expect(out.status).toBe(204);
    const after = await env.api.get('/api/v1/patient/me', p.session); // the old cookie value is replayed
    expect(after.status).toBe(401);
  });

  it('AUTH-07 sessions expire after the idle period and after the absolute lifetime', async () => {
    const p = await registerPatient(env);
    env.clock.advance(23 * 3600_000); // within the 24h idle window
    expect((await env.api.get('/api/v1/patient/me', p.session)).status).toBe(200); // slides the window
    env.clock.advance(25 * 3600_000); // idle > 24h now
    const idle = await env.api.get('/api/v1/patient/me', p.session);
    expect(idle.status).toBe(401);
    expect(idle.body.error.code).toBe('SESSION_EXPIRED');

    // Absolute lifetime (7 days = 168 h): keep the session "active" with a request every 23 h so only the absolute limit can end it.
    const q = await registerPatient(env);
    for (let hours = 23; hours <= 161; hours += 23) {
      env.clock.advance(23 * 3600_000);
      expect((await env.api.get('/api/v1/patient/me', q.session)).status, `valid at +${hours}h`).toBe(200);
    }
    env.clock.advance(23 * 3600_000); // +184 h > 168 h
    const expired = await env.api.get('/api/v1/patient/me', q.session);
    expect(expired.status).toBe(401);
    expect(expired.body.error.code).toBe('SESSION_EXPIRED');
    env.clock.set('2026-11-02T08:00:00Z');
  });

  it('AUTH-09 state-changing requests need the CSRF token and an allowed Origin', async () => {
    const p = await registerPatient(env);
    const noCsrf = await env.api.request('POST', '/api/v1/patient/auth/logout', { body: {}, headers: { cookie: `dc_patient=${p.session.token}` } });
    expect(noCsrf.status).toBe(403);
    expect(noCsrf.body.error.code).toBe('CSRF_INVALID');
    const wrongCsrf = await env.api.request('POST', '/api/v1/patient/auth/logout', { body: {}, headers: { cookie: `dc_patient=${p.session.token}`, 'x-csrf-token': 'wrong' } });
    expect(wrongCsrf.status).toBe(403);
    const evil = await env.api.request('POST', '/api/v1/patient/auth/login', { body: { phone: p.phone, password: p.password }, headers: { origin: 'https://evil.example' } });
    expect(evil.status).toBe(403);
    expect(evil.body.error.code).toBe('ORIGIN_NOT_ALLOWED');
    const good = await env.api.request('POST', '/api/v1/patient/auth/login', { body: { phone: p.phone, password: p.password }, headers: { origin: 'http://localhost:8480' } });
    expect(good.status).toBe(200);
  });

  it('AUTH-04b profile update works; the phone number cannot be changed by the patient', async () => {
    const p = await registerPatient(env);
    const res = await env.api.patch('/api/v1/patient/me', { fullName: 'New Name', preferredLocale: 'fr', phone: '01099999999' }, p.session);
    expect(res.status).toBe(200);
    expect(res.body.data.patient).toMatchObject({ fullName: 'New Name', preferredLocale: 'fr', phone: p.phone.replace(/^0/, '+20') });
  });
});

describe('rate limiting & lockout (AUTH-08)', () => {
  it('locks an account after repeated failures, even from different IPs, and a correct password then also waits', async () => {
    const p = await registerPatient(env, { password: 'Right-Pass-123' });
    for (let i = 0; i < 8; i++) {
      const r = await env.api.request('POST', '/api/v1/patient/auth/login', { body: { phone: p.phone, password: 'wrong-wrong-1' }, ip: `10.0.0.${i + 1}` });
      expect(r.status).toBe(401);
    }
    const locked = await env.api.request('POST', '/api/v1/patient/auth/login', { body: { phone: p.phone, password: 'Right-Pass-123' }, ip: '10.9.9.9' });
    expect(locked.status).toBe(429);
    expect(locked.body.error.code).toBe('TOO_MANY_ATTEMPTS');
    env.clock.advance(16 * 60_000); // window passes
    const again = await env.api.request('POST', '/api/v1/patient/auth/login', { body: { phone: p.phone, password: 'Right-Pass-123' }, ip: '10.9.9.9' });
    expect(again.status).toBe(200);
  });

  it('applies a per-IP login limit in production-like configuration', async () => {
    const strict = await createTestEnv({ NODE_ENV: 'development' });
    try {
      let last = 0;
      for (let i = 0; i < 25; i++) {
        const r = await strict.api.request('POST', '/api/v1/patient/auth/login', { body: { phone: `0101999${String(1000 + i)}`, password: 'whatever-1' }, ip: '203.0.113.7' });
        last = r.status;
        if (r.status === 429) { expect(r.body.error.code).toBe('RATE_LIMITED'); break; }
      }
      expect(last).toBe(429);
    } finally { await strict.close(); }
  });
});

describe('admin authentication', () => {
  let admin: Awaited<ReturnType<typeof adminSession>>;
  it('AUTH-10 bootstrap creates exactly one admin, is idempotent and never resets an existing account', async () => {
    const first = await bootstrapAdmin(env.databaseUrl, ADMIN_USER, ADMIN_PASS_INITIAL);
    expect(first.created).toBe(true);
    const second = await bootstrapAdmin(env.databaseUrl, 'someone-else', 'Another-Strong-Pass-9');
    expect(second.created).toBe(false);
    const rows = await env.db.query('SELECT username, must_change_password, password_hash FROM admin_users');
    expect(rows.rowCount).toBe(1);
    expect(rows.rows[0].username).toBe(ADMIN_USER);
    expect(rows.rows[0].must_change_password).toBe(true);
    expect(rows.rows[0].password_hash).toMatch(/^\$argon2id\$/);
    await expect(bootstrapAdmin(env.databaseUrl, 'x', 'short')).rejects.toThrow();
  });

  it('AUTH-11 a fresh admin can do nothing but change the password until it is changed', async () => {
    const login = await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS_INITIAL });
    expect(login.status).toBe(200);
    expect(login.body.data.admin.mustChangePassword).toBe(true);
    const s = sessionFrom(login, 'dc_admin');
    expect((await env.api.get('/api/v1/admin/auth/me', s)).status).toBe(200);
    for (const url of ['/api/v1/admin/dashboard', '/api/v1/admin/patients', '/api/v1/admin/departments', '/api/v1/admin/audit-events', '/api/v1/admin/appointments']) {
      const r = await env.api.get(url, s);
      expect(r.status, url).toBe(403);
      expect(r.body.error.code).toBe('PASSWORD_CHANGE_REQUIRED');
    }
    const same = await env.api.post('/api/v1/admin/auth/change-password', { currentPassword: ADMIN_PASS_INITIAL, newPassword: ADMIN_PASS_INITIAL }, s);
    expect(same.body.error.code).toBe('PASSWORD_UNCHANGED');
    const weak = await env.api.post('/api/v1/admin/auth/change-password', { currentPassword: ADMIN_PASS_INITIAL, newPassword: 'short' }, s);
    expect(weak.body.error.code).toBe('PASSWORD_TOO_SHORT');
    const wrongCur = await env.api.post('/api/v1/admin/auth/change-password', { currentPassword: 'not-the-password', newPassword: ADMIN_PASS }, s);
    expect(wrongCur.status).toBe(401);
    const ok = await env.api.post('/api/v1/admin/auth/change-password', { currentPassword: ADMIN_PASS_INITIAL, newPassword: ADMIN_PASS }, s);
    expect(ok.status).toBe(204);
    expect((await env.api.get('/api/v1/admin/dashboard', s)).status).toBe(200);
    // old password no longer works; new one does
    expect((await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS_INITIAL })).status).toBe(401);
    admin = sessionFrom(await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS }), 'dc_admin');
  });

  it('AUTH-12 patient and admin credentials are not interchangeable', async () => {
    const p = await registerPatient(env);
    // patient cookie presented to an admin route
    const asAdmin = await env.api.request('GET', '/api/v1/admin/dashboard', { headers: { cookie: `dc_patient=${p.session.token}` } });
    expect(asAdmin.status).toBe(401);
    // admin token smuggled under the patient cookie name
    const asPatient = await env.api.request('GET', '/api/v1/patient/me', { headers: { cookie: `dc_patient=${admin.token}` } });
    expect(asPatient.status).toBe(401);
    // integration key is not an admin credential
    const key = await env.api.request('GET', '/api/v1/admin/dashboard', { headers: { authorization: 'Bearer test-integration-key-0123456789abcdef0123456789' } });
    expect(key.status).toBe(401);
    // anonymous
    expect((await env.api.get('/api/v1/admin/patients')).status).toBe(401);
    expect((await env.api.get('/api/v1/patient/appointments')).status).toBe(401);
  });

  it('AUTH-14 staff-assisted reset: admin only, requires identity confirmation, revokes sessions, audited without the password', async () => {
    const p = await registerPatient(env, { password: 'Old-Pass-12345' });
    const asPatient = await env.api.post(`/api/v1/admin/patients/${p.id}/reset-password`, { newPassword: 'New-Pass-12345', identityVerified: true }, p.session);
    expect(asPatient.status).toBe(401);
    const admin2 = sessionFrom(await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS }), 'dc_admin');
    const noConfirm = await env.api.post(`/api/v1/admin/patients/${p.id}/reset-password`, { newPassword: 'New-Pass-12345' }, admin2);
    expect(noConfirm.status).toBe(400);
    const notTrue = await env.api.post(`/api/v1/admin/patients/${p.id}/reset-password`, { newPassword: 'New-Pass-12345', identityVerified: false }, admin2);
    expect(notTrue.status).toBe(400);
    const ok = await env.api.post(`/api/v1/admin/patients/${p.id}/reset-password`, { newPassword: 'New-Pass-12345', identityVerified: true }, admin2);
    expect(ok.status).toBe(204);
    expect((await env.api.get('/api/v1/patient/me', p.session)).status).toBe(401); // old session revoked
    expect((await env.api.post('/api/v1/patient/auth/login', { phone: p.phone, password: 'Old-Pass-12345' })).status).toBe(401);
    expect((await env.api.post('/api/v1/patient/auth/login', { phone: p.phone, password: 'New-Pass-12345' })).status).toBe(200);
    const audit = await env.db.query("SELECT * FROM audit_events WHERE action = 'patient.password_reset_by_admin' AND entity_id = $1", [p.id]);
    expect(audit.rowCount).toBe(1);
    expect(audit.rows[0].actor_type).toBe('admin');
    expect(JSON.stringify(audit.rows[0])).not.toMatch(/New-Pass|Old-Pass/);
  });

  it('AUTH-15 there is no unauthenticated password-reset or recovery route', () => {
    const unauth = routeRegistry.filter((r) => r.auth === 'public');
    for (const r of unauth) expect(r.url, `${r.method} ${r.url}`).not.toMatch(/reset|forgot|recover|otp|verify/i);
    const everything = routeRegistry.filter((r) => /reset|forgot|recover/i.test(r.url));
    for (const r of everything) expect(r.auth).toBe('admin');
  });

  it('audits admin login success and failure, and logout', async () => {
    await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: 'wrong-wrong-wrong' });
    const ok = sessionFrom(await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS }), 'dc_admin');
    await env.api.post('/api/v1/admin/auth/logout', {}, ok);
    const a = await env.db.query("SELECT action, outcome FROM audit_events WHERE action LIKE 'admin.%' ORDER BY id");
    const actions = a.rows.map((r) => `${r.action}:${r.outcome}`);
    expect(actions).toEqual(expect.arrayContaining(['admin.bootstrap:success', 'admin.login:success', 'admin.login_failed:failure', 'admin.logout:success', 'admin.password_changed:success']));
  });

  it('lock-out recovery: the command-line reset replaces the password, forces a change, closes sessions and is audited', async () => {
    const live = sessionFrom(await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS }), 'dc_admin');
    expect((await env.api.get('/api/v1/admin/auth/me', live)).status).toBe(200);

    expect((await resetAdminPassword(env.databaseUrl, 'nobody-here', 'Operator-Chosen-77')).reset).toBe(false); // unknown user: nothing happens
    await expect(resetAdminPassword(env.databaseUrl, ADMIN_USER, 'short')).rejects.toThrow(); // the policy still applies
    expect((await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS })).status).toBe(200); // unchanged so far

    expect((await resetAdminPassword(env.databaseUrl, ` ${ADMIN_USER.toUpperCase()} `, 'Operator-Chosen-77')).reset).toBe(true);
    expect((await env.api.get('/api/v1/admin/auth/me', live)).status).toBe(401); // the old session is closed
    expect((await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: ADMIN_PASS })).status).toBe(401); // the old password is gone
    const login = await env.api.post('/api/v1/admin/auth/login', { username: ADMIN_USER, password: 'Operator-Chosen-77' });
    expect(login.status).toBe(200);
    expect(login.body.data.admin.mustChangePassword).toBe(true); // and a new one must be chosen before anything else works
    expect((await env.api.get('/api/v1/admin/dashboard', sessionFrom(login, 'dc_admin'))).status).toBe(403);

    const audit = await env.db.query("SELECT actor_type, metadata FROM audit_events WHERE action = 'admin.password_reset_cli'");
    expect(audit.rowCount).toBe(1);
    expect(audit.rows[0].actor_type).toBe('system');
    expect(JSON.stringify(audit.rows[0])).not.toMatch(/Operator-Chosen|argon2/);
  });
});
