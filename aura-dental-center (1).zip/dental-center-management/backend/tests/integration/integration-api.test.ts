import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import {
  ADMIN_USER, BASE_NOW, INTEGRATION_KEY, adminSession, createTestEnv, dayOffset, departmentId, registerPatient,
  type Session, type TestEnv, type TestPatient,
} from '../helpers/harness.js';
import { routeRegistry } from '../../src/lib/routes.js';

let env: TestEnv;
let admin: Session;
let tgCounter = 700_000_000;
const nextTg = () => String(++tgCounter);

beforeAll(async () => {
  env = await createTestEnv({
    SESSION_PATIENT_IDLE_MINUTES: '1000000', SESSION_PATIENT_TTL_HOURS: '100000', SESSION_ADMIN_IDLE_MINUTES: '1000000', SESSION_ADMIN_TTL_HOURS: '100000',
  });
  admin = await adminSession(env);
});
afterAll(async () => { await env.close(); });
beforeEach(() => { env.clock.set(BASE_NOW); });

const integ = (method: string, url: string, body?: unknown) => env.api.integration(method, url, body);

/** Full, real linking flow: logged-in patient creates a code, "n8n" redeems it with the Telegram user id. */
async function linkedPatient(opts: { tg?: string; fullName?: string } = {}): Promise<TestPatient & { tg: string }> {
  const p = await registerPatient(env, { fullName: opts.fullName });
  const tg = opts.tg ?? nextTg();
  const token = await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session);
  expect(token.status, JSON.stringify(token.body)).toBe(201);
  const redeemed = await integ('POST', '/telegram/link', { code: token.body.data.code, telegramUserId: tg });
  expect(redeemed.status, JSON.stringify(redeemed.body)).toBe(200);
  expect(redeemed.body.data).toEqual({ linked: true });
  return { ...p, tg };
}

const book = (tg: string, slug: string, date: string, slotNumber: number) =>
  integ('POST', `/telegram/${tg}/appointments?locale=en`, { departmentSlug: slug, date, slotNumber });

describe('INT-01 integration key authentication', () => {
  it('missing, malformed or wrong credentials are refused with one stable code; the right key works', async () => {
    const url = '/api/v1/integrations/center';
    const bad: Record<string, string>[] = [
      {},
      { authorization: '' },
      { authorization: 'Bearer ' },
      { authorization: 'Bearer wrong-key' },
      { authorization: `Bearer ${INTEGRATION_KEY}x` },
      { authorization: `Bearer ${INTEGRATION_KEY.slice(0, -1)}` },
      { authorization: `Basic ${INTEGRATION_KEY}` },
      { authorization: INTEGRATION_KEY },
      { 'x-api-key': INTEGRATION_KEY },
    ];
    for (const headers of bad) {
      const r = await env.api.request('GET', url, { headers });
      expect(r.status, JSON.stringify(headers)).toBe(401);
      expect(r.body.error.code).toBe('INVALID_INTEGRATION_KEY');
      expect(JSON.stringify(r.body)).not.toContain(INTEGRATION_KEY);
    }
    expect((await env.api.request('GET', `${url}?key=${INTEGRATION_KEY}`)).status).toBe(401); // never accepted via the URL
    expect((await integ('GET', '/center')).status).toBe(200);
  });

  it('accepts either key during rotation, and refuses a retired key', async () => {
    const OLD = 'old-integration-key-aaaaaaaaaaaaaaaaaaaaaaaaaaaa';
    const NEW = 'new-integration-key-bbbbbbbbbbbbbbbbbbbbbbbbbbbb';
    const rot = await createTestEnv({ INTEGRATION_API_KEY: OLD, INTEGRATION_API_KEY_NEXT: NEW });
    try {
      const get = (key: string) => rot.api.request('GET', '/api/v1/integrations/center', { headers: { authorization: `Bearer ${key}` } });
      expect((await get(OLD)).status).toBe(200);
      expect((await get(NEW)).status).toBe(200);
      expect((await get('third-key-cccccccccccccccccccccccccccccccc')).status).toBe(401);
    } finally { await rot.close(); }
    const done = await createTestEnv({ INTEGRATION_API_KEY: NEW }); // rotation finished: only the new key remains
    try {
      const get = (key: string) => done.api.request('GET', '/api/v1/integrations/center', { headers: { authorization: `Bearer ${key}` } });
      expect((await get(NEW)).status).toBe(200);
      expect((await get(OLD)).status).toBe(401);
    } finally { await done.close(); }
  });

  it('with no key configured the whole integration API is disabled (503), not open', async () => {
    const off = await createTestEnv({ INTEGRATION_API_KEY: undefined });
    try {
      for (const headers of [{} as Record<string, string>, { authorization: `Bearer ${INTEGRATION_KEY}` }]) {
        const r = await off.api.request('GET', '/api/v1/integrations/center', { headers });
        expect(r.status).toBe(503);
        expect(r.body.error.code).toBe('INTEGRATION_DISABLED');
      }
      expect((await off.api.get('/api/v1/public/center')).status).toBe(200); // the website is unaffected
    } finally { await off.close(); }
  });
});

describe('INT-02 / INT-10 the assistant reads the same data as the website', () => {
  it('availability is identical, including after a booking changes it', async () => {
    const from = dayOffset(1); const to = dayOffset(9);
    const pub = async () => (await env.api.get(`/api/v1/public/departments/orthodontics/availability?from=${from}&to=${to}`)).body.data;
    const viaN8n = async () => (await integ('GET', `/availability?department=orthodontics&from=${from}&to=${to}`)).body.data;
    expect(await viaN8n()).toEqual(await pub());
    const p = await linkedPatient();
    expect((await book(p.tg, 'orthodontics', dayOffset(2), 2)).status).toBe(201);
    const after = await viaN8n();
    expect(after).toEqual(await pub());
    expect(after.days.find((d: any) => d.date === dayOffset(2)).slots.map((s: any) => s.slotNumber)).toEqual([1, 3, 4]);
    expect((await integ('GET', '/availability?department=nope')).body.error.code).toBe('DEPARTMENT_NOT_FOUND');
    expect((await integ('GET', `/availability?department=orthodontics&from=${to}&to=${from}`)).body.error.code).toBe('INVALID_RANGE');
    expect((await integ('GET', `/availability?department=orthodontics&from=${from}&to=${dayOffset(200)}`)).body.error.code).toBe('RANGE_TOO_LARGE');
  });

  it('center profile, departments and department detail equal the public endpoints in every language', async () => {
    await env.api.put('/api/v1/admin/settings/center', {
      phone: '+20 2 5555 0000',
      translations: { ar: { address: 'عنوان تجريبي' }, en: { address: 'Sample address' }, fr: { address: 'Adresse exemple' } },
    }, admin);
    for (const locale of ['ar', 'en', 'fr']) {
      expect((await integ('GET', `/center?locale=${locale}`)).body.data).toEqual((await env.api.get(`/api/v1/public/center?locale=${locale}`)).body.data);
      expect((await integ('GET', `/departments?locale=${locale}`)).body.data).toEqual((await env.api.get(`/api/v1/public/departments?locale=${locale}`)).body.data);
      expect((await integ('GET', `/departments/endodontics?locale=${locale}`)).body.data).toEqual((await env.api.get(`/api/v1/public/departments/endodontics?locale=${locale}`)).body.data);
    }
    expect((await integ('GET', '/center?locale=en')).body.data.address).toBe('Sample address'); // the one configured address, not a prompt constant
    await env.api.put('/api/v1/admin/settings/center', { translations: { ar: { address: '' }, en: { address: '' }, fr: { address: '' } } }, admin);
    expect((await integ('GET', '/center?locale=en')).body.data).toMatchObject({ address: '', addressConfigured: false });
  });
});

describe('INT-04 linking codes', () => {
  it('a code is single-use, bound to one redemption, and only its hash is stored', async () => {
    const p = await registerPatient(env);
    const t = await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session);
    const { code, ttlSeconds } = t.body.data;
    expect(ttlSeconds).toBe(600);
    expect(code).toMatch(/^[A-Z0-9-]{8,16}$/i);
    const rows = (await env.db.query('SELECT * FROM telegram_link_tokens WHERE patient_id = $1', [p.id])).rows;
    expect(rows.length).toBe(1);
    expect(JSON.stringify(rows[0])).not.toContain(code.replace(/-/g, ''));
    expect(JSON.stringify(rows[0])).not.toContain(code);
    const tg = nextTg();
    expect((await integ('POST', '/telegram/link', { code, telegramUserId: tg })).status).toBe(200);
    const second = await integ('POST', '/telegram/link', { code, telegramUserId: nextTg() });
    expect(second.status).toBe(404);
    expect(second.body.error.code).toBe('LINK_CODE_INVALID');
    expect((await integ('GET', `/telegram/${tg}/status`)).body.data).toEqual({ linked: true });
  });

  it('the code is case/format tolerant but expires after exactly 10 minutes; expired, used and unknown look identical', async () => {
    const p = await registerPatient(env);
    const t = await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session);
    const code: string = t.body.data.code;
    env.clock.advance(10 * 60 * 1000 - 1000); // 9 min 59 s: still valid
    const tg = nextTg();
    expect((await integ('POST', '/telegram/link', { code: code.toLowerCase(), telegramUserId: tg })).status).toBe(200);

    const q = await registerPatient(env);
    const t2 = await env.api.post('/api/v1/patient/telegram/link-token', {}, q.session);
    env.clock.advance(10 * 60 * 1000); // exactly 10 minutes: expired
    const expired = await integ('POST', '/telegram/link', { code: t2.body.data.code, telegramUserId: nextTg() });
    const unknown = await integ('POST', '/telegram/link', { code: 'ZZZZZZZZZZZZ', telegramUserId: nextTg() });
    const used = await integ('POST', '/telegram/link', { code, telegramUserId: nextTg() });
    for (const r of [expired, unknown, used]) expect(r.status).toBe(404);
    expect(expired.body).toEqual(unknown.body);
    expect(used.body).toEqual(unknown.body);
  });

  it('only the newest code works: asking for a new one burns the previous one', async () => {
    const p = await registerPatient(env);
    const first = (await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session)).body.data.code;
    const second = (await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session)).body.data.code;
    expect(first).not.toBe(second);
    expect((await integ('POST', '/telegram/link', { code: first, telegramUserId: nextTg() })).status).toBe(404);
    expect((await integ('POST', '/telegram/link', { code: second, telegramUserId: nextTg() })).status).toBe(200);
  });

  it('creating a code needs a logged-in patient: no session, admin session or integration key is not enough', async () => {
    expect((await env.api.post('/api/v1/patient/telegram/link-token', {})).status).toBe(401);
    expect((await env.api.post('/api/v1/patient/telegram/link-token', {}, admin)).status).toBe(401);
    const r = await env.api.request('POST', '/api/v1/patient/telegram/link-token', { body: {}, headers: { authorization: `Bearer ${INTEGRATION_KEY}` } });
    expect(r.status).toBe(401);
  });

  it('guessing codes is throttled per Telegram account, even a correct code is refused while locked, and the lock expires', async () => {
    const victim = await registerPatient(env);
    const good = (await env.api.post('/api/v1/patient/telegram/link-token', {}, victim.session)).body.data.code;
    const attacker = nextTg();
    for (let i = 0; i < 8; i++) expect((await integ('POST', '/telegram/link', { code: `GUESS${String(i).padStart(7, '0')}`, telegramUserId: attacker })).status).toBe(404);
    const locked = await integ('POST', '/telegram/link', { code: good, telegramUserId: attacker });
    expect(locked.status).toBe(429);
    expect(locked.body.error.code).toBe('TOO_MANY_ATTEMPTS');
    expect((await integ('GET', `/telegram/${attacker}/status`)).body.data.linked).toBe(false);
    env.clock.advance(16 * 60 * 1000);
    // the code itself expired in the meantime (10 min), so the legitimate owner simply asks for a fresh one
    const fresh = (await env.api.post('/api/v1/patient/telegram/link-token', {}, victim.session)).body.data.code;
    expect((await integ('POST', '/telegram/link', { code: fresh, telegramUserId: attacker })).status).toBe(200);
  });

  it('a deactivated patient cannot be linked, and malformed input is rejected before any lookup', async () => {
    const p = await registerPatient(env);
    const code = (await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session)).body.data.code;
    await env.api.patch(`/api/v1/admin/patients/${p.id}`, { isActive: false }, admin);
    expect((await integ('POST', '/telegram/link', { code, telegramUserId: nextTg() })).body.error.code).toBe('LINK_CODE_INVALID');
    for (const body of [{ code: 'short', telegramUserId: '123' }, { code: 'ABCDEFGHIJKL', telegramUserId: 'abc' }, { code: 'ABCDEFGHIJKL', telegramUserId: '0123' }, { code: 'ABCDEFGHIJKL' }, {}]) {
      expect((await integ('POST', '/telegram/link', body)).status, JSON.stringify(body)).toBe(400);
    }
  });

  it('re-linking replaces: a Telegram account follows its newest patient, and a patient has one Telegram account', async () => {
    const a = await linkedPatient();
    const b = await registerPatient(env);
    const codeB = (await env.api.post('/api/v1/patient/telegram/link-token', {}, b.session)).body.data.code;
    expect((await integ('POST', '/telegram/link', { code: codeB, telegramUserId: a.tg })).status).toBe(200); // same Telegram account, other patient
    const mine = await integ('GET', `/telegram/${a.tg}/appointments?scope=all`);
    expect(mine.status).toBe(200);
    expect((await env.api.get('/api/v1/patient/telegram', a.session)).body.data.linked).toBe(false); // A lost the link
    expect((await env.api.get('/api/v1/patient/telegram', b.session)).body.data.linked).toBe(true);
    const codeA2 = (await env.api.post('/api/v1/patient/telegram/link-token', {}, b.session)).body.data.code;
    const newTg = nextTg();
    expect((await integ('POST', '/telegram/link', { code: codeA2, telegramUserId: newTg })).status).toBe(200); // B moves to another Telegram account
    expect((await integ('GET', `/telegram/${a.tg}/status`)).body.data.linked).toBe(false);
    expect((await integ('GET', `/telegram/${newTg}/status`)).body.data.linked).toBe(true);
    const active = await env.db.query('SELECT count(*)::int AS n FROM telegram_links WHERE revoked_at IS NULL AND patient_id = $1', [b.id]);
    expect(active.rows[0].n).toBe(1);
  });
});

describe('INT-03 personal operations need a link', () => {
  it('an unlinked Telegram user gets TELEGRAM_NOT_LINKED everywhere and nothing is created', async () => {
    const tg = nextTg();
    const before = Number((await env.db.query('SELECT count(*) AS n FROM appointments')).rows[0].n);
    const someone = await registerPatient(env);
    const dept = await departmentId(env, 'restorative-dentistry');
    const appt = await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date: dayOffset(5), slotNumber: 1 }, someone.session);
    const calls: [string, string, unknown?][] = [
      ['GET', `/telegram/${tg}/appointments`],
      ['POST', `/telegram/${tg}/appointments`, { departmentSlug: 'restorative-dentistry', date: dayOffset(6), slotNumber: 1 }],
      ['POST', `/telegram/${tg}/appointments/${appt.body.data.id}/cancel`, {}],
      ['POST', `/telegram/${tg}/appointments/${appt.body.data.id}/reschedule`, { date: dayOffset(7), slotNumber: 1 }],
    ];
    for (const [m, u, b] of calls) {
      const r = await integ(m, u, b ?? undefined);
      expect(r.status, `${m} ${u}`).toBe(403);
      expect(r.body.error.code).toBe('TELEGRAM_NOT_LINKED');
    }
    expect(Number((await env.db.query('SELECT count(*) AS n FROM appointments')).rows[0].n)).toBe(before + 1); // only the website one
    expect((await env.db.query('SELECT status FROM appointments WHERE id = $1', [appt.body.data.id])).rows[0].status).toBe('booked');
    expect((await integ('GET', `/telegram/${tg}/status`)).body.data).toEqual({ linked: false });
    expect((await integ('GET', '/telegram/not-a-number/status')).body.error.code).toBe('VALIDATION_ERROR');
  });

  it('a linked user books, lists, and the appointment is persisted as a telegram booking without patient contact data', async () => {
    const p = await linkedPatient({ fullName: 'Layla Telegram' });
    const r = await book(p.tg, 'endodontics', dayOffset(3), 3);
    expect(r.status, JSON.stringify(r.body)).toBe(201);
    expect(r.body.data).toMatchObject({ status: 'booked', createdVia: 'telegram', slotNumber: 3, startTime: '20:00', endTime: '22:00', department: { slug: 'endodontics', name: 'Endodontics' } });
    const raw = JSON.stringify(r.body);
    expect(raw).not.toContain('Layla'); expect(raw).not.toContain(p.phone); expect(raw).not.toContain('+20');
    expect(r.body.data.patient).toBeUndefined();
    const row = (await env.db.query('SELECT patient_id, created_via FROM appointments WHERE id = $1', [r.body.data.id])).rows[0];
    expect(row).toEqual({ patient_id: p.id, created_via: 'telegram' });
    const list = await integ('GET', `/telegram/${p.tg}/appointments?scope=upcoming&locale=ar`);
    expect(list.body.data.map((a: any) => a.id)).toEqual([r.body.data.id]);
    expect(list.body.data[0].department.name).not.toBe('Endodontics'); // localized
    // the website shows the very same appointment
    expect((await env.api.get(`/api/v1/patient/appointments/${r.body.data.id}`, p.session)).status).toBe(200);
    const audit = (await env.db.query("SELECT actor_type, actor_id FROM audit_events WHERE action = 'appointment.created' AND entity_id = $1", [r.body.data.id])).rows[0];
    expect(audit).toEqual({ actor_type: 'integration', actor_id: 'n8n' });
    expect((await book(p.tg, 'no-such-department', dayOffset(3), 1)).body.error.code).toBe('DEPARTMENT_NOT_FOUND');
  });

  it('the same booking rules apply: past slots, closed days, the horizon, overlap and the daily capacity', async () => {
    const p = await linkedPatient();
    env.clock.set('2026-11-02T15:00:00Z'); // 17:00 Cairo: today's first slot has started
    expect((await book(p.tg, 'restorative-dentistry', dayOffset(0), 1)).body.error.code).toBe('SLOT_IN_PAST');
    expect((await book(p.tg, 'restorative-dentistry', dayOffset(0), 4)).status).toBe(201);
    env.clock.set(BASE_NOW);
    expect((await book(p.tg, 'restorative-dentistry', dayOffset(400), 1)).body.error.code).toBe('BEYOND_BOOKING_HORIZON');
    const closure = await env.api.post('/api/v1/admin/closures', { dateFrom: dayOffset(20), dateTo: dayOffset(20) }, admin);
    expect((await book(p.tg, 'restorative-dentistry', dayOffset(20), 1)).body.error.code).toBe('DATE_CLOSED');
    await env.api.del(`/api/v1/admin/closures/${closure.body.data.id}`, admin);
    // the same patient cannot hold two departments at the same time
    expect((await book(p.tg, 'periodontics', dayOffset(0), 4)).body.error.code).toBe('PATIENT_OVERLAP');
    // capacity: four per department per day, whoever books
    for (const slot of [1, 2, 3, 4]) expect((await book((await linkedPatient()).tg, 'orthodontics', dayOffset(8), slot)).status).toBe(201);
    expect((await book((await linkedPatient()).tg, 'orthodontics', dayOffset(8), 1)).body.error.code).toBe('SLOT_UNAVAILABLE');
    expect((await book((await linkedPatient()).tg, 'orthodontics', dayOffset(8), 2)).body.error.code).toBe('SLOT_UNAVAILABLE');
    expect((await book((await linkedPatient()).tg, 'oral-surgery', dayOffset(8), 1)).status).toBe(201); // other department: unaffected
  });
});

describe('INT-05 a Telegram user can only touch their own appointments', () => {
  it("cannot list, cancel or reschedule another patient's appointment, and learns nothing about it", async () => {
    const mine = await linkedPatient();
    const other = await linkedPatient();
    const theirs = await book(other.tg, 'orthodontics', dayOffset(6), 1);
    expect(theirs.status).toBe(201);
    const id = theirs.body.data.id;
    expect((await integ('GET', `/telegram/${mine.tg}/appointments?scope=all`)).body.data).toEqual([]);
    const cancel = await integ('POST', `/telegram/${mine.tg}/appointments/${id}/cancel`, {});
    const reschedule = await integ('POST', `/telegram/${mine.tg}/appointments/${id}/reschedule`, { date: dayOffset(7), slotNumber: 2 });
    const missing = await integ('POST', `/telegram/${mine.tg}/appointments/00000000-0000-4000-8000-000000000009/cancel`, {});
    for (const r of [cancel, reschedule]) { expect(r.status).toBe(404); expect(r.body.error.code).toBe('APPOINTMENT_NOT_FOUND'); }
    expect(cancel.body).toEqual(missing.body); // indistinguishable from "does not exist"
    const row = (await env.db.query('SELECT status, appointment_date, slot_number FROM appointments WHERE id = $1', [id])).rows[0];
    expect(row).toMatchObject({ status: 'booked', slot_number: 1 });
  });
});

describe('INT-06 the 24-hour rule through the integration', () => {
  it('refuses cancel and reschedule inside 24 h, allows outside, with an inclusive boundary', async () => {
    const p = await linkedPatient();
    const soon = (await book(p.tg, 'periodontics', dayOffset(0), 4)).body.data; // today 22:00, 12 h away
    const c = await integ('POST', `/telegram/${p.tg}/appointments/${soon.id}/cancel`, {});
    expect(c.status).toBe(422);
    expect(c.body.error.code).toBe('WITHIN_24H_WINDOW');
    const r = await integ('POST', `/telegram/${p.tg}/appointments/${soon.id}/reschedule`, { date: dayOffset(5), slotNumber: 1 });
    expect(r.body.error.code).toBe('WITHIN_24H_WINDOW');
    expect((await env.db.query('SELECT status, slot_number, rescheduled_count FROM appointments WHERE id = $1', [soon.id])).rows[0]).toEqual({ status: 'booked', slot_number: 4, rescheduled_count: 0 });
    expect((await integ('GET', `/telegram/${p.tg}/appointments`)).body.data[0].selfService).toMatchObject({ canCancel: false, blockedReason: 'WITHIN_24H_WINDOW' });

    // Tuesday 16:00 Cairo = 14:00Z. Exactly 24 h before is the last allowed instant.
    const target = (await book(p.tg, 'periodontics', dayOffset(1), 1)).body.data;
    env.clock.set('2026-11-02T14:00:00Z');
    const okAtBoundary = await integ('POST', `/telegram/${p.tg}/appointments/${target.id}/reschedule`, { date: dayOffset(4), slotNumber: 2 });
    expect(okAtBoundary.status, JSON.stringify(okAtBoundary.body)).toBe(200);
    expect(okAtBoundary.body.data).toMatchObject({ date: dayOffset(4), slotNumber: 2, rescheduledCount: 1 });
    const second = (await book(p.tg, 'periodontics', dayOffset(1), 1)).body.data;
    env.clock.set('2026-11-02T14:00:00.001Z');
    expect((await integ('POST', `/telegram/${p.tg}/appointments/${second.id}/cancel`, {})).body.error.code).toBe('WITHIN_24H_WINDOW');
    env.clock.set('2026-11-02T14:00:00Z');
    const cancelled = await integ('POST', `/telegram/${p.tg}/appointments/${second.id}/cancel`, {});
    expect(cancelled.status).toBe(200);
    expect(cancelled.body.data).toMatchObject({ status: 'cancelled', cancelledBy: 'telegram' });
    expect((await integ('POST', `/telegram/${p.tg}/appointments/${second.id}/cancel`, {})).body.error.code).toBe('APPOINTMENT_NOT_ACTIVE');
    // a cancelled slot is released for anyone, on the website too
    const again = await env.api.post('/api/v1/patient/appointments', { departmentId: await departmentId(env, 'periodontics'), date: dayOffset(1), slotNumber: 1 }, (await registerPatient(env)).session);
    expect(again.status).toBe(201);
  });
});

describe('INT-07 website and Telegram compete for the same capacity', () => {
  it('a race for the same slot between a website patient and a Telegram patient has exactly one winner', async () => {
    const web = await registerPatient(env);
    const tg = await linkedPatient();
    const dept = await departmentId(env, 'prosthodontics');
    const date = dayOffset(10);
    const [a, b] = await Promise.all([
      env.api.post('/api/v1/patient/appointments', { departmentId: dept, date, slotNumber: 2 }, web.session),
      book(tg.tg, 'prosthodontics', date, 2),
    ]);
    expect([a.status, b.status].sort()).toEqual([201, 409]);
    expect([a, b].find((r) => r.status === 409)!.body.error.code).toBe('SLOT_UNAVAILABLE');
    expect(Number((await env.db.query("SELECT count(*) AS n FROM appointments WHERE department_id = $1 AND appointment_date = $2 AND slot_number = 2 AND status = 'booked'", [dept, date])).rows[0].n)).toBe(1);
  });

  it('mixed channels share the 4-per-day capacity: two from each, then the day is full for both', async () => {
    const dept = await departmentId(env, 'pediatric-dentistry');
    const date = dayOffset(11);
    const web = () => registerPatient(env);
    expect((await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date, slotNumber: 1 }, (await web()).session)).status).toBe(201);
    expect((await book((await linkedPatient()).tg, 'pediatric-dentistry', date, 2)).status).toBe(201);
    expect((await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date, slotNumber: 3 }, (await web()).session)).status).toBe(201);
    expect((await book((await linkedPatient()).tg, 'pediatric-dentistry', date, 4)).status).toBe(201);
    const full = await integ('GET', `/availability?department=pediatric-dentistry&from=${date}&to=${date}`);
    expect(full.body.data.days[0]).toMatchObject({ status: 'full', availableCount: 0 });
    expect((await env.api.get(`/api/v1/public/departments/pediatric-dentistry/availability?from=${date}&to=${date}`)).body.data.days[0].status).toBe('full');
    const fifthWeb = await env.api.post('/api/v1/patient/appointments', { departmentId: dept, date, slotNumber: 1 }, (await web()).session);
    const fifthTg = await book((await linkedPatient()).tg, 'pediatric-dentistry', date, 1);
    expect(fifthWeb.status).toBe(409);
    expect(fifthTg.status).toBe(409);
  });

  it('many simultaneous Telegram and website bookings never exceed capacity (20 contenders, 4 seats)', async () => {
    const dept = await departmentId(env, 'endodontics');
    const date = dayOffset(12);
    const contenders = await Promise.all(Array.from({ length: 20 }, async (_, i) => (i % 2 === 0 ? { web: await registerPatient(env) } : { tg: await linkedPatient() })));
    const results = await Promise.all(contenders.map((c, i) => {
      const slot = (i % 4) + 1;
      return 'web' in c && c.web
        ? env.api.post('/api/v1/patient/appointments', { departmentId: dept, date, slotNumber: slot }, c.web.session)
        : book(c.tg!.tg, 'endodontics', date, slot);
    }));
    expect(results.filter((r) => r.status === 201).length).toBe(4);
    expect(results.filter((r) => r.status === 409).length).toBe(16);
    const rows = (await env.db.query("SELECT slot_number FROM appointments WHERE department_id = $1 AND appointment_date = $2 AND status = 'booked' ORDER BY 1", [dept, date])).rows;
    expect(rows.map((r: any) => r.slot_number)).toEqual([1, 2, 3, 4]);
  });
});

describe('INT-08 revoking a link takes effect immediately', () => {
  it('the patient unlinking from the website blocks the bot at once', async () => {
    const p = await linkedPatient();
    expect((await integ('GET', `/telegram/${p.tg}/appointments`)).status).toBe(200);
    expect((await env.api.del('/api/v1/patient/telegram', p.session)).status).toBe(204);
    expect((await integ('GET', `/telegram/${p.tg}/appointments`)).body.error.code).toBe('TELEGRAM_NOT_LINKED');
    expect((await book(p.tg, 'restorative-dentistry', dayOffset(9), 1)).body.error.code).toBe('TELEGRAM_NOT_LINKED');
    expect((await integ('GET', `/telegram/${p.tg}/status`)).body.data.linked).toBe(false);
  });

  it('an admin revoking blocks the bot, a /unlink from the bot is idempotent, and relinking works again', async () => {
    const p = await linkedPatient();
    expect((await env.api.post(`/api/v1/admin/patients/${p.id}/telegram/revoke`, {}, admin)).status).toBe(204);
    expect((await integ('GET', `/telegram/${p.tg}/appointments`)).status).toBe(403);
    const q = await linkedPatient();
    expect((await integ('DELETE', `/telegram/${q.tg}/link`)).status).toBe(204);
    expect((await integ('DELETE', `/telegram/${q.tg}/link`)).status).toBe(204); // already gone: still fine
    expect((await integ('DELETE', `/telegram/${nextTg()}/link`)).status).toBe(204); // never linked: nothing leaks
    expect((await integ('GET', `/telegram/${q.tg}/appointments`)).status).toBe(403);
    const code = (await env.api.post('/api/v1/patient/telegram/link-token', {}, q.session)).body.data.code;
    expect((await integ('POST', '/telegram/link', { code, telegramUserId: q.tg })).status).toBe(200);
    expect((await integ('GET', `/telegram/${q.tg}/appointments`)).status).toBe(200);
    const actions = (await env.db.query("SELECT action FROM audit_events WHERE action LIKE 'telegram.%'")).rows.map((r: any) => r.action);
    expect(actions).toEqual(expect.arrayContaining(['telegram.link_token_created', 'telegram.linked', 'telegram.link_revoked']));
  });

  it('deactivating the patient also stops the bot, and reactivating restores it without a new code', async () => {
    const p = await linkedPatient();
    await env.api.patch(`/api/v1/admin/patients/${p.id}`, { isActive: false }, admin);
    expect((await integ('GET', `/telegram/${p.tg}/appointments`)).body.error.code).toBe('TELEGRAM_NOT_LINKED');
    await env.api.patch(`/api/v1/admin/patients/${p.id}`, { isActive: true }, admin);
    expect((await integ('GET', `/telegram/${p.tg}/appointments`)).status).toBe(200);
  });
});

describe('INT-09 the integration key is confined to the integration API', () => {
  it('cannot reach admin, patient-session or medical-record routes, and sessions cannot reach integration routes', async () => {
    const p = await registerPatient(env);
    const bearer = { authorization: `Bearer ${INTEGRATION_KEY}` };
    for (const [m, u] of [
      ['GET', '/api/v1/admin/patients'], ['GET', '/api/v1/admin/audit-events'], ['GET', '/api/v1/admin/dashboard'], ['POST', '/api/v1/admin/departments'],
      ['GET', '/api/v1/admin/medical-records/00000000-0000-4000-8000-000000000001'], ['GET', '/api/v1/patient/me'], ['GET', '/api/v1/patient/appointments'],
      ['POST', '/api/v1/patient/telegram/link-token'],
    ] as const) {
      const r = await env.api.request(m, u, { headers: bearer, body: m === 'POST' ? {} : undefined });
      expect(r.status, `${m} ${u}`).toBe(401);
    }
    const asAdmin = await env.api.get('/api/v1/integrations/center', admin);
    const asPatient = await env.api.get('/api/v1/integrations/center', p.session);
    expect(asAdmin.status).toBe(401); expect(asAdmin.body.error.code).toBe('INVALID_INTEGRATION_KEY');
    expect(asPatient.status).toBe(401);
    // no integration route is shaped like an admin / medical / password route
    const routes = routeRegistry.filter((r) => r.url.startsWith('/api/v1/integrations'));
    expect(routes.length).toBeGreaterThanOrEqual(11);
    for (const r of routes) {
      expect(r.auth, r.url).toBe('integration');
      expect(r.url).not.toMatch(/admin|medical|password|session|audit/i);
    }
    // and the reverse: nothing outside that group accepts the integration key
    for (const r of routeRegistry.filter((x) => !x.url.startsWith('/api/v1/integrations'))) expect(r.auth, r.url).not.toBe('integration');
  });

  it('no integration response ever exposes password hashes, session tokens, other patients or clinical data', async () => {
    const p = await linkedPatient({ fullName: 'Hidden Name Hamza' });
    await env.api.post(`/api/v1/admin/patients/${p.id}/medical-records`, { diagnosis: 'INT-SECRET-DIAGNOSIS', allergies: 'INT-SECRET-ALLERGY' }, admin);
    const b = await book(p.tg, 'restorative-dentistry', dayOffset(13), 1);
    const dump = JSON.stringify([
      b.body, (await integ('GET', `/telegram/${p.tg}/appointments?scope=all`)).body, (await integ('GET', '/center')).body, (await integ('GET', '/departments')).body,
      (await integ('GET', `/telegram/${p.tg}/status`)).body,
    ]);
    for (const needle of ['INT-SECRET', 'Hidden Name', p.phone, p.password, 'argon2', 'password_hash', 'token_hash', ADMIN_USER]) expect(dump, needle).not.toContain(needle);
  });
});
