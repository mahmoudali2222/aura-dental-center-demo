import { createRequire } from 'node:module';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import {
  BASE_NOW, INTEGRATION_KEY, createTestEnv, dayOffset, registerPatient, type TestEnv,
} from '../helpers/harness.js';

/**
 * The exported n8n Telegram workflow, executed node by node (its REAL embedded Code nodes, its expressions and its wiring)
 * against the REAL backend and PostgreSQL. Only two things are replaced: the Telegram transport (updates come in as
 * objects, replies are captured) and the HTTP transport (requests are injected into the Fastify app instead of the network).
 * It does not prove that n8n itself accepts the file; that is covered by the import test run against a real n8n.
 */
const require = createRequire(import.meta.url);
const { runWorkflow } = require('../../../integrations/n8n/test/helpers/simulate.cjs') as {
  runWorkflow: (wf: unknown, start: string, json: unknown, env: Record<string, unknown>) => Promise<{ sent: { chatId: number; text: string }[]; last: unknown }>;
};
const TG = require('../../../integrations/n8n/workflows/dental-center-telegram-commands.workflow.json') as unknown;

const BASE_URL = 'http://host.docker.internal:8480/api/v1/integrations';
let env: TestEnv;
let tgCounter = 810_000_000;
const nextTg = () => ++tgCounter;
const state: Record<string, unknown> = {};

beforeAll(async () => {
  env = await createTestEnv({ SESSION_PATIENT_IDLE_MINUTES: '1000000', SESSION_PATIENT_TTL_HOURS: '100000' });
});
afterAll(async () => { await env.close(); });
beforeEach(() => { env.clock.set(BASE_NOW); });

/** HTTP layer for the simulator: the same method/URL/body n8n would send, answered by the real app. */
const http = (key: string | null = INTEGRATION_KEY) => async (req: { method: string; url: string; body?: unknown }) => {
  expect(req.url.startsWith(BASE_URL)).toBe(true);
  const path = req.url.slice('http://host.docker.internal:8480'.length);
  const headers: Record<string, string> = {};
  if (key) headers.authorization = `Bearer ${key}`;
  const r = await env.api.request(req.method, path, { headers, body: req.body });
  return { statusCode: r.status, headers: {}, body: r.body ?? '' };
};

/** One Telegram message from a private chat, through the whole workflow. Returns what the bot would have sent. */
async function say(tg: number, text: string, opts: { key?: string | null; lang?: string } = {}): Promise<string> {
  const update = { update_id: 1, message: { message_id: 1, from: { id: tg, is_bot: false, first_name: 'P', language_code: opts.lang ?? 'en' }, chat: { id: tg, type: 'private' }, date: 0, text } };
  const run = await runWorkflow(TG, 'Telegram Trigger', update, { http: http(opts.key === undefined ? INTEGRATION_KEY : opts.key), staticData: state });
  expect(run.sent, `bot reply count for "${text}"`).toHaveLength(1);
  expect(run.sent[0]!.chatId).toBe(tg);
  return run.sent[0]!.text;
}

async function linkTelegram(tg: number) {
  const p = await registerPatient(env);
  const token = await env.api.post('/api/v1/patient/telegram/link-token', {}, p.session);
  expect(token.status).toBe(201);
  const reply = await say(tg, `/link ${token.body.data.code}`);
  expect(reply).toMatch(/now linked/);
  return p;
}

describe('N8N-E2E public information comes from the API, not from the workflow', () => {
  it('/info shows the configured address and hours, /departments and /slots list real data', async () => {
    const tg = nextTg();
    await env.api.request('GET', '/api/v1/health'); // sanity: app is up
    const info = await say(tg, '/info');
    expect(info).toMatch(/16:00-18:00, 18:00-20:00, 20:00-22:00, 22:00-00:00/);
    expect(info).toMatch(/Africa\/Cairo/);
    const center = (await env.api.integration('GET', '/center')).body.data;
    if (center.addressConfigured) expect(info).toContain(center.address);
    else expect(info).toMatch(/Address: not available yet/);

    const depts = await say(tg, '/departments');
    expect(depts).toMatch(/1\. .*\[[a-z-]+\]/);
    expect(depts).toMatch(/Endodontics \[endodontics\]/);

    const slots = await say(tg, `/slots endodontics ${dayOffset(3)}`);
    expect(slots).toContain(dayOffset(3));
    expect(slots).toMatch(/1\) 16:00-18:00, 2\) 18:00-20:00, 3\) 20:00-22:00, 4\) 22:00-00:00/);
    expect(await say(tg, '/slots nonexistent-dept')).toMatch(/could not find that department/i);
  });
});

describe('N8N-E2E personal operations', () => {
  it('an unlinked Telegram account cannot see or change anything and is told how to link', async () => {
    const tg = nextTg();
    for (const t of ['/my', '/book endodontics ' + dayOffset(3) + ' 1']) expect(await say(tg, t)).toMatch(/not linked.*\/link YOUR-CODE/s);
    expect(await say(tg, '/link ZZZZ-ZZZZ-ZZZZ')).toMatch(/invalid or has expired/);
  });

  it('link -> book -> list -> reschedule -> cancel works, and every state change really happened in the database', async () => {
    const tg = nextTg();
    const p = await linkTelegram(tg);
    const date = dayOffset(5);

    const booked = await say(tg, `/book endodontics ${date} 2`);
    expect(booked).toMatch(new RegExp(`^Booked: Endodontics - ${date} 18:00-20:00`));
    const row = (await env.db.query('SELECT status, created_via, slot_number FROM appointments WHERE patient_id = $1', [p.id])).rows;
    expect(row).toEqual([{ status: 'booked', created_via: 'telegram', slot_number: 2 }]);

    const mine = await say(tg, '/my');
    expect(mine).toMatch(new RegExp(`^Your upcoming appointments:\\n1\\. Endodontics - ${date} 18:00-20:00`));

    const moved = await say(tg, `/reschedule 1 ${dayOffset(6)} 3`);
    expect(moved).toMatch(new RegExp(`Moved: Endodontics is now ${dayOffset(6)} 20:00-22:00`));
    expect((await env.db.query('SELECT slot_number, appointment_date::text AS d FROM appointments WHERE patient_id = $1', [p.id])).rows).toEqual([{ slot_number: 3, d: dayOffset(6) }]);

    expect(await say(tg, '/cancel 1')).toMatch(new RegExp(`^Cancelled: Endodontics - ${dayOffset(6)} 20:00-22:00`));
    const after = (await env.db.query('SELECT status, cancelled_by FROM appointments WHERE patient_id = $1', [p.id])).rows;
    expect(after).toEqual([{ status: 'cancelled', cancelled_by: 'telegram' }]);
    expect(await say(tg, '/my')).toMatch(/no upcoming appointments/);
  });

  it('a slot that is already taken is refused honestly and nothing is created', async () => {
    const date = dayOffset(7);
    const a = nextTg(); const b = nextTg();
    await linkTelegram(a); const pb = await linkTelegram(b);
    expect(await say(a, `/book orthodontics ${date} 1`)).toMatch(/^Booked:/);
    const refused = await say(b, `/book orthodontics ${date} 1`);
    expect(refused).not.toMatch(/Booked:/);
    expect(refused).toMatch(/no longer available|just taken|not available/i);
    expect((await env.db.query('SELECT 1 FROM appointments WHERE patient_id = $1', [pb.id])).rowCount).toBe(0);
  });

  it('the 24-hour rule is enforced by the backend for Telegram too: no cancel and no reschedule inside the window', async () => {
    const tg = nextTg();
    const p = await linkTelegram(tg);
    // BASE_NOW is 10:00 Cairo on 2026-11-02; the 18:00 slot the same evening starts in 8 hours: bookable, but not changeable by the patient
    const date = dayOffset(0);
    expect(await say(tg, `/book restorative-dentistry ${date} 2`)).toMatch(/^Booked:/);
    expect(await say(tg, '/my')).toMatch(/can no longer be changed here/);
    const cancel = await say(tg, '/cancel 1');
    expect(cancel).toMatch(/24 hours/);
    expect(cancel).not.toMatch(/^Cancelled:/);
    expect(await say(tg, `/reschedule 1 ${dayOffset(9)} 2`)).toMatch(/24 hours/);
    expect((await env.db.query('SELECT status, slot_number FROM appointments WHERE patient_id = $1', [p.id])).rows).toEqual([{ status: 'booked', slot_number: 2 }]);
  });

  it('Telegram numbers cannot be used to reach another patient\'s appointment', async () => {
    const a = nextTg(); const b = nextTg();
    const pa = await linkTelegram(a); await linkTelegram(b);
    expect(await say(a, `/book endodontics ${dayOffset(8)} 4`)).toMatch(/^Booked:/);
    expect(await say(b, '/cancel 1')).toMatch(/\/my first/); // b has no list yet
    expect(await say(b, '/my')).toMatch(/no upcoming appointments/);
    expect(await say(b, '/cancel 1')).toMatch(/\/my first|could not find/i);
    expect((await env.db.query('SELECT status FROM appointments WHERE patient_id = $1', [pa.id])).rows).toEqual([{ status: 'booked' }]);
  });

  it('/unlink revokes the link: personal commands stop working', async () => {
    const tg = nextTg();
    await linkTelegram(tg);
    expect(await say(tg, '/my')).toMatch(/no upcoming appointments/);
    expect(await say(tg, '/unlink')).toMatch(/no longer linked/);
    expect(await say(tg, '/my')).toMatch(/not linked/);
  });

  it('works in Arabic and French too', async () => {
    const tg = nextTg();
    await linkTelegram(tg);
    const ar = await say(tg, `/book endodontics ${dayOffset(10)} 2`, { lang: 'ar' });
    expect(ar).toMatch(/^تم الحجز/);
    const fr = await say(nextTg(), '/help', { lang: 'fr' });
    expect(fr).toMatch(/Je peux vous aider/);
  });
});

describe('N8N-E2E failure handling', () => {
  it('a wrong or missing integration key never produces a success message and leaks nothing internal', async () => {
    const tg = nextTg();
    for (const key of ['wrong-key-wrong-key-wrong-key-123456', null]) {
      for (const cmd of ['/info', '/my', `/book endodontics ${dayOffset(3)} 1`]) {
        const reply = await say(tg, cmd, { key });
        expect(reply).not.toMatch(/Booked:|appointments:/);
        expect(reply).not.toMatch(/INVALID_INTEGRATION_KEY|Bearer|key/i);
      }
    }
  });

  it('a backend that is down or answers garbage yields a retry message, not a fake confirmation', async () => {
    const tg = nextTg();
    for (const broken of [async () => ({ statusCode: 502, headers: {}, body: '<html>Bad Gateway</html>' }), async () => undefined, async () => ({ statusCode: 200, headers: {}, body: { unexpected: true } })]) {
      const run = await runWorkflow(TG, 'Telegram Trigger',
        { update_id: 1, message: { message_id: 1, from: { id: tg, is_bot: false, first_name: 'P', language_code: 'en' }, chat: { id: tg, type: 'private' }, date: 0, text: `/book endodontics ${dayOffset(3)} 1` } },
        { http: broken, staticData: state });
      expect(run.sent).toHaveLength(1);
      expect(run.sent[0]!.text).not.toMatch(/Booked:/);
    }
  });

  it('group chats get no reply and trigger no backend call', async () => {
    const before = (await env.db.query('SELECT count(*)::int AS n FROM audit_events')).rows[0].n;
    const run = await runWorkflow(TG, 'Telegram Trigger',
      { update_id: 1, message: { message_id: 1, from: { id: nextTg(), is_bot: false, first_name: 'P' }, chat: { id: -100123, type: 'supergroup' }, date: 0, text: '/my' } },
      { http: http(), staticData: state });
    expect(run.sent).toHaveLength(0);
    expect((await env.db.query('SELECT count(*)::int AS n FROM audit_events')).rows[0].n).toBe(before);
  });
});
