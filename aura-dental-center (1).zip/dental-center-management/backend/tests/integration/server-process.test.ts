import { spawn, spawnSync, type ChildProcess } from 'node:child_process';
import { createServer } from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import pg from 'pg';
import { ADMIN_URL, createTestDatabase } from '../helpers/harness.js';

const backendDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const tsx = path.join(backendDir, 'node_modules', '.bin', 'tsx');
const baseEnv = { PATH: process.env.PATH ?? '', HOME: process.env.HOME ?? '' };

const freePort = () => new Promise<number>((resolve, reject) => {
  const s = createServer();
  s.listen(0, '127.0.0.1', () => { const { port } = s.address() as { port: number }; s.close(() => resolve(port)); });
  s.on('error', reject);
});
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

describe('OPS the real server process', () => {
  let db: Awaited<ReturnType<typeof createTestDatabase>>;
  const children: ChildProcess[] = [];
  beforeAll(async () => { db = await createTestDatabase(); });
  afterAll(async () => { for (const c of children) c.kill('SIGKILL'); await db.drop(); });

  function start(env: Record<string, string>) {
    const child = spawn(tsx, ['src/server.ts'], { cwd: backendDir, env: { ...baseEnv, ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
    children.push(child);
    let out = '';
    child.stdout!.on('data', (d) => { out += d; });
    child.stderr!.on('data', (d) => { out += d; });
    const exited = new Promise<number | null>((resolve) => child.on('exit', (code) => resolve(code)));
    return { child, exited, output: () => out };
  }
  async function waitHealthy(port: number, exited: Promise<unknown>) {
    let dead = false; void exited.then(() => { dead = true; });
    for (let i = 0; i < 100 && !dead; i++) {
      try { const r = await fetch(`http://127.0.0.1:${port}/api/health`); if (r.ok) return; } catch { /* not up yet */ }
      await sleep(150);
    }
    throw new Error('server did not become healthy');
  }

  it('exits non-zero with a clear message, and no secret, when the configuration is invalid (production)', () => {
    const run = (env: Record<string, string>) => spawnSync(tsx, ['src/server.ts'], { cwd: backendDir, encoding: 'utf8', timeout: 60_000, env: { ...baseEnv, NODE_ENV: 'production', ...env } });
    const schema = run({ DATABASE_URL: 'mysql://user:TopSecretDbPassword@db/app', PUBLIC_APP_URL: 'https://clinic.example.com', INTEGRATION_API_KEY: 'tiny-secret-key' });
    expect(schema.status).toBe(1);
    const t1 = `${schema.stdout}${schema.stderr}`;
    expect(t1).toMatch(/Invalid configuration/);
    expect(t1).toMatch(/DATABASE_URL/);
    expect(t1).toMatch(/INTEGRATION_API_KEY/);
    for (const secret of ['TopSecretDbPassword', 'tiny-secret-key']) expect(t1).not.toContain(secret);
    const semantic = run({ DATABASE_URL: 'postgres://user:AnotherSecretPw@db/app', PUBLIC_APP_URL: 'http://clinic.example.com' });
    expect(semantic.status).toBe(1);
    const t2 = `${semantic.stdout}${semantic.stderr}`;
    expect(t2).toMatch(/PUBLIC_APP_URL must use https/);
    expect(t2).not.toContain('AnotherSecretPw');
    const empty = run({});
    expect(empty.status).toBe(1);
    expect(`${empty.stdout}${empty.stderr}`).toMatch(/DATABASE_URL/);
  }, 120_000);

  it('with an unreachable database it stays alive but not ready, and API errors are generic (no connection details)', async () => {
    const port = await freePort();
    const s = start({ NODE_ENV: 'production', HOST: '127.0.0.1', PORT: String(port), DATABASE_URL: 'postgres://nobody:nopw-secret@127.0.0.1:1/none', PUBLIC_APP_URL: `http://localhost:${port}`, COOKIE_SECURE: 'false' });
    try {
      await waitHealthy(port, s.exited);
      const base = `http://127.0.0.1:${port}`;
      const ready = await fetch(`${base}/api/ready`);
      expect(ready.status).toBe(503);
      expect(await ready.json()).toEqual({ status: 'not_ready', reason: 'database unavailable' });
      const api = await fetch(`${base}/api/v1/public/center`);
      expect(api.status).toBe(500);
      const body = await api.text();
      expect(JSON.parse(body)).toEqual({ error: { code: 'INTERNAL_ERROR', message: 'Something went wrong' } });
      await sleep(200);
      expect(s.output()).not.toContain('nopw-secret');
    } finally { s.child.kill('SIGKILL'); }
  }, 120_000);

  it('a reachable but not-yet-migrated database is not ready (so Docker waits for the migrate step)', async () => {
    const name = `dc_empty_${Date.now().toString(36)}`;
    const admin = new pg.Client({ connectionString: ADMIN_URL });
    await admin.connect(); await admin.query(`CREATE DATABASE ${name}`); await admin.end();
    const u = new URL(ADMIN_URL); u.pathname = `/${name}`;
    const port = await freePort();
    const s = start({ NODE_ENV: 'production', HOST: '127.0.0.1', PORT: String(port), DATABASE_URL: u.toString(), PUBLIC_APP_URL: `http://localhost:${port}`, COOKIE_SECURE: 'false' });
    try {
      await waitHealthy(port, s.exited);
      expect((await fetch(`http://127.0.0.1:${port}/api/ready`)).status).toBe(503);
    } finally {
      s.child.kill('SIGKILL');
      await s.exited;
      const a2 = new pg.Client({ connectionString: ADMIN_URL });
      await a2.connect(); await a2.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`); await a2.end();
    }
  }, 120_000);

  it('boots, reports health and readiness, serves the API, and shuts down gracefully on SIGTERM', async () => {
    const port = await freePort();
    const s = start({ NODE_ENV: 'production', HOST: '127.0.0.1', PORT: String(port), DATABASE_URL: db.url, PUBLIC_APP_URL: `http://localhost:${port}`, COOKIE_SECURE: 'false', LOG_LEVEL: 'info' });
    await waitHealthy(port, s.exited);
    const base = `http://127.0.0.1:${port}`;
    expect((await (await fetch(`${base}/api/health`)).json())).toMatchObject({ status: 'ok' });
    const ready = await fetch(`${base}/api/ready`);
    expect(ready.status).toBe(200);
    const center = await (await fetch(`${base}/api/v1/public/center?locale=en`)).json() as any;
    expect(center.data).toMatchObject({ timezone: 'Africa/Cairo', addressConfigured: false });
    // the integration API is closed without a key and says so
    const integ = await fetch(`${base}/api/v1/integrations/center`);
    expect(integ.status).toBe(503);
    // security headers and no technology disclosure
    const h = (await fetch(`${base}/api/v1/public/center`)).headers;
    expect(h.get('x-content-type-options')).toBe('nosniff');
    expect(h.get('x-powered-by')).toBeNull();
    expect(s.output()).toContain('INTEGRATION_API_KEY is not set');
    s.child.kill('SIGTERM');
    expect(await Promise.race([s.exited, sleep(15_000).then(() => 'timeout')])).toBe(0);
    expect(s.output()).toContain('shutting down');
  }, 120_000);

  it('reports not-ready (503) when the database goes away, without leaking connection details', async () => {
    const own = await createTestDatabase();
    const port = await freePort();
    const s = start({ NODE_ENV: 'production', HOST: '127.0.0.1', PORT: String(port), DATABASE_URL: own.url, PUBLIC_APP_URL: `http://localhost:${port}`, COOKIE_SECURE: 'false' });
    try {
      await waitHealthy(port, s.exited);
      expect((await fetch(`http://127.0.0.1:${port}/api/ready`)).status).toBe(200);
      await own.drop(); // WITH (FORCE) terminates the server's connections
      let status = 0; let body = '';
      for (let i = 0; i < 20 && status !== 503; i++) { const r = await fetch(`http://127.0.0.1:${port}/api/ready`); status = r.status; body = await r.text(); await sleep(200); }
      expect(status).toBe(503);
      expect(body).not.toMatch(/postgres|password|127\.0\.0\.1:\d+|dc_test/i);
      expect((await fetch(`http://127.0.0.1:${port}/api/health`)).status).toBe(200); // liveness is independent of the DB
    } finally { s.child.kill('SIGKILL'); }
  }, 120_000);
});
