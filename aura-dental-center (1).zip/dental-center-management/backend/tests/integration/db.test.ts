import { randomBytes } from 'node:crypto';
import { access, cp, mkdtemp, readFile, rm, writeFile, appendFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import pg from 'pg';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { ADMIN_URL, createTestEnv, departmentId, registerPatient, type TestEnv } from '../helpers/harness.js';
import { DEFAULT_MIGRATIONS_DIR, migrate } from '../../src/database/migrate.js';
import { seedCatalog } from '../../src/database/seed.js';
import { pgConstraint, pgErrorCode } from '../../src/database/pool.js';
import { imagePathSchema } from '../../src/lib/validation.js';

/** An empty database (no migrations applied). */
async function emptyDatabase() {
  const name = `dc_mig_${randomBytes(5).toString('hex')}`;
  const admin = new pg.Client({ connectionString: ADMIN_URL });
  await admin.connect();
  await admin.query(`CREATE DATABASE ${name}`);
  await admin.end();
  const u = new URL(ADMIN_URL);
  u.pathname = `/${name}`;
  return {
    url: u.toString(),
    drop: async () => {
      const c = new pg.Client({ connectionString: ADMIN_URL });
      await c.connect();
      await c.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`);
      await c.end();
    },
  };
}

async function oneShot<T extends pg.QueryResultRow = any>(url: string, sql: string, params: unknown[] = []) {
  const c = new pg.Client({ connectionString: url });
  await c.connect();
  try { return await c.query<T>(sql, params); } finally { await c.end(); }
}

const ALL_MIGRATIONS = ['0001_init.sql', '0002_reference_data.sql', '0003_department_working_days_and_seven_departments.sql'];

describe('DB-01 migrations', () => {
  const dbs: { drop: () => Promise<void> }[] = [];
  const dirs: string[] = [];
  afterAll(async () => { for (const d of dbs) await d.drop(); for (const d of dirs) await rm(d, { recursive: true, force: true }); });
  const fresh = async () => { const d = await emptyDatabase(); dbs.push(d); return d; };
  const copyOfMigrations = async () => { const d = await mkdtemp(path.join(tmpdir(), 'dc-migrations-')); dirs.push(d); await cp(DEFAULT_MIGRATIONS_DIR, d, { recursive: true }); return d; };

  it('applies to an empty database, records checksums, and a re-run is a no-op', async () => {
    const db = await fresh();
    const first = await migrate(db.url);
    expect(first.applied).toEqual(ALL_MIGRATIONS);
    const again = await migrate(db.url);
    expect(again).toEqual({ applied: [], alreadyApplied: ALL_MIGRATIONS.length });
    const rows = (await oneShot(db.url, 'SELECT version, checksum FROM schema_migrations ORDER BY version')).rows;
    expect(rows.map((r) => r.version)).toEqual(ALL_MIGRATIONS);
    for (const r of rows) expect(r.checksum).toMatch(/^[0-9a-f]{64}$/);
    // reference data from 0002 is present; business content (departments) is not part of migrations
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM slot_templates')).rows[0].n)).toBe(4);
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM departments')).rows[0].n)).toBe(0);
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM admin_users')).rows[0].n)).toBe(0); // no default admin, ever
  });

  it('refuses to run when an already-applied migration file was edited', async () => {
    const db = await fresh();
    const dir = await copyOfMigrations();
    await migrate(db.url, dir);
    await appendFile(path.join(dir, '0001_init.sql'), '\n-- sneaky edit\n');
    await expect(migrate(db.url, dir)).rejects.toThrow(/0001_init\.sql was modified after being applied/);
  });

  it('rolls a failing migration back completely, then applies it once fixed', async () => {
    const db = await fresh();
    const dir = await copyOfMigrations();
    const bad = path.join(dir, '0004_broken.sql');
    await writeFile(bad, 'CREATE TABLE zz_partial (id int);\nINSERT INTO zz_partial VALUES (1);\nSELECT 1/0;\n');
    await expect(migrate(db.url, dir)).rejects.toThrow(/0004_broken\.sql failed and was rolled back/);
    expect((await oneShot(db.url, "SELECT to_regclass('public.zz_partial') AS t")).rows[0].t).toBeNull();
    expect((await oneShot(db.url, "SELECT count(*)::int AS n FROM schema_migrations WHERE version = '0004_broken.sql'")).rows[0].n).toBe(0);
    expect((await oneShot(db.url, 'SELECT count(*)::int AS n FROM schema_migrations')).rows[0].n).toBe(ALL_MIGRATIONS.length); // earlier ones stay applied
    await writeFile(bad, 'CREATE TABLE zz_fixed (id int);\n');
    expect((await migrate(db.url, dir)).applied).toEqual(['0004_broken.sql']);
    expect((await oneShot(db.url, "SELECT to_regclass('public.zz_fixed') AS t")).rows[0].t).toBe('zz_fixed');
  });

  it('two migrators started at the same time apply each migration exactly once and neither fails', async () => {
    const db = await fresh();
    const [a, b] = await Promise.all([migrate(db.url), migrate(db.url)]);
    expect([...a.applied, ...b.applied].sort()).toEqual(ALL_MIGRATIONS);
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM schema_migrations')).rows[0].n)).toBe(ALL_MIGRATIONS.length);
  });

  it('ignores files that are not numbered migrations', async () => {
    const db = await fresh();
    const dir = await copyOfMigrations();
    await writeFile(path.join(dir, 'README.md'), '# not sql');
    await writeFile(path.join(dir, 'draft.sql'), 'DROP TABLE everything;');
    await writeFile(path.join(dir, '0009_Bad Name.sql'), 'DROP TABLE everything;');
    expect((await migrate(db.url, dir)).applied).toEqual(ALL_MIGRATIONS);
  });

  it('migration files never contain destructive statements (forward-only, data-preserving)', async () => {
    for (const f of ['0001_init.sql', '0002_reference_data.sql']) {
      const sql = (await readFile(path.join(DEFAULT_MIGRATIONS_DIR, f), 'utf8')).replace(/--.*$/gm, '');
      // only statements count: `BEFORE TRUNCATE ON audit_events` (the trigger that forbids truncation) is fine
      expect(sql, f).not.toMatch(/(^|;)\s*DROP\s+(TABLE|DATABASE|SCHEMA|COLUMN)\b/im);
      expect(sql, f).not.toMatch(/(^|;)\s*(TRUNCATE|DELETE\s+FROM)\b/im);
      expect(sql, f).not.toMatch(/(^|;)\s*ALTER\s+TABLE\s+\w+\s+DROP\b/im);
    }
  });
});

describe('DB-02 seed', () => {
  let env: TestEnv;
  beforeAll(async () => { env = await createTestEnv(); });
  afterAll(async () => { await env.close(); });
  const counts = async () => (await env.db.query(
    `SELECT (SELECT count(*) FROM departments)::int AS departments, (SELECT count(*) FROM department_translations)::int AS dept_tr,
            (SELECT count(*) FROM dentists)::int AS dentists, (SELECT count(*) FROM dentist_translations)::int AS dentist_tr,
            (SELECT count(*) FROM services)::int AS services, (SELECT count(*) FROM service_translations)::int AS service_tr`)).rows[0];

  it('is idempotent: running it again changes nothing', async () => {
    const before = await counts();
    expect(before).toMatchObject({ departments: 7, dept_tr: 21, dentists: 7, dentist_tr: 21, services: 14, service_tr: 42 });
    const result = await seedCatalog(env.databaseUrl);
    expect(result).toEqual({ departmentsInserted: 0, departmentsSkipped: 7 });
    expect(await counts()).toEqual(before);
  });

  it("never overwrites what the admin edited, and does not resurrect deleted sample content", async () => {
    await env.db.query("UPDATE department_translations SET name = 'My own name' WHERE locale = 'en' AND department_id = (SELECT id FROM departments WHERE slug = 'endodontics')");
    await env.db.query("INSERT INTO center_profile_translations (locale, name) VALUES ('en', 'My Clinic') ON CONFLICT (locale) DO UPDATE SET name = 'My Clinic'");
    const sampleSvc = (await env.db.query("SELECT id FROM services WHERE department_id = (SELECT id FROM departments WHERE slug = 'endodontics') LIMIT 1")).rows[0].id;
    await env.db.query('DELETE FROM services WHERE id = $1', [sampleSvc]);
    await seedCatalog(env.databaseUrl);
    expect((await env.db.query("SELECT name FROM department_translations WHERE locale = 'en' AND department_id = (SELECT id FROM departments WHERE slug = 'endodontics')")).rows[0].name).toBe('My own name');
    expect((await env.db.query("SELECT name FROM center_profile_translations WHERE locale = 'en'")).rows[0].name).toBe('My Clinic');
    expect((await env.db.query('SELECT count(*)::int AS n FROM services')).rows[0].n).toBe(13);
  });

  it('gives each of the seven departments its supplied picture, and every path is valid and points at a file that ships with the site', async () => {
    const rows = (await env.db.query('SELECT slug, image_path FROM departments ORDER BY display_order')).rows as { slug: string; image_path: string | null }[];
    expect(rows).toHaveLength(7);
    const assets = path.join(DEFAULT_MIGRATIONS_DIR, '..', '..', 'frontend', 'public');
    for (const r of rows) {
      expect(r.image_path, r.slug).toBe(`/assets/departments/${r.slug}-before-after.jpg`);
      expect(imagePathSchema.safeParse(r.image_path).success, r.slug).toBe(true);
      await expect(access(path.join(assets, r.image_path!)), `${r.image_path} must exist in frontend/public`).resolves.toBeUndefined();
    }
  });

  it('does not put a picture back after the administrator removed it', async () => {
    await env.db.query("UPDATE departments SET image_path = NULL WHERE slug = 'oral-surgery'");
    await seedCatalog(env.databaseUrl);
    expect((await env.db.query("SELECT image_path FROM departments WHERE slug = 'oral-surgery'")).rows[0].image_path).toBeNull();
  });

  it('contains no real people, prices, addresses or secrets: everything it creates is flagged as sample', async () => {
    expect((await env.db.query('SELECT count(*)::int AS n FROM dentists WHERE NOT is_sample')).rows[0].n).toBe(0);
    expect((await env.db.query('SELECT count(*)::int AS n FROM services WHERE NOT is_sample OR price IS NOT NULL')).rows[0].n).toBe(0);
    expect((await env.db.query("SELECT count(*)::int AS n FROM center_profile_translations WHERE address <> ''")).rows[0].n).toBe(0);
    expect((await env.db.query("SELECT count(*)::int AS n FROM center_profile WHERE coalesce(phone,'') <> '' OR coalesce(email,'') <> ''")).rows[0].n).toBe(0);
    const raw = await readFile(path.join(DEFAULT_MIGRATIONS_DIR, '..', 'seeds', 'catalog.sample.json'), 'utf8');
    expect(raw).not.toMatch(/https?:\/\/|@[a-z0-9-]+\.[a-z]{2,}|\+?\d{9,}/i);
  });
});

describe('DB-03 constraints hold even when the API is bypassed', () => {
  let env: TestEnv;
  let dept: string; let dept2: string; let patient: string; let patient2: string;
  beforeAll(async () => {
    env = await createTestEnv();
    dept = await departmentId(env, 'restorative-dentistry');
    dept2 = await departmentId(env, 'endodontics');
    patient = (await registerPatient(env)).id;
    patient2 = (await registerPatient(env)).id;
  });
  afterAll(async () => { await env.close(); });

  // 1 Dec 2026 is UTC+2 in Cairo: slot 1 = 14:00-16:00Z, slot 2 = 16:00-18:00Z ...
  const slotTimes = (n: number, date = '2026-12-01') => {
    const start = new Date(`${date}T${String(12 + 2 * n).padStart(2, '0')}:00:00Z`);
    return { start, end: new Date(start.getTime() + 2 * 3600_000) };
  };
  async function insert(o: { dept: string; patient: string; slot: number; date?: string; status?: string; start?: Date; end?: Date; cancelledAt?: Date | null }) {
    const t = slotTimes(o.slot, o.date);
    const status = o.status ?? 'booked';
    return env.db.query(
      `INSERT INTO appointments (patient_id, department_id, appointment_date, slot_number, starts_at, ends_at, status, created_via, cancelled_at, cancelled_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'admin',$8,$9) RETURNING id`,
      [o.patient, o.dept, o.date ?? '2026-12-01', o.slot, o.start ?? t.start, o.end ?? t.end, status, o.cancelledAt === undefined ? (status === 'cancelled' ? new Date() : null) : o.cancelledAt, status === 'cancelled' ? 'admin' : null],
    );
  }
  const code = async (p: Promise<unknown>) => p.then(() => 'ok', (e) => `${pgErrorCode(e)}:${pgConstraint(e) ?? ''}`);

  it('rejects a second active appointment in the same department slot, but a cancelled one does not block it', async () => {
    await insert({ dept, patient, slot: 1, date: '2026-12-01' });
    expect(await code(insert({ dept, patient: patient2, slot: 1, date: '2026-12-01' }))).toBe('23505:appointments_active_slot_uq');
    await insert({ dept, patient: patient2, slot: 1, date: '2026-12-01', status: 'cancelled' }); // history is allowed to repeat
    await insert({ dept: dept2, patient: patient2, slot: 1, date: '2026-12-01' }); // another department, same time: fine
  });

  it('rejects overlapping times in one department even under a different slot number', async () => {
    const t = slotTimes(3, '2026-12-02');
    await insert({ dept, patient, slot: 3, date: '2026-12-02' });
    const half = { start: new Date(t.start.getTime() + 3600_000), end: new Date(t.end.getTime() + 3600_000) };
    expect(await code(insert({ dept, patient: patient2, slot: 4, date: '2026-12-02', ...half }))).toBe('23P01:appointments_no_department_overlap');
  });

  it('rejects one patient in two overlapping appointments, allows back-to-back ones', async () => {
    await insert({ dept, patient, slot: 1, date: '2026-12-03' });
    expect(await code(insert({ dept: dept2, patient, slot: 1, date: '2026-12-03' }))).toBe('23P01:appointments_no_patient_overlap');
    expect(await code(insert({ dept: dept2, patient, slot: 2, date: '2026-12-03' }))).toBe('ok'); // 16:00-18:00 right after 14:00-16:00
  });

  it('rejects wrong slot numbers, durations and a cancelled status without a timestamp', async () => {
    const t = slotTimes(1, '2026-12-04');
    expect(await code(insert({ dept, patient, slot: 5 as any, date: '2026-12-04' }))).toMatch(/^23514/);
    expect(await code(insert({ dept, patient, slot: 1, date: '2026-12-04', start: t.start, end: new Date(t.start.getTime() + 3 * 3600_000) }))).toMatch(/^23514/);
    expect(await code(insert({ dept, patient, slot: 1, date: '2026-12-04', start: t.start, end: new Date(t.start.getTime() + 3600_000) }))).toMatch(/^23514/);
    expect(await code(insert({ dept, patient, slot: 1, date: '2026-12-04', status: 'cancelled', cancelledAt: null }))).toMatch(/^23514/);
    expect(await code(insert({ dept, patient, slot: 1, date: '2026-12-04', status: 'vanished' }))).toMatch(/^23514/);
  });

  it('enforces the status lifecycle; terminal appointments cannot be revived or moved', async () => {
    const id = (await insert({ dept, patient, slot: 2, date: '2026-12-05' })).rows[0].id;
    const set = (status: string, extra = '') => code(env.db.query(`UPDATE appointments SET status = $2 ${extra} WHERE id = $1`, [id, status]));
    expect(await set('booked')).toBe('ok'); // no-op
    expect(await set('no_show')).toBe('ok');
    expect(await set('booked')).toBe('23514:appointments_status_transition');
    expect(await set('completed')).toBe('ok'); // admin correction no_show -> completed
    expect(await set('booked')).toBe('23514:appointments_status_transition');
    expect(await set('cancelled', ', cancelled_at = now(), cancelled_by = \'admin\'')).toBe('23514:appointments_status_transition');
    expect(await code(env.db.query('UPDATE appointments SET slot_number = 3 WHERE id = $1', [id]))).toBe('23514:appointments_terminal_immutable');
    const c = (await insert({ dept, patient, slot: 3, date: '2026-12-05' })).rows[0].id;
    await env.db.query("UPDATE appointments SET status = 'cancelled', cancelled_at = now(), cancelled_by = 'patient' WHERE id = $1", [c]);
    expect(await code(env.db.query("UPDATE appointments SET status = 'booked', cancelled_at = NULL WHERE id = $1", [c]))).toBe('23514:appointments_status_transition');
  });

  it('keeps patients and their history: patients with appointments or medical records cannot be deleted', async () => {
    expect(await code(env.db.query('DELETE FROM patients WHERE id = $1', [patient]))).toMatch(/^23503/);
    expect(await code(env.db.query('DELETE FROM departments WHERE id = $1', [dept]))).toMatch(/^23503/);
  });

  it('validates patient identity data: unique E.164 phone, sane name', async () => {
    const ph = (await env.db.query('SELECT phone_e164 FROM patients WHERE id = $1', [patient])).rows[0].phone_e164;
    const ins = (phone: string, name = 'Valid Name') => code(env.db.query('INSERT INTO patients (phone_e164, full_name, password_hash) VALUES ($1,$2,$3)', [phone, name, 'x']));
    expect(await ins(ph)).toMatch(/^23505/);
    expect(await ins('01012345678')).toMatch(/^23514/); // not normalized
    expect(await ins('+20 101 234 5678')).toMatch(/^23514/);
    expect(await ins('+201099990000', ' ')).toMatch(/^23514/);
  });

  it('allows one active Telegram link per patient and per Telegram account; revoked ones do not count', async () => {
    const link = (p: string, tg: number, revoked = false) => code(env.db.query('INSERT INTO telegram_links (patient_id, telegram_user_id, revoked_at) VALUES ($1,$2,$3)', [p, tg, revoked ? new Date() : null]));
    expect(await link(patient, 4242)).toBe('ok');
    expect(await link(patient, 4343)).toMatch(/^23505:telegram_links_active_patient_uq/);
    expect(await link(patient2, 4242)).toMatch(/^23505:telegram_links_active_telegram_uq/);
    expect(await link(patient, 4545, true)).toBe('ok');
    expect(await link(patient2, 0 as any)).toMatch(/^23514/);
  });

  it('gallery: a real case cannot be published without consent, not even by SQL', async () => {
    const g = (kind: string, consent: boolean, published: boolean) => code(env.db.query(
      "INSERT INTO gallery_cases (department_id, before_image_path, after_image_path, case_kind, consent_confirmed, is_published) VALUES ($1,'/a.jpg','/b.jpg',$2,$3,$4)", [dept, kind, consent, published]));
    expect(await g('real', false, true)).toMatch(/^23514/);
    expect(await g('real', true, true)).toBe('ok');
    expect(await g('real', false, false)).toBe('ok');
    expect(await g('sample', false, true)).toBe('ok');
    expect(await g('other', false, false)).toMatch(/^23514/);
  });

  it('center profile is a single row; working days and horizon are bounded', async () => {
    expect(await code(env.db.query("INSERT INTO center_profile (id) VALUES (2)"))).toMatch(/^23514/);
    expect(await code(env.db.query("UPDATE center_profile SET working_days = '{}'"))).toMatch(/^23514/);
    expect(await code(env.db.query("UPDATE center_profile SET working_days = '{1,9}'"))).toMatch(/^23514/);
    expect(await code(env.db.query('UPDATE center_profile SET booking_horizon_days = 0'))).toMatch(/^23514/);
    expect(await code(env.db.query("UPDATE center_profile SET default_locale = 'de'"))).toMatch(/^23514/);
  });

  it('slot templates are fixed to two hours and cannot overlap', async () => {
    expect(await code(env.db.query("INSERT INTO slot_templates (slot_number, start_time) VALUES (5, '10:00')"))).toMatch(/^23514/);
    expect(await code(env.db.query("UPDATE slot_templates SET start_time = '16:00' WHERE slot_number = 2"))).toMatch(/^23(505|P01|514)/);
  });

  it('AUD: the audit log is append-only at database level (update, delete, truncate all refused)', async () => {
    await env.db.query("INSERT INTO audit_events (actor_type, action, outcome) VALUES ('system','test.event','success')");
    expect(await code(env.db.query("UPDATE audit_events SET action = 'tampered'"))).toMatch(/^42501/);
    expect(await code(env.db.query('DELETE FROM audit_events'))).toMatch(/^42501/);
    expect(await code(env.db.query('TRUNCATE audit_events'))).toMatch(/^42501/);
    expect(await code(env.db.query("INSERT INTO audit_events (actor_type, action, outcome) VALUES ('hacker','x','success')"))).toMatch(/^23514/);
    expect(Number((await env.db.query("SELECT count(*) AS n FROM audit_events WHERE action = 'test.event'")).rows[0].n)).toBe(1);
  });

  it('medical records reject oversized text and reference only real patients and admins', async () => {
    expect(await code(env.db.query("INSERT INTO medical_records (patient_id, diagnosis, created_by, updated_by) VALUES ($1, $2, gen_random_uuid(), gen_random_uuid())", [patient, 'x']))).toMatch(/^23503/);
    expect(await code(env.db.query("INSERT INTO medical_records (patient_id, diagnosis, created_by, updated_by) VALUES (gen_random_uuid(), 'x', gen_random_uuid(), gen_random_uuid())"))).toMatch(/^23503/);
  });
});

/**
 * Migration 0003 on a database that already has data in it: the seven kept departments stay exactly as they were, every other
 * department disappears completely, and a department that has appointments is never deleted silently.
 */
describe('DB-01b migration 0003: working days and exactly seven departments', () => {
  const KEPT = ['restorative-dentistry', 'endodontics', 'orthodontics', 'periodontics', 'pediatric-dentistry', 'prosthodontics', 'oral-surgery'];
  const dbs: { drop: () => Promise<void> }[] = [];
  const dirs: string[] = [];
  afterAll(async () => { for (const d of dbs) await d.drop(); for (const d of dirs) await rm(d, { recursive: true, force: true }); });

  /** A database migrated up to 0002 only (what an installation made before this change looks like), and the directory for the rest. */
  async function beforeThree() {
    const db = await emptyDatabase(); dbs.push(db);
    const dir = await mkdtemp(path.join(tmpdir(), 'dc-migrations-')); dirs.push(dir);
    await cp(DEFAULT_MIGRATIONS_DIR, dir, { recursive: true });
    await rm(path.join(dir, '0003_department_working_days_and_seven_departments.sql'));
    await migrate(db.url, dir);
    return db;
  }
  /** A department with everything that hangs off it. */
  async function department(url: string, slug: string) {
    const id = (await oneShot(url, "INSERT INTO departments (slug, display_order) VALUES ($1, 1) RETURNING id", [slug])).rows[0].id as string;
    await oneShot(url, "INSERT INTO department_translations (department_id, locale, name) VALUES ($1, 'en', $2)", [id, slug]);
    const dentist = (await oneShot(url, 'INSERT INTO dentists (department_id) VALUES ($1) RETURNING id', [id])).rows[0].id as string;
    await oneShot(url, "INSERT INTO dentist_translations (dentist_id, locale, display_name) VALUES ($1, 'en', 'Dr. X')", [dentist]);
    const service = (await oneShot(url, 'INSERT INTO services (department_id, price) VALUES ($1, 100) RETURNING id', [id])).rows[0].id as string;
    await oneShot(url, "INSERT INTO service_translations (service_id, locale, name) VALUES ($1, 'en', 'A service')", [service]);
    const gallery = (await oneShot(url, "INSERT INTO gallery_cases (department_id, service_id, before_image_path, after_image_path) VALUES ($1, $2, '/assets/b.jpg', '/assets/a.jpg') RETURNING id", [id, service])).rows[0].id as string;
    await oneShot(url, "INSERT INTO gallery_case_translations (case_id, locale, title) VALUES ($1, 'en', 'Case')", [gallery]);
    await oneShot(url, "INSERT INTO closures (date_from, date_to, department_id, reason) VALUES ('2027-01-01', '2027-01-02', $1, 'x')", [id]);
    return { id, dentist, service, gallery };
  }
  const count = async (url: string, table: string) => Number((await oneShot(url, `SELECT count(*) AS n FROM ${table}`)).rows[0].n);

  it('deletes every other department completely and leaves the seven kept ones untouched, with all days working', async () => {
    const db = await beforeThree();
    const kept = await department(db.url, 'endodontics');
    await oneShot(db.url, "UPDATE department_translations SET name = 'My own name' WHERE department_id = $1", [kept.id]);
    const doomedA = await department(db.url, 'general-dentistry');
    const doomedB = await department(db.url, 'cosmetic-dentistry');
    expect(await count(db.url, 'departments')).toBe(3);

    const res = await migrate(db.url);
    expect(res.applied).toEqual(['0003_department_working_days_and_seven_departments.sql']);

    expect((await oneShot(db.url, 'SELECT slug FROM departments ORDER BY slug')).rows.map((r) => r.slug)).toEqual(['endodontics']);
    // nothing of the deleted departments remains anywhere
    for (const [table, column, ids] of [
      ['department_translations', 'department_id', [doomedA.id, doomedB.id]],
      ['dentists', 'id', [doomedA.dentist, doomedB.dentist]],
      ['dentist_translations', 'dentist_id', [doomedA.dentist, doomedB.dentist]],
      ['services', 'id', [doomedA.service, doomedB.service]],
      ['service_translations', 'service_id', [doomedA.service, doomedB.service]],
      ['gallery_cases', 'id', [doomedA.gallery, doomedB.gallery]],
      ['gallery_case_translations', 'case_id', [doomedA.gallery, doomedB.gallery]],
      ['closures', 'department_id', [doomedA.id, doomedB.id]],
    ] as const) {
      expect(Number((await oneShot(db.url, `SELECT count(*) AS n FROM ${table} WHERE ${column} = ANY($1::uuid[])`, [ids])).rows[0].n), table).toBe(0);
    }
    // the kept department keeps its own content, and now works every day
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM dentists WHERE department_id = $1', [kept.id])).rows[0].n)).toBe(1);
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM services WHERE department_id = $1', [kept.id])).rows[0].n)).toBe(1);
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM gallery_cases WHERE department_id = $1', [kept.id])).rows[0].n)).toBe(1);
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM closures WHERE department_id = $1', [kept.id])).rows[0].n)).toBe(1);
    expect((await oneShot(db.url, 'SELECT name FROM department_translations WHERE department_id = $1', [kept.id])).rows[0].name).toBe('My own name');
    expect((await oneShot(db.url, 'SELECT working_days FROM departments WHERE id = $1', [kept.id])).rows[0].working_days).toEqual([1, 2, 3, 4, 5, 6, 7]);
    // each deletion is on record
    const audit = (await oneShot(db.url, "SELECT entity_id, actor_type, metadata->>'slug' AS slug FROM audit_events WHERE action = 'department.deleted' ORDER BY metadata->>'slug'")).rows;
    expect(audit.map((a) => a.slug)).toEqual(['cosmetic-dentistry', 'general-dentistry']);
    expect(audit.every((a) => a.actor_type === 'system')).toBe(true);
    // a second run has nothing left to do
    expect((await migrate(db.url)).applied).toEqual([]);
  });

  it('never deletes a kept department, whatever it contains', async () => {
    const db = await beforeThree();
    for (const slug of KEPT) await department(db.url, slug);
    await migrate(db.url);
    expect((await oneShot(db.url, 'SELECT slug FROM departments ORDER BY slug')).rows.map((r) => r.slug)).toEqual([...KEPT].sort());
    expect(await count(db.url, 'dentists')).toBe(7);
    expect(await count(db.url, 'services')).toBe(7);
    expect(await count(db.url, 'audit_events')).toBe(0);
  });

  it('refuses to delete a department that has appointments, says which one, and changes nothing at all', async () => {
    const db = await beforeThree();
    const keep = await department(db.url, 'endodontics');
    const doomedFree = await department(db.url, 'cosmetic-dentistry'); // no appointments: must NOT be deleted either, the whole migration rolls back
    const doomedBusy = await department(db.url, 'general-dentistry');
    const patient = (await oneShot(db.url, "INSERT INTO patients (phone_e164, full_name, password_hash) VALUES ('+201000000001', 'Test Patient', 'x') RETURNING id")).rows[0].id;
    await oneShot(db.url,
      `INSERT INTO appointments (patient_id, department_id, appointment_date, slot_number, starts_at, ends_at, created_via)
       VALUES ($1, $2, '2027-02-01', 1, '2027-02-01T14:00:00Z', '2027-02-01T16:00:00Z', 'web')`, [patient, doomedBusy.id]);

    await expect(migrate(db.url)).rejects.toThrow(/Cannot delete departments that still have appointments: general-dentistry \(1 appointments\)/);

    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM departments')).rows[0].n)).toBe(3);
    expect(Number((await oneShot(db.url, 'SELECT count(*) AS n FROM departments WHERE id = ANY($1::uuid[])', [[keep.id, doomedFree.id, doomedBusy.id]])).rows[0].n)).toBe(3);
    expect(await count(db.url, 'appointments')).toBe(1);
    expect(await count(db.url, 'services')).toBe(3);
    expect((await oneShot(db.url, "SELECT count(*)::int AS n FROM information_schema.columns WHERE table_name = 'departments' AND column_name = 'working_days'")).rows[0].n).toBe(0); // the column was rolled back too
    expect((await oneShot(db.url, "SELECT count(*)::int AS n FROM schema_migrations WHERE version LIKE '0003%'")).rows[0].n).toBe(0);
    expect(await count(db.url, 'audit_events')).toBe(0);

    // once the appointment is dealt with deliberately, the migration goes through
    await oneShot(db.url, 'DELETE FROM appointments');
    expect((await migrate(db.url)).applied).toEqual(['0003_department_working_days_and_seven_departments.sql']);
    expect((await oneShot(db.url, 'SELECT slug FROM departments')).rows.map((r) => r.slug)).toEqual(['endodontics']);
  });

  it('the column rejects an empty list, a weekday outside 1-7, and the default is all seven days', async () => {
    const db = await emptyDatabase(); dbs.push(db);
    await migrate(db.url);
    const id = (await oneShot(db.url, "INSERT INTO departments (slug) VALUES ('endodontics') RETURNING id")).rows[0].id;
    expect((await oneShot(db.url, 'SELECT working_days FROM departments WHERE id = $1', [id])).rows[0].working_days).toEqual([1, 2, 3, 4, 5, 6, 7]);
    for (const bad of ["'{}'", "'{0}'", "'{8}'", "'{1,9}'"]) {
      await expect(oneShot(db.url, `UPDATE departments SET working_days = ${bad}::smallint[] WHERE id = $1`, [id]), bad).rejects.toThrow(/departments_working_days_valid/);
    }
    await oneShot(db.url, "UPDATE departments SET working_days = '{1,3,5}' WHERE id = $1", [id]);
  });
});
