import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createTestEnv, dayOffset, departmentId, registerPatient, type TestEnv, type TestPatient } from '../helpers/harness.js';

let env: TestEnv;
let general: string;
let endo: string;
let patients: TestPatient[];

beforeAll(async () => {
  env = await createTestEnv({ SESSION_PATIENT_IDLE_MINUTES: '1000000', SESSION_PATIENT_TTL_HOURS: '100000' });
  general = await departmentId(env, 'restorative-dentistry');
  endo = await departmentId(env, 'endodontics');
  patients = [];
  for (let i = 0; i < 24; i++) patients.push(await registerPatient(env, { fullName: `Racer ${i}` }));
}, 120_000);
afterAll(async () => { await env.close(); });

const book = (p: TestPatient, departmentId: string, date: string, slotNumber: number) =>
  env.api.post('/api/v1/patient/appointments', { departmentId, date, slotNumber }, p.session);

const rows = async (departmentId: string, date: string) =>
  (await env.db.query("SELECT slot_number, status FROM appointments WHERE department_id = $1 AND appointment_date = $2 ORDER BY slot_number", [departmentId, date])).rows as { slot_number: number; status: string }[];

const tally = (rs: { status: number; body: any }[]) => ({
  created: rs.filter((r) => r.status === 201).length,
  conflicts: rs.filter((r) => r.status === 409).length,
  codes: [...new Set(rs.filter((r) => r.status !== 201).map((r) => r.body.error?.code))],
  other: rs.filter((r) => r.status !== 201 && r.status !== 409).map((r) => `${r.status} ${JSON.stringify(r.body)}`),
});

describe('concurrent booking protection', () => {
  it('CONC-01 24 simultaneous requests for the same slot: exactly one wins, 23 get SLOT_UNAVAILABLE, one row exists', async () => {
    const date = dayOffset(3);
    const results = await Promise.all(patients.map((p) => book(p, general, date, 2)));
    const t = tally(results);
    expect(t.other).toEqual([]);
    expect(t.created).toBe(1);
    expect(t.conflicts).toBe(23);
    expect(t.codes).toEqual(['SLOT_UNAVAILABLE']);
    expect(await rows(general, date)).toEqual([{ slot_number: 2, status: 'booked' }]);
  });

  it('CONC-02 24 simultaneous requests spread across the four slots of one department-day: exactly four succeed, never more', async () => {
    const date = dayOffset(4);
    const results = await Promise.all(patients.map((p, i) => book(p, general, date, (i % 4) + 1)));
    const t = tally(results);
    expect(t.other).toEqual([]);
    expect(t.created).toBe(4);
    expect(t.conflicts).toBe(20);
    const stored = await rows(general, date);
    expect(stored.map((r) => r.slot_number)).toEqual([1, 2, 3, 4]); // four distinct slots, no duplicates
    expect(stored.every((r) => r.status === 'booked')).toBe(true);
  });

  it('CONC-02b the last free slot of a nearly full day goes to exactly one of many competitors', async () => {
    const date = dayOffset(5);
    for (let slot = 1; slot <= 3; slot++) expect((await book(patients[slot]!, general, date, slot)).status).toBe(201);
    const contenders = patients.slice(4, 24); // 20 competitors; every one of them tries slot 4
    const t = tally(await Promise.all(contenders.map((p) => book(p, general, date, 4))));
    expect(t.other).toEqual([]);
    expect(t.created).toBe(1);
    const stored = await rows(general, date);
    expect(stored.length).toBe(4);
    expect(new Set(stored.map((r) => r.slot_number)).size).toBe(4);
  });

  it('CONC-02c two departments competing at the same time never affect each other\'s capacity', async () => {
    const date = dayOffset(6);
    const results = await Promise.all(patients.slice(0, 16).map((p, i) => book(p, i % 2 === 0 ? general : endo, date, ((i >> 1) % 4) + 1)));
    const t = tally(results);
    expect(t.other).toEqual([]);
    expect(t.created).toBe(8); // 4 per department
    expect((await rows(general, date)).length).toBe(4);
    expect((await rows(endo, date)).length).toBe(4);
  });

  it('CONC-03 concurrent cancel + booking of the same slot ends in a consistent state, repeated on 8 fresh slots', async () => {
    for (let round = 0; round < 8; round++) {
      const date = dayOffset(10 + round);
      const owner = patients[round]!;
      const first = await book(owner, endo, date, 1);
      expect(first.status).toBe(201);
      const challengers = patients.slice(8, 12);
      const [cancel, ...bookings] = await Promise.all([
        env.api.post(`/api/v1/patient/appointments/${first.body.data.id}/cancel`, {}, owner.session),
        ...challengers.map((c) => book(c, endo, date, 1)),
      ]);
      expect(cancel.status, JSON.stringify(cancel.body)).toBe(200); // a cancel always succeeds
      const t = tally(bookings);
      expect(t.other).toEqual([]);
      expect(t.created).toBeLessThanOrEqual(1);
      const stored = await rows(endo, date);
      const active = stored.filter((r) => r.status === 'booked');
      expect(active.length).toBe(t.created); // exactly the successful booking is active
      expect(stored.filter((r) => r.status === 'cancelled').length).toBe(1);
    }
  });

  it('CONC-04 two patients rescheduling into the same free slot: exactly one succeeds and the other keeps their old slot', async () => {
    const date = dayOffset(25);
    const a = await book(patients[0]!, general, date, 1);
    const b = await book(patients[1]!, general, date, 2);
    const [ra, rb] = await Promise.all([
      env.api.post(`/api/v1/patient/appointments/${a.body.data.id}/reschedule`, { date, slotNumber: 4 }, patients[0]!.session),
      env.api.post(`/api/v1/patient/appointments/${b.body.data.id}/reschedule`, { date, slotNumber: 4 }, patients[1]!.session),
    ]);
    expect([ra.status, rb.status].sort()).toEqual([200, 409]);
    const stored = await rows(general, date);
    expect(stored.length).toBe(2);
    expect(new Set(stored.map((r) => r.slot_number)).size).toBe(2);
    expect(stored.filter((r) => r.slot_number === 4).length).toBe(1);
  });

  it('CONC-05 one patient booking two departments at the same time slot concurrently: exactly one succeeds (PATIENT_OVERLAP)', async () => {
    const date = dayOffset(26);
    const p = patients[2]!;
    const depts = [general, endo, await departmentId(env, 'orthodontics'), await departmentId(env, 'periodontics')];
    const results = await Promise.all(depts.map((d) => book(p, d, date, 3)));
    const t = tally(results);
    expect(t.other).toEqual([]);
    expect(t.created).toBe(1);
    expect(t.codes).toEqual(['PATIENT_OVERLAP']);
    const n = await env.db.query("SELECT count(*)::int AS n FROM appointments WHERE patient_id = $1 AND appointment_date = $2 AND status = 'booked'", [p.id, date]);
    expect(n.rows[0].n).toBe(1);
  });

  it('CONC-06 sustained load: 24 patients x 4 slots x 3 days hammering simultaneously never breaks the invariants', async () => {
    const dates = [dayOffset(40), dayOffset(41), dayOffset(42)];
    const jobs: Promise<any>[] = [];
    for (const date of dates) for (const slot of [1, 2, 3, 4]) for (const p of patients.slice(0, 6)) jobs.push(book(p, general, date, slot));
    const results = await Promise.all(jobs);
    expect(tally(results).other).toEqual([]);
    for (const date of dates) {
      const stored = await rows(general, date);
      expect(stored.length).toBeLessThanOrEqual(4);
      expect(new Set(stored.map((r) => r.slot_number)).size).toBe(stored.length);
    }
    // system-wide invariant straight from SQL
    const bad = await env.db.query(`SELECT department_id, appointment_date, count(*) FROM appointments
      WHERE status IN ('booked','completed','no_show') GROUP BY 1,2 HAVING count(*) > 4`);
    expect(bad.rowCount).toBe(0);
    const dupes = await env.db.query(`SELECT 1 FROM appointments WHERE status IN ('booked','completed','no_show') GROUP BY department_id, appointment_date, slot_number HAVING count(*) > 1`);
    expect(dupes.rowCount).toBe(0);
  });
});
